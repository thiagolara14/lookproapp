# Comandos Supabase para Desenvolvimento Local

Como não posso modificar o package.json diretamente, aqui estão os comandos que você pode usar:

## Comandos Básicos

```bash
# Instalar dependências (já feito)
npm install

# Iniciar serviços Supabase localmente
npx supabase start

# Parar serviços Supabase
npx supabase stop

# Ver status dos serviços
npx supabase status

# Resetar banco de dados local
npx supabase db reset

# Executar aplicação em desenvolvimento
npm run dev
```

## Fluxo Completo para Primeiro Setup

1. **Certifique-se que o Docker está rodando**
2. **Execute:** `npx supabase start`
3. **Copie as credenciais mostradas no terminal**
4. **Crie arquivo .env.local com:**
   ```
   VITE_SUPABASE_URL=http://127.0.0.1:54321
   VITE_SUPABASE_ANON_KEY=sua_chave_local_aqui
   ```
5. **Execute:** `npm run dev`

## Notas Importantes

- O projeto já está configurado para funcionar em produção sem variáveis de ambiente
- As variáveis locais são opcionais - se não configuradas, usa a instância de produção
- O Supabase CLI foi adicionado às dependências do projeto
- Docker é obrigatório apenas para desenvolvimento local

O projeto agora suporta tanto desenvolvimento local quanto produção de forma transparente!