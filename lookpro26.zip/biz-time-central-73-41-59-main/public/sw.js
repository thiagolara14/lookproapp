// Service Worker para PWA e Push Notifications

const CACHE_NAME = 'lookpro-v2.1';
const urlsToCache = [
  '/',
  '/manifest.json',
  '/icon-192.png',
  '/icon-512.png',
  '/favicon-32x32.png'
];

// Instalação do Service Worker
self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then((cache) => cache.addAll(urlsToCache))
      .then(() => self.skipWaiting())
  );
});

// Ativação do Service Worker
self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((cacheNames) => {
      return Promise.all(
        cacheNames.map((cacheName) => {
          if (cacheName !== CACHE_NAME) {
            return caches.delete(cacheName);
          }
        })
      );
    }).then(() => self.clients.claim())
  );
});

// Estratégia de cache: Network First com fallback
self.addEventListener('fetch', (event) => {
  // Skip cross-origin requests and non-GET requests
  if (!event.request.url.startsWith(self.location.origin) || event.request.method !== 'GET') {
    return;
  }

  event.respondWith(
    fetch(event.request)
      .then((response) => {
        // Se a resposta é válida, clona e cacheia
        if (response && response.status === 200 && response.type === 'basic') {
          const responseClone = response.clone();
          caches.open(CACHE_NAME)
            .then((cache) => cache.put(event.request, responseClone))
            .catch(console.warn);
        }
        return response;
      })
      .catch(() => {
        // Se falha na rede, tenta o cache
        return caches.match(event.request)
          .then((response) => {
            if (response) {
              return response;
            }
            // Para navegação, retorna a página principal
            if (event.request.mode === 'navigate') {
              return caches.match('/');
            }
            throw new Error('No cache match found');
          });
      })
  );
});

// ========== PUSH NOTIFICATIONS ==========

// Receber push notifications
self.addEventListener('push', (event) => {
  console.log('Push event received:', event);
  
  let data = {};
  try { 
    data = event.data ? event.data.json() : {}; 
  } catch (error) {
    console.error('Error parsing push data:', error);
  }
  
  const title = data.title || 'LookPro';
  const body = data.body || 'Nova notificação';
  const icon = data.icon || '/icon-192.png';
  const badge = data.badge || '/icon-192.png';
  const url = data.url || '/';

  const options = {
    body,
    icon,
    badge,
    data: { url, ...data },
    requireInteraction: false,
    vibrate: [80, 40, 80],
    actions: data.actions || [],
    tag: data.tag || 'lookpro-notification'
  };

  event.waitUntil(
    self.registration.showNotification(title, options)
  );
});

// Clique na notificação
self.addEventListener('notificationclick', (event) => {
  console.log('Notification click:', event);
  
  event.notification.close();
  
  const url = event.notification?.data?.url || '/';
  
  event.waitUntil(
    clients.matchAll({ type: 'window', includeUncontrolled: true })
      .then((clientList) => {
        // Procura uma janela já aberta
        for (const client of clientList) {
          if (client.url === url && 'focus' in client) {
            return client.focus();
          }
        }
        
        // Se não encontrou, abre nova janela
        if (clients.openWindow) {
          return clients.openWindow(url);
        }
      })
  );
});

// Fechar notificação
self.addEventListener('notificationclose', (event) => {
  console.log('Notification closed:', event.notification.tag);
});