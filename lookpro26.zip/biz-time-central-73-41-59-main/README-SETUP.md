# Setup do Projeto LOOK PRO

Este guia explica como configurar o projeto para rodar tanto localmente (com Docker) quanto em produção.

## Pré-requisitos

1. **Node.js** (versão 18 ou superior)
2. **Docker** instalado e em execução
3. **Git** para controle de versão

## Configuração para Desenvolvimento Local

### 1. Instalar Dependências
```bash
npm install
```

### 2. Inicializar Supabase Local
```bash
# Inicia os serviços do Supabase localmente
npm run supabase:start
```

Este comando irá:
- Baixar e configurar os containers Docker necessários
- Criar um banco de dados PostgreSQL local
- Configurar Auth, Storage e outros serviços
- Mostrar as URLs e chaves locais

### 3. Configurar Variáveis de Ambiente (Opcional)

Crie um arquivo `.env.local` na raiz do projeto:

```bash
# Copie as informações fornecidas pelo comando anterior
VITE_SUPABASE_URL=http://127.0.0.1:54321
VITE_SUPABASE_ANON_KEY=sua_chave_local_aqui
```

**Nota:** Se você não configurar essas variáveis, o projeto usará automaticamente a instância de produção.

### 4. Executar o Projeto
```bash
npm run dev
```

## Scripts Disponíveis

- `npm run supabase:start` - Inicia serviços Supabase localmente
- `npm run supabase:stop` - Para os serviços Supabase
- `npm run supabase:reset` - Reseta o banco de dados local
- `npm run supabase:status` - Mostra status dos serviços
- `npm run supabase:db:reset` - Reseta apenas o banco de dados

## Configuração para Produção

O projeto já está configurado para produção com as credenciais do Supabase na nuvem. Não é necessária configuração adicional.

## Estrutura de Banco de Dados

O projeto utiliza as seguintes tabelas principais:
- `profiles` - Perfis de usuários
- `establishments` - Estabelecimentos/negócios
- `services` - Serviços oferecidos
- `professionals` - Profissionais
- `appointments` - Agendamentos
- `reviews` - Avaliações
- E outras tabelas de suporte

## Troubleshooting

### Docker não está rodando
Certifique-se de que o Docker Desktop está instalado e em execução.

### Porta já em uso
Se a porta 54321 estiver em uso, o Supabase CLI irá automaticamente usar outra porta disponível.

### Erro de permissões
No Linux/Mac, você pode precisar executar os comandos com `sudo` ou ajustar as permissões do Docker.

## Links Úteis

- [Documentação Supabase](https://supabase.com/docs)
- [Supabase CLI](https://supabase.com/docs/reference/cli)
- [Docker Desktop](https://www.docker.com/products/docker-desktop)