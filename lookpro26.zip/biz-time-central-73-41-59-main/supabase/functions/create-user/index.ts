
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.55.0'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

Deno.serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    console.log('Function started - checking auth header')
    
    // Create Supabase client with service role key for admin operations
    const supabaseAdmin = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '',
      {
        auth: {
          autoRefreshToken: false,
          persistSession: false
        }
      }
    )

    // Get the Authorization header
    const authHeader = req.headers.get('Authorization')
    if (!authHeader) {
      console.error('Missing authorization header')
      return new Response(
        JSON.stringify({ error: 'Missing authorization header' }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      )
    }

    console.log('Auth header found, getting user')
    
    // Set the session from the auth header  
    const token = authHeader.replace('Bearer ', '')
    
    // Use admin client to get user
    const { data: { user }, error: userError } = await supabaseAdmin.auth.getUser(token)
    
    if (userError || !user) {
      console.error('Auth error:', userError)
      return new Response(
        JSON.stringify({ error: 'Invalid authorization token' }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      )
    }

    console.log('User authenticated:', user.id)

    // Check if user is super admin using admin client
    const { data: profile, error: profileError } = await supabaseAdmin
      .from('profiles')
      .select('role')
      .eq('user_id', user.id)
      .maybeSingle()

    console.log('Profile query result:', { profile, profileError })

    if (profileError || profile?.role !== 'super_admin') {
      console.error('Permission denied - role:', profile?.role)
      return new Response(
        JSON.stringify({ error: 'Access denied. Only super admins can create users.' }),
        { status: 403, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      )
    }

    console.log('Permission check passed, parsing request body')

    // Parse request body
    const { email, password, full_name, role, establishment_id } = await req.json()

    console.log('Request data:', { email, role, establishment_id })

    if (!email || !password || !full_name || !role) {
      console.error('Missing required fields')
      return new Response(
        JSON.stringify({ error: 'Missing required fields: email, password, full_name, role' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      )
    }

    // Validar establishment_id obrigatório para admin e professional
    if ((role === 'admin' || role === 'professional') && !establishment_id) {
      console.error('Missing establishment_id for role:', role)
      return new Response(
        JSON.stringify({ error: 'establishment_id é obrigatório para admins e profissionais' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      )
    }

    // Verificar se o estabelecimento existe
    if (establishment_id) {
      const { data: establishment, error: estError } = await supabaseAdmin
        .from('establishments')
        .select('id, name')
        .eq('id', establishment_id)
        .maybeSingle()

      if (estError) {
        console.error('Error checking establishment:', estError)
        return new Response(
          JSON.stringify({ error: 'Erro ao verificar estabelecimento' }),
          { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        )
      }

      if (!establishment) {
        console.error('Establishment not found:', establishment_id)
        return new Response(
          JSON.stringify({ error: 'Estabelecimento não encontrado' }),
          { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        )
      }

      console.log('Establishment found:', establishment.name)
    }

    console.log(`Creating user: ${email} with role: ${role}`)

    // Check if user already exists by email
    const { data: existingUser, error: existingUserError } = await supabaseAdmin.auth.admin.listUsers()
    
    if (existingUserError) {
      console.error('Error checking existing users:', existingUserError)
      return new Response(
        JSON.stringify({ error: 'Error checking existing users' }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      )
    }

    const userExists = existingUser.users.find(u => u.email === email)
    if (userExists) {
      console.log('User exists in auth.users, checking if has profile')
      
      // Check if user has profile - if not, this is an orphaned auth user
      const { data: existingProfile } = await supabaseAdmin
        .from('profiles')
        .select('id')
        .eq('user_id', userExists.id)
        .maybeSingle()
      
      if (!existingProfile) {
        console.log('User exists in auth but has no profile - deleting orphaned auth user')
        // Delete orphaned auth user and proceed with creation
        await supabaseAdmin.auth.admin.deleteUser(userExists.id)
        console.log('Orphaned auth user deleted, proceeding with new user creation')
      } else {
        console.error('User already exists with profile:', email)
        return new Response(
          JSON.stringify({ error: 'User with this email already exists' }),
          { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        )
      }
    }

    // Create user in auth.users using admin client
    const { data: newUser, error: createError } = await supabaseAdmin.auth.admin.createUser({
      email,
      password,
      email_confirm: true, // Auto-confirm email
      user_metadata: {
        full_name,
        role,
        establishment_id
      }
    })

    if (createError) {
      console.error('User creation error:', createError)
      return new Response(
        JSON.stringify({ error: `Failed to create user: ${createError.message}` }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      )
    }

    if (!newUser.user) {
      return new Response(
        JSON.stringify({ error: 'User creation failed - no user returned' }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      )
    }

    console.log(`User created with ID: ${newUser.user.id}`)

    // Check if profile already exists (in case of race condition)
    const { data: existingProfile } = await supabaseAdmin
      .from('profiles')
      .select('id')
      .eq('user_id', newUser.user.id)
      .maybeSingle()

    if (existingProfile) {
      console.log('Profile already exists, skipping creation')
    } else {
      // Create profile record
      const { error: profileInsertError } = await supabaseAdmin
        .from('profiles')
        .insert({
          user_id: newUser.user.id,
          email,
          full_name,
          role,
          establishment_id: establishment_id || null
        })

      if (profileInsertError) {
        console.error('Profile creation error:', profileInsertError)
        // Try to clean up the auth user if profile creation fails
        await supabaseAdmin.auth.admin.deleteUser(newUser.user.id)
        return new Response(
          JSON.stringify({ error: `Failed to create profile: ${profileInsertError.message}` }),
          { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        )
      }
    }

    // If role is 'professional', create professional record
    if (role === 'professional' && establishment_id) {
      const { error: professionalError } = await supabaseAdmin
        .from('professionals')
        .insert({
          user_id: newUser.user.id,
          establishment_id,
          active: true
        })

      if (professionalError) {
        console.error('Professional record creation error:', professionalError)
        // Don't fail the entire operation for this
      }
    }

    console.log(`Successfully created user ${email} with role ${role}`)

    return new Response(
      JSON.stringify({
        success: true,
        user: {
          id: newUser.user.id,
          email: newUser.user.email,
          role,
          establishment_id
        },
        message: 'User created successfully'
      }),
      { 
        status: 200, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      }
    )

  } catch (error) {
    console.error('Unexpected error:', error)
    return new Response(
      JSON.stringify({ error: 'Internal server error' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )
  }
})
