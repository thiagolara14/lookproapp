import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.56.0";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface LeadStatusResponse {
  success: boolean;
  lead_id: string;
  status: 'novo' | 'em_provisionamento' | 'entregue' | 'erro';
  tenant_data?: {
    url_publica: string;
    url_admin: string;
    login: string;
  };
  message?: string;
}

const supabase = createClient(
  Deno.env.get('SUPABASE_URL') ?? '',
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
);

serve(async (req: Request) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    if (req.method !== 'GET') {
      return new Response('Method not allowed', { 
        status: 405, 
        headers: corsHeaders 
      });
    }

    const url = new URL(req.url);
    const leadId = url.searchParams.get('lead_id');

    if (!leadId) {
      return new Response(JSON.stringify({
        success: false,
        lead_id: '',
        status: 'erro',
        message: 'lead_id é obrigatório'
      }), {
        status: 400,
        headers: { 'Content-Type': 'application/json', ...corsHeaders }
      });
    }

    // Get lead status
    const { data: lead, error: leadError } = await supabase
      .from('onboarding.leads')
      .select('id, status')
      .eq('id', leadId)
      .single();

    if (leadError || !lead) {
      return new Response(JSON.stringify({
        success: false,
        lead_id: leadId,
        status: 'erro',
        message: 'Lead não encontrado'
      }), {
        status: 404,
        headers: { 'Content-Type': 'application/json', ...corsHeaders }
      });
    }

    let tenantData = undefined;

    // If lead is delivered, get tenant information
    if (lead.status === 'entregue') {
      const { data: tenant, error: tenantError } = await supabase
        .from('tenants')
        .select('url_publica, url_admin')
        .eq('lead_id', leadId)
        .single();

      if (!tenantError && tenant) {
        const { data: user, error: userError } = await supabase
          .from('tenant_users')
          .select('login')
          .eq('tenant_id', (await supabase
            .from('tenants')
            .select('id')
            .eq('lead_id', leadId)
            .single()
          ).data?.id)
          .single();

        if (!userError && user) {
          tenantData = {
            url_publica: tenant.url_publica,
            url_admin: tenant.url_admin,
            login: user.login
          };
        }
      }
    }

    const response: LeadStatusResponse = {
      success: true,
      lead_id: leadId,
      status: lead.status as 'novo' | 'em_provisionamento' | 'entregue' | 'erro',
      tenant_data: tenantData,
      message: getStatusMessage(lead.status)
    };

    return new Response(JSON.stringify(response), {
      status: 200,
      headers: { 'Content-Type': 'application/json', ...corsHeaders }
    });

  } catch (error) {
    console.error('Handler error:', error);
    return new Response(JSON.stringify({
      success: false,
      lead_id: '',
      status: 'erro',
      message: 'Erro interno do servidor'
    }), {
      status: 500,
      headers: { 'Content-Type': 'application/json', ...corsHeaders }
    });
  }
});

function getStatusMessage(status: string): string {
  switch (status) {
    case 'novo':
      return 'Lead recebido, aguardando processamento';
    case 'em_provisionamento':
      return 'Criando seu app, aguarde alguns minutos...';
    case 'entregue':
      return 'Seu app está pronto! Verifique seu WhatsApp para os links de acesso.';
    case 'erro':
      return 'Ocorreu um erro no processamento. Entre em contato conosco.';
    default:
      return 'Status desconhecido';
  }
}