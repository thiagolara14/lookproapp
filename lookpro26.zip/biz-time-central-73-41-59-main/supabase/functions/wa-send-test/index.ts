import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

serve(async (req: Request) => {
  // Handle CORS preflight requests
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    if (req.method !== "POST") {
      return new Response("Method Not Allowed", { status: 405, headers: corsHeaders });
    }

    const { to, text = "Hello World from LookPro!" } = await req.json();

    if (!to) {
      return new Response(
        JSON.stringify({ error: "Campo 'to' é obrigatório" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Validar formato E.164
    const e164Regex = /^\+?\d{10,15}$/;
    if (!e164Regex.test(to.replace(/\D/g, ""))) {
      return new Response(
        JSON.stringify({ error: "Número deve estar no formato E.164 (10-15 dígitos)" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Obter secrets do server
    const phoneNumberId = Deno.env.get("WHATS_CLOUD_PHONE_NUMBER_ID");
    const accessToken = Deno.env.get("WHATS_CLOUD_ACCESS_TOKEN");

    if (!phoneNumberId || !accessToken) {
      console.error("Missing WhatsApp Cloud API credentials");
      return new Response(
        JSON.stringify({ error: "Credenciais do WhatsApp Cloud API não configuradas" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Formatar número para E.164
    const formattedTo = to.startsWith("+") ? to : `+${to.replace(/\D/g, "")}`;

    // Preparar payload para Meta API
    const payload = {
      messaging_product: "whatsapp",
      to: formattedTo,
      type: "text",
      text: {
        body: text
      }
    };

    console.log("Sending WhatsApp message:", { to: formattedTo, text });

    // Chamar WhatsApp Cloud API
    const response = await fetch(`https://graph.facebook.com/v20.0/${phoneNumberId}/messages`, {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${accessToken}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify(payload)
    });

    const result = await response.json();

    if (!response.ok) {
      console.error("WhatsApp API error:", result);
      return new Response(
        JSON.stringify({ 
          error: "Erro ao enviar mensagem", 
          details: result.error?.message || result 
        }),
        { status: response.status, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    console.log("WhatsApp message sent successfully:", result);

    return new Response(
      JSON.stringify({ 
        success: true, 
        messageId: result.messages?.[0]?.id,
        result 
      }),
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );

  } catch (error) {
    console.error("Error in wa-send-test:", error);
    return new Response(
      JSON.stringify({ error: "Erro interno do servidor" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});