import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const supabaseUrl = Deno.env.get("SUPABASE_URL");
const supabaseServiceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
const verifyToken = Deno.env.get("WHATS_CLOUD_VERIFY_TOKEN");

if (!supabaseUrl || !supabaseServiceRoleKey) {
  console.error("Missing SUPABASE_URL or SUPABASE_SERVICE_ROLE_KEY env vars");
}

const supabase = createClient(supabaseUrl!, supabaseServiceRoleKey!);

serve(async (req: Request) => {
  // CORS preflight
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    if (req.method === "GET") {
      const url = new URL(req.url);
      const mode = url.searchParams.get("hub.mode");
      const token = url.searchParams.get("hub.verify_token");
      const challenge = url.searchParams.get("hub.challenge");

      console.log("GET verification:", { mode, hasToken: !!token, hasChallenge: !!challenge });

      if (mode === "subscribe" && token && challenge && token === verifyToken) {
        return new Response(challenge, {
          status: 200,
          headers: { ...corsHeaders, "Content-Type": "text/plain" },
        });
      }

      return new Response("Forbidden", { status: 403, headers: corsHeaders });
    }

    if (req.method === "POST") {
      let body: unknown = null;
      try {
        body = await req.json();
      } catch (e) {
        console.error("Failed to parse JSON body", e);
        body = { parse_error: true };
      }

      console.log("WhatsApp webhook payload:", JSON.stringify(body));

      // Insert into onboarding.messages_log
      const { error } = await supabase
        .from("onboarding.messages_log")
        .insert({ body });

      if (error) {
        console.error("DB insert error:", error);
      } else {
        console.log("Payload stored in onboarding.messages_log");
      }

      return new Response("ok", { status: 200, headers: corsHeaders });
    }

    return new Response("Method Not Allowed", { status: 405, headers: corsHeaders });
  } catch (e) {
    console.error("Unhandled error in whats-webhook:", e);
    // Always return 200 ok for POST per spec, 500 for GET errors
    if (req.method === "POST") {
      return new Response("ok", { status: 200, headers: corsHeaders });
    }
    return new Response("Internal Error", { status: 500, headers: corsHeaders });
  }
});
