#!/bin/bash

# Script de testes do webhook WhatsApp Cloud API

echo "=== Teste GET (verificação) ==="
echo "Testando verificação do webhook..."

curl -G "https://fdxmegjbmglkbpylfeso.supabase.co/functions/v1/whats-webhook" \
  --data-urlencode "hub.mode=subscribe" \
  --data-urlencode "hub.verify_token=$WHATS_CLOUD_VERIFY_TOKEN" \
  --data-urlencode "hub.challenge=123"

echo -e "\nEsperado: deve imprimir '123'\n"

echo "=== Teste POST (evento simulado) ==="
echo "Testando recebimento de mensagem..."

curl -X POST "https://fdxmegjbmglkbpylfeso.supabase.co/functions/v1/whats-webhook" \
  -H "Content-Type: application/json" \
  -d '{"object":"whatsapp_business_account","entry":[{"id":"4948938748664002","changes":[{"field":"messages","value":{"messages":[{"from":"5511999999999","id":"wamid.TESTE","type":"text","text":{"body":"ping"}}]}}]}]}'

echo -e "\nEsperado: deve gravar na tabela onboarding.messages_log"
echo "Verifique no Supabase Dashboard ou na página /debug/whatsapp"