import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

interface IntakeMetaRequest {
  lead_id: string;
  raw_city?: string;
  phone_e164?: string;
  form_version?: string;
}

Deno.serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    // Create Supabase client with service role
    const supabaseAdmin = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '',
      {
        auth: {
          autoRefreshToken: false,
          persistSession: false
        }
      }
    );

    const body: IntakeMetaRequest = await req.json();
    
    // Validate required fields
    if (!body.lead_id) {
      return new Response(
        JSON.stringify({ error: 'lead_id is required' }),
        { 
          status: 400,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        }
      );
    }

    console.log('Storing intake metadata for lead:', body.lead_id);

    // For now, just log the metadata since we're keeping things simple
    // In the future, this could store in a dedicated table
    console.log('Metadata:', {
      lead_id: body.lead_id,
      raw_city: body.raw_city,
      phone_e164: body.phone_e164,
      form_version: body.form_version || 'v1.0',
      processed_at: new Date().toISOString()
    });

    // Update the lead with additional metadata if needed
    if (body.raw_city || body.phone_e164) {
      const updateData: any = {};
      
      if (body.raw_city) {
        updateData.cidade = body.raw_city; // Update city field
      }
      
      if (body.phone_e164) {
        updateData.whatsapp = body.phone_e164; // Ensure phone is in correct format
      }

      const { error: updateError } = await supabaseAdmin
        .from('leads')
        .update(updateData)
        .eq('id', body.lead_id);

      if (updateError) {
        console.error('Error updating lead metadata:', updateError);
        // Don't fail the request, just log the error
      }
    }

    return new Response(
      JSON.stringify({ 
        success: true,
        message: 'Metadata processed successfully',
        lead_id: body.lead_id
      }),
      { 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      }
    );

  } catch (error) {
    console.error('Error in onboarding-intake-meta:', error);
    
    return new Response(
      JSON.stringify({ 
        error: 'Internal server error',
        message: error instanceof Error ? error.message : 'Unknown error'
      }),
      { 
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      }
    );
  }
});
