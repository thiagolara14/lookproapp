import { serve } from "https://deno.land/std@0.190.0/http/server.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface MessageRequest {
  type: 'imediato' | '3h' | 'd1';
  to: string;
  vars: {
    NOME_RESP: string;
    URL_PUBLICA: string;
    URL_ADMIN: string;
    LOGIN: string;
    SENHA?: string;
  };
}

function getTemplate(type: string, vars: MessageRequest['vars']): string {
  switch (type) {
    case 'imediato':
      return `✅ ${vars.NOME_RESP}, seu app LookPro está no ar!
🔗 Link para seus clientes: ${vars.URL_PUBLICA}
🛠️ Painel do Admin: ${vars.URL_ADMIN}
👤 Login: ${vars.LOGIN}
${vars.SENHA ? `🔒 Senha temporária: ${vars.SENHA}` : ''}

Dica: compartilhe o link agora com seus clientes. Se quiser, eu configuro sua logo, fotos e preços por você. Responda SIM e deixo tudo prontinho hoje.`;

    case '3h':
      return `Oi, ${vars.NOME_RESP}! Vi que ainda não entrou no painel. Posso ajustar tudo pra você (logo, serviços e valores) e entregar pronto hoje. Quer?

🛠️ Painel: ${vars.URL_ADMIN}
👤 Login: ${vars.LOGIN}`;

    case 'd1':
      return `${vars.NOME_RESP}, seu link segue ativo 👉 ${vars.URL_PUBLICA}

Posso transformar em ícone no celular e configurar tudo por você, sem custo no teste. Responda ATIVAR COMPLETO.

🛠️ Painel: ${vars.URL_ADMIN}`;

    default:
      return `Mensagem para ${vars.NOME_RESP}: ${vars.URL_PUBLICA}`;
  }
}

async function sendWhatsAppMessage(to: string, message: string): Promise<boolean> {
  try {
    const provider = Deno.env.get('WHATSAPP_PROVIDER');
    const apiUrl = Deno.env.get('WHATSAPP_API_URL');
    const apiKey = Deno.env.get('WHATSAPP_API_KEY');

    if (!provider || provider === 'none' || !apiUrl || !apiKey) {
      console.log('WhatsApp not configured, logging message:', { to, message });
      return true;
    }

    // Generic WhatsApp API call - adapt based on your provider
    const response = await fetch(apiUrl, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${apiKey}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        to: to,
        message: message,
        type: 'text'
      })
    });

    if (response.ok) {
      console.log(`WhatsApp message sent to ${to}`);
      return true;
    } else {
      console.error(`Failed to send WhatsApp message to ${to}:`, await response.text());
      return false;
    }
  } catch (error) {
    console.error(`Error sending WhatsApp message to ${to}:`, error);
    return false;
  }
}

async function sendEmail(to: string, subject: string, message: string): Promise<boolean> {
  try {
    const smtpHost = Deno.env.get('SMTP_HOST');
    const smtpPort = Deno.env.get('SMTP_PORT');
    const smtpUser = Deno.env.get('SMTP_USER');
    const smtpPass = Deno.env.get('SMTP_PASS');

    if (!smtpHost || !smtpUser || !smtpPass) {
      console.log('SMTP not configured, logging email:', { to, subject, message });
      return true;
    }

    // Simple email sending implementation
    // In production, use a proper email service like Resend
    console.log(`Email would be sent to ${to}: ${subject} - ${message}`);
    return true;
  } catch (error) {
    console.error(`Error sending email to ${to}:`, error);
    return false;
  }
}

serve(async (req: Request) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    if (req.method !== 'POST') {
      return new Response('Method not allowed', { 
        status: 405, 
        headers: corsHeaders 
      });
    }

    const body: MessageRequest = await req.json();

    if (!body.type || !body.to || !body.vars) {
      return new Response(JSON.stringify({
        success: false,
        message: 'Campos obrigatórios: type, to, vars'
      }), {
        status: 400,
        headers: { 'Content-Type': 'application/json', ...corsHeaders }
      });
    }

    const message = getTemplate(body.type, body.vars);
    const subject = `LookPro - ${body.type === 'imediato' ? 'Seu app está pronto!' : 'Lembrete do seu app'}`;

    // Try WhatsApp first, fallback to email
    const whatsappSent = await sendWhatsAppMessage(body.to, message);
    let emailSent = false;

    if (!whatsappSent) {
      // Extract email from vars if available, or skip email
      emailSent = await sendEmail(body.vars.LOGIN || body.to, subject, message);
    }

    return new Response(JSON.stringify({
      success: true,
      whatsapp_sent: whatsappSent,
      email_sent: emailSent,
      message: 'Mensagem processada'
    }), {
      status: 200,
      headers: { 'Content-Type': 'application/json', ...corsHeaders }
    });

  } catch (error) {
    console.error('Handler error:', error);
    return new Response(JSON.stringify({
      success: false,
      message: 'Erro interno do servidor'
    }), {
      status: 500,
      headers: { 'Content-Type': 'application/json', ...corsHeaders }
    });
  }
});