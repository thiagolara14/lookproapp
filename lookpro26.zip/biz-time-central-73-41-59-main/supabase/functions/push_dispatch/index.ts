import { serve } from "https://deno.land/std@0.224.0/http/server.ts";
import webpush from "npm:web-push@3.6.7";

// Secrets configurados no Supabase
const VAPID_PUBLIC = Deno.env.get("VAPID_PUBLIC_KEY")!;
const VAPID_PRIVATE = Deno.env.get("VAPID_PRIVATE_KEY")!;
const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SUPABASE_ANON = Deno.env.get("SUPABASE_ANON_KEY")!;

webpush.setVapidDetails("mailto:suporte@lookpro.com", VAPID_PUBLIC, VAPID_PRIVATE);

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  // Handle CORS
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const auth = req.headers.get("Authorization") || "";
    const isFromTrigger = auth.includes("service"); // identificar chamadas do trigger
    const payload = await req.json();

    const { type, establishment_id } = payload || {};
    if (!type || !establishment_id) {
      return response(400, { error: "type e establishment_id são obrigatórios" });
    }

    console.log(`Push dispatch: ${type} for establishment ${establishment_id}`);

    // Supabase client
    const { createClient } = await import("https://esm.sh/@supabase/supabase-js@2");
    const supabase = createClient(SUPABASE_URL, SUPABASE_ANON, { 
      global: { headers: { Authorization: auth } } 
    });

    // Se broadcast_admin, validar permissões
    if (type === "broadcast_admin" && !isFromTrigger) {
      const user = await supabase.auth.getUser();
      if (!user?.data?.user) {
        return response(401, { error: "unauthorized" });
      }

      const uid = user.data.user.id;
      console.log(`Validating admin permissions for user ${uid}`);
      
      // Verificar se usuário é admin do estabelecimento
      const { data: profile } = await supabase
        .from("profiles")
        .select("role, establishment_id")
        .eq("user_id", uid)
        .eq("establishment_id", establishment_id)
        .eq("role", "admin")
        .limit(1)
        .maybeSingle();
        
      if (!profile) {
        return response(403, { error: "forbidden - user is not admin of this establishment" });
      }
    }

    // Selecionar alvos baseado no tipo
    let targets: any[] = [];
    
    if (type === "broadcast_admin") {
      console.log("Selecting customers for broadcast");
      const { data, error } = await supabase
        .from("push_subscriptions")
        .select("endpoint, p256dh, auth")
        .eq("establishment_id", establishment_id)
        .not("customer_id", "is", null); // somente clientes
      
      if (error) {
        console.error("Error fetching customer subscriptions:", error);
        return response(500, { error: "Failed to fetch subscriptions" });
      }
      targets = data || [];
      
    } else if (type === "appointment_created") {
      const { professional_id } = payload;
      if (!professional_id) {
        return response(400, { error: "professional_id obrigatório para appointment_created" });
      }
      
      console.log(`Selecting professional ${professional_id} for appointment notification`);
      const { data, error } = await supabase
        .from("push_subscriptions")
        .select("endpoint, p256dh, auth")
        .eq("establishment_id", establishment_id)
        .eq("professional_id", professional_id);
      
      if (error) {
        console.error("Error fetching professional subscriptions:", error);
        return response(500, { error: "Failed to fetch subscriptions" });
      }
      targets = data || [];
      
    } else {
      return response(400, { error: "type inválido" });
    }

    console.log(`Found ${targets.length} push subscription targets`);

    if (targets.length === 0) {
      return response(200, { ok: true, sent: 0, message: "No subscriptions found" });
    }

    // Montar payload da notificação
    const notif = {
      title: payload.title || (type === "broadcast_admin" ? "Mensagem do Estabelecimento" : "Novo agendamento"),
      body: payload.body || "",
      url: payload.url || (type === "appointment_created" ? `/dashboard/pro/agenda` : `/`),
      icon: "/icon-192.png",
      badge: "/icon-192.png"
    };

    console.log("Sending notification:", notif);

    // Enviar notificações (ignorar falhas individuais)
    const sends = targets.map(async (target) => {
      try {
        await webpush.sendNotification({
          endpoint: target.endpoint,
          keys: { p256dh: target.p256dh, auth: target.auth }
        }, JSON.stringify(notif));
        return true;
      } catch (error) {
        console.error("Failed to send notification to endpoint:", target.endpoint, error);
        return false;
      }
    });

    const results = await Promise.all(sends);
    const successCount = results.filter(Boolean).length;

    console.log(`Successfully sent ${successCount} out of ${targets.length} notifications`);

    return response(200, { 
      ok: true, 
      sent: successCount, 
      total: targets.length,
      notification: notif
    });

  } catch (error) {
    console.error("Push dispatch error:", error);
    return response(500, { error: String(error?.message || error) });
  }
});

function response(status: number, data: any) {
  return new Response(JSON.stringify(data), { 
    status, 
    headers: { 
      ...corsHeaders,
      "content-type": "application/json" 
    } 
  });
}