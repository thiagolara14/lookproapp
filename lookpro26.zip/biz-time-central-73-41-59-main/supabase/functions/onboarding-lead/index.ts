import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.56.0";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface OnboardingRequest {
  estabelecimento: string;
  responsavel: string;
  whatsapp: string;
  cidade: string;
  tipo: string;
  servicos_principais: string[];
  foto_base64?: string;
}

const supabase = createClient(
  Deno.env.get('SUPABASE_URL') ?? '',
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
);

serve(async (req: Request) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    if (req.method !== 'POST') {
      return new Response('Method not allowed', { 
        status: 405, 
        headers: corsHeaders 
      });
    }

    const body: OnboardingRequest = await req.json();

    // Validate required fields
    const requiredFields = ['estabelecimento', 'responsavel', 'whatsapp', 'cidade', 'tipo'];
    for (const field of requiredFields) {
      if (!body[field as keyof OnboardingRequest]) {
        return new Response(JSON.stringify({
          success: false,
          message: `Campo obrigatório: ${field}`
        }), {
          status: 400,
          headers: { 'Content-Type': 'application/json', ...corsHeaders }
        });
      }
    }

    if (!body.servicos_principais || body.servicos_principais.length === 0) {
      return new Response(JSON.stringify({
        success: false,
        message: 'Pelo menos um serviço principal é obrigatório'
      }), {
        status: 400,
        headers: { 'Content-Type': 'application/json', ...corsHeaders }
      });
    }

    // Rate limiting (simple IP-based check)
    const clientIP = req.headers.get('x-forwarded-for') || 'unknown';
    console.log(`Lead submission from IP: ${clientIP}`);

    // Create lead
    const { data: lead, error: leadError } = await supabase
      .from('leads')
      .insert({
        estabelecimento: body.estabelecimento,
        responsavel: body.responsavel,
        whatsapp: body.whatsapp,
        cidade: body.cidade,
        tipo: body.tipo,
        servicos_json: body.servicos_principais,
        foto_url: body.foto_base64, // Store base64 for now
        status: 'novo'
      })
      .select()
      .single();

    if (leadError) {
      console.error('Lead creation error:', leadError);
      return new Response(JSON.stringify({
        success: false,
        message: 'Erro ao criar lead'
      }), {
        status: 500,
        headers: { 'Content-Type': 'application/json', ...corsHeaders }
      });
    }

    console.log(`Lead created successfully: ${lead.id} for ${body.estabelecimento}`);

    return new Response(JSON.stringify({
      success: true,
      lead_id: lead.id,
      status: 'created'
    }), {
      status: 201,
      headers: { 'Content-Type': 'application/json', ...corsHeaders }
    });

  } catch (error) {
    console.error('Handler error:', error);
    return new Response(JSON.stringify({
      success: false,
      message: 'Erro interno do servidor'
    }), {
      status: 500,
      headers: { 'Content-Type': 'application/json', ...corsHeaders }
    });
  }
});