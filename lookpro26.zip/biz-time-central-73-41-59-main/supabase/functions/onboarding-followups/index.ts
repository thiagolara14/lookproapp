import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.56.0";

const supabase = createClient(
  Deno.env.get('SUPABASE_URL') ?? '',
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
);

interface LeadForFollowup {
  id: string;
  responsavel: string;
  whatsapp: string;
  tenant_data?: {
    url_publica: string;
    url_admin: string;
    login: string;
  };
}

serve(async (req: Request) => {
  try {
    // Check if onboarding is enabled
    if (Deno.env.get('ONBOARDING_ENABLE') !== 'true') {
      console.log('Onboarding followups disabled by feature flag');
      return new Response('OK - Feature disabled', { status: 200 });
    }

    console.log('Running onboarding followups...');

    const now = new Date();
    const threeHoursAgo = new Date(now.getTime() - 3 * 60 * 60 * 1000);
    const oneDayAgo = new Date(now.getTime() - 24 * 60 * 60 * 1000);

    // Get leads that need 3h followup
    const leadsFor3h = await getLeadsForFollowup(threeHoursAgo, '3h');
    console.log(`Found ${leadsFor3h.length} leads for 3h followup`);

    // Get leads that need D+1 followup
    const leadsForD1 = await getLeadsForFollowup(oneDayAgo, 'd1');
    console.log(`Found ${leadsForD1.length} leads for D+1 followup`);

    // Process 3h followups
    for (const lead of leadsFor3h) {
      await sendFollowup(lead, '3h');
    }

    // Process D+1 followups
    for (const lead of leadsForD1) {
      await sendFollowup(lead, 'd1');
    }

    return new Response(JSON.stringify({
      success: true,
      processed: {
        '3h': leadsFor3h.length,
        'd1': leadsForD1.length
      }
    }), {
      status: 200,
      headers: { 'Content-Type': 'application/json' }
    });

  } catch (error) {
    console.error('Followup cron error:', error);
    return new Response(JSON.stringify({
      success: false,
      error: error.message
    }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' }
    });
  }
});

async function getLeadsForFollowup(
  cutoffTime: Date,
  followupType: '3h' | 'd1'
): Promise<LeadForFollowup[]> {
  
  const windowStart = new Date(cutoffTime.getTime() - 30 * 60 * 1000); // 30 min window
  const windowEnd = new Date(cutoffTime.getTime() + 30 * 60 * 1000);

  try {
    // Get leads that are 'entregue' and within the time window
    const { data: leads, error } = await supabase
      .from('onboarding.leads')
      .select('id, responsavel, whatsapp, updated_at')
      .eq('status', 'entregue')
      .gte('updated_at', windowStart.toISOString())
      .lte('updated_at', windowEnd.toISOString());

    if (error) {
      console.error('Error fetching leads:', error);
      return [];
    }

    if (!leads || leads.length === 0) {
      return [];
    }

    // Filter leads that haven't had first login
    const eligibleLeads: LeadForFollowup[] = [];

    for (const lead of leads) {
      // Check if user has logged in (first_login_at is set)
      const { data: tenant } = await supabase
        .from('tenants')
        .select('slug, url_publica, url_admin')
        .eq('lead_id', lead.id)
        .single();

      if (!tenant) continue;

      const { data: user } = await supabase
        .from('tenant_users')
        .select('first_login_at')
        .eq('tenant_id', tenant.slug) // Assuming slug is used as tenant_id
        .single();

      // Only send followup if user hasn't logged in yet
      if (!user?.first_login_at) {
        eligibleLeads.push({
          id: lead.id,
          responsavel: lead.responsavel,
          whatsapp: lead.whatsapp,
          tenant_data: {
            url_publica: tenant.url_publica,
            url_admin: tenant.url_admin,
            login: `${tenant.slug}@lookpro.app`
          }
        });
      }
    }

    return eligibleLeads;
    
  } catch (error) {
    console.error('Error in getLeadsForFollowup:', error);
    return [];
  }
}

async function sendFollowup(lead: LeadForFollowup, type: '3h' | 'd1'): Promise<void> {
  try {
    // Call the messages-dispatch function
    const messagesUrl = `${Deno.env.get('SUPABASE_URL')}/functions/v1/messages-dispatch`;
    
    const payload = {
      type: type,
      to: lead.whatsapp,
      vars: {
        NOME_RESP: lead.responsavel,
        URL_PUBLICA: lead.tenant_data?.url_publica || '',
        URL_ADMIN: lead.tenant_data?.url_admin || '',
        LOGIN: lead.tenant_data?.login || ''
      }
    };

    const response = await fetch(messagesUrl, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(payload)
    });

    if (response.ok) {
      console.log(`Followup ${type} sent to ${lead.whatsapp} (${lead.responsavel})`);
    } else {
      console.error(`Failed to send followup ${type} to ${lead.whatsapp}:`, await response.text());
    }

  } catch (error) {
    console.error(`Error sending followup to ${lead.whatsapp}:`, error);
  }
}