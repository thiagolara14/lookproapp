-- Add category_id column to establishments table
ALTER TABLE public.establishments 
ADD COLUMN category_id UUID REFERENCES public.categories(id);

-- Update existing establishments with sample category assignments
UPDATE public.establishments 
SET category_id = (
  CASE 
    WHEN name ILIKE '%barb%' THEN (SELECT id FROM public.categories WHERE name = 'Barbearia' LIMIT 1)
    WHEN name ILIKE '%studio%' OR name ILIKE '%bela%' OR name ILIKE '%hair%' OR name ILIKE '%beauty%' THEN (SELECT id FROM public.categories WHERE name = 'Salão de Beleza' LIMIT 1)
    WHEN name ILIKE '%spa%' THEN (SELECT id FROM public.categories WHERE name = 'Estética' LIMIT 1)
    ELSE (SELECT id FROM public.categories WHERE name = 'Barbearia' LIMIT 1)
  END
)
WHERE category_id IS NULL;