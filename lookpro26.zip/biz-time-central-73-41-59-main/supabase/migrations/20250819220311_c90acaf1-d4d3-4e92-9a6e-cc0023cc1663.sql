UPDATE establishments 
SET phone = '5511999999999' 
WHERE id = 'b6cf2cb5-6756-4bb3-b016-010af6bb041a';