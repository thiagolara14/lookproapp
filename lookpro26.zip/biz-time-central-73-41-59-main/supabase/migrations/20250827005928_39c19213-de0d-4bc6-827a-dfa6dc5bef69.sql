-- Create schema for onboarding integrations if it doesn't exist
CREATE SCHEMA IF NOT EXISTS onboarding;

-- Create messages_log table to store incoming WhatsApp webhook payloads
CREATE TABLE IF NOT EXISTS onboarding.messages_log (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  body JSONB NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
