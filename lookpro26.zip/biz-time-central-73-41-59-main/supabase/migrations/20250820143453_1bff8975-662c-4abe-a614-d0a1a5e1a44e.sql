-- Criar o profile que está faltando para o profissional
INSERT INTO profiles (user_id, email, full_name, role, establishment_id)
VALUES (
  '1e9367ec-c24a-4dba-8f5a-675cee47eec9',
  'thiago.lara14@gmail.com',
  'Thiago',
  'professional',
  'b6cf2cb5-6756-4bb3-b016-010af6bb041a'
)
ON CONFLICT (user_id) DO UPDATE SET
  full_name = EXCLUDED.full_name,
  email = EXCLUDED.email,
  role = EXCLUDED.role,
  establishment_id = EXCLUDED.establishment_id;