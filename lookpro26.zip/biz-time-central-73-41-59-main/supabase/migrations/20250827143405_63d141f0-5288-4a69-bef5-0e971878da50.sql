-- Onboarding schema and intake metadata for manual flow (corrected)
CREATE SCHEMA IF NOT EXISTS onboarding;

-- Intake metadata table to track raw inputs for admin processing
CREATE TABLE IF NOT EXISTS onboarding.intake_meta (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  lead_id UUID, -- Relates to public.leads.id but no FK for flexibility
  raw_city TEXT, -- Free text city input from user
  phone_e164 TEXT, -- Normalized phone in E.164 format
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Messages log table for WhatsApp message tracking
CREATE TABLE IF NOT EXISTS onboarding.messages_log (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  lead_id UUID NOT NULL,
  message_text TEXT NOT NULL,
  copied_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  sent_manually BOOLEAN DEFAULT FALSE,
  body JSONB DEFAULT '{}',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Enable RLS on new tables
ALTER TABLE onboarding.intake_meta ENABLE ROW LEVEL SECURITY;
ALTER TABLE onboarding.messages_log ENABLE ROW LEVEL SECURITY;

-- RLS policies - only service role can access (server-side only)
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE schemaname = 'onboarding' 
    AND tablename = 'intake_meta' 
    AND policyname = 'Service role can manage intake_meta'
  ) THEN
    CREATE POLICY "Service role can manage intake_meta" ON onboarding.intake_meta
      FOR ALL USING (auth.role() = 'service_role');
  END IF;
END $$;

DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE schemaname = 'onboarding' 
    AND tablename = 'messages_log' 
    AND policyname = 'Service role can manage messages_log'
  ) THEN
    CREATE POLICY "Service role can manage messages_log" ON onboarding.messages_log
      FOR ALL USING (auth.role() = 'service_role');
  END IF;
END $$;

-- Create function for updated_at trigger if not exists
CREATE OR REPLACE FUNCTION onboarding.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger if not exists
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.triggers 
    WHERE trigger_name = 'update_intake_meta_updated_at'
  ) THEN
    CREATE TRIGGER update_intake_meta_updated_at 
      BEFORE UPDATE ON onboarding.intake_meta 
      FOR EACH ROW EXECUTE PROCEDURE onboarding.update_updated_at_column();
  END IF;
END $$;

-- Create indexes if not exist
CREATE INDEX IF NOT EXISTS idx_intake_meta_lead_id ON onboarding.intake_meta(lead_id);
CREATE INDEX IF NOT EXISTS idx_intake_meta_created_at ON onboarding.intake_meta(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_messages_log_lead_id ON onboarding.messages_log(lead_id);