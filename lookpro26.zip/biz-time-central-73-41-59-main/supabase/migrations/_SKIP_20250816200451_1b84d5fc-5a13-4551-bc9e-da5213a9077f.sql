-- Migrar dados de "professional" para "pro"
UPDATE profiles SET role = 'pro' WHERE role = 'professional';