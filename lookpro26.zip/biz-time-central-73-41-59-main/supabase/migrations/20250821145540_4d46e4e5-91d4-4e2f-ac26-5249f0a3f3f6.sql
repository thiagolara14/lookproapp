-- Create extensions for exclusion constraints
CREATE EXTENSION IF NOT EXISTS btree_gist;

-- Add indices for better performance
CREATE INDEX IF NOT EXISTS idx_appointments_professional_date_time 
ON appointments (professional_id, appointment_date, start_time);

CREATE INDEX IF NOT EXISTS idx_appointments_professional_status 
ON appointments (professional_id, status);

CREATE INDEX IF NOT EXISTS idx_blocked_periods_professional_dates 
ON blocked_periods (professional_id, start_date, end_date);

-- Convert time columns to timestamptz for proper overlap checking
ALTER TABLE appointments 
ADD COLUMN IF NOT EXISTS start_at TIMESTAMPTZ,
ADD COLUMN IF NOT EXISTS end_at TIMESTAMPTZ;

ALTER TABLE blocked_periods 
ADD COLUMN IF NOT EXISTS start_at TIMESTAMPTZ,
ADD COLUMN IF NOT EXISTS end_at TIMESTAMPTZ;

-- Update existing data to populate new timestamptz columns
UPDATE appointments 
SET 
    start_at = (appointment_date::text || ' ' || start_time::text)::timestamptz,
    end_at = (appointment_date::text || ' ' || end_time::text)::timestamptz
WHERE start_at IS NULL;

UPDATE blocked_periods 
SET 
    start_at = CASE 
        WHEN start_time IS NOT NULL THEN (start_date::text || ' ' || start_time::text)::timestamptz
        ELSE start_date::timestamptz
    END,
    end_at = CASE 
        WHEN end_time IS NOT NULL THEN (end_date::text || ' ' || end_time::text)::timestamptz
        ELSE (end_date::timestamptz + INTERVAL '1 day' - INTERVAL '1 second')
    END
WHERE start_at IS NULL;

-- Create function to update timestamptz columns automatically
CREATE OR REPLACE FUNCTION update_appointment_timestamps()
RETURNS TRIGGER AS $$
BEGIN
    NEW.start_at := (NEW.appointment_date::text || ' ' || NEW.start_time::text)::timestamptz;
    NEW.end_at := (NEW.appointment_date::text || ' ' || NEW.end_time::text)::timestamptz;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION update_blocked_period_timestamps()
RETURNS TRIGGER AS $$
BEGIN
    NEW.start_at := CASE 
        WHEN NEW.start_time IS NOT NULL THEN (NEW.start_date::text || ' ' || NEW.start_time::text)::timestamptz
        ELSE NEW.start_date::timestamptz
    END;
    NEW.end_at := CASE 
        WHEN NEW.end_time IS NOT NULL THEN (NEW.end_date::text || ' ' || NEW.end_time::text)::timestamptz
        ELSE (NEW.end_date::timestamptz + INTERVAL '1 day' - INTERVAL '1 second')
    END;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create triggers to keep timestamptz columns in sync
DROP TRIGGER IF EXISTS trigger_update_appointment_timestamps ON appointments;
CREATE TRIGGER trigger_update_appointment_timestamps
    BEFORE INSERT OR UPDATE ON appointments
    FOR EACH ROW
    EXECUTE FUNCTION update_appointment_timestamps();

DROP TRIGGER IF EXISTS trigger_update_blocked_period_timestamps ON blocked_periods;
CREATE TRIGGER trigger_update_blocked_period_timestamps
    BEFORE INSERT OR UPDATE ON blocked_periods
    FOR EACH ROW
    EXECUTE FUNCTION update_blocked_period_timestamps();

-- Add EXCLUDE constraint to prevent overlapping appointments for same professional
ALTER TABLE appointments
DROP CONSTRAINT IF EXISTS appointments_no_overlap;

ALTER TABLE appointments
ADD CONSTRAINT appointments_no_overlap
EXCLUDE USING gist (
    professional_id WITH =,
    tstzrange(start_at, end_at, '[)') WITH &&
) WHERE (status != 'cancelled');

-- Update RLS policies for appointment creation with conflict checking
DROP POLICY IF EXISTS "appointments_insert_no_overlap" ON appointments;
CREATE POLICY "appointments_insert_no_overlap"
ON appointments FOR INSERT
WITH CHECK (
    -- Basic validation
    NEW.start_at < NEW.end_at
    -- Professional must exist and belong to same establishment
    AND EXISTS (
        SELECT 1 FROM professionals p
        WHERE p.id = NEW.professional_id
          AND p.establishment_id = NEW.establishment_id
    )
    -- No overlap with other appointments (handled by EXCLUDE constraint but good to have as policy too)
    AND NOT EXISTS (
        SELECT 1 FROM appointments a
        WHERE a.professional_id = NEW.professional_id
          AND a.status != 'cancelled'
          AND tstzrange(a.start_at, a.end_at, '[)') && tstzrange(NEW.start_at, NEW.end_at, '[)')
    )
    -- No overlap with blocked periods
    AND NOT EXISTS (
        SELECT 1 FROM blocked_periods b
        WHERE b.professional_id = NEW.professional_id
          AND tstzrange(b.start_at, b.end_at, '[)') && tstzrange(NEW.start_at, NEW.end_at, '[)')
    )
);

-- RPC function for atomic appointment creation with proper conflict checking
CREATE OR REPLACE FUNCTION create_appointment_rpc(
    p_establishment_id UUID,
    p_professional_id UUID,
    p_service_id UUID,
    p_appointment_date DATE,
    p_start_time TIME,
    p_duration_minutes INTEGER,
    p_client_id UUID DEFAULT NULL,
    p_client_name TEXT DEFAULT NULL,
    p_client_phone TEXT DEFAULT NULL,
    p_status TEXT DEFAULT 'scheduled'
) RETURNS UUID
LANGUAGE plpgsql
SECURITY INVOKER
AS $$
DECLARE
    v_start_at TIMESTAMPTZ;
    v_end_at TIMESTAMPTZ;
    v_appointment_id UUID;
    v_service_price NUMERIC;
BEGIN
    -- Calculate timestamps
    v_start_at := (p_appointment_date::text || ' ' || p_start_time::text)::timestamptz;
    v_end_at := v_start_at + make_interval(mins => p_duration_minutes);
    
    -- Get service price
    SELECT price INTO v_service_price 
    FROM services 
    WHERE id = p_service_id;
    
    -- Insert appointment (RLS and EXCLUDE constraint will validate conflicts)
    INSERT INTO appointments (
        id,
        establishment_id,
        professional_id,
        service_id,
        appointment_date,
        start_time,
        end_time,
        start_at,
        end_at,
        client_id,
        client_name,
        client_phone,
        status,
        total_price
    ) VALUES (
        gen_random_uuid(),
        p_establishment_id,
        p_professional_id,
        p_service_id,
        p_appointment_date,
        p_start_time,
        (v_end_at::time),
        v_start_at,
        v_end_at,
        p_client_id,
        p_client_name,
        p_client_phone,
        p_status::appointment_status,
        v_service_price
    ) RETURNING id INTO v_appointment_id;
    
    RETURN v_appointment_id;
EXCEPTION
    WHEN unique_violation OR exclusion_violation THEN
        RAISE EXCEPTION 'Horário indisponível (conflito com outro agendamento).' USING ERRCODE = 'P0001';
    WHEN check_violation THEN
        RAISE EXCEPTION 'Horário não disponível (bloqueado ou inválido).' USING ERRCODE = 'P0002';
    WHEN OTHERS THEN
        RAISE;
END;
$$;