-- Create onboarding schema and messages_log table (idempotent)
CREATE SCHEMA IF NOT EXISTS onboarding;

CREATE TABLE IF NOT EXISTS onboarding.messages_log (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  body JSONB NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Enable RLS and restrict access
ALTER TABLE onboarding.messages_log ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON onboarding.messages_log FROM anon, authenticated;

-- Allow super admins to manage messages_log
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE schemaname = 'onboarding' 
    AND tablename = 'messages_log' 
    AND policyname = 'Super admins can manage messages_log'
  ) THEN
    CREATE POLICY "Super admins can manage messages_log" 
    ON onboarding.messages_log 
    FOR ALL 
    USING (get_user_role() = 'super_admin'::user_role);
  END IF;
END
$$;