-- Drop foreign key constraints that prevent NULL values
ALTER TABLE public.reviews DROP CONSTRAINT IF EXISTS reviews_appointment_id_fkey;
ALTER TABLE public.reviews DROP CONSTRAINT IF EXISTS reviews_client_id_fkey;

-- Ensure professional_id can also be NULL for truly anonymous reviews
ALTER TABLE public.reviews ALTER COLUMN professional_id DROP NOT NULL;

-- Update policy to be even more permissive for anonymous reviews
DROP POLICY IF EXISTS "Anon can create reviews" ON public.reviews;
CREATE POLICY "Allow anonymous reviews" 
ON public.reviews 
FOR INSERT 
WITH CHECK (true);  -- Allow all inserts for now to test