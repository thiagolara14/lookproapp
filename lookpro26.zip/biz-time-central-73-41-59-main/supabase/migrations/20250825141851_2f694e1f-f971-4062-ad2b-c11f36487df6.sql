-- Verificar e criar estrutura para professional_services (se necessária)
-- Criar trigger updated_at se não existir
CREATE OR REPLACE FUNCTION set_updated_at() 
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Triggers para updated_at
DROP TRIGGER IF EXISTS t_services_updated ON services;
CREATE TRIGGER t_services_updated 
  BEFORE UPDATE ON services
  FOR EACH ROW 
  EXECUTE FUNCTION set_updated_at();

DROP TRIGGER IF EXISTS t_prof_services_updated ON professional_services;  
CREATE TRIGGER t_prof_services_updated 
  BEFORE UPDATE ON professional_services
  FOR EACH ROW 
  EXECUTE FUNCTION set_updated_at();

-- Atualizar a view para usar price em vez de price_cents 
CREATE OR REPLACE VIEW v_professional_services_effective AS
SELECT
  ps.id as professional_service_id,
  ps.professional_id,
  ps.establishment_id,
  s.id as service_id,
  s.name,
  s.description,
  s.image_url,
  COALESCE(ps.custom_duration_minutes, s.duration_minutes) as duration_minutes,
  COALESCE(ps.custom_price, s.price) as price,
  (ps.is_active AND s.is_active) as is_active
FROM professional_services ps
JOIN services s ON s.id = ps.service_id;

-- Função para listar serviços efetivos de um profissional
CREATE OR REPLACE FUNCTION rpc_list_professional_services(p_professional_id uuid)
RETURNS SETOF v_professional_services_effective
LANGUAGE sql STABLE
SET search_path TO 'public'
AS $$
  SELECT * FROM v_professional_services_effective
  WHERE professional_id = p_professional_id
  AND is_active = true
  ORDER BY name;
$$;

-- Função para listar serviços disponíveis para vínculo de um profissional
CREATE OR REPLACE FUNCTION rpc_get_available_services_for_professional(
  p_professional_id uuid,
  p_establishment_id uuid
)
RETURNS TABLE(
  service_id uuid,
  name text,
  description text,
  image_url text,
  duration_minutes int,
  price numeric
)
LANGUAGE sql STABLE  
SET search_path TO 'public'
AS $$
  SELECT s.id, s.name, s.description, s.image_url, s.duration_minutes, s.price
  FROM services s
  WHERE s.establishment_id = p_establishment_id
  AND s.is_active = true
  AND s.id NOT IN (
    SELECT ps.service_id 
    FROM professional_services ps 
    WHERE ps.professional_id = p_professional_id
  )
  ORDER BY s.name ASC;
$$;

-- RLS para professional_services
ALTER TABLE professional_services ENABLE ROW LEVEL SECURITY;

-- Políticas RLS para professional_services
DROP POLICY IF EXISTS "Professionals can manage their services" ON professional_services;
CREATE POLICY "Professionals can manage their services" 
ON professional_services 
FOR ALL 
USING (
  EXISTS (
    SELECT 1 FROM professionals p 
    WHERE p.id = professional_services.professional_id 
    AND p.user_id = auth.uid()
  )
);

DROP POLICY IF EXISTS "Admins can manage establishment professional services" ON professional_services;
CREATE POLICY "Admins can manage establishment professional services" 
ON professional_services 
FOR ALL 
USING (
  (get_user_role() = 'admin' AND establishment_id = get_user_establishment_id())
);

DROP POLICY IF EXISTS "Super admins can manage all professional services" ON professional_services;
CREATE POLICY "Super admins can manage all professional services" 
ON professional_services 
FOR ALL 
USING (get_user_role() = 'super_admin');

DROP POLICY IF EXISTS "Professional services select for establishment" ON professional_services;
CREATE POLICY "Professional services select for establishment" 
ON professional_services 
FOR SELECT 
USING (
  establishment_id = get_user_establishment_id() 
  OR EXISTS (
    SELECT 1 FROM professionals p 
    WHERE p.id = professional_services.professional_id 
    AND p.user_id = auth.uid()
  )
  OR get_user_role() = 'super_admin'
);