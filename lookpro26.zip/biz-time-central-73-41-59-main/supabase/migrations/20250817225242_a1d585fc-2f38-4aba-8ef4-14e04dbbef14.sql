-- Create a function for super admin to create users with credentials
CREATE OR REPLACE FUNCTION public.create_user_with_credentials(
  p_email TEXT,
  p_password TEXT,
  p_full_name TEXT,
  p_role user_role,
  p_establishment_id UUID DEFAULT NULL
) RETURNS JSON
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  new_user_id UUID;
  result JSON;
BEGIN
  -- Check if user has super admin role
  IF get_user_role() != 'super_admin' THEN
    RAISE EXCEPTION 'Access denied. Only super admins can create users.';
  END IF;

  -- Create the user in auth.users using Supabase auth admin API
  -- This would need to be done via edge function in practice
  -- For now, we'll create the profile assuming the auth user was created
  
  -- Generate a UUID for the new user
  new_user_id := gen_random_uuid();
  
  -- Insert the profile
  INSERT INTO public.profiles (
    user_id,
    email,
    full_name,
    role,
    establishment_id
  ) VALUES (
    new_user_id,
    p_email,
    p_full_name,
    p_role,
    p_establishment_id
  );

  -- If role is 'professional', create professional record
  IF p_role = 'professional' THEN
    INSERT INTO public.professionals (
      user_id,
      establishment_id,
      active
    ) VALUES (
      new_user_id,
      p_establishment_id,
      true
    );
  END IF;

  -- Return success result
  result := json_build_object(
    'success', true,
    'user_id', new_user_id,
    'email', p_email,
    'message', 'User created successfully'
  );

  RETURN result;
EXCEPTION
  WHEN OTHERS THEN
    result := json_build_object(
      'success', false,
      'error', SQLERRM,
      'message', 'Failed to create user'
    );
    RETURN result;
END;
$$;

-- Create edge function for actual user creation
-- This will be handled by the edge function that calls Supabase auth admin API