-- Add EXCLUDE constraint to prevent overlapping appointments for same professional
ALTER TABLE appointments
DROP CONSTRAINT IF EXISTS appointments_no_overlap;

ALTER TABLE appointments
ADD CONSTRAINT appointments_no_overlap
EXCLUDE USING gist (
    professional_id WITH =,
    tstzrange(start_at, end_at, '[)') WITH &&
) WHERE (status != 'cancelled');

-- RPC function for atomic appointment creation with proper conflict checking
CREATE OR REPLACE FUNCTION create_appointment_rpc(
    p_establishment_id UUID,
    p_professional_id UUID,
    p_service_id UUID,
    p_appointment_date DATE,
    p_start_time TIME,
    p_duration_minutes INTEGER,
    p_client_id UUID DEFAULT NULL,
    p_client_name TEXT DEFAULT NULL,
    p_client_phone TEXT DEFAULT NULL,
    p_status TEXT DEFAULT 'scheduled'
) RETURNS UUID
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
    v_start_at TIMESTAMPTZ;
    v_end_at TIMESTAMPTZ;
    v_appointment_id UUID;
    v_service_price NUMERIC;
BEGIN
    -- Calculate timestamps
    v_start_at := (p_appointment_date::text || ' ' || p_start_time::text)::timestamptz;
    v_end_at := v_start_at + make_interval(mins => p_duration_minutes);
    
    -- Get service price
    SELECT price INTO v_service_price 
    FROM services 
    WHERE id = p_service_id;
    
    -- Insert appointment (EXCLUDE constraint will validate conflicts)
    INSERT INTO appointments (
        id,
        establishment_id,
        professional_id,
        service_id,
        appointment_date,
        start_time,
        end_time,
        start_at,
        end_at,
        client_id,
        client_name,
        client_phone,
        status,
        total_price
    ) VALUES (
        gen_random_uuid(),
        p_establishment_id,
        p_professional_id,
        p_service_id,
        p_appointment_date,
        p_start_time,
        (v_end_at::time),
        v_start_at,
        v_end_at,
        p_client_id,
        p_client_name,
        p_client_phone,
        p_status::appointment_status,
        v_service_price
    ) RETURNING id INTO v_appointment_id;
    
    RETURN v_appointment_id;
EXCEPTION
    WHEN unique_violation OR exclusion_violation THEN
        RAISE EXCEPTION 'Horário indisponível (conflito com outro agendamento).' USING ERRCODE = 'P0001';
    WHEN check_violation THEN
        RAISE EXCEPTION 'Horário não disponível (bloqueado ou inválido).' USING ERRCODE = 'P0002';
    WHEN OTHERS THEN
        RAISE;
END;
$$;