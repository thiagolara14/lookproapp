UPDATE establishments 
SET city = 'São Roque' 
WHERE id = 'b6cf2cb5-6756-4bb3-b016-010af6bb041a' AND city = '890ea9c1-e3f0-465c-a31e-8abf78394f84'