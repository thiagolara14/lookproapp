-- Inserir profissionais (sem perfis vinculados)
INSERT INTO public.professionals (id, user_id, establishment_id, active, avatar_url, bio)
VALUES
('10101010-1010-1010-1010-101010101010', 'a1a1a1a1-a1a1-a1a1-a1a1-a1a1a1a1a1a1', '356e31a3-3b88-4b9d-a647-c4c7400ea1bc', true, NULL, 'Especialista em cortes masculinos'),
('20202020-2020-2020-2020-202020202020', 'b2b2b2b2-b2b2-b2b2-b2b2-b2b2b2b2b2b2', '356e31a3-3b88-4b9d-a647-c4c7400ea1bc', true, NULL, 'Barbeiro e especialista em barbas'),
('30303030-3030-3030-3030-303030303030', 'c3c3c3c3-c3c3-c3c3-c3c3-c3c3c3c3c3c3', '23df2895-0618-425f-be3d-1106b2128858', true, NULL, 'Cabeleireira e colorista'),
('40404040-4040-4040-4040-404040404040', 'd4d4d4d4-d4d4-d4d4-d4d4-d4d4d4d4d4d4', '23df2895-0618-425f-be3d-1106b2128858', true, NULL, 'Cabeleireira e finalização'),
('50505050-5050-5050-5050-505050505050', 'e5e5e5e5-e5e5-e5e5-e5e5-e5e5e5e5e5e5', 'a3ce0609-28f2-48f2-ae69-3c8777282ff2', true, NULL, 'Artista de tatuagem')
ON CONFLICT (id) DO UPDATE
SET user_id = EXCLUDED.user_id,
    establishment_id = EXCLUDED.establishment_id,
    active = EXCLUDED.active,
    avatar_url = EXCLUDED.avatar_url,
    bio = EXCLUDED.bio;