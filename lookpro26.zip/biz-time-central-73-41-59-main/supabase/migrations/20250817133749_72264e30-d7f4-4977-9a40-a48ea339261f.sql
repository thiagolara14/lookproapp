-- Criar perfis fake para os profissionais
INSERT INTO public.profiles (id, user_id, full_name, email, role, establishment_id) VALUES
('a1a1a1a1-a1a1-a1a1-a1a1-a1a1a1a1a1a1', 'a1a1a1a1-a1a1-a1a1-a1a1-a1a1a1a1a1a1', 'Rafa Barbeiro', 'rafa@lookbarba.com', 'pro', '356e31a3-3b88-4b9d-a647-c4c7400ea1bc'),
('b2b2b2b2-b2b2-b2b2-b2b2-b2b2b2b2b2b2', 'b2b2b2b2-b2b2-b2b2-b2b2-b2b2b2b2b2b2', 'Doni Silva', 'doni@lookbarba.com', 'pro', '356e31a3-3b88-4b9d-a647-c4c7400ea1bc'),
('c3c3c3c3-c3c3-c3c3-c3c3-c3c3c3c3c3c3', 'c3c3c3c3-c3c3-c3c3-c3c3-c3c3c3c3c3c3', 'Marina Santos', 'marina@studiobela.com', 'pro', '23df2895-0618-425f-be3d-1106b2128858'),
('d4d4d4d4-d4d4-d4d4-d4d4-d4d4d4d4d4d4', 'd4d4d4d4-d4d4-d4d4-d4d4-d4d4d4d4d4d4', 'Lívia Costa', 'livia@studiobela.com', 'pro', '23df2895-0618-425f-be3d-1106b2128858'),
('e5e5e5e5-e5e5-e5e5-e5e5-e5e5e5e5e5e5', 'e5e5e5e5-e5e5-e5e5-e5e5-e5e5e5e5e5e5', 'Nina Tattoo', 'nina@inkflow.com', 'pro', 'a3ce0609-28f2-48f2-ae69-3c8777282ff2')
ON CONFLICT (id) DO UPDATE SET
full_name = EXCLUDED.full_name,
email = EXCLUDED.email,
role = EXCLUDED.role,
establishment_id = EXCLUDED.establishment_id;