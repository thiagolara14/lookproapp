-- Verificar se todos os profissionais têm um perfil no sistema
-- e criar função para automatizar isso para novos usuários

-- Primeiro, vamos criar uma função para garantir que quando um profissional é criado,
-- ele sempre tem um perfil associado
CREATE OR REPLACE FUNCTION public.ensure_professional_profile()
RETURNS TRIGGER AS $$
BEGIN
  -- Verificar se o user_id já existe na tabela profiles
  IF NOT EXISTS (SELECT 1 FROM public.profiles WHERE user_id = NEW.user_id) THEN
    -- Se não existe, criar um perfil básico
    INSERT INTO public.profiles (user_id, email, full_name, role, establishment_id)
    VALUES (
      NEW.user_id,
      COALESCE((SELECT email FROM auth.users WHERE id = NEW.user_id), 'profissional@exemplo.com'),
      'Profissional',
      'pro',
      NEW.establishment_id
    );
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Criar trigger para executar a função sempre que um profissional for inserido
DROP TRIGGER IF EXISTS ensure_professional_profile_trigger ON public.professionals;
CREATE TRIGGER ensure_professional_profile_trigger
  AFTER INSERT ON public.professionals
  FOR EACH ROW
  EXECUTE FUNCTION public.ensure_professional_profile();

-- Agora vamos corrigir os profissionais existentes que não têm perfil
INSERT INTO public.profiles (user_id, email, full_name, role, establishment_id)
SELECT DISTINCT 
  p.user_id,
  COALESCE((SELECT email FROM auth.users WHERE id = p.user_id), 'profissional@exemplo.com'),
  'Profissional',
  'pro',
  p.establishment_id
FROM public.professionals p
WHERE NOT EXISTS (SELECT 1 FROM public.profiles WHERE user_id = p.user_id);