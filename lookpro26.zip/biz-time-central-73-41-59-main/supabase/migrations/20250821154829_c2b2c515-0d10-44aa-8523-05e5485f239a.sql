-- 1. Tabela de assinaturas de push
create table if not exists public.push_subscriptions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null,
  professional_id uuid,
  customer_id uuid,
  establishment_id uuid not null,
  endpoint text not null unique,
  p256dh text not null,
  auth text not null,
  user_agent text,
  platform text,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

-- 2. Índices para performance
create index if not exists idx_push_subs_est on push_subscriptions (establishment_id);
create index if not exists idx_push_subs_user on push_subscriptions (user_id);
create index if not exists idx_push_subs_prof on push_subscriptions (professional_id);
create index if not exists idx_push_subs_cust on push_subscriptions (customer_id);

-- 3. RLS
alter table push_subscriptions enable row level security;

-- Inserção: qualquer user autenticado pode gravar sua própria assinatura
create policy "push_subscriptions_insert_own" on push_subscriptions
for insert to authenticated
with check (auth.uid() = user_id);

-- Leitura: restrita a funções (usaremos RPC/Edge Function com security invoker).
create policy "push_subscriptions_select_none" on push_subscriptions
for select to authenticated
using (false);

-- 4. Trigger para updated_at
create trigger update_push_subscriptions_updated_at
before update on push_subscriptions
for each row
execute function public.update_updated_at_column();

-- 5. Habilitar extensão pg_net para HTTP requests
create extension if not exists pg_net;

-- 6. Função para notificar profissional sobre novo agendamento
create or replace function public.notify_professional_on_appointment()
returns trigger language plpgsql as $$
declare
  url text := 'https://fdxmegjbmglkbpylfeso.functions.supabase.co/push_dispatch';
  body jsonb;
begin
  -- somente para novos agendamentos
  body := jsonb_build_object(
    'type', 'appointment_created',
    'establishment_id', NEW.establishment_id,
    'professional_id', NEW.professional_id,
    'appointment_id', NEW.id,
    'title', 'Novo agendamento',
    'body', format('Agendamento para %s em %s', 
      NEW.client_name, 
      to_char(NEW.start_at at time zone 'America/Sao_Paulo', 'DD/MM "às" HH24:MI')
    )
  );

  perform net.http_post(
    url := url,
    headers := jsonb_build_object(
      'Content-Type','application/json', 
      'Authorization','Bearer service'
    ),
    body := body
  );
  return NEW;
end $$;

-- 7. Trigger para notificar profissional
drop trigger if exists trg_notify_professional_on_insert on public.appointments;
create trigger trg_notify_professional_on_insert
after insert on public.appointments
for each row execute function public.notify_professional_on_appointment();