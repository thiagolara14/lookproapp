-- Fix function security by setting search path
CREATE OR REPLACE FUNCTION update_appointment_timestamps()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
    NEW.start_at := (NEW.appointment_date::text || ' ' || NEW.start_time::text)::timestamptz;
    NEW.end_at := (NEW.appointment_date::text || ' ' || NEW.end_time::text)::timestamptz;
    RETURN NEW;
END;
$$;

CREATE OR REPLACE FUNCTION update_blocked_period_timestamps()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
    NEW.start_at := CASE 
        WHEN NEW.start_time IS NOT NULL THEN (NEW.start_date::text || ' ' || NEW.start_time::text)::timestamptz
        ELSE NEW.start_date::timestamptz
    END;
    NEW.end_at := CASE 
        WHEN NEW.end_time IS NOT NULL THEN (NEW.end_date::text || ' ' || NEW.end_time::text)::timestamptz
        ELSE (NEW.end_date::timestamptz + INTERVAL '1 day' - INTERVAL '1 second')
    END;
    RETURN NEW;
END;
$$;

-- Create triggers
DROP TRIGGER IF EXISTS trigger_update_appointment_timestamps ON appointments;
CREATE TRIGGER trigger_update_appointment_timestamps
    BEFORE INSERT OR UPDATE ON appointments
    FOR EACH ROW
    EXECUTE FUNCTION update_appointment_timestamps();

DROP TRIGGER IF EXISTS trigger_update_blocked_period_timestamps ON blocked_periods;
CREATE TRIGGER trigger_update_blocked_period_timestamps
    BEFORE INSERT OR UPDATE ON blocked_periods
    FOR EACH ROW
    EXECUTE FUNCTION update_blocked_period_timestamps();