-- Corrigir search_path nas funções criadas

-- RPC: Total do profissional (com período opcional) - corrigido
CREATE OR REPLACE FUNCTION public.finance_total_for_professional(
  p_professional_id uuid,
  p_start timestamptz DEFAULT NULL,
  p_end timestamptz DEFAULT NULL
) RETURNS bigint
LANGUAGE sql
SECURITY INVOKER
SET search_path = public
AS $$
  SELECT COALESCE(SUM(amount_cents), 0)::bigint
  FROM v_appointments_finalized v
  WHERE v.professional_id = p_professional_id
    AND (p_start IS NULL OR v.start_at >= p_start)
    AND (p_end IS NULL OR v.start_at < p_end);
$$;

-- RPC: Total do estabelecimento (Admin) - corrigido
CREATE OR REPLACE FUNCTION public.finance_total_for_establishment(
  p_establishment_id uuid,
  p_start timestamptz DEFAULT NULL,
  p_end timestamptz DEFAULT NULL
) RETURNS bigint
LANGUAGE sql
SECURITY INVOKER
SET search_path = public
AS $$
  SELECT COALESCE(SUM(amount_cents), 0)::bigint
  FROM v_appointments_finalized v
  WHERE v.establishment_id = p_establishment_id
    AND (p_start IS NULL OR v.start_at >= p_start)
    AND (p_end IS NULL OR v.start_at < p_end);
$$;

-- RPC: Quebrado por profissional (para Admin) - corrigido
CREATE OR REPLACE FUNCTION public.finance_breakdown_by_professional(
  p_establishment_id uuid,
  p_start timestamptz DEFAULT NULL,
  p_end timestamptz DEFAULT NULL
) RETURNS TABLE(professional_id uuid, total_cents bigint)
LANGUAGE sql
SECURITY INVOKER
SET search_path = public
AS $$
  SELECT v.professional_id, SUM(v.amount_cents)::bigint AS total_cents
  FROM v_appointments_finalized v
  WHERE v.establishment_id = p_establishment_id
    AND (p_start IS NULL OR v.start_at >= p_start)
    AND (p_end IS NULL OR v.start_at < p_end)
  GROUP BY v.professional_id
  ORDER BY total_cents DESC;
$$;