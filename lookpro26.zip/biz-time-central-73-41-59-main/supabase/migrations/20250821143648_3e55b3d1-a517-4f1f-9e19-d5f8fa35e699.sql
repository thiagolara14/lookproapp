-- Remover todas as políticas existentes da tabela blocked_periods
DROP POLICY IF EXISTS "Professionals can create their blocked periods" ON public.blocked_periods;
DROP POLICY IF EXISTS "Admins can view establishment blocked periods" ON public.blocked_periods;
DROP POLICY IF EXISTS "Professionals can update their blocked periods" ON public.blocked_periods;
DROP POLICY IF EXISTS "Professionals can delete their blocked periods" ON public.blocked_periods;
DROP POLICY IF EXISTS "Professionals can view their blocked periods" ON public.blocked_periods;
DROP POLICY IF EXISTS "Super admins can manage all blocked periods" ON public.blocked_periods;

-- Política permissiva para todos lerem bloqueios (necessário para agenda)
CREATE POLICY "Allow read blocked periods" 
ON public.blocked_periods 
FOR SELECT 
USING (true);

-- Política para profissionais criarem seus bloqueios
CREATE POLICY "Professionals can create their blocked periods" 
ON public.blocked_periods 
FOR INSERT 
WITH CHECK (
  EXISTS (
    SELECT 1 FROM public.professionals pr 
    WHERE pr.id = blocked_periods.professional_id 
    AND pr.user_id = auth.uid()
  )
);

-- Política para profissionais atualizarem seus bloqueios
CREATE POLICY "Professionals can update their blocked periods" 
ON public.blocked_periods 
FOR UPDATE 
USING (
  EXISTS (
    SELECT 1 FROM public.professionals pr 
    WHERE pr.id = blocked_periods.professional_id 
    AND pr.user_id = auth.uid()
  )
);

-- Política para profissionais removerem seus bloqueios
CREATE POLICY "Professionals can delete their blocked periods" 
ON public.blocked_periods 
FOR DELETE 
USING (
  EXISTS (
    SELECT 1 FROM public.professionals pr 
    WHERE pr.id = blocked_periods.professional_id 
    AND pr.user_id = auth.uid()
  )
);

-- Política para super admins
CREATE POLICY "Super admins can manage all blocked periods" 
ON public.blocked_periods 
FOR ALL 
USING (get_user_role() = 'super_admin'::user_role);