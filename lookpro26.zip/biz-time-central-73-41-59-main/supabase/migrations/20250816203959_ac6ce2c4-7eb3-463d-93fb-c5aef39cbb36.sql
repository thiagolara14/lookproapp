-- Allow anonymous booking via phone
ALTER TABLE public.appointments ALTER COLUMN client_id DROP NOT NULL;

-- Create policy for anon inserts with phone
DROP POLICY IF EXISTS "Anon can create appointments with phone" ON public.appointments;
CREATE POLICY "Anon can create appointments with phone"
ON public.appointments
FOR INSERT TO anon
WITH CHECK (
  client_id IS NULL AND client_phone IS NOT NULL AND professional_id IS NOT NULL AND service_id IS NOT NULL
);

-- Ensure professional_id references professionals(id)
ALTER TABLE public.appointments DROP CONSTRAINT IF EXISTS appointments_professional_id_fkey;
ALTER TABLE public.appointments
  ADD CONSTRAINT appointments_professional_id_fkey
  FOREIGN KEY (professional_id) REFERENCES public.professionals(id);
