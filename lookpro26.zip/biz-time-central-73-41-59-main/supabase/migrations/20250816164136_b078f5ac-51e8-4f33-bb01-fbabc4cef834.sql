-- Add missing tables and fields for complete Supabase migration

-- Create cities table
CREATE TABLE public.cities (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name text NOT NULL,
  visible boolean NOT NULL DEFAULT true,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now()
);

-- Create categories table  
CREATE TABLE public.categories (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name text NOT NULL,
  image_url text,
  active boolean NOT NULL DEFAULT true,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now()
);

-- Create plans table
CREATE TABLE public.plans (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name text NOT NULL,
  price numeric NOT NULL,
  period text NOT NULL, -- 'monthly' or 'yearly'
  trial_days integer NOT NULL DEFAULT 0,
  booking_limit integer NOT NULL DEFAULT 100,
  extras text[] DEFAULT '{}',
  active boolean NOT NULL DEFAULT true,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now()
);

-- Add missing appointment_id field to reviews table
ALTER TABLE public.reviews 
ADD COLUMN IF NOT EXISTS appointment_id uuid NOT NULL DEFAULT gen_random_uuid();

-- Enable RLS on new tables
ALTER TABLE public.cities ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.plans ENABLE ROW LEVEL SECURITY;

-- Create policies for cities
CREATE POLICY "Everyone can view cities" ON public.cities FOR SELECT USING (visible = true);
CREATE POLICY "Super admins can manage cities" ON public.cities FOR ALL USING (get_user_role() = 'super_admin'::user_role);

-- Create policies for categories  
CREATE POLICY "Everyone can view active categories" ON public.categories FOR SELECT USING (active = true);
CREATE POLICY "Super admins can manage categories" ON public.categories FOR ALL USING (get_user_role() = 'super_admin'::user_role);

-- Create policies for plans
CREATE POLICY "Everyone can view active plans" ON public.plans FOR SELECT USING (active = true);
CREATE POLICY "Super admins can manage plans" ON public.plans FOR ALL USING (get_user_role() = 'super_admin'::user_role);

-- Add update triggers for new tables
CREATE TRIGGER update_cities_updated_at
  BEFORE UPDATE ON public.cities
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_categories_updated_at
  BEFORE UPDATE ON public.categories
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_plans_updated_at
  BEFORE UPDATE ON public.plans
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();