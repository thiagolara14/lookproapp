-- Allow anonymous public reviews while keeping client-auth reviews
-- This policy enables inserts from unauthenticated (anon) users with basic validation
CREATE POLICY "Anon can create reviews"
ON public.reviews
FOR INSERT
WITH CHECK (
  auth.uid() IS NULL
  AND client_id IS NOT NULL
  AND professional_id IS NOT NULL
  AND establishment_id IS NOT NULL
  AND professional_rating BETWEEN 1 AND 5
  AND establishment_rating BETWEEN 1 AND 5
  AND char_length(COALESCE(comment, '')) <= 1000
);
