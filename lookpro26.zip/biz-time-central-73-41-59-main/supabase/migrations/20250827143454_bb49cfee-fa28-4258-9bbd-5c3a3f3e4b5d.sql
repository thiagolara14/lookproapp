-- Minimal onboarding tables creation
CREATE SCHEMA IF NOT EXISTS onboarding;

CREATE TABLE IF NOT EXISTS onboarding.intake_meta (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  lead_id UUID,
  raw_city TEXT,
  phone_e164 TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS onboarding.messages_log (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  lead_id UUID NOT NULL,
  message_text TEXT NOT NULL,
  copied_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  sent_manually BOOLEAN DEFAULT FALSE,
  body JSONB DEFAULT '{}',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);