-- Allow super admins to delete profiles so UI reflects deletions
CREATE POLICY IF NOT EXISTS "Super admins can delete profiles"
ON public.profiles
FOR DELETE
USING (get_user_role() = 'super_admin');