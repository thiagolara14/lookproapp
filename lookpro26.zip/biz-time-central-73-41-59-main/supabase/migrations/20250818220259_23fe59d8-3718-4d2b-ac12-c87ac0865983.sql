-- Inserir horários de funcionamento padrão para estabelecimentos que não os possuem
-- Segunda a Sexta: 09:00 - 18:00
-- Sábado: 09:00 - 14:00  
-- Domingo: Fechado

INSERT INTO establishment_hours (establishment_id, day_of_week, open_time, close_time, is_closed)
SELECT 
  e.id,
  dow.day_of_week,
  CASE 
    WHEN dow.day_of_week = 0 THEN NULL -- Domingo fechado
    WHEN dow.day_of_week = 6 THEN '09:00' -- Sábado
    ELSE '09:00' -- Segunda a sexta
  END as open_time,
  CASE 
    WHEN dow.day_of_week = 0 THEN NULL -- Domingo fechado
    WHEN dow.day_of_week = 6 THEN '14:00' -- Sábado até 14h
    ELSE '18:00' -- Segunda a sexta até 18h
  END as close_time,
  CASE 
    WHEN dow.day_of_week = 0 THEN true -- Domingo fechado
    ELSE false
  END as is_closed
FROM establishments e
CROSS JOIN (
  SELECT generate_series(0, 6) as day_of_week
) dow
WHERE NOT EXISTS (
  SELECT 1 FROM establishment_hours eh 
  WHERE eh.establishment_id = e.id 
  AND eh.day_of_week = dow.day_of_week
)
ON CONFLICT (establishment_id, day_of_week) DO NOTHING;