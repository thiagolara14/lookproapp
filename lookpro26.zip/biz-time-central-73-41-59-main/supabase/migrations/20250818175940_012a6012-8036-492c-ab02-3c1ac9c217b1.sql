-- Ensure every professional has a corresponding profile and enforce it for new inserts

CREATE OR REPLACE FUNCTION public.ensure_professional_profile()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
BEGIN
  -- If the professional's user_id doesn't have a profile, create a basic one
  IF NOT EXISTS (
    SELECT 1 FROM public.profiles WHERE user_id = NEW.user_id
  ) THEN
    INSERT INTO public.profiles (user_id, email, full_name, role, establishment_id)
    VALUES (
      NEW.user_id,
      COALESCE((SELECT email FROM auth.users WHERE id = NEW.user_id), 'profissional@exemplo.com'),
      'Profissional',
      'pro'::user_role,
      NEW.establishment_id
    );
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS ensure_professional_profile_trigger ON public.professionals;
CREATE TRIGGER ensure_professional_profile_trigger
AFTER INSERT ON public.professionals
FOR EACH ROW
EXECUTE FUNCTION public.ensure_professional_profile();

-- Backfill: create profiles for professionals missing one
INSERT INTO public.profiles (user_id, email, full_name, role, establishment_id)
SELECT DISTINCT 
  p.user_id,
  COALESCE((SELECT email FROM auth.users WHERE id = p.user_id), 'profissional@exemplo.com'),
  'Profissional',
  'pro'::user_role,
  p.establishment_id
FROM public.professionals p
WHERE NOT EXISTS (SELECT 1 FROM public.profiles pr WHERE pr.user_id = p.user_id);