-- Public function to expose active professionals with names for an establishment
CREATE OR REPLACE FUNCTION public.get_establishment_professionals(establishment_uuid uuid)
RETURNS TABLE (
  id uuid,
  name text,
  email text,
  establishment_id uuid,
  created_at timestamptz,
  updated_at timestamptz
)
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT 
    p.id,
    COALESCE(pr.full_name, 'Profissional') AS name,
    pr.email,
    p.establishment_id,
    p.created_at,
    p.updated_at
  FROM professionals p
  LEFT JOIN profiles pr ON pr.user_id = p.user_id
  WHERE p.establishment_id = establishment_uuid
    AND p.active = true;
$$;