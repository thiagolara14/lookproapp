-- 1. Índices para performance
CREATE INDEX IF NOT EXISTS idx_appts_prof ON appointments (professional_id);
CREATE INDEX IF NOT EXISTS idx_appts_est ON appointments (establishment_id);  
CREATE INDEX IF NOT EXISTS idx_appts_stat ON appointments (status);
CREATE INDEX IF NOT EXISTS idx_appts_start ON appointments (start_at);

-- 2. View base: apenas finalizados, com valor em centavos padronizado
CREATE OR REPLACE VIEW v_appointments_finalized AS
SELECT
  a.id,
  a.professional_id,
  a.establishment_id,
  a.status,
  a.start_at,
  a.end_at,
  -- normaliza para centavos (bigint)
  COALESCE((a.total_price * 100)::bigint, 0) AS amount_cents
FROM appointments a
WHERE a.status = 'completed';

-- 3. Views de agregação
CREATE OR REPLACE VIEW v_finance_total_by_professional AS
SELECT
  professional_id,
  SUM(amount_cents)::bigint AS total_cents
FROM v_appointments_finalized
GROUP BY professional_id;

CREATE OR REPLACE VIEW v_finance_total_by_establishment AS
SELECT
  establishment_id,
  SUM(amount_cents)::bigint AS total_cents
FROM v_appointments_finalized
GROUP BY establishment_id;

-- 4. RPC: Total do profissional (com período opcional)
CREATE OR REPLACE FUNCTION public.finance_total_for_professional(
  p_professional_id uuid,
  p_start timestamptz DEFAULT NULL,
  p_end timestamptz DEFAULT NULL
) RETURNS bigint
LANGUAGE sql
SECURITY INVOKER
AS $$
  SELECT COALESCE(SUM(amount_cents), 0)::bigint
  FROM v_appointments_finalized v
  WHERE v.professional_id = p_professional_id
    AND (p_start IS NULL OR v.start_at >= p_start)
    AND (p_end IS NULL OR v.start_at < p_end);
$$;

-- 5. RPC: Total do estabelecimento (Admin)
CREATE OR REPLACE FUNCTION public.finance_total_for_establishment(
  p_establishment_id uuid,
  p_start timestamptz DEFAULT NULL,
  p_end timestamptz DEFAULT NULL
) RETURNS bigint
LANGUAGE sql
SECURITY INVOKER
AS $$
  SELECT COALESCE(SUM(amount_cents), 0)::bigint
  FROM v_appointments_finalized v
  WHERE v.establishment_id = p_establishment_id
    AND (p_start IS NULL OR v.start_at >= p_start)
    AND (p_end IS NULL OR v.start_at < p_end);
$$;

-- 6. RPC: Quebrado por profissional (para Admin)
CREATE OR REPLACE FUNCTION public.finance_breakdown_by_professional(
  p_establishment_id uuid,
  p_start timestamptz DEFAULT NULL,
  p_end timestamptz DEFAULT NULL
) RETURNS TABLE(professional_id uuid, total_cents bigint)
LANGUAGE sql
SECURITY INVOKER
AS $$
  SELECT v.professional_id, SUM(v.amount_cents)::bigint AS total_cents
  FROM v_appointments_finalized v
  WHERE v.establishment_id = p_establishment_id
    AND (p_start IS NULL OR v.start_at >= p_start)
    AND (p_end IS NULL OR v.start_at < p_end)
  GROUP BY v.professional_id
  ORDER BY total_cents DESC;
$$;