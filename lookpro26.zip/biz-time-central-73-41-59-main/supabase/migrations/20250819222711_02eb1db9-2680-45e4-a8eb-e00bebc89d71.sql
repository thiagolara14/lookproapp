-- Add client_name field to reviews table to store anonymous client names
ALTER TABLE public.reviews ADD COLUMN client_name TEXT;