-- Insert test services for Barbearia Bonini
INSERT INTO public.services (establishment_id, name, description, duration_minutes, price, is_active)
VALUES 
  ('b6cf2cb5-6756-4bb3-b016-010af6bb041a', 'Corte Masculino', 'Corte de cabelo masculino tradicional', 30, 3000, true),
  ('b6cf2cb5-6756-4bb3-b016-010af6bb041a', 'Barba Completa', 'Aparar e modelar barba completa', 20, 2000, true),
  ('b6cf2cb5-6756-4bb3-b016-010af6bb041a', 'Corte + Barba', 'Combo corte de cabelo + barba', 45, 4500, true),
  ('b6cf2cb5-6756-4bb3-b016-010af6bb041a', 'Sobrancelha', 'Aparar e modelar sobrancelhas', 15, 1500, true);

-- Insert test appointments for today
INSERT INTO public.appointments (
  establishment_id, 
  professional_id, 
  service_id, 
  client_name, 
  client_phone, 
  appointment_date, 
  start_time, 
  end_time, 
  total_price, 
  status
)
VALUES 
  (
    'b6cf2cb5-6756-4bb3-b016-010af6bb041a',
    'e3be710a-7140-4c36-983d-0b1e587796d6',
    (SELECT id FROM services WHERE name = 'Corte Masculino' AND establishment_id = 'b6cf2cb5-6756-4bb3-b016-010af6bb041a' LIMIT 1),
    'João Silva',
    '(11) 99999-1111',
    CURRENT_DATE,
    '10:00',
    '10:30',
    3000,
    'confirmed'
  ),
  (
    'b6cf2cb5-6756-4bb3-b016-010af6bb041a',
    'e3be710a-7140-4c36-983d-0b1e587796d6',
    (SELECT id FROM services WHERE name = 'Corte + Barba' AND establishment_id = 'b6cf2cb5-6756-4bb3-b016-010af6bb041a' LIMIT 1),
    'Pedro Santos',
    '(11) 99999-2222',
    CURRENT_DATE,
    '14:00',
    '14:45',
    4500,
    'scheduled'
  ),
  (
    'b6cf2cb5-6756-4bb3-b016-010af6bb041a',
    'e3be710a-7140-4c36-983d-0b1e587796d6',
    (SELECT id FROM services WHERE name = 'Barba Completa' AND establishment_id = 'b6cf2cb5-6756-4bb3-b016-010af6bb041a' LIMIT 1),
    'Carlos Oliveira',
    '(11) 99999-3333',
    CURRENT_DATE,
    '16:30',
    '16:50',
    2000,
    'completed'
  );