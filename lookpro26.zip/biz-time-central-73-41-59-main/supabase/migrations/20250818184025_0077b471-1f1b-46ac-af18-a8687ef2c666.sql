-- Limpar dados mockados que não têm profiles correspondentes
DELETE FROM professionals 
WHERE user_id IN (
  'a1a1a1a1-a1a1-a1a1-a1a1-a1a1a1a1a1a1',
  'b2b2b2b2-b2b2-b2b2-b2b2-b2b2b2b2b2b2',
  'c3c3c3c3-c3c3-c3c3-c3c3-c3c3c3c3c3c3',
  'd4d4d4d4-d4d4-d4d4-d4d4-d4d4d4d4d4d4',
  'e5e5e5e5-e5e5-e5e5-e5e5-e5e5e5e5e5e5'
);

-- Verificar se há dados inconsistentes (profissionais sem profiles)
DO $$
DECLARE
    orphaned_professionals_count INTEGER;
BEGIN
    -- Contar profissionais órfãos (sem profile correspondente)
    SELECT COUNT(*) INTO orphaned_professionals_count
    FROM professionals p
    LEFT JOIN profiles prof ON p.user_id = prof.user_id
    WHERE prof.user_id IS NULL;
    
    -- Se houver profissionais órfãos, vamos removê-los
    IF orphaned_professionals_count > 0 THEN
        DELETE FROM professionals 
        WHERE user_id IN (
            SELECT p.user_id 
            FROM professionals p
            LEFT JOIN profiles prof ON p.user_id = prof.user_id
            WHERE prof.user_id IS NULL
        );
        
        RAISE NOTICE 'Removidos % profissionais órfãos (sem profiles)', orphaned_professionals_count;
    END IF;
END $$;