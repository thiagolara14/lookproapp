-- Recreate messages_log table with all columns and add missing RLS policies
DROP TABLE IF EXISTS onboarding.messages_log;

CREATE TABLE onboarding.messages_log (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  lead_id UUID NOT NULL,
  message_text TEXT NOT NULL,
  copied_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  sent_manually BOOLEAN DEFAULT FALSE,
  body JSONB DEFAULT '{}',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Enable RLS
ALTER TABLE onboarding.messages_log ENABLE ROW LEVEL SECURITY;

-- Add RLS policies for both tables
CREATE POLICY "Service role can manage messages_log" ON onboarding.messages_log
  FOR ALL USING (auth.role() = 'service_role');

-- Add RLS policy for intake_meta if not exists  
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE schemaname = 'onboarding' 
    AND tablename = 'intake_meta' 
    AND policyname = 'Service role can manage intake_meta'
  ) THEN
    ALTER TABLE onboarding.intake_meta ENABLE ROW LEVEL SECURITY;
    CREATE POLICY "Service role can manage intake_meta" ON onboarding.intake_meta
      FOR ALL USING (auth.role() = 'service_role');
  END IF;
END $$;

-- Create indexes
CREATE INDEX IF NOT EXISTS idx_intake_meta_lead_id ON onboarding.intake_meta(lead_id);
CREATE INDEX IF NOT EXISTS idx_intake_meta_created_at ON onboarding.intake_meta(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_messages_log_lead_id ON onboarding.messages_log(lead_id);