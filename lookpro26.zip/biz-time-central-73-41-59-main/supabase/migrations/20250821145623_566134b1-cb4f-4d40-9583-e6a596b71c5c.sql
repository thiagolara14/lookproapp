-- Update existing data to populate new timestamptz columns
UPDATE appointments 
SET 
    start_at = (appointment_date::text || ' ' || start_time::text)::timestamptz,
    end_at = (appointment_date::text || ' ' || end_time::text)::timestamptz
WHERE start_at IS NULL;

UPDATE blocked_periods 
SET 
    start_at = CASE 
        WHEN start_time IS NOT NULL THEN (start_date::text || ' ' || start_time::text)::timestamptz
        ELSE start_date::timestamptz
    END,
    end_at = CASE 
        WHEN end_time IS NOT NULL THEN (end_date::text || ' ' || end_time::text)::timestamptz
        ELSE (end_date::timestamptz + INTERVAL '1 day' - INTERVAL '1 second')
    END
WHERE start_at IS NULL;

-- Create function to update timestamptz columns automatically
CREATE OR REPLACE FUNCTION update_appointment_timestamps()
RETURNS TRIGGER AS $$
BEGIN
    NEW.start_at := (NEW.appointment_date::text || ' ' || NEW.start_time::text)::timestamptz;
    NEW.end_at := (NEW.appointment_date::text || ' ' || NEW.end_time::text)::timestamptz;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;