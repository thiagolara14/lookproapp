-- Corrigir o establishment_id do profissional Thiago para que apareça no dashboard do admin
UPDATE profiles 
SET establishment_id = 'b6cf2cb5-6756-4bb3-b016-010af6bb041a'
WHERE user_id = '1e9367ec-c24a-4dba-8f5a-675cee47eec9' AND role = 'professional';