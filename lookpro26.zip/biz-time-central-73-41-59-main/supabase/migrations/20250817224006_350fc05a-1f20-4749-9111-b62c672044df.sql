-- Create global_settings table for platform-wide configurations
CREATE TABLE public.global_settings (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  key TEXT NOT NULL UNIQUE,
  value TEXT NOT NULL,
  description TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.global_settings ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Super admins can manage global settings" 
ON public.global_settings 
FOR ALL 
USING (get_user_role() = 'super_admin'::user_role);

CREATE POLICY "Everyone can view global settings" 
ON public.global_settings 
FOR SELECT 
USING (true);

-- Insert default support settings
INSERT INTO public.global_settings (key, value, description) VALUES
('support_whatsapp', '5511999999999', 'WhatsApp number for support (without + or 55)'),
('support_email', 'suporte@lookpro.app', 'Email address for support');

-- Create trigger for automatic timestamp updates
CREATE TRIGGER update_global_settings_updated_at
BEFORE UPDATE ON public.global_settings
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();