-- Inserir dados mock nos estabelecimentos
INSERT INTO public.establishments (id, name, description, address, city, state, phone, status, slug) VALUES
('356e31a3-3b88-4b9d-a647-c4c7400ea1bc', 'LookBarba Prime', 'Barbearia premium com os melhores profissionais', 'Rua Exemplo, 123', 'São Paulo', 'SP', '(11) 99999-0001', 'active', 'lookbarba-prime'),
('23df2895-0618-425f-be3d-1106b2128858', 'Studio Bela RJ', 'Salão de beleza completo', 'Av. Central, 456', 'Rio de Janeiro', 'RJ', '(21) 99999-0002', 'active', 'studio-bela-rj'),
('a3ce0609-28f2-48f2-ae69-3c8777282ff2', 'Ink & Flow', 'Estúdio de tatuagem e piercing', 'Rua Bela Vista, 789', 'Belo Horizonte', 'MG', '(31) 99999-0003', 'active', 'ink-flow')
ON CONFLICT (id) DO UPDATE SET
name = EXCLUDED.name,
description = EXCLUDED.description,
address = EXCLUDED.address,
city = EXCLUDED.city,
state = EXCLUDED.state,
phone = EXCLUDED.phone,
status = EXCLUDED.status,
slug = EXCLUDED.slug;

-- Inserir serviços para LookBarba Prime
INSERT INTO public.services (id, establishment_id, name, description, price, duration_minutes, is_active) VALUES
('corte-lookbarba', '356e31a3-3b88-4b9d-a647-c4c7400ea1bc', 'Corte Clássico', 'Corte masculino tradicional', 70.00, 30, true),
('barba-lookbarba', '356e31a3-3b88-4b9d-a647-c4c7400ea1bc', 'Barba', 'Aparar e modelar barba', 50.00, 30, true),
('combo-lookbarba', '356e31a3-3b88-4b9d-a647-c4c7400ea1bc', 'Corte + Barba', 'Pacote completo corte e barba', 110.00, 60, true)
ON CONFLICT (id) DO UPDATE SET
name = EXCLUDED.name,
description = EXCLUDED.description,
price = EXCLUDED.price,
duration_minutes = EXCLUDED.duration_minutes,
is_active = EXCLUDED.is_active;

-- Inserir serviços para Studio Bela RJ
INSERT INTO public.services (id, establishment_id, name, description, price, duration_minutes, is_active) VALUES
('escova-studio', '23df2895-0618-425f-be3d-1106b2128858', 'Escova', 'Escova modeladora', 85.00, 45, true),
('coloracao-studio', '23df2895-0618-425f-be3d-1106b2128858', 'Coloração', 'Coloração completa', 200.00, 90, true),
('corte-feminino-studio', '23df2895-0618-425f-be3d-1106b2128858', 'Corte Feminino', 'Corte e finalização', 120.00, 60, true)
ON CONFLICT (id) DO UPDATE SET
name = EXCLUDED.name,
description = EXCLUDED.description,
price = EXCLUDED.price,
duration_minutes = EXCLUDED.duration_minutes,
is_active = EXCLUDED.is_active;

-- Inserir serviços para Ink & Flow
INSERT INTO public.services (id, establishment_id, name, description, price, duration_minutes, is_active) VALUES
('flash-tattoo', 'a3ce0609-28f2-48f2-ae69-3c8777282ff2', 'Flash Tattoo', 'Tatuagem de catálogo', 250.00, 60, true),
('custom-tattoo', 'a3ce0609-28f2-48f2-ae69-3c8777282ff2', 'Custom Tattoo', 'Tatuagem personalizada', 500.00, 120, true),
('piercing', 'a3ce0609-28f2-48f2-ae69-3c8777282ff2', 'Piercing', 'Colocação de piercing', 80.00, 30, true)
ON CONFLICT (id) DO UPDATE SET
name = EXCLUDED.name,
description = EXCLUDED.description,
price = EXCLUDED.price,
duration_minutes = EXCLUDED.duration_minutes,
is_active = EXCLUDED.is_active;