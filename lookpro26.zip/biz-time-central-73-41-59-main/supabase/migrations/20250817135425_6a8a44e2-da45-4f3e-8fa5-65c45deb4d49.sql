-- Create storage buckets for photos
INSERT INTO storage.buckets (id, name, public) 
VALUES 
  ('establishment-photos', 'establishment-photos', true),
  ('establishment-logos', 'establishment-logos', true),
  ('establishment-covers', 'establishment-covers', true),
  ('service-photos', 'service-photos', true),
  ('professional-avatars', 'professional-avatars', true);

-- Storage policies for establishment photos
CREATE POLICY "Anyone can view establishment photos" 
ON storage.objects 
FOR SELECT 
USING (bucket_id = 'establishment-photos');

CREATE POLICY "Admins can upload establishment photos" 
ON storage.objects 
FOR INSERT 
WITH CHECK (bucket_id = 'establishment-photos' AND get_user_role() IN ('admin', 'super_admin'));

CREATE POLICY "Admins can update establishment photos" 
ON storage.objects 
FOR UPDATE 
USING (bucket_id = 'establishment-photos' AND get_user_role() IN ('admin', 'super_admin'));

-- Storage policies for establishment logos
CREATE POLICY "Anyone can view establishment logos" 
ON storage.objects 
FOR SELECT 
USING (bucket_id = 'establishment-logos');

CREATE POLICY "Admins can upload establishment logos" 
ON storage.objects 
FOR INSERT 
WITH CHECK (bucket_id = 'establishment-logos' AND get_user_role() IN ('admin', 'super_admin'));

CREATE POLICY "Admins can update establishment logos" 
ON storage.objects 
FOR UPDATE 
USING (bucket_id = 'establishment-logos' AND get_user_role() IN ('admin', 'super_admin'));

-- Storage policies for establishment covers
CREATE POLICY "Anyone can view establishment covers" 
ON storage.objects 
FOR SELECT 
USING (bucket_id = 'establishment-covers');

CREATE POLICY "Admins can upload establishment covers" 
ON storage.objects 
FOR INSERT 
WITH CHECK (bucket_id = 'establishment-covers' AND get_user_role() IN ('admin', 'super_admin'));

CREATE POLICY "Admins can update establishment covers" 
ON storage.objects 
FOR UPDATE 
USING (bucket_id = 'establishment-covers' AND get_user_role() IN ('admin', 'super_admin'));

-- Storage policies for service photos
CREATE POLICY "Anyone can view service photos" 
ON storage.objects 
FOR SELECT 
USING (bucket_id = 'service-photos');

CREATE POLICY "Admins can upload service photos" 
ON storage.objects 
FOR INSERT 
WITH CHECK (bucket_id = 'service-photos' AND get_user_role() IN ('admin', 'super_admin'));

CREATE POLICY "Admins can update service photos" 
ON storage.objects 
FOR UPDATE 
USING (bucket_id = 'service-photos' AND get_user_role() IN ('admin', 'super_admin'));

-- Storage policies for professional avatars
CREATE POLICY "Anyone can view professional avatars" 
ON storage.objects 
FOR SELECT 
USING (bucket_id = 'professional-avatars');

CREATE POLICY "Professionals can upload their avatars" 
ON storage.objects 
FOR INSERT 
WITH CHECK (bucket_id = 'professional-avatars' AND auth.uid()::text = (storage.foldername(name))[1]);

CREATE POLICY "Professionals can update their avatars" 
ON storage.objects 
FOR UPDATE 
USING (bucket_id = 'professional-avatars' AND auth.uid()::text = (storage.foldername(name))[1]);

-- Update backend configuration and add blocked periods table
CREATE TYPE blocked_period_type AS ENUM ('vacation', 'sick_leave', 'personal', 'maintenance', 'other');

CREATE TABLE public.blocked_periods (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  professional_id UUID NOT NULL,
  start_date DATE NOT NULL,
  end_date DATE NOT NULL,
  start_time TIME,
  end_time TIME,
  type blocked_period_type NOT NULL DEFAULT 'personal',
  reason TEXT,
  is_all_day BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  CONSTRAINT blocked_periods_date_check CHECK (end_date >= start_date)
);

-- Enable RLS
ALTER TABLE public.blocked_periods ENABLE ROW LEVEL SECURITY;

-- RLS policies for blocked periods
CREATE POLICY "Professionals can view their blocked periods" 
ON public.blocked_periods 
FOR SELECT 
USING (EXISTS (
  SELECT 1 FROM profiles p 
  WHERE p.user_id = auth.uid() AND p.id = blocked_periods.professional_id
));

CREATE POLICY "Professionals can create their blocked periods" 
ON public.blocked_periods 
FOR INSERT 
WITH CHECK (EXISTS (
  SELECT 1 FROM profiles p 
  WHERE p.user_id = auth.uid() AND p.id = blocked_periods.professional_id
));

CREATE POLICY "Professionals can update their blocked periods" 
ON public.blocked_periods 
FOR UPDATE 
USING (EXISTS (
  SELECT 1 FROM profiles p 
  WHERE p.user_id = auth.uid() AND p.id = blocked_periods.professional_id
));

CREATE POLICY "Professionals can delete their blocked periods" 
ON public.blocked_periods 
FOR DELETE 
USING (EXISTS (
  SELECT 1 FROM profiles p 
  WHERE p.user_id = auth.uid() AND p.id = blocked_periods.professional_id
));

CREATE POLICY "Admins can view establishment blocked periods" 
ON public.blocked_periods 
FOR SELECT 
USING ((get_user_role() = 'admin') AND EXISTS (
  SELECT 1 FROM professionals pr 
  WHERE pr.id = blocked_periods.professional_id 
  AND pr.establishment_id = get_user_establishment_id()
));

CREATE POLICY "Super admins can manage all blocked periods" 
ON public.blocked_periods 
FOR ALL 
USING (get_user_role() = 'super_admin');

-- Create trigger for updating updated_at
CREATE TRIGGER update_blocked_periods_updated_at
BEFORE UPDATE ON public.blocked_periods
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

-- Create notifications table
CREATE TABLE public.notifications (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  professional_id UUID NOT NULL,
  title TEXT NOT NULL,
  message TEXT NOT NULL,
  type TEXT NOT NULL DEFAULT 'info',
  read BOOLEAN NOT NULL DEFAULT false,
  data JSONB,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;

-- RLS policies for notifications
CREATE POLICY "Professionals can view their notifications" 
ON public.notifications 
FOR SELECT 
USING (EXISTS (
  SELECT 1 FROM profiles p 
  WHERE p.user_id = auth.uid() AND p.id = notifications.professional_id
));

CREATE POLICY "Professionals can update their notifications" 
ON public.notifications 
FOR UPDATE 
USING (EXISTS (
  SELECT 1 FROM profiles p 
  WHERE p.user_id = auth.uid() AND p.id = notifications.professional_id
));

CREATE POLICY "Admins can create notifications for establishment professionals" 
ON public.notifications 
FOR INSERT 
WITH CHECK ((get_user_role() = 'admin') AND EXISTS (
  SELECT 1 FROM professionals pr 
  WHERE pr.id = notifications.professional_id 
  AND pr.establishment_id = get_user_establishment_id()
));

CREATE POLICY "Super admins can manage all notifications" 
ON public.notifications 
FOR ALL 
USING (get_user_role() = 'super_admin');

-- Create trigger for updating updated_at
CREATE TRIGGER update_notifications_updated_at
BEFORE UPDATE ON public.notifications
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();