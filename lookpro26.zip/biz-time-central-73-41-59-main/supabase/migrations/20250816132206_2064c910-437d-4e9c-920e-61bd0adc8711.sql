-- Create storage buckets and policies for file uploads

-- Create storage buckets
INSERT INTO storage.buckets (id, name, public) 
VALUES 
  ('establishments', 'establishments', true),
  ('professionals', 'professionals', true),
  ('services', 'services', true),
  ('categories', 'categories', true)
ON CONFLICT (id) DO NOTHING;

-- Storage policies for categories bucket
CREATE POLICY "Categories images are publicly accessible" 
ON storage.objects FOR SELECT 
USING (bucket_id = 'categories');

CREATE POLICY "Super admins can upload category images" 
ON storage.objects FOR INSERT 
WITH CHECK (
  bucket_id = 'categories' AND 
  EXISTS (SELECT 1 FROM public.users WHERE id = auth.uid() AND role = 'super_admin')
);

CREATE POLICY "Super admins can update category images" 
ON storage.objects FOR UPDATE 
USING (
  bucket_id = 'categories' AND 
  EXISTS (SELECT 1 FROM public.users WHERE id = auth.uid() AND role = 'super_admin')
);

CREATE POLICY "Super admins can delete category images" 
ON storage.objects FOR DELETE 
USING (
  bucket_id = 'categories' AND 
  EXISTS (SELECT 1 FROM public.users WHERE id = auth.uid() AND role = 'super_admin')
);

-- Storage policies for establishments bucket
CREATE POLICY "Establishment images are publicly accessible" 
ON storage.objects FOR SELECT 
USING (bucket_id = 'establishments');

CREATE POLICY "Authenticated users can upload establishment images" 
ON storage.objects FOR INSERT 
WITH CHECK (bucket_id = 'establishments' AND auth.role() = 'authenticated');

CREATE POLICY "Authenticated users can update establishment images" 
ON storage.objects FOR UPDATE 
USING (bucket_id = 'establishments' AND auth.role() = 'authenticated');

CREATE POLICY "Authenticated users can delete establishment images" 
ON storage.objects FOR DELETE 
USING (bucket_id = 'establishments' AND auth.role() = 'authenticated');

-- Storage policies for professionals bucket
CREATE POLICY "Professional images are publicly accessible" 
ON storage.objects FOR SELECT 
USING (bucket_id = 'professionals');

CREATE POLICY "Authenticated users can upload professional images" 
ON storage.objects FOR INSERT 
WITH CHECK (bucket_id = 'professionals' AND auth.role() = 'authenticated');

CREATE POLICY "Authenticated users can update professional images" 
ON storage.objects FOR UPDATE 
USING (bucket_id = 'professionals' AND auth.role() = 'authenticated');

CREATE POLICY "Authenticated users can delete professional images" 
ON storage.objects FOR DELETE 
USING (bucket_id = 'professionals' AND auth.role() = 'authenticated');

-- Storage policies for services bucket
CREATE POLICY "Service images are publicly accessible" 
ON storage.objects FOR SELECT 
USING (bucket_id = 'services');

CREATE POLICY "Authenticated users can upload service images" 
ON storage.objects FOR INSERT 
WITH CHECK (bucket_id = 'services' AND auth.role() = 'authenticated');

CREATE POLICY "Authenticated users can update service images" 
ON storage.objects FOR UPDATE 
USING (bucket_id = 'services' AND auth.role() = 'authenticated');

CREATE POLICY "Authenticated users can delete service images" 
ON storage.objects FOR DELETE 
USING (bucket_id = 'services' AND auth.role() = 'authenticated');

-- Seed data for initial setup
INSERT INTO public.cities (name, state, visible) VALUES
  ('São Paulo', 'SP', true),
  ('Rio de Janeiro', 'RJ', true),
  ('Campinas', 'SP', true),
  ('Belo Horizonte', 'MG', true),
  ('Salvador', 'BA', true)
ON CONFLICT (name) DO NOTHING;

INSERT INTO public.categories (name, active) VALUES
  ('Barbearia', true),
  ('Clínica de Estética', true),
  ('Tatuagem', true),
  ('Salão de Beleza', true),
  ('Spa', true)
ON CONFLICT (name) DO NOTHING;

INSERT INTO public.plans (name, price, period, trial_days, booking_limit, extras, active) VALUES
  ('Basic', 49.90, 'monthly', 7, 200, ARRAY['Relatórios básicos'], true),
  ('Pro', 99.90, 'monthly', 14, 1000, ARRAY['Estatísticas avançadas', 'Notificações'], true),
  ('Enterprise', 199.90, 'monthly', 30, 5000, ARRAY['Relatórios avançados', 'Suporte prioritário', 'API access'], true)
ON CONFLICT (name) DO NOTHING;