-- Get the barbearia category ID
-- Fix Barbearia Continental to have the correct category
WITH barbearia_category AS (
  SELECT id FROM categories WHERE name = 'Barbearia' LIMIT 1
)
UPDATE establishments 
SET category_id = (SELECT id FROM barbearia_category)
WHERE name ILIKE '%continental%' AND category_id IS NULL;

-- Create establishment_categories entry for Continental
WITH continental_est AS (
  SELECT id FROM establishments WHERE name ILIKE '%continental%' LIMIT 1
),
barbearia_category AS (
  SELECT id FROM categories WHERE name = 'Barbearia' LIMIT 1
)
INSERT INTO establishment_categories (establishment_id, category_id, is_primary)
SELECT ce.id, bc.id, true
FROM continental_est ce, barbearia_category bc
WHERE NOT EXISTS (
  SELECT 1 FROM establishment_categories 
  WHERE establishment_id = ce.id AND category_id = bc.id
);