-- Inserir horários de funcionamento para os estabelecimentos
INSERT INTO public.establishment_hours (establishment_id, day_of_week, open_time, close_time, is_closed) VALUES
-- LookBarba Prime - Segunda a Sexta 09:00-19:00, Sábado 09:00-14:00, Domingo fechado
('356e31a3-3b88-4b9d-a647-c4c7400ea1bc', 1, '09:00', '19:00', false), -- Segunda
('356e31a3-3b88-4b9d-a647-c4c7400ea1bc', 2, '09:00', '19:00', false), -- Terça
('356e31a3-3b88-4b9d-a647-c4c7400ea1bc', 3, '09:00', '19:00', false), -- Quarta
('356e31a3-3b88-4b9d-a647-c4c7400ea1bc', 4, '09:00', '19:00', false), -- Quinta
('356e31a3-3b88-4b9d-a647-c4c7400ea1bc', 5, '09:00', '19:00', false), -- Sexta
('356e31a3-3b88-4b9d-a647-c4c7400ea1bc', 6, '09:00', '14:00', false), -- Sábado
('356e31a3-3b88-4b9d-a647-c4c7400ea1bc', 0, NULL, NULL, true), -- Domingo fechado

-- Studio Bela RJ - Segunda a Sexta 10:00-18:00, Sábado 10:00-14:00, Domingo fechado
('23df2895-0618-425f-be3d-1106b2128858', 1, '10:00', '18:00', false), -- Segunda
('23df2895-0618-425f-be3d-1106b2128858', 2, '10:00', '18:00', false), -- Terça
('23df2895-0618-425f-be3d-1106b2128858', 3, '10:00', '18:00', false), -- Quarta
('23df2895-0618-425f-be3d-1106b2128858', 4, '10:00', '18:00', false), -- Quinta
('23df2895-0618-425f-be3d-1106b2128858', 5, '10:00', '18:00', false), -- Sexta
('23df2895-0618-425f-be3d-1106b2128858', 6, '10:00', '14:00', false), -- Sábado
('23df2895-0618-425f-be3d-1106b2128858', 0, NULL, NULL, true), -- Domingo fechado

-- Ink & Flow - Segunda a Sexta 11:00-20:00, Sábado 12:00-18:00, Domingo fechado
('a3ce0609-28f2-48f2-ae69-3c8777282ff2', 1, '11:00', '20:00', false), -- Segunda
('a3ce0609-28f2-48f2-ae69-3c8777282ff2', 2, '11:00', '20:00', false), -- Terça
('a3ce0609-28f2-48f2-ae69-3c8777282ff2', 3, '11:00', '20:00', false), -- Quarta
('a3ce0609-28f2-48f2-ae69-3c8777282ff2', 4, '11:00', '20:00', false), -- Quinta
('a3ce0609-28f2-48f2-ae69-3c8777282ff2', 5, '11:00', '20:00', false), -- Sexta
('a3ce0609-28f2-48f2-ae69-3c8777282ff2', 6, '12:00', '18:00', false), -- Sábado
('a3ce0609-28f2-48f2-ae69-3c8777282ff2', 0, NULL, NULL, true) -- Domingo fechado
ON CONFLICT (establishment_id, day_of_week) DO UPDATE SET
open_time = EXCLUDED.open_time,
close_time = EXCLUDED.close_time,
is_closed = EXCLUDED.is_closed;