-- Corrigir categoria do estabelecimento Kabra Macho
UPDATE establishments 
SET category_id = (SELECT id FROM categories WHERE name = 'Barbearia' LIMIT 1) 
WHERE name = 'Barbearia Kabra Macho' AND category_id IS NULL;

-- Inserir relationship de categoria para o Kabra Macho se não existir
INSERT INTO establishment_categories (establishment_id, category_id, is_primary)
SELECT 
    e.id,
    c.id,
    true
FROM establishments e, categories c
WHERE e.name = 'Barbearia Kabra Macho' 
AND c.name = 'Barbearia'
AND NOT EXISTS (
    SELECT 1 FROM establishment_categories ec 
    WHERE ec.establishment_id = e.id
);

-- Adicionar professional para o Kabra Macho (criar um profissional genérico se necessário)
-- Primeiro, vamos verificar se existe um usuário para o estabelecimento