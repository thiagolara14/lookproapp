-- Storage buckets for CMS assets
INSERT INTO storage.buckets (id, name, public) 
VALUES ('cms-assets', 'cms-assets', true)
ON CONFLICT (id) DO NOTHING;

-- RLS policies for CMS assets storage bucket
CREATE POLICY "Allow public read for CMS assets"
ON storage.objects FOR SELECT
USING (bucket_id = 'cms-assets');

CREATE POLICY "Allow super admin uploads to CMS assets"
ON storage.objects FOR INSERT
WITH CHECK (
  bucket_id = 'cms-assets' AND 
  get_user_role() = 'super_admin'::user_role
);

CREATE POLICY "Allow super admin updates to CMS assets"
ON storage.objects FOR UPDATE
USING (
  bucket_id = 'cms-assets' AND 
  get_user_role() = 'super_admin'::user_role
);

CREATE POLICY "Allow super admin deletes from CMS assets"
ON storage.objects FOR DELETE
USING (
  bucket_id = 'cms-assets' AND 
  get_user_role() = 'super_admin'::user_role
);