-- Create onboarding schema and messages_log table (idempotent)
CREATE SCHEMA IF NOT EXISTS onboarding;

CREATE TABLE IF NOT EXISTS onboarding.messages_log (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  body JSONB NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Enable RLS and secure the table
ALTER TABLE onboarding.messages_log ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON onboarding.messages_log FROM anon, authenticated;

-- Create RPC function to access messages_log from frontend
CREATE OR REPLACE FUNCTION public.get_whatsapp_message_logs(limit_count INTEGER DEFAULT 10)
RETURNS TABLE(id UUID, body JSONB, created_at TIMESTAMPTZ)
LANGUAGE SQL
SECURITY DEFINER
SET search_path = 'onboarding', 'public'
AS $$
  SELECT id, body, created_at
  FROM onboarding.messages_log
  ORDER BY created_at DESC
  LIMIT limit_count;
$$;