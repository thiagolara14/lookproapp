-- Add display_name column to professionals table
ALTER TABLE public.professionals 
ADD COLUMN display_name TEXT;

-- Update the get_establishment_professionals function to include display_name
CREATE OR REPLACE FUNCTION public.get_establishment_professionals(establishment_uuid uuid)
 RETURNS TABLE(id uuid, name text, display_name text, email text, establishment_id uuid, created_at timestamp with time zone, updated_at timestamp with time zone)
 LANGUAGE sql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
  SELECT 
    p.id,
    COALESCE(p.display_name, pr.full_name, 'Profissional') AS name,
    p.display_name,
    pr.email,
    p.establishment_id,
    p.created_at,
    p.updated_at
  FROM professionals p
  LEFT JOIN profiles pr ON pr.user_id = p.user_id
  WHERE p.establishment_id = establishment_uuid
    AND p.active = true;
$function$