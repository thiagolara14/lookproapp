-- Adicionar colunas necessárias à tabela professionals
ALTER TABLE public.professionals
  ADD COLUMN IF NOT EXISTS slug text UNIQUE,
  ADD COLUMN IF NOT EXISTS bio text,
  ADD COLUMN IF NOT EXISTS avatar_path text,
  ADD COLUMN IF NOT EXISTS is_public boolean NOT NULL DEFAULT true;

-- Criar índices para performance
CREATE INDEX IF NOT EXISTS idx_professionals_est ON public.professionals (establishment_id);
CREATE INDEX IF NOT EXISTS idx_professionals_is_public ON public.professionals (is_public);
CREATE INDEX IF NOT EXISTS idx_professionals_slug ON public.professionals (slug);

-- Migrar URLs existentes para caminhos (se necessário)
UPDATE public.professionals
SET avatar_path = regexp_replace(avatar_url, '.*?/object/public/professional-avatars/', '')
WHERE avatar_path IS NULL AND avatar_url LIKE '%/object/public/professional-avatars/%';

-- Políticas RLS para leitura pública
DROP POLICY IF EXISTS "read_public_pros" ON public.professionals;
CREATE POLICY "read_public_pros"
ON public.professionals
FOR SELECT
TO anon, authenticated
USING (is_public = true);

-- Política para storage de avatars (leitura pública)
DROP POLICY IF EXISTS "Public read avatars" ON storage.objects;
CREATE POLICY "Public read avatars"
ON storage.objects 
FOR SELECT
TO anon, authenticated
USING (bucket_id = 'professional-avatars');