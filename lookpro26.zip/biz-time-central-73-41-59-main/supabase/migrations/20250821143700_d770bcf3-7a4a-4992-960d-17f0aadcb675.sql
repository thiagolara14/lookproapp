-- Remover políticas duplicadas e criar apenas as políticas essenciais que estão faltando

-- Remover policy duplicada se existir
DROP POLICY IF EXISTS "Professionals can create their blocked periods" ON public.blocked_periods;

-- Criar a política mais simples para criação de bloqueios
-- Permitir que qualquer profissional autenticado crie bloqueios
CREATE POLICY "Professional can create blocked periods" 
ON public.blocked_periods 
FOR INSERT 
WITH CHECK (
  EXISTS (
    SELECT 1 FROM public.professionals pr 
    WHERE pr.id = blocked_periods.professional_id 
    AND pr.user_id = auth.uid()
  )
);

-- Política para permitir leitura de todos os bloqueios (necessário para verificação de disponibilidade)
DROP POLICY IF EXISTS "Allow read blocked periods for scheduling" ON public.blocked_periods;

CREATE POLICY "Public read for blocked periods" 
ON public.blocked_periods 
FOR SELECT 
USING (true);