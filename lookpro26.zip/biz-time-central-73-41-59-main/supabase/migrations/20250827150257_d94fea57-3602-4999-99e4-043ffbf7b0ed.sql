-- Fix RLS policy for leads table to allow public registration

-- Ensure RLS is enabled on leads table
ALTER TABLE public.leads ENABLE ROW LEVEL SECURITY;

-- Create policy to allow public inserts for lead registration
CREATE POLICY IF NOT EXISTS "Allow public insert for lead registration" 
ON public.leads 
FOR INSERT 
TO public
WITH CHECK (true);

-- Create policy to allow authenticated users to view all leads (for admin)
CREATE POLICY IF NOT EXISTS "Allow authenticated users to view leads" 
ON public.leads 
FOR SELECT 
TO authenticated
USING (true);

-- Create policy to allow authenticated users to update leads (for admin)
CREATE POLICY IF NOT EXISTS "Allow authenticated users to update leads" 
ON public.leads 
FOR UPDATE 
TO authenticated
USING (true);