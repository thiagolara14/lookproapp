-- RLS policies para table professionals
-- Garantir que a tabela tenha RLS habilitado
ALTER TABLE public.professionals ENABLE ROW LEVEL SECURITY;

-- DROP existing conflicting policies if they exist
DROP POLICY IF EXISTS "read professionals public" ON public.professionals;
DROP POLICY IF EXISTS "pro updates own row" ON public.professionals;
DROP POLICY IF EXISTS "pro inserts own row" ON public.professionals;

-- SELECT: Leitura pública de profissionais ativos
CREATE POLICY "read professionals public"
ON public.professionals
FOR SELECT
TO anon, authenticated
USING (active = true AND is_public = true);

-- UPDATE: apenas o dono (user_id = auth.uid())
CREATE POLICY "pro updates own row"
ON public.professionals
FOR UPDATE
TO authenticated
USING (auth.uid() = user_id)
WITH CHECK (auth.uid() = user_id);

-- INSERT: o próprio usuário cria/atualiza seu registro
CREATE POLICY "pro inserts own row"
ON public.professionals
FOR INSERT
TO authenticated
WITH CHECK (auth.uid() = user_id);