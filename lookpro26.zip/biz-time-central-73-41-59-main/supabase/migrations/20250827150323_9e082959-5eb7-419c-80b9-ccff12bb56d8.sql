-- Fix RLS policies for leads table to allow public registration

-- Drop duplicate policies if they exist
DROP POLICY IF EXISTS "Allow public lead creation" ON public.leads;

-- Ensure RLS is enabled on leads table
ALTER TABLE public.leads ENABLE ROW LEVEL SECURITY;

-- Create policy to allow public inserts for lead registration
CREATE POLICY "allow_public_lead_creation" 
ON public.leads 
FOR INSERT 
TO public
WITH CHECK (true);

-- Create policy to allow authenticated users to view all leads (for admin)
CREATE POLICY "allow_authenticated_view_leads" 
ON public.leads 
FOR SELECT 
TO authenticated
USING (true);

-- Create policy to allow authenticated users to update leads (for admin)
CREATE POLICY "allow_authenticated_update_leads" 
ON public.leads 
FOR UPDATE 
TO authenticated
USING (true);