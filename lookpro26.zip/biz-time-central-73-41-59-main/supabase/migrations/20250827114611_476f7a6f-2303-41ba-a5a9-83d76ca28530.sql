-- Create function to get WhatsApp message logs for debug page
CREATE OR REPLACE FUNCTION get_whatsapp_message_logs(limit_count INTEGER DEFAULT 10)
RETURNS TABLE (
  id UUID,
  body JSONB,
  created_at TIMESTAMPTZ
)
LANGUAGE sql
SECURITY DEFINER
SET search_path = 'onboarding', 'public'
AS $$
  SELECT id, body, created_at
  FROM onboarding.messages_log
  ORDER BY created_at DESC
  LIMIT limit_count;
$$;