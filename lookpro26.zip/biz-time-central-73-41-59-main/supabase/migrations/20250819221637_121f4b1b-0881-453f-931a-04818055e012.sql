BEGIN;
-- Allow anonymous reviews by relaxing NOT NULLs
ALTER TABLE public.reviews ALTER COLUMN appointment_id DROP NOT NULL;
ALTER TABLE public.reviews ALTER COLUMN client_id DROP NOT NULL;

-- Update anon insert policy to not require client_id
DROP POLICY IF EXISTS "Anon can create reviews" ON public.reviews;
CREATE POLICY "Anon can create reviews"
ON public.reviews
FOR INSERT
WITH CHECK (
  auth.uid() IS NULL
  AND establishment_id IS NOT NULL
  AND professional_id IS NOT NULL
  AND professional_rating BETWEEN 1 AND 5
  AND establishment_rating BETWEEN 1 AND 5
  AND char_length(COALESCE(comment, '')) <= 1000
);
COMMIT;