-- Garantir que appointments tem os campos necessários para cliente anônimo
ALTER TABLE public.appointments ADD COLUMN IF NOT EXISTS client_phone text;
ALTER TABLE public.appointments ADD COLUMN IF NOT EXISTS client_name text;

-- FK correto para professionals (se ainda não existir)
ALTER TABLE public.appointments DROP CONSTRAINT IF EXISTS appointments_professional_id_fkey;
ALTER TABLE public.appointments
  ADD CONSTRAINT appointments_professional_id_fkey
  FOREIGN KEY (professional_id) REFERENCES public.professionals(id);