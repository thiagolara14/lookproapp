-- Create establishment_categories junction table
CREATE TABLE public.establishment_categories (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  establishment_id UUID NOT NULL REFERENCES public.establishments(id) ON DELETE CASCADE,
  category_id UUID NOT NULL REFERENCES public.categories(id) ON DELETE CASCADE,
  is_primary BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(establishment_id, category_id)
);

-- Enable RLS
ALTER TABLE public.establishment_categories ENABLE ROW LEVEL SECURITY;

-- Create policies for establishment_categories
CREATE POLICY "Everyone can view establishment categories"
ON public.establishment_categories
FOR SELECT
USING (true);

CREATE POLICY "Admins can manage their establishment categories"
ON public.establishment_categories
FOR ALL
USING (
  (get_user_role() = 'admin'::user_role) AND 
  (establishment_id = get_user_establishment_id())
);

CREATE POLICY "Super admins can manage all establishment categories"
ON public.establishment_categories
FOR ALL
USING (get_user_role() = 'super_admin'::user_role);

-- Create CMS settings table for editable homepage content
CREATE TABLE public.cms_settings (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  key TEXT NOT NULL UNIQUE,
  value TEXT NOT NULL,
  description TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.cms_settings ENABLE ROW LEVEL SECURITY;

-- Create policies for CMS settings
CREATE POLICY "Everyone can view CMS settings"
ON public.cms_settings
FOR SELECT
USING (true);

CREATE POLICY "Super admins can manage CMS settings"
ON public.cms_settings
FOR ALL
USING (get_user_role() = 'super_admin'::user_role);

-- Insert default CMS values
INSERT INTO public.cms_settings (key, value, description) VALUES
('hero_title', 'Agende serviços e gerencie seu negócio com LookPro', 'Título principal da homepage'),
('hero_subtitle', 'Vitrine pública, agendamento sem conta e painéis para cliente, profissional, admin e super admin.', 'Subtítulo da homepage'),
('app_name', 'LookPro', 'Nome da aplicação'),
('app_description', 'Agendamento online, vitrine e gestão completa para serviços locais.', 'Descrição da aplicação');

-- Create trigger for auto-updating updated_at
CREATE TRIGGER update_cms_settings_updated_at
BEFORE UPDATE ON public.cms_settings
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

-- Create function to get real metrics for dashboard
CREATE OR REPLACE FUNCTION public.get_super_admin_metrics()
RETURNS JSON
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  result JSON;
  total_establishments INT;
  active_establishments INT;
  inactive_establishments INT;
  total_appointments INT;
  unique_clients INT;
  city_data JSON;
  category_data JSON;
  period_data JSON;
BEGIN
  -- Check if user has super admin role
  IF get_user_role() != 'super_admin'::user_role THEN
    RAISE EXCEPTION 'Access denied. Only super admins can view metrics.';
  END IF;

  -- Count establishments
  SELECT COUNT(*) INTO total_establishments FROM establishments;
  SELECT COUNT(*) INTO active_establishments FROM establishments WHERE status = 'active';
  inactive_establishments := total_establishments - active_establishments;

  -- Count appointments
  SELECT COUNT(*) INTO total_appointments FROM appointments;

  -- Count unique clients (by phone for anonymous bookings, by client_id for logged in)
  SELECT COUNT(DISTINCT COALESCE(client_id::text, client_phone)) 
  INTO unique_clients 
  FROM appointments 
  WHERE COALESCE(client_id::text, client_phone) IS NOT NULL;

  -- Establishments by city
  SELECT JSON_AGG(
    JSON_BUILD_OBJECT(
      'city', city,
      'count', count
    )
  ) INTO city_data
  FROM (
    SELECT city, COUNT(*) as count
    FROM establishments 
    GROUP BY city
    ORDER BY count DESC
  ) city_counts;

  -- Establishments by category (using junction table)
  SELECT JSON_AGG(
    JSON_BUILD_OBJECT(
      'type', name,
      'count', count
    )
  ) INTO category_data
  FROM (
    SELECT c.name, COUNT(DISTINCT ec.establishment_id) as count
    FROM categories c
    LEFT JOIN establishment_categories ec ON c.id = ec.category_id
    GROUP BY c.id, c.name
    ORDER BY count DESC
  ) category_counts;

  -- Appointments by period (last 14 days)
  SELECT JSON_AGG(
    JSON_BUILD_OBJECT(
      'date', date,
      'count', count
    ) ORDER BY date
  ) INTO period_data
  FROM (
    SELECT 
      date_series::date as date,
      COALESCE(appointment_counts.count, 0) as count
    FROM (
      SELECT generate_series(
        CURRENT_DATE - INTERVAL '13 days',
        CURRENT_DATE,
        INTERVAL '1 day'
      )::date as date_series
    ) dates
    LEFT JOIN (
      SELECT 
        appointment_date,
        COUNT(*) as count
      FROM appointments
      WHERE appointment_date >= CURRENT_DATE - INTERVAL '13 days'
      GROUP BY appointment_date
    ) appointment_counts ON dates.date_series = appointment_counts.appointment_date
  ) period_counts;

  -- Build final result
  result := JSON_BUILD_OBJECT(
    'totalEst', total_establishments,
    'active', active_establishments,
    'inactive', inactive_establishments,
    'totalBookings', total_appointments,
    'uniqueUsers', unique_clients,
    'mrr', 0, -- Mock value for now
    'arr', 0, -- Mock value for now
    'byCity', COALESCE(city_data, '[]'::json),
    'byCategory', COALESCE(category_data, '[]'::json),
    'byPeriod', COALESCE(period_data, '[]'::json),
    'revenueByPlan', '[]'::json -- Mock value for now
  );

  RETURN result;
END;
$$;