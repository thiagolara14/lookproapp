-- Add columns for anonymous client support (if they don't exist)
ALTER TABLE public.appointments 
ADD COLUMN IF NOT EXISTS client_phone text,
ADD COLUMN IF NOT EXISTS client_name text;