-- Adicionar "pro" ao enum user_role
ALTER TYPE user_role ADD VALUE 'pro';

-- Migrar dados de "professional" para "pro"
UPDATE profiles SET role = 'pro' WHERE role = 'professional';

-- Opcional: remover "professional" do enum (comentado pois pode quebrar se houver dependências)
-- Primeiro precisamos recriar o enum sem "professional"
-- CREATE TYPE user_role_new AS ENUM ('super_admin', 'admin', 'pro', 'client');
-- ALTER TABLE profiles ALTER COLUMN role TYPE user_role_new USING role::text::user_role_new;
-- DROP TYPE user_role;
-- ALTER TYPE user_role_new RENAME TO user_role;