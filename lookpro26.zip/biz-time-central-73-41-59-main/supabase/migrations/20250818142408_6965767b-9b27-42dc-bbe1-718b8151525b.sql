-- 1) Update handle_new_user to also set establishment_id from metadata
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
BEGIN
  INSERT INTO public.profiles (user_id, email, full_name, role, establishment_id)
  VALUES (
    NEW.id,
    NEW.email,
    COALESCE(NEW.raw_user_meta_data ->> 'full_name', NEW.email),
    COALESCE((NEW.raw_user_meta_data ->> 'role')::user_role, 'client'),
    NULLIF(NEW.raw_user_meta_data ->> 'establishment_id', '')::uuid
  );
  RETURN NEW;
END;
$function$;

-- 2) Ensure Thiago is linked to Barbearia Bonini and has admin role
UPDATE public.profiles
SET establishment_id = 'b6cf2cb5-6756-4bb3-b016-010af6bb041a', role = 'admin'
WHERE email = 'thiago.lara23@gmail.com';