-- Criar função para obter horários de funcionamento do estabelecimento
CREATE OR REPLACE FUNCTION public.get_establishment_working_hours(establishment_uuid uuid)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = 'public'
AS $$
DECLARE
  hours_data jsonb;
BEGIN
  -- Buscar horários de funcionamento por dia da semana
  SELECT jsonb_object_agg(
    day_of_week::text,
    CASE 
      WHEN is_closed THEN jsonb_build_object('closed', true)
      ELSE jsonb_build_object(
        'start', open_time::text,
        'end', close_time::text,
        'closed', false
      )
    END
  ) INTO hours_data
  FROM establishment_hours
  WHERE establishment_id = establishment_uuid;
  
  -- Se não houver dados específicos, retornar horário padrão
  IF hours_data IS NULL THEN
    hours_data := jsonb_build_object(
      '1', jsonb_build_object('start', '09:00', 'end', '18:00', 'closed', false),
      '2', jsonb_build_object('start', '09:00', 'end', '18:00', 'closed', false),
      '3', jsonb_build_object('start', '09:00', 'end', '18:00', 'closed', false),
      '4', jsonb_build_object('start', '09:00', 'end', '18:00', 'closed', false),
      '5', jsonb_build_object('start', '09:00', 'end', '18:00', 'closed', false),
      '6', jsonb_build_object('start', '09:00', 'end', '14:00', 'closed', false),
      '0', jsonb_build_object('closed', true)
    );
  END IF;
  
  RETURN hours_data;
END;
$$;