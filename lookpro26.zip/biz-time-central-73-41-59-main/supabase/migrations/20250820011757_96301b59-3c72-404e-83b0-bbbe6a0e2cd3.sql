-- Create RLS policies for professional-avatars bucket

-- Policy to allow professionals to upload their own avatars
CREATE POLICY "Professionals can upload their own avatars" 
ON storage.objects 
FOR INSERT 
WITH CHECK (
  bucket_id = 'professional-avatars' 
  AND auth.uid() IS NOT NULL
  AND EXISTS (
    SELECT 1 FROM professionals p 
    WHERE p.user_id = auth.uid() 
    AND p.id::text = (storage.foldername(name))[1]
  )
);

-- Policy to allow professionals to update their own avatars
CREATE POLICY "Professionals can update their own avatars" 
ON storage.objects 
FOR UPDATE 
USING (
  bucket_id = 'professional-avatars' 
  AND auth.uid() IS NOT NULL
  AND EXISTS (
    SELECT 1 FROM professionals p 
    WHERE p.user_id = auth.uid() 
    AND p.id::text = (storage.foldername(name))[1]
  )
);

-- Policy to allow everyone to view professional avatars (since bucket is public)
CREATE POLICY "Everyone can view professional avatars" 
ON storage.objects 
FOR SELECT 
USING (bucket_id = 'professional-avatars');

-- Policy to allow professionals to delete their own avatars
CREATE POLICY "Professionals can delete their own avatars" 
ON storage.objects 
FOR DELETE 
USING (
  bucket_id = 'professional-avatars' 
  AND auth.uid() IS NOT NULL
  AND EXISTS (
    SELECT 1 FROM professionals p 
    WHERE p.user_id = auth.uid() 
    AND p.id::text = (storage.foldername(name))[1]
  )
);