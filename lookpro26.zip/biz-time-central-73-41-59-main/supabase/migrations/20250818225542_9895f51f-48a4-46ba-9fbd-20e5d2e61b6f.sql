-- Inserir profile para o profissional existente que não tem profile
INSERT INTO public.profiles (user_id, email, full_name, role, establishment_id)
SELECT 
  p.user_id,
  'profissional@barbeariabonini.com' as email,
  'João Silva' as full_name,
  'professional' as role,
  p.establishment_id
FROM professionals p
LEFT JOIN profiles pr ON p.user_id = pr.user_id
WHERE pr.user_id IS NULL
AND p.establishment_id = 'b6cf2cb5-6756-4bb3-b016-010af6bb041a';