-- Create storage bucket for tenant assets
INSERT INTO storage.buckets (id, name, public)
VALUES ('tenant-assets', 'tenant-assets', true);

-- Create RLS policies for tenant assets
CREATE POLICY "Avatar images are publicly accessible" 
ON storage.objects 
FOR SELECT 
USING (bucket_id = 'tenant-assets');

CREATE POLICY "Allow public uploads to tenant assets" 
ON storage.objects 
FOR INSERT 
WITH CHECK (bucket_id = 'tenant-assets');

CREATE POLICY "Allow updates to tenant assets" 
ON storage.objects 
FOR UPDATE 
USING (bucket_id = 'tenant-assets');