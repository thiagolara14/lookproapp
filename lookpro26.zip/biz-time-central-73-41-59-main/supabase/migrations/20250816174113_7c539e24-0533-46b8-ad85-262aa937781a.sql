-- Update categories with the generated image URLs
UPDATE categories 
SET image_url = CASE 
  WHEN name = 'Barbearia' THEN '/images/categories/barbearia.jpg'
  WHEN name = 'Salão de Beleza' THEN '/images/categories/salao-beleza.jpg'
  WHEN name = 'Manicure/Pedicure' THEN '/images/categories/manicure-pedicure.jpg'
  WHEN name = 'Estética' THEN '/images/categories/estetica.jpg'
  WHEN name = 'Clínica de Depilação' THEN '/images/categories/clinica-depilacao.jpg'
  WHEN name = 'Clínica de Massagem/Terapias' THEN '/images/categories/clinica-massagem.jpg'
  WHEN name = 'Clínica de Estética Avançada' THEN '/images/categories/estetica-avancada.jpg'
  WHEN name = 'Clínica Capilar' THEN '/images/categories/clinica-capilar.jpg'
  WHEN name = 'Podologia' THEN '/images/categories/podologia.jpg'
  WHEN name = 'Terapia Capilar' THEN '/images/categories/terapia-capilar.jpg'
  WHEN name = 'Bronzeamento Artificial' THEN '/images/categories/bronzeamento.jpg'
  WHEN name = 'Barbearia Infantil' THEN '/images/categories/barbearia-infantil.jpg'
  WHEN name = 'Tatuagem/Piercing' THEN '/images/categories/tatuagem-piercing.jpg'
  WHEN name = 'Consultoria de Imagem' THEN '/images/categories/consultoria-imagem.jpg'
  WHEN name = 'Clínica Dermatológica/Capilar Avançada' THEN '/images/categories/dermatologia-capilar.jpg'
  ELSE image_url
END
WHERE name IN (
  'Barbearia', 'Salão de Beleza', 'Manicure/Pedicure', 'Estética', 
  'Clínica de Depilação', 'Clínica de Massagem/Terapias', 
  'Clínica de Estética Avançada', 'Clínica Capilar', 'Podologia', 
  'Terapia Capilar', 'Bronzeamento Artificial', 'Barbearia Infantil', 
  'Tatuagem/Piercing', 'Consultoria de Imagem', 
  'Clínica Dermatológica/Capilar Avançada'
);