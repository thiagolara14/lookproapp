-- Adicionar soft delete para profiles (profissionais)
ALTER TABLE public.profiles 
ADD COLUMN IF NOT EXISTS deleted_at TIMESTAMPTZ;

-- Criar índice para performance na consulta de profissionais ativos
CREATE INDEX IF NOT EXISTS idx_profiles_deleted_at 
ON public.profiles (deleted_at) 
WHERE deleted_at IS NULL;

-- Atualizar RLS policy para filtrar profissionais deletados da visualização pública
DROP POLICY IF EXISTS "Everyone can view active professionals" ON public.professionals;
CREATE POLICY "Everyone can view active professionals" 
ON public.professionals 
FOR SELECT 
USING (
  active = true 
  AND is_public = true 
  AND EXISTS (
    SELECT 1 FROM public.profiles p 
    WHERE p.user_id = professionals.user_id 
    AND p.deleted_at IS NULL
  )
);