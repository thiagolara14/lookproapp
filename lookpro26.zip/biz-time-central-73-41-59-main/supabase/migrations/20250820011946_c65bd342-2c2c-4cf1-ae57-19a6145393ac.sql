-- Drop existing policies for professional-avatars bucket
DROP POLICY IF EXISTS "Professionals can upload their own avatars" ON storage.objects;
DROP POLICY IF EXISTS "Professionals can update their own avatars" ON storage.objects;
DROP POLICY IF EXISTS "Everyone can view professional avatars" ON storage.objects;
DROP POLICY IF EXISTS "Professionals can delete their own avatars" ON storage.objects;

-- Create simpler policies that work with direct filename structure
CREATE POLICY "Allow professional avatar uploads"
ON storage.objects FOR INSERT
WITH CHECK (
  bucket_id = 'professional-avatars' 
  AND auth.uid() IS NOT NULL
  AND EXISTS (
    SELECT 1 FROM professionals p 
    WHERE p.user_id = auth.uid() 
    AND name LIKE p.id::text || '.%'
  )
);

CREATE POLICY "Allow professional avatar updates"
ON storage.objects FOR UPDATE
USING (
  bucket_id = 'professional-avatars' 
  AND auth.uid() IS NOT NULL
  AND EXISTS (
    SELECT 1 FROM professionals p 
    WHERE p.user_id = auth.uid() 
    AND name LIKE p.id::text || '.%'
  )
);

CREATE POLICY "Allow professional avatar deletes"
ON storage.objects FOR DELETE
USING (
  bucket_id = 'professional-avatars' 
  AND auth.uid() IS NOT NULL
  AND EXISTS (
    SELECT 1 FROM professionals p 
    WHERE p.user_id = auth.uid() 
    AND name LIKE p.id::text || '.%'
  )
);

CREATE POLICY "Allow public access to professional avatars"
ON storage.objects FOR SELECT
USING (bucket_id = 'professional-avatars');