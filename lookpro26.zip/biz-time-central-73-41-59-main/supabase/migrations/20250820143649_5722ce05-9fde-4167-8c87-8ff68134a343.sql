-- Atualizar dados do profissional com informações completas
UPDATE professionals 
SET bio = '{"description": "Profissional experiente em cortes masculinos e cuidados com barba", "whatsapp": "(11) 99999-9999", "experienceYears": 5}',
    specialties = ARRAY['Corte Masculino', 'Barba', 'Bigode'],
    avatar_url = 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&h=150&fit=crop&crop=face'
WHERE user_id = '1e9367ec-c24a-4dba-8f5a-675cee47eec9';

-- Atualizar dados do profile
UPDATE profiles 
SET full_name = 'Thiago Barbeiro',
    phone = '(11) 99999-9999'
WHERE user_id = '1e9367ec-c24a-4dba-8f5a-675cee47eec9';