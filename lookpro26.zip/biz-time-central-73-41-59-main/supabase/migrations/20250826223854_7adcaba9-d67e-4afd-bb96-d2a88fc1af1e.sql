-- Create onboarding leads table
CREATE TABLE public.leads (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  estabelecimento TEXT NOT NULL,
  responsavel TEXT NOT NULL,
  whatsapp TEXT NOT NULL,
  cidade TEXT NOT NULL,
  tipo TEXT NOT NULL,
  servicos_json JSONB NOT NULL DEFAULT '[]'::jsonb,
  status TEXT NOT NULL DEFAULT 'novo' CHECK (status IN ('novo', 'em_provisionamento', 'entregue', 'erro')),
  foto_url TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create tenants table for provisioned establishments
CREATE TABLE public.tenants (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  lead_id UUID NOT NULL REFERENCES public.leads(id),
  slug TEXT NOT NULL UNIQUE,
  url_publica TEXT NOT NULL,
  url_admin TEXT NOT NULL,
  plano TEXT NOT NULL DEFAULT 'trial',
  trial_ends_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT (now() + INTERVAL '7 days'),
  cover_url TEXT,
  active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create admin users for tenants
CREATE TABLE public.tenant_users (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  tenant_id UUID NOT NULL REFERENCES public.tenants(id),
  role TEXT NOT NULL DEFAULT 'admin',
  login TEXT NOT NULL,
  senha_hash TEXT NOT NULL,
  phone TEXT,
  must_reset_password BOOLEAN NOT NULL DEFAULT true,
  first_login_at TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create initial services for tenants
CREATE TABLE public.tenant_services (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  tenant_id UUID NOT NULL REFERENCES public.tenants(id),
  nome TEXT NOT NULL,
  preco NUMERIC(10,2) NOT NULL DEFAULT 50.00,
  duracao_min INTEGER NOT NULL DEFAULT 30,
  active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create tenant settings
CREATE TABLE public.tenant_settings (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  tenant_id UUID NOT NULL REFERENCES public.tenants(id),
  horario_funcionamento_json JSONB NOT NULL DEFAULT '{"seg_sab": {"inicio": "09:00", "fim": "19:00"}, "domingo": {"fechado": true}}'::jsonb,
  notificacoes_json JSONB NOT NULL DEFAULT '{"whatsapp": true, "email": true}'::jsonb,
  slot_duracao_min INTEGER NOT NULL DEFAULT 30,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(tenant_id)
);

-- Create indexes for performance
CREATE INDEX idx_leads_status ON public.leads(status);
CREATE INDEX idx_leads_created_at ON public.leads(created_at);
CREATE INDEX idx_tenants_slug ON public.tenants(slug);
CREATE INDEX idx_tenants_lead_id ON public.tenants(lead_id);
CREATE INDEX idx_tenant_users_tenant_id ON public.tenant_users(tenant_id);
CREATE INDEX idx_tenant_services_tenant_id ON public.tenant_services(tenant_id);

-- Enable RLS on all tables
ALTER TABLE public.leads ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.tenants ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.tenant_users ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.tenant_services ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.tenant_settings ENABLE ROW LEVEL SECURITY;

-- RLS Policies for leads (public insertion allowed for onboarding)
CREATE POLICY "Allow public lead creation" ON public.leads
  FOR INSERT WITH CHECK (true);

CREATE POLICY "Super admins can manage all leads" ON public.leads
  FOR ALL USING (get_user_role() = 'super_admin'::user_role);

-- RLS Policies for tenants
CREATE POLICY "Public can view active tenants by slug" ON public.tenants
  FOR SELECT USING (active = true);

CREATE POLICY "Super admins can manage all tenants" ON public.tenants
  FOR ALL USING (get_user_role() = 'super_admin'::user_role);

-- RLS Policies for tenant users
CREATE POLICY "Super admins can manage tenant users" ON public.tenant_users
  FOR ALL USING (get_user_role() = 'super_admin'::user_role);

-- RLS Policies for tenant services
CREATE POLICY "Public can view tenant services" ON public.tenant_services
  FOR SELECT USING (active = true);

CREATE POLICY "Super admins can manage tenant services" ON public.tenant_services
  FOR ALL USING (get_user_role() = 'super_admin'::user_role);

-- RLS Policies for tenant settings
CREATE POLICY "Public can view tenant settings" ON public.tenant_settings
  FOR SELECT USING (true);

CREATE POLICY "Super admins can manage tenant settings" ON public.tenant_settings
  FOR ALL USING (get_user_role() = 'super_admin'::user_role);

-- Update timestamp function
CREATE OR REPLACE FUNCTION update_onboarding_updated_at()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;

-- Add triggers for updated_at
CREATE TRIGGER update_leads_updated_at
  BEFORE UPDATE ON public.leads
  FOR EACH ROW
  EXECUTE FUNCTION update_onboarding_updated_at();

CREATE TRIGGER update_tenants_updated_at
  BEFORE UPDATE ON public.tenants
  FOR EACH ROW
  EXECUTE FUNCTION update_onboarding_updated_at();

CREATE TRIGGER update_tenant_users_updated_at
  BEFORE UPDATE ON public.tenant_users
  FOR EACH ROW
  EXECUTE FUNCTION update_onboarding_updated_at();

CREATE TRIGGER update_tenant_services_updated_at
  BEFORE UPDATE ON public.tenant_services
  FOR EACH ROW
  EXECUTE FUNCTION update_onboarding_updated_at();

CREATE TRIGGER update_tenant_settings_updated_at
  BEFORE UPDATE ON public.tenant_settings
  FOR EACH ROW
  EXECUTE FUNCTION update_onboarding_updated_at();