-- Update professionals table with required columns
ALTER TABLE public.professionals
  ADD COLUMN IF NOT EXISTS slug text UNIQUE,
  ADD COLUMN IF NOT EXISTS bio text,
  ADD COLUMN IF NOT EXISTS avatar_path text,
  ADD COLUMN IF NOT EXISTS is_public boolean NOT NULL DEFAULT true;

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_professionals_est ON public.professionals (establishment_id);
CREATE INDEX IF NOT EXISTS idx_professionals_slug ON public.professionals (slug);
CREATE INDEX IF NOT EXISTS idx_professionals_is_public ON public.professionals (is_public);

-- Update RLS policies for public reading
DROP POLICY IF EXISTS "read_public_pros" ON public.professionals;
CREATE POLICY "read_public_pros"
  ON public.professionals
  FOR SELECT
  TO anon, authenticated
  USING (is_public = true);

-- Storage policy for public avatar reading
DROP POLICY IF EXISTS "Public read avatars" ON storage.objects;
CREATE POLICY "Public read avatars"
  ON storage.objects 
  FOR SELECT
  TO anon, authenticated
  USING (bucket_id = 'professional-avatars');