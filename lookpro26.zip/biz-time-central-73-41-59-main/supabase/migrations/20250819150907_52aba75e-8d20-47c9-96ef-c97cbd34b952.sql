-- Habilitar RLS na tabela appointments se não estiver habilitado
ALTER TABLE public.appointments ENABLE ROW LEVEL SECURITY;

-- Política para permitir que qualquer pessoa possa criar agendamentos (clientes anônimos)
CREATE POLICY "Permitir inserção de agendamentos para todos" 
ON public.appointments 
FOR INSERT 
WITH CHECK (true);

-- Política para permitir leitura de agendamentos para verificar disponibilidade
CREATE POLICY "Permitir leitura de agendamentos para verificar horários" 
ON public.appointments 
FOR SELECT 
USING (true);

-- Política para estabelecimentos e profissionais atualizarem seus agendamentos
CREATE POLICY "Profissionais podem atualizar agendamentos do seu estabelecimento" 
ON public.appointments 
FOR UPDATE 
USING (
  EXISTS (
    SELECT 1 FROM public.profiles p
    WHERE p.user_id = auth.uid()
    AND (
      p.role IN ('admin', 'professional') 
      AND p.establishment_id = appointments.establishment_id
    )
  )
  OR
  EXISTS (
    SELECT 1 FROM public.profiles p
    WHERE p.user_id = auth.uid()
    AND p.role = 'super_admin'
  )
);

-- Política para estabelecimentos e profissionais deletarem agendamentos
CREATE POLICY "Profissionais podem deletar agendamentos do seu estabelecimento" 
ON public.appointments 
FOR DELETE 
USING (
  EXISTS (
    SELECT 1 FROM public.profiles p
    WHERE p.user_id = auth.uid()
    AND (
      p.role IN ('admin', 'professional') 
      AND p.establishment_id = appointments.establishment_id
    )
  )
  OR
  EXISTS (
    SELECT 1 FROM public.profiles p
    WHERE p.user_id = auth.uid()
    AND p.role = 'super_admin'
  )
);