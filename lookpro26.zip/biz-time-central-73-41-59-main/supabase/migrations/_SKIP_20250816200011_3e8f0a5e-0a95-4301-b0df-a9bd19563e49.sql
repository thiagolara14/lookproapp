-- Ajustar FK de appointments.professional_id para apontar para users(id)
ALTER TABLE public.appointments DROP CONSTRAINT IF EXISTS appointments_professional_id_fkey;
ALTER TABLE public.appointments
  ADD CONSTRAINT appointments_professional_id_fkey
  FOREIGN KEY (professional_id) REFERENCES public.profiles(id);

-- Adicionar campos para dados do cliente anônimo
ALTER TABLE public.appointments ADD COLUMN IF NOT EXISTS client_phone text;
ALTER TABLE public.appointments ADD COLUMN IF NOT EXISTS client_name text;