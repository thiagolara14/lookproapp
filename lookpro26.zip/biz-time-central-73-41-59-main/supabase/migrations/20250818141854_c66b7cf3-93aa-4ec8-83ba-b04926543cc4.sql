-- Associar o usuário admin atual ao primeiro estabelecimento
UPDATE profiles 
SET establishment_id = 'd873afa3-f7ae-4f4f-bcdd-8b975ff2ea1c'
WHERE user_id = '5c300950-2c85-4ee2-8e45-f9db71b021b9' AND role = 'admin';

-- Verificar se existem outros admins sem estabelecimento associado
-- Se existirem, vamos associá-los aos estabelecimentos disponíveis