-- Add RLS policies for the new onboarding tables
ALTER TABLE onboarding.intake_meta ENABLE ROW LEVEL SECURITY;
ALTER TABLE onboarding.messages_log ENABLE ROW LEVEL SECURITY;

-- RLS policies - only service role can access (server-side only)
CREATE POLICY "Service role can manage intake_meta" ON onboarding.intake_meta
  FOR ALL USING (auth.role() = 'service_role');

CREATE POLICY "Service role can manage messages_log" ON onboarding.messages_log
  FOR ALL USING (auth.role() = 'service_role');

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_intake_meta_lead_id ON onboarding.intake_meta(lead_id);
CREATE INDEX IF NOT EXISTS idx_intake_meta_created_at ON onboarding.intake_meta(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_messages_log_lead_id ON onboarding.messages_log(lead_id);