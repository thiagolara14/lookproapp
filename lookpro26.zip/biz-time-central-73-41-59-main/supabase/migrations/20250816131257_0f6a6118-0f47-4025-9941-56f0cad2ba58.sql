-- Initial database schema for LookPro migration from Firebase to Supabase

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Create custom types
CREATE TYPE user_role AS ENUM ('super_admin', 'admin', 'pro', 'client');
CREATE TYPE establishment_status AS ENUM ('active', 'inactive');
CREATE TYPE appointment_status AS ENUM ('scheduled', 'confirmed', 'cancelled', 'completed');

-- Create tables
CREATE TABLE public.cities (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text UNIQUE NOT NULL,
  state text,
  visible boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE TABLE public.categories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text UNIQUE NOT NULL,
  image_url text,
  active boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE TABLE public.plans (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  price numeric(12,2) NOT NULL,
  period text CHECK (period IN ('monthly', 'yearly')) DEFAULT 'monthly',
  trial_days integer DEFAULT 0,
  booking_limit integer DEFAULT 0,
  extras text[] DEFAULT '{}',
  active boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Users table (synced with auth.users)
CREATE TABLE public.users (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email text NOT NULL,
  display_name text,
  photo_url text,
  role user_role DEFAULT 'client',
  establishment_id uuid,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE TABLE public.establishments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  description text,
  logo_url text,
  cover_image_url text,
  email text,
  phone text,
  address text NOT NULL,
  city text NOT NULL,
  state text NOT NULL,
  city_id uuid REFERENCES public.cities(id),
  category_id uuid REFERENCES public.categories(id),
  plan_id uuid REFERENCES public.plans(id),
  status establishment_status DEFAULT 'active',
  last_access_at timestamptz,
  is_featured boolean DEFAULT false,
  website text,
  slug text,
  monthly_fee numeric(12,2) DEFAULT 99.90,
  subscription_start_date timestamptz DEFAULT now(),
  next_payment_date timestamptz DEFAULT (now() + interval '30 days'),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Add foreign key to users table
ALTER TABLE public.users ADD CONSTRAINT fk_users_establishment 
  FOREIGN KEY (establishment_id) REFERENCES public.establishments(id);

CREATE TABLE public.professionals (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES public.users(id) ON DELETE CASCADE,
  establishment_id uuid REFERENCES public.establishments(id) ON DELETE CASCADE,
  avatar_url text,
  bio text,
  specialties text[],
  active boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE TABLE public.services (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  establishment_id uuid REFERENCES public.establishments(id) ON DELETE CASCADE,
  category_id uuid REFERENCES public.categories(id),
  name text NOT NULL,
  description text,
  price numeric(12,2) NOT NULL,
  duration_minutes integer NOT NULL,
  image_url text,
  is_active boolean DEFAULT true,
  sort_order integer DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE TABLE public.appointments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  establishment_id uuid REFERENCES public.establishments(id) ON DELETE CASCADE,
  professional_id uuid REFERENCES public.professionals(id),
  client_id uuid REFERENCES public.users(id),
  service_id uuid REFERENCES public.services(id),
  appointment_date date NOT NULL,
  start_time time NOT NULL,
  end_time time NOT NULL,
  total_price numeric(12,2) NOT NULL,
  status appointment_status DEFAULT 'scheduled',
  notes text,
  cancelled_at timestamptz,
  confirmed_at timestamptz,
  completed_at timestamptz,
  cancellation_reason text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE TABLE public.reviews (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  establishment_id uuid REFERENCES public.establishments(id) ON DELETE CASCADE,
  professional_id uuid REFERENCES public.professionals(id),
  client_id uuid REFERENCES public.users(id),
  appointment_id uuid REFERENCES public.appointments(id),
  establishment_rating integer CHECK (establishment_rating >= 1 AND establishment_rating <= 5),
  professional_rating integer CHECK (professional_rating >= 1 AND professional_rating <= 5),
  comment text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE TABLE public.establishment_hours (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  establishment_id uuid REFERENCES public.establishments(id) ON DELETE CASCADE,
  day_of_week integer CHECK (day_of_week >= 0 AND day_of_week <= 6), -- 0 = Sunday
  open_time time,
  close_time time,
  is_closed boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);

CREATE TABLE public.establishment_photos (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  establishment_id uuid REFERENCES public.establishments(id) ON DELETE CASCADE,
  url text NOT NULL,
  caption text,
  sort_order integer DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

-- Create indexes for performance
CREATE INDEX idx_users_establishment_id ON public.users(establishment_id);
CREATE INDEX idx_users_role ON public.users(role);
CREATE INDEX idx_establishments_city_id ON public.establishments(city_id);
CREATE INDEX idx_establishments_category_id ON public.establishments(category_id);
CREATE INDEX idx_establishments_status ON public.establishments(status);
CREATE INDEX idx_professionals_establishment_id ON public.professionals(establishment_id);
CREATE INDEX idx_services_establishment_id ON public.services(establishment_id);
CREATE INDEX idx_appointments_establishment_id ON public.appointments(establishment_id);
CREATE INDEX idx_appointments_professional_id ON public.appointments(professional_id);
CREATE INDEX idx_appointments_client_id ON public.appointments(client_id);
CREATE INDEX idx_appointments_date ON public.appointments(appointment_date);
CREATE INDEX idx_reviews_establishment_id ON public.reviews(establishment_id);
CREATE INDEX idx_reviews_created_at ON public.reviews(created_at);

-- Create functions for RLS
CREATE OR REPLACE FUNCTION public.get_user_role(user_uuid uuid DEFAULT auth.uid())
RETURNS user_role
LANGUAGE sql
STABLE SECURITY DEFINER
SET search_path TO 'public'
AS $$
  SELECT role FROM public.users WHERE id = user_uuid;
$$;

CREATE OR REPLACE FUNCTION public.get_user_establishment_id(user_uuid uuid DEFAULT auth.uid())
RETURNS uuid
LANGUAGE sql
STABLE SECURITY DEFINER
SET search_path TO 'public'
AS $$
  SELECT establishment_id FROM public.users WHERE id = user_uuid;
$$;

-- Function to handle new user creation
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
BEGIN
  INSERT INTO public.users (id, email, display_name, role)
  VALUES (
    NEW.id,
    NEW.email,
    COALESCE(NEW.raw_user_meta_data ->> 'display_name', NEW.email),
    COALESCE((NEW.raw_user_meta_data ->> 'role')::user_role, 'client')
  );
  RETURN NEW;
END;
$$;

-- Create trigger for new users
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- Function to update updated_at timestamp
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;

-- Add update triggers to all tables with updated_at
CREATE TRIGGER update_cities_updated_at BEFORE UPDATE ON public.cities FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER update_categories_updated_at BEFORE UPDATE ON public.categories FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER update_plans_updated_at BEFORE UPDATE ON public.plans FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON public.users FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER update_establishments_updated_at BEFORE UPDATE ON public.establishments FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER update_professionals_updated_at BEFORE UPDATE ON public.professionals FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER update_services_updated_at BEFORE UPDATE ON public.services FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER update_appointments_updated_at BEFORE UPDATE ON public.appointments FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER update_reviews_updated_at BEFORE UPDATE ON public.reviews FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- Enable Row Level Security on all tables
ALTER TABLE public.cities ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.plans ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.users ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.establishments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.professionals ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.services ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.appointments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.reviews ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.establishment_hours ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.establishment_photos ENABLE ROW LEVEL SECURITY;

-- Create RLS policies for cities
CREATE POLICY "Cities are viewable by everyone" ON public.cities
  FOR SELECT USING (true);

CREATE POLICY "Super admins can manage cities" ON public.cities
  FOR ALL USING (get_user_role() = 'super_admin');

-- Create RLS policies for categories
CREATE POLICY "Categories are viewable by everyone" ON public.categories
  FOR SELECT USING (true);

CREATE POLICY "Super admins can manage categories" ON public.categories
  FOR ALL USING (get_user_role() = 'super_admin');

-- Create RLS policies for plans
CREATE POLICY "Plans are viewable by everyone" ON public.plans
  FOR SELECT USING (true);

CREATE POLICY "Super admins can manage plans" ON public.plans
  FOR ALL USING (get_user_role() = 'super_admin');

-- Create RLS policies for users
CREATE POLICY "Users can view their own profile" ON public.users
  FOR SELECT USING (auth.uid() = id);

CREATE POLICY "Users can update their own profile" ON public.users
  FOR UPDATE USING (auth.uid() = id);

CREATE POLICY "Super admins can view all profiles" ON public.users
  FOR SELECT USING (get_user_role() = 'super_admin');

CREATE POLICY "Super admins can insert profiles" ON public.users
  FOR INSERT WITH CHECK (get_user_role() = 'super_admin');

CREATE POLICY "Admins can view establishment profiles" ON public.users
  FOR SELECT USING (
    get_user_role() = 'admin' AND 
    establishment_id = get_user_establishment_id()
  );

-- Create RLS policies for establishments
CREATE POLICY "Everyone can view active establishments" ON public.establishments
  FOR SELECT USING (status = 'active');

CREATE POLICY "Admins can view their establishment" ON public.establishments
  FOR SELECT USING (
    get_user_role() = 'admin' AND 
    id = get_user_establishment_id()
  );

CREATE POLICY "Admins can update their establishment" ON public.establishments
  FOR UPDATE USING (
    get_user_role() = 'admin' AND 
    id = get_user_establishment_id()
  );

CREATE POLICY "Super admins can manage all establishments" ON public.establishments
  FOR ALL USING (get_user_role() = 'super_admin');

-- Create RLS policies for professionals
CREATE POLICY "Everyone can view active professionals" ON public.professionals
  FOR SELECT USING (active = true);

CREATE POLICY "Admins can manage establishment professionals" ON public.professionals
  FOR ALL USING (
    get_user_role() = 'admin' AND 
    establishment_id = get_user_establishment_id()
  );

CREATE POLICY "Super admins can manage all professionals" ON public.professionals
  FOR ALL USING (get_user_role() = 'super_admin');

-- Create RLS policies for services
CREATE POLICY "Everyone can view active services" ON public.services
  FOR SELECT USING (is_active = true);

CREATE POLICY "Admins can manage establishment services" ON public.services
  FOR ALL USING (
    get_user_role() = 'admin' AND 
    establishment_id = get_user_establishment_id()
  );

CREATE POLICY "Super admins can manage all services" ON public.services
  FOR ALL USING (get_user_role() = 'super_admin');

-- Create RLS policies for appointments
CREATE POLICY "Users can view their appointments" ON public.appointments
  FOR SELECT USING (
    auth.uid() IN (
      SELECT u.id FROM public.users u 
      WHERE u.id IN (appointments.client_id, 
        (SELECT p.user_id FROM public.professionals p WHERE p.id = appointments.professional_id)
      )
    )
  );

CREATE POLICY "Clients can create appointments" ON public.appointments
  FOR INSERT WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.users u 
      WHERE u.id = auth.uid() AND u.id = appointments.client_id AND u.role = 'client'
    )
  );

CREATE POLICY "Professionals can update their appointments" ON public.appointments
  FOR UPDATE USING (
    EXISTS (
      SELECT 1 FROM public.professionals p 
      WHERE p.user_id = auth.uid() AND p.id = appointments.professional_id
    )
  );

CREATE POLICY "Admins can view establishment appointments" ON public.appointments
  FOR SELECT USING (
    get_user_role() = 'admin' AND 
    establishment_id = get_user_establishment_id()
  );

CREATE POLICY "Super admins can manage all appointments" ON public.appointments
  FOR ALL USING (get_user_role() = 'super_admin');

-- Create RLS policies for reviews
CREATE POLICY "Everyone can view reviews" ON public.reviews
  FOR SELECT USING (true);

CREATE POLICY "Clients can create reviews for their appointments" ON public.reviews
  FOR INSERT WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.users u 
      WHERE u.id = auth.uid() AND u.id = reviews.client_id AND u.role = 'client'
    )
  );

-- Create RLS policies for establishment hours
CREATE POLICY "Everyone can view establishment hours" ON public.establishment_hours
  FOR SELECT USING (true);

CREATE POLICY "Admins can manage their establishment hours" ON public.establishment_hours
  FOR ALL USING (
    get_user_role() = 'admin' AND 
    establishment_id = get_user_establishment_id()
  );

CREATE POLICY "Super admins can manage all hours" ON public.establishment_hours
  FOR ALL USING (get_user_role() = 'super_admin');

-- Create RLS policies for establishment photos
CREATE POLICY "Everyone can view establishment photos" ON public.establishment_photos
  FOR SELECT USING (true);

CREATE POLICY "Admins can manage their establishment photos" ON public.establishment_photos
  FOR ALL USING (
    get_user_role() = 'admin' AND 
    establishment_id = get_user_establishment_id()
  );

CREATE POLICY "Super admins can manage all photos" ON public.establishment_photos
  FOR ALL USING (get_user_role() = 'super_admin');