-- Ensure professionals table exists and has proper structure
CREATE TABLE IF NOT EXISTS public.professionals (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id uuid NOT NULL,
  establishment_id uuid NOT NULL,
  avatar_url text,
  bio text,
  specialties text[],
  active boolean NOT NULL DEFAULT true,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now()
);

-- Enable RLS on professionals table
ALTER TABLE public.professionals ENABLE ROW LEVEL SECURITY;

-- Create RLS policies for professionals
CREATE POLICY IF NOT EXISTS "Admins can manage establishment professionals" 
ON public.professionals 
FOR ALL
USING ((get_user_role() = 'admin'::user_role) AND (establishment_id = get_user_establishment_id()));

CREATE POLICY IF NOT EXISTS "Everyone can view active professionals" 
ON public.professionals 
FOR SELECT
USING (active = true);

CREATE POLICY IF NOT EXISTS "Super admins can manage all professionals" 
ON public.professionals 
FOR ALL
USING (get_user_role() = 'super_admin'::user_role);

-- Ensure appointments.professional_id references professionals table
ALTER TABLE public.appointments DROP CONSTRAINT IF EXISTS appointments_professional_id_fkey;
ALTER TABLE public.appointments
  ADD CONSTRAINT appointments_professional_id_fkey
  FOREIGN KEY (professional_id) REFERENCES public.professionals(id);

-- Add client fields for anonymous booking if not exists
ALTER TABLE public.appointments ADD COLUMN IF NOT EXISTS client_phone text;
ALTER TABLE public.appointments ADD COLUMN IF NOT EXISTS client_name text;