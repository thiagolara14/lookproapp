-- Remove todas as políticas existentes para professional-avatars
DROP POLICY IF EXISTS "Allow professional avatar uploads" ON storage.objects;
DROP POLICY IF EXISTS "Allow professional avatar updates" ON storage.objects;
DROP POLICY IF EXISTS "Allow professional avatar deletes" ON storage.objects;
DROP POLICY IF EXISTS "Allow public access to professional avatars" ON storage.objects;

-- Criar políticas mais simples
-- Permite upload para usuários autenticados no bucket professional-avatars
CREATE POLICY "Enable upload for authenticated users" ON storage.objects
FOR INSERT WITH CHECK (
  bucket_id = 'professional-avatars' 
  AND auth.uid() IS NOT NULL
);

-- Permite update para usuários autenticados no bucket professional-avatars  
CREATE POLICY "Enable update for authenticated users" ON storage.objects
FOR UPDATE USING (
  bucket_id = 'professional-avatars' 
  AND auth.uid() IS NOT NULL
);

-- Permite delete para usuários autenticados no bucket professional-avatars
CREATE POLICY "Enable delete for authenticated users" ON storage.objects
FOR DELETE USING (
  bucket_id = 'professional-avatars' 
  AND auth.uid() IS NOT NULL
);

-- Permite visualização pública
CREATE POLICY "Enable public read access" ON storage.objects
FOR SELECT USING (bucket_id = 'professional-avatars');