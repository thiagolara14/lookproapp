-- Criar perfis para profissionais (simulando usuários já existentes)
INSERT INTO public.profiles (id, user_id, full_name, email, role, establishment_id) VALUES
('aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa', 'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa', 'Rafa Barbeiro', 'rafa@lookbarba.com', 'pro', '356e31a3-3b88-4b9d-a647-c4c7400ea1bc'),
('bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb', 'bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb', 'Doni Silva', 'doni@lookbarba.com', 'pro', '356e31a3-3b88-4b9d-a647-c4c7400ea1bc'),
('cccccccc-cccc-cccc-cccc-cccccccccccc', 'cccccccc-cccc-cccc-cccc-cccccccccccc', 'Marina Santos', 'marina@studiobela.com', 'pro', '23df2895-0618-425f-be3d-1106b2128858'),
('dddddddd-dddd-dddd-dddd-dddddddddddd', 'dddddddd-dddd-dddd-dddd-dddddddddddd', 'Lívia Costa', 'livia@studiobela.com', 'pro', '23df2895-0618-425f-be3d-1106b2128858'),
('eeeeeeee-eeee-eeee-eeee-eeeeeeeeeeee', 'eeeeeeee-eeee-eeee-eeee-eeeeeeeeeeee', 'Nina Tattoo', 'nina@inkflow.com', 'pro', 'a3ce0609-28f2-48f2-ae69-3c8777282ff2')
ON CONFLICT (id) DO UPDATE SET
full_name = EXCLUDED.full_name,
email = EXCLUDED.email,
role = EXCLUDED.role,
establishment_id = EXCLUDED.establishment_id;

-- Inserir profissionais na tabela específica
INSERT INTO public.professionals (id, user_id, establishment_id, active) VALUES
('aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa', 'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa', '356e31a3-3b88-4b9d-a647-c4c7400ea1bc', true),
('bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb', 'bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb', '356e31a3-3b88-4b9d-a647-c4c7400ea1bc', true),
('cccccccc-cccc-cccc-cccc-cccccccccccc', 'cccccccc-cccc-cccc-cccc-cccccccccccc', '23df2895-0618-425f-be3d-1106b2128858', true),
('dddddddd-dddd-dddd-dddd-dddddddddddd', 'dddddddd-dddd-dddd-dddd-dddddddddddd', '23df2895-0618-425f-be3d-1106b2128858', true),
('eeeeeeee-eeee-eeee-eeee-eeeeeeeeeeee', 'eeeeeeee-eeee-eeee-eeee-eeeeeeeeeeee', 'a3ce0609-28f2-48f2-ae69-3c8777282ff2', true)
ON CONFLICT (id) DO UPDATE SET
user_id = EXCLUDED.user_id,
establishment_id = EXCLUDED.establishment_id,
active = EXCLUDED.active;