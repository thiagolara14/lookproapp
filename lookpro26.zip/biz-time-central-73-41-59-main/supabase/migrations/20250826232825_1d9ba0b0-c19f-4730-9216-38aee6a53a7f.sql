-- Criar schema isolado para onboarding
CREATE SCHEMA IF NOT EXISTS onboarding;

-- Tabela de leads para onboarding
CREATE TABLE IF NOT EXISTS onboarding.leads (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  estabelecimento text NOT NULL,
  responsavel text NOT NULL,
  whatsapp text NOT NULL,
  cidade text NOT NULL,
  tipo text NOT NULL,
  servicos_json jsonb NOT NULL DEFAULT '[]'::jsonb,
  status text NOT NULL DEFAULT 'novo', -- novo|em_provisionamento|entregue|erro
  foto_url text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- Habilitar RLS na tabela leads
ALTER TABLE onboarding.leads ENABLE ROW LEVEL SECURITY;

-- Policy para permitir criação pública de leads
CREATE POLICY "Allow public lead creation" 
ON onboarding.leads 
FOR INSERT 
TO anon 
WITH CHECK (true);

-- Policy para super admins gerenciarem todos os leads
CREATE POLICY "Super admins can manage all leads" 
ON onboarding.leads 
FOR ALL 
TO authenticated 
USING (get_user_role() = 'super_admin'::user_role);

-- Criar bucket para assets dos tenants
INSERT INTO storage.buckets (id, name, public) 
VALUES ('tenant-assets', 'tenant-assets', true)
ON CONFLICT (id) DO NOTHING;

-- Policies para o bucket tenant-assets
-- Leitura pública
CREATE POLICY "Public can view tenant assets" 
ON storage.objects 
FOR SELECT 
TO public 
USING (bucket_id = 'tenant-assets');

-- Insert apenas via service role (edge functions)
CREATE POLICY "Service role can upload tenant assets" 
ON storage.objects 
FOR INSERT 
TO service_role 
WITH CHECK (bucket_id = 'tenant-assets');

-- Update apenas via service role
CREATE POLICY "Service role can update tenant assets" 
ON storage.objects 
FOR UPDATE 
TO service_role 
USING (bucket_id = 'tenant-assets');

-- Delete apenas via service role
CREATE POLICY "Service role can delete tenant assets" 
ON storage.objects 
FOR DELETE 
TO service_role 
USING (bucket_id = 'tenant-assets');

-- Trigger para atualizar updated_at
CREATE OR REPLACE FUNCTION onboarding.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_leads_updated_at
    BEFORE UPDATE ON onboarding.leads
    FOR EACH ROW
    EXECUTE FUNCTION onboarding.update_updated_at_column();