-- Drop e recriar a view corretamente
DROP VIEW IF EXISTS v_professional_services_effective CASCADE;

CREATE VIEW v_professional_services_effective AS
SELECT
  ps.id as professional_service_id,
  ps.professional_id,
  ps.establishment_id,
  s.id as service_id,
  s.name,
  s.description,
  s.image_url,
  COALESCE(ps.custom_duration_minutes, s.duration_minutes) as duration_minutes,
  COALESCE(ps.custom_price, s.price) as price,
  (ps.is_active AND s.is_active) as is_active
FROM professional_services ps
JOIN services s ON s.id = ps.service_id;