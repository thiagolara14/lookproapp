-- Adicionar "pro" ao enum user_role
ALTER TYPE user_role ADD VALUE 'pro';