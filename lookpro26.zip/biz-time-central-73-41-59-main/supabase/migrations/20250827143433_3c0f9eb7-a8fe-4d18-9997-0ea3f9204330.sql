-- Onboarding schema and intake metadata for manual flow (simplified)
CREATE SCHEMA IF NOT EXISTS onboarding;

-- Intake metadata table to track raw inputs for admin processing
CREATE TABLE IF NOT EXISTS onboarding.intake_meta (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  lead_ref_id UUID, -- Reference to public.leads.id (no FK constraint)
  raw_city TEXT, -- Free text city input from user
  phone_e164 TEXT, -- Normalized phone in E.164 format
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Messages log table for WhatsApp message tracking  
CREATE TABLE IF NOT EXISTS onboarding.messages_log (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  lead_ref_id UUID NOT NULL, -- Reference to public.leads.id
  message_text TEXT NOT NULL,
  copied_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  sent_manually BOOLEAN DEFAULT FALSE,
  body JSONB DEFAULT '{}',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Enable RLS on new tables
ALTER TABLE onboarding.intake_meta ENABLE ROW LEVEL SECURITY;
ALTER TABLE onboarding.messages_log ENABLE ROW LEVEL SECURITY;

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_intake_meta_lead_ref ON onboarding.intake_meta(lead_ref_id);
CREATE INDEX IF NOT EXISTS idx_intake_meta_created_at ON onboarding.intake_meta(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_messages_log_lead_ref ON onboarding.messages_log(lead_ref_id);