-- Gerar slugs para profissionais que não têm
UPDATE public.professionals 
SET slug = LOWER(REGEXP_REPLACE(
  COALESCE(
    (SELECT full_name FROM profiles WHERE user_id = professionals.user_id), 
    'profissional'
  ) || '-' || SUBSTRING(professionals.id::text, 1, 8), 
  '[^a-zA-Z0-9\-]', '-', 'g'
))
WHERE slug IS NULL OR slug = '';

-- Remover hífens duplicados e limpar
UPDATE public.professionals 
SET slug = REGEXP_REPLACE(REGEXP_REPLACE(slug, '-+', '-', 'g'), '^-|-$', '', 'g')
WHERE slug ~ '(-{2,}|^-|-$)';

-- Garantir unicidade dos slugs adicionando número sequencial se necessário
DO $$
DECLARE
    rec RECORD;
    new_slug TEXT;
    counter INTEGER;
BEGIN
    FOR rec IN 
        SELECT id, slug 
        FROM professionals 
        WHERE slug IS NOT NULL
        ORDER BY created_at
    LOOP
        new_slug := rec.slug;
        counter := 1;
        
        -- Verificar se já existe outro profissional com o mesmo slug
        WHILE EXISTS (
            SELECT 1 FROM professionals 
            WHERE slug = new_slug AND id != rec.id
        ) LOOP
            new_slug := rec.slug || '-' || counter;
            counter := counter + 1;
        END LOOP;
        
        -- Atualizar se necessário
        IF new_slug != rec.slug THEN
            UPDATE professionals SET slug = new_slug WHERE id = rec.id;
        END IF;
    END LOOP;
END $$;