-- Atualizar o profile existente para o nome Thiago
UPDATE public.profiles 
SET full_name = 'Thiago'
WHERE user_id = (
  SELECT user_id 
  FROM professionals 
  WHERE establishment_id = 'b6cf2cb5-6756-4bb3-b016-010af6bb041a'
  LIMIT 1
);