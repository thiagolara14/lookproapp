-- Verificar e corrigir as políticas RLS para blocked_periods

-- Primeiro, vamos ver as políticas atuais e depois corrigi-las
-- Remover políticas problemáticas e criar novas mais permissivas

-- Remover políticas existentes que podem estar causando problemas
DROP POLICY IF EXISTS "Professionals can create their blocked periods" ON public.blocked_periods;
DROP POLICY IF EXISTS "Admins can view establishment blocked periods" ON public.blocked_periods;

-- Política para permitir que profissionais criem seus próprios bloqueios
-- Usando uma abordagem mais direta que verifica se o professional_id corresponde ao usuário logado
CREATE POLICY "Professionals can create blocked periods" 
ON public.blocked_periods 
FOR INSERT 
WITH CHECK (
  EXISTS (
    SELECT 1 FROM public.professionals pr 
    WHERE pr.id = blocked_periods.professional_id 
    AND pr.user_id = auth.uid()
  )
);

-- Política para admins visualizarem bloqueios do estabelecimento
CREATE POLICY "Admins can view blocked periods" 
ON public.blocked_periods 
FOR SELECT 
USING (
  EXISTS (
    SELECT 1 FROM public.professionals pr 
    JOIN public.profiles p ON p.user_id = auth.uid()
    WHERE pr.id = blocked_periods.professional_id 
    AND pr.establishment_id = p.establishment_id
    AND p.role = 'admin'
  )
);

-- Política para permitir que todos vejam bloqueios (necessário para verificar disponibilidade)
CREATE POLICY "Allow read blocked periods for scheduling" 
ON public.blocked_periods 
FOR SELECT 
USING (true);

-- Política mais permissiva para profissionais atualizar seus bloqueios
CREATE POLICY "Professionals can update their blocked periods" 
ON public.blocked_periods 
FOR UPDATE 
USING (
  EXISTS (
    SELECT 1 FROM public.professionals pr 
    WHERE pr.id = blocked_periods.professional_id 
    AND pr.user_id = auth.uid()
  )
);

-- Política mais permissiva para profissionais deletar seus bloqueios  
CREATE POLICY "Professionals can delete their blocked periods" 
ON public.blocked_periods 
FOR DELETE 
USING (
  EXISTS (
    SELECT 1 FROM public.professionals pr 
    WHERE pr.id = blocked_periods.professional_id 
    AND pr.user_id = auth.uid()
  )
);