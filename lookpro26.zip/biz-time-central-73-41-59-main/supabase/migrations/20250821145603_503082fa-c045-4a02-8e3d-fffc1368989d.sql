-- Create extensions for exclusion constraints
CREATE EXTENSION IF NOT EXISTS btree_gist;

-- Add basic indices for better performance
CREATE INDEX IF NOT EXISTS idx_appointments_professional_date_time 
ON appointments (professional_id, appointment_date, start_time);

CREATE INDEX IF NOT EXISTS idx_appointments_professional_status 
ON appointments (professional_id, status);

CREATE INDEX IF NOT EXISTS idx_blocked_periods_professional_dates 
ON blocked_periods (professional_id, start_date, end_date);

-- Add timestamptz columns for proper overlap checking
ALTER TABLE appointments 
ADD COLUMN IF NOT EXISTS start_at TIMESTAMPTZ,
ADD COLUMN IF NOT EXISTS end_at TIMESTAMPTZ;

ALTER TABLE blocked_periods 
ADD COLUMN IF NOT EXISTS start_at TIMESTAMPTZ,
ADD COLUMN IF NOT EXISTS end_at TIMESTAMPTZ;