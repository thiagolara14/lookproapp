import { useTenantContext } from "@/context/TenantContext";

export const useTenant = () => {
  const { tenantId } = useTenantContext();
  return { tenantId };
};
