import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";

export const useCurrentEstablishmentId = () => {
  const [establishmentId, setEstablishmentId] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const getEstablishmentId = async () => {
      try {
        const { data: { user }, error: userError } = await supabase.auth.getUser();
        
        if (userError) {
          throw userError;
        }

        if (!user) {
          setEstablishmentId(null);
          setLoading(false);
          return;
        }

        // Lookup establishment_id from profiles table
        const { data: profile, error: profileError } = await supabase
          .from('profiles')
          .select('establishment_id')
          .eq('user_id', user.id)
          .single();

        if (profileError) {
          throw profileError;
        }

        setEstablishmentId(profile?.establishment_id || null);
        setError(null);
      } catch (err) {
        console.error('Error getting establishment ID:', err);
        setError(err instanceof Error ? err.message : 'Failed to get establishment ID');
        setEstablishmentId(null);
      } finally {
        setLoading(false);
      }
    };

    getEstablishmentId();

    // Listen for auth changes
    const { data: { subscription } } = supabase.auth.onAuthStateChange(() => {
      getEstablishmentId();
    });

    return () => subscription.unsubscribe();
  }, []);

  return { establishmentId, loading, error };
};