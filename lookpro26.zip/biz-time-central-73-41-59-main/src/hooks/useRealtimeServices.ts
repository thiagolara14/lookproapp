import { useEffect, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';

/**
 * Hook para escutar mudanças em tempo real em services e professional_services
 * e disparar callbacks quando detectar alterações
 */
export function useRealtimeServices(
  establishmentId?: string,
  professionalId?: string,
  onServicesChanged?: () => void,
  onProfessionalServicesChanged?: () => void
) {
  const handleServicesChange = useCallback(() => {
    console.log('Services table changed, triggering callback');
    onServicesChanged?.();
  }, [onServicesChanged]);

  const handleProfessionalServicesChange = useCallback(() => {
    console.log('Professional services table changed, triggering callback');
    onProfessionalServicesChanged?.();
  }, [onProfessionalServicesChanged]);

  useEffect(() => {
    if (!establishmentId && !professionalId) return;

    console.log('Setting up realtime listeners for services', { establishmentId, professionalId });

    const channels: any[] = [];

    // Listen to services changes if establishment ID provided
    if (establishmentId) {
      const servicesChannel = supabase
        .channel(`services-${establishmentId}`)
        .on(
          'postgres_changes',
          {
            event: '*',
            schema: 'public',
            table: 'services',
            filter: `establishment_id=eq.${establishmentId}`
          },
          handleServicesChange
        )
        .subscribe();

      channels.push(servicesChannel);
    }

    // Listen to professional_services changes if professional ID provided
    if (professionalId) {
      const professionalServicesChannel = supabase
        .channel(`professional-services-${professionalId}`)
        .on(
          'postgres_changes',
          {
            event: '*',
            schema: 'public',
            table: 'professional_services',
            filter: `professional_id=eq.${professionalId}`
          },
          handleProfessionalServicesChange
        )
        .subscribe();

      channels.push(professionalServicesChannel);
    }

    // Also listen to custom events for immediate UI updates
    const handleServicesUpdated = () => {
      console.log('Custom services updated event received');
      onServicesChanged?.();
    };

    const handleProfessionalServicesUpdated = () => {
      console.log('Custom professional services updated event received');
      onProfessionalServicesChanged?.();
    };

    window.addEventListener('servicesUpdated', handleServicesUpdated);
    window.addEventListener('professionalServicesUpdated', handleProfessionalServicesUpdated);

    return () => {
      // Remove Supabase channels
      channels.forEach(channel => {
        supabase.removeChannel(channel);
      });

      // Remove custom event listeners
      window.removeEventListener('servicesUpdated', handleServicesUpdated);
      window.removeEventListener('professionalServicesUpdated', handleProfessionalServicesUpdated);
    };
  }, [establishmentId, professionalId, handleServicesChange, handleProfessionalServicesChange]);
}

/**
 * Utility functions to trigger custom events for immediate UI updates
 */
export const triggerServicesUpdate = (establishmentId?: string) => {
  window.dispatchEvent(new CustomEvent('servicesUpdated', { 
    detail: { establishmentId } 
  }));
};

export const triggerProfessionalServicesUpdate = (professionalId?: string) => {
  window.dispatchEvent(new CustomEvent('professionalServicesUpdated', { 
    detail: { professionalId } 
  }));
};