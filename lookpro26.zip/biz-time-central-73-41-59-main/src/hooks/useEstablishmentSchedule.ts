import React from "react";
import { supabase } from "@/integrations/supabase/client";
import { getEstablishmentWorkingHours, generateTimeSlots } from "@/services/supabase/schedule";
import type { Appointment } from "@/types/appointments";

/**
 * Hook para obter e gerenciar os horários de funcionamento de um estabelecimento
 */
export function useEstablishmentSchedule(establishmentId: string) {
  const [workingHours, setWorkingHours] = React.useState<any>(null);
  const [loading, setLoading] = React.useState(true);
  const [error, setError] = React.useState<string | null>(null);

  React.useEffect(() => {
    if (!establishmentId) {
      setLoading(false);
      return;
    }

    const loadWorkingHours = async () => {
      try {
        setLoading(true);
        const hours = await getEstablishmentWorkingHours(establishmentId);
        setWorkingHours(hours);
        setError(null);
      } catch (err: any) {
        console.error('Error loading working hours:', err);
        setError(err.message || 'Erro ao carregar horários');
        setWorkingHours({});
      } finally {
        setLoading(false);
      }
    };

    loadWorkingHours();
  }, [establishmentId]);

  const getAvailableSlots = React.useCallback(async (
    date: Date,
    professionalId?: string,
    serviceId?: string
  ): Promise<{ time: string; available: boolean }[]> => {
    if (!workingHours || !date) {
      console.log('No working hours or date provided', { workingHours, date });
      return [];
    }

    const dayOfWeek = date.getDay();
    const dayHours = workingHours[dayOfWeek.toString()];

    console.log('Day hours for', dayOfWeek, ':', dayHours);

    if (!dayHours || dayHours.closed) {
      console.log('Day is closed or no hours defined');
      return [];
    }

    try {
      // Gerar slots base baseados no horário de funcionamento
      const timeSlots = generateTimeSlots(dayHours, 30);
      console.log('Generated time slots:', timeSlots);
      
      // Buscar agendamentos existentes
      const dateStr = date.toISOString().split('T')[0];
      let appointmentsQuery = supabase
        .from('appointments')
        .select('start_time')
        .eq('appointment_date', dateStr)
        .neq('status', 'cancelled');

      if (professionalId) {
        appointmentsQuery = appointmentsQuery.eq('professional_id', professionalId);
      }

      const { data: appointments } = await appointmentsQuery;
      const busyTimes = appointments?.map(apt => apt.start_time) || [];

      // Buscar períodos bloqueados
      let blockedQuery = supabase
        .from('blocked_periods')
        .select('start_time, end_time, start_date, end_date')
        .lte('start_date', dateStr)
        .gte('end_date', dateStr);

      if (professionalId) {
        blockedQuery = blockedQuery.eq('professional_id', professionalId);
      }

      const { data: blockedPeriods } = await blockedQuery;
      
      // Verificar slots bloqueados
      const blockedTimes: string[] = [];
      const currentDateTime = new Date();
      const isToday = date.toDateString() === currentDateTime.toDateString();
      const currentTimeStr = isToday ? 
        `${currentDateTime.getHours().toString().padStart(2, '0')}:${currentDateTime.getMinutes().toString().padStart(2, '0')}` 
        : '00:00';

      timeSlots.forEach(time => {
        const slotDateTime = new Date(`${dateStr}T${time}:00`);
        
        // Verificar se é no passado (apenas para hoje)
        if (isToday && time <= currentTimeStr) {
          blockedTimes.push(time);
          return;
        }
        
        // Verificar períodos bloqueados
        const isBlocked = blockedPeriods?.some(block => {
          const blockStart = new Date(`${block.start_date}T${block.start_time || '00:00'}:00`);
          const blockEnd = new Date(`${block.end_date}T${block.end_time || '23:59'}:59`);
          return slotDateTime >= blockStart && slotDateTime <= blockEnd;
        }) || false;

        if (isBlocked) {
          blockedTimes.push(time);
        }
      });

      // Retornar slots com status de disponibilidade
      const finalSlots = timeSlots.map(time => ({
        time,
        available: !busyTimes.includes(time) && !blockedTimes.includes(time)
      }));
      
      console.log('Final slots with availability:', finalSlots);
      return finalSlots;

    } catch (err) {
      console.error('Error getting available slots:', err);
      // Em caso de erro, retornar slots sem disponibilidade baseados no horário
      const timeSlots = generateTimeSlots(dayHours, 30);
      return timeSlots.map(time => ({ time, available: false }));
    }
  }, [workingHours]);

  const getWorkingHoursForDate = React.useCallback((date: Date) => {
    if (!workingHours) return null;
    
    const dayOfWeek = date.getDay();
    return workingHours[dayOfWeek.toString()] || null;
  }, [workingHours]);

  const isOpenOnDate = React.useCallback((date: Date) => {
    const dayHours = getWorkingHoursForDate(date);
    return dayHours && !dayHours.closed;
  }, [getWorkingHoursForDate]);

  return {
    workingHours,
    loading,
    error,
    getAvailableSlots,
    getWorkingHoursForDate,
    isOpenOnDate
  };
}