// @deprecated - This file is deprecated when using backend.provider = "supabase"
// Use @/context/AuthContext instead for Supabase authentication

import { useCallback } from "react";
import type { AuthUser } from "@/services/auth";
import { getAuthAdapter } from "@/services/auth";

const KEY = "lp_auth_user";

export const getAuthUser = (): AuthUser | null => {
  const raw = localStorage.getItem(KEY);
  return raw ? (JSON.parse(raw) as AuthUser) : null;
};

export const setAuthUser = (user: AuthUser) => {
  localStorage.setItem(KEY, JSON.stringify(user));
};

export const clearAuthUser = () => localStorage.removeItem(KEY);

export const useAuth = () => {
  const current = getAuthUser();
  const signOut = useCallback(async () => {
    try {
      await getAuthAdapter().signOut();
    } catch (_) {
      // no-op if provider not configured
    } finally {
      clearAuthUser();
    }
  }, []);
  return { user: current, signOut };
};