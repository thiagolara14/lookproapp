/**
 * Hooks para dados financeiros
 */

import { useQuery } from "@tanstack/react-query";
import { 
  fetchProfessionalTotalCents, 
  fetchEstablishmentTotalCents, 
  fetchEstablishmentBreakdownByProfessional,
  type FinanceBreakdownItem
} from "@/services/finance";

/**
 * Hook para buscar total financeiro do profissional
 */
export const useProfessionalFinance = (
  professionalId?: string,
  startDate?: Date,
  endDate?: Date
) => {
  return useQuery({
    queryKey: ["professional-finance", professionalId, startDate?.toISOString(), endDate?.toISOString()],
    queryFn: () => {
      if (!professionalId) throw new Error("Professional ID is required");
      return fetchProfessionalTotalCents(professionalId, startDate, endDate);
    },
    enabled: !!professionalId,
    staleTime: 5 * 60 * 1000, // 5 minutos
  });
};

/**
 * Hook para buscar total financeiro do estabelecimento
 */
export const useEstablishmentFinance = (
  establishmentId?: string,
  startDate?: Date,
  endDate?: Date
) => {
  return useQuery({
    queryKey: ["establishment-finance", establishmentId, startDate?.toISOString(), endDate?.toISOString()],
    queryFn: () => {
      if (!establishmentId) throw new Error("Establishment ID is required");
      return fetchEstablishmentTotalCents(establishmentId, startDate, endDate);
    },
    enabled: !!establishmentId,
    staleTime: 5 * 60 * 1000, // 5 minutos
  });
};

/**
 * Hook para buscar breakdown financeiro por profissional
 */
export const useEstablishmentBreakdown = (
  establishmentId?: string,
  startDate?: Date,
  endDate?: Date
) => {
  return useQuery({
    queryKey: ["establishment-breakdown", establishmentId, startDate?.toISOString(), endDate?.toISOString()],
    queryFn: (): Promise<FinanceBreakdownItem[]> => {
      if (!establishmentId) throw new Error("Establishment ID is required");
      return fetchEstablishmentBreakdownByProfessional(establishmentId, startDate, endDate);
    },
    enabled: !!establishmentId,
    staleTime: 5 * 60 * 1000, // 5 minutos
  });
};