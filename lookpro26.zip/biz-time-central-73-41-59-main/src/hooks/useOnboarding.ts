import { useState } from "react";
import { FeatureFlags } from "@/lib/featureFlags";

export function useOnboarding() {
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [isSuccessOpen, setIsSuccessOpen] = useState(false);
  const [leadId, setLeadId] = useState<string>("");

  const openForm = () => {
    if (!FeatureFlags.ONBOARDING_SELF_SERVE) {
      console.warn('Onboarding feature is disabled');
      return;
    }
    setIsFormOpen(true);
  };

  const closeForm = () => {
    setIsFormOpen(false);
  };

  const showSuccess = (id: string) => {
    setLeadId(id);
    setIsFormOpen(false);
    setIsSuccessOpen(true);
  };

  const closeSuccess = () => {
    setIsSuccessOpen(false);
    setLeadId("");
  };

  return {
    isFormOpen,
    isSuccessOpen,
    leadId,
    openForm,
    closeForm,
    showSuccess,
    closeSuccess,
    isFeatureEnabled: FeatureFlags.ONBOARDING_SELF_SERVE
  };
}