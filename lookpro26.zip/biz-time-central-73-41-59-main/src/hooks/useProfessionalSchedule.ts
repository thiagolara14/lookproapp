import React from "react";
import { supabase } from "@/integrations/supabase/client";
import { getEstablishmentWorkingHours, generateTimeSlots } from "@/services/supabase/schedule";
import type { Appointment } from "@/types/appointments";

/**
 * Hook para obter e gerenciar a agenda individual de um profissional
 */
export function useProfessionalSchedule(professionalId: string) {
  const [appointments, setAppointments] = React.useState<Appointment[]>([]);
  const [blockedPeriods, setBlockedPeriods] = React.useState<any[]>([]);
  const [workingHours, setWorkingHours] = React.useState<any>(null);
  const [loading, setLoading] = React.useState(true);
  const [error, setError] = React.useState<string | null>(null);

  console.log('useProfessionalSchedule hook initialized with professionalId:', professionalId);

  React.useEffect(() => {
    if (!professionalId) {
      setLoading(false);
      return;
    }

    const loadScheduleData = async () => {
      try {
        setLoading(true);
        
        // 1. Get professional's establishment
        const { data: professional } = await supabase
          .from('professionals')
          .select('establishment_id')
          .eq('id', professionalId)
          .single();

        if (!professional) {
          throw new Error('Profissional não encontrado');
        }

        // 2. Get establishment working hours
        const hours = await getEstablishmentWorkingHours(professional.establishment_id);
        setWorkingHours(hours);

        // 3. Load appointments
        await loadAppointments();

        // 4. Load blocked periods
        await loadBlockedPeriods();

        setError(null);
      } catch (err: any) {
        console.error('Error loading schedule data:', err);
        setError(err.message || 'Erro ao carregar agenda');
      } finally {
        setLoading(false);
      }
    };

   const loadAppointments = async () => {
    console.log('Loading appointments for professional ID:', professionalId);
    
    const { data, error } = await supabase
      .from('appointments')
      .select(`
        *,
        services(name)
      `)
      .eq('professional_id', professionalId)
      .order('appointment_date', { ascending: true })
      .order('start_time', { ascending: true });

    if (error) {
      console.error('Error loading appointments:', error);
      return;
    }

    console.log('Raw appointments data from Supabase for professional:', professionalId, data);

    const mappedAppointments = data?.map(apt => ({
      id: apt.id,
      establishmentId: apt.establishment_id,
      professionalId: apt.professional_id,
      professionalName: '',
      clientId: apt.client_id || apt.client_phone || '',
      clientName: apt.client_name || '',
      serviceId: apt.service_id,
      serviceName: apt.services?.name || '',
      date: apt.appointment_date,
      time: apt.start_time,
      status: mapSupabaseStatus(apt.status),
      notes: apt.notes,
      createdAt: apt.created_at,
      updatedAt: apt.updated_at,
    })) || [];

    console.log('Mapped appointments for professional:', professionalId, mappedAppointments);
    setAppointments(mappedAppointments);
  };

    const loadBlockedPeriods = async () => {
      const { data, error } = await supabase
        .from('blocked_periods')
        .select('*')
        .eq('professional_id', professionalId);

      if (error) {
        console.error('Error loading blocked periods:', error);
        return;
      }

      setBlockedPeriods(data || []);
    };

    loadScheduleData();
  }, [professionalId]);

  const getScheduleForDate = React.useCallback((date: Date) => {
    if (!workingHours) return { slots: [], appointments: [] };

    const dayOfWeek = date.getDay();
    const dayHours = workingHours[dayOfWeek.toString()];
    const dateStr = date.toISOString().split('T')[0];

    if (!dayHours || dayHours.closed) {
      return { slots: [], appointments: [] };
    }

    // Generate time slots
    const timeSlots = generateTimeSlots(dayHours, 30);

    // Get appointments for this date
    const dayAppointments = appointments.filter(apt => apt.date === dateStr);

    // Get blocked periods for this date
    const dayBlocked = blockedPeriods.filter(bp => {
      return bp.start_date <= dateStr && bp.end_date >= dateStr;
    });

    // Create slots with status
    const slots = timeSlots.map(time => {
      const appointment = dayAppointments.find(apt => apt.time === time);
      
      const isBlocked = dayBlocked.some(bp => {
        const slotDateTime = new Date(`${dateStr}T${time}:00`);
        const blockStart = new Date(`${bp.start_date}T${bp.start_time || '00:00'}:00`);
        const blockEnd = new Date(`${bp.end_date}T${bp.end_time || '23:59'}:59`);
        return slotDateTime >= blockStart && slotDateTime <= blockEnd;
      });

      return {
        time,
        available: !appointment && !isBlocked,
        blocked: isBlocked,
        appointment
      };
    });

    return { slots, appointments: dayAppointments };
  }, [workingHours, appointments, blockedPeriods]);

  const refreshSchedule = React.useCallback(async () => {
    // Reload appointments and blocked periods
    setLoading(true);
    try {
      const { data: appts } = await supabase
        .from('appointments')
        .select(`
          *,
          services(name)
        `)
        .eq('professional_id', professionalId);

      const mappedAppointments = appts?.map(apt => ({
        id: apt.id,
        establishmentId: apt.establishment_id,
        professionalId: apt.professional_id,
        professionalName: '',
        clientId: apt.client_id || apt.client_phone || '',
        clientName: apt.client_name || '',
        serviceId: apt.service_id,
        serviceName: apt.services?.name || '',
        date: apt.appointment_date,
        time: apt.start_time,
        status: mapSupabaseStatus(apt.status),
        notes: apt.notes,
        createdAt: apt.created_at,
        updatedAt: apt.updated_at,
      })) || [];

      setAppointments(mappedAppointments);

      const { data: blocked } = await supabase
        .from('blocked_periods')
        .select('*')
        .eq('professional_id', professionalId);

      setBlockedPeriods(blocked || []);
    } catch (err) {
      console.error('Error refreshing schedule:', err);
    } finally {
      setLoading(false);
    }
  }, [professionalId]);

  // Listen to appointments changes for real-time updates
  React.useEffect(() => {
    if (!professionalId) return;

    console.log('Setting up realtime listeners for professional:', professionalId);

    // Listen to appointments changes
    const appointmentsChannel = supabase
      .channel('appointments-changes')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'appointments',
          filter: `professional_id=eq.${professionalId}`
        },
        (payload) => {
          console.log('Appointment realtime update:', payload);
          refreshSchedule();
        }
      )
      .subscribe();

    // Listen to blocked periods changes
    const blockedChannel = supabase
      .channel('blocked-periods-changes')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'blocked_periods',
          filter: `professional_id=eq.${professionalId}`
        },
        (payload) => {
          console.log('Blocked period realtime update:', payload);
          refreshSchedule();
        }
      )
      .subscribe();

    // Legacy custom event listeners for backward compatibility
    const handleAppointmentCreated = (event: any) => {
      console.log('Appointment created event received:', event.detail);
      if (event.detail?.professionalId === professionalId) {
        console.log('Refreshing schedule for professional:', professionalId);
        refreshSchedule();
      }
    };

    const handleProfileUpdated = (event: any) => {
      console.log('Professional profile updated event received:', event.detail);
      if (event.detail?.professionalId === professionalId) {
        console.log('Refreshing schedule for professional after profile update:', professionalId);
        refreshSchedule();
      }
    };

    const handleBlockingUpdated = (event: any) => {
      console.log('Blocking updated event received:', event.detail);
      if (event.detail?.professionalId === professionalId) {
        console.log('Refreshing schedule for blocking update:', professionalId);
        refreshSchedule();
      }
    };

    // Also listen to custom events for immediate propagation
    const handleNewAppointmentCreated = (event: any) => {
      console.log('New appointment created event received:', event.detail);
      if (event.detail?.professionalId === professionalId) {
        console.log('Refreshing schedule for new appointment:', professionalId);
        refreshSchedule();
      }
    };

    window.addEventListener('appointmentCreated', handleAppointmentCreated);
    window.addEventListener('professionalProfileUpdated', handleProfileUpdated);
    window.addEventListener('blockingUpdated', handleBlockingUpdated);
    window.addEventListener('newAppointmentCreated', handleNewAppointmentCreated);
    
    return () => {
      supabase.removeChannel(appointmentsChannel);
      supabase.removeChannel(blockedChannel);
      window.removeEventListener('appointmentCreated', handleAppointmentCreated);
      window.removeEventListener('professionalProfileUpdated', handleProfileUpdated);
      window.removeEventListener('blockingUpdated', handleBlockingUpdated);
      window.removeEventListener('newAppointmentCreated', handleNewAppointmentCreated);
    };
  }, [professionalId, refreshSchedule]);

  return {
    appointments,
    blockedPeriods,
    workingHours,
    loading,
    error,
    getScheduleForDate,
    refreshSchedule
  };
}

function mapSupabaseStatus(status: string): 'pendente' | 'confirmado' | 'concluído' | 'cancelado' {
  const statusMap: Record<string, 'pendente' | 'confirmado' | 'concluído' | 'cancelado'> = {
    'scheduled': 'pendente',
    'confirmed': 'confirmado',
    'completed': 'concluído',
    'cancelled': 'cancelado'
  };
  return statusMap[status] || 'pendente';
}