import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';

interface WorkingHours {
  [dayOfWeek: string]: {
    start: string;
    end: string;
    closed: boolean;
  };
}

export function useEstablishmentAvailability(establishmentId: string, professionalId?: string) {
  const [workingHours, setWorkingHours] = useState<WorkingHours>({});
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function loadWorkingHours() {
      if (!establishmentId) return;
      
      try {
        setLoading(true);
        const { data } = await supabase.rpc('get_establishment_working_hours', {
          establishment_uuid: establishmentId
        });
        
        if (data) {
          setWorkingHours(data as WorkingHours);
        }
      } catch (error) {
        console.error('Error loading working hours:', error);
      } finally {
        setLoading(false);
      }
    }

    loadWorkingHours();
  }, [establishmentId]);

  const isDateAvailable = (date: Date): boolean => {
    if (loading) return false;
    
    const dayOfWeek = date.getDay();
    const dayHours = workingHours[dayOfWeek.toString()];
    
    // If no hours defined for this day or marked as closed, it's not available
    if (!dayHours || dayHours.closed) {
      return false;
    }
    
    return true;
  };

  return {
    workingHours,
    loading,
    isDateAvailable
  };
}