import { createRoot } from 'react-dom/client'
import App from './App.tsx'
import { AuthProvider } from '@/context/AuthContext'
import { applyPWAFromCMS } from '@/services/cms'
import { registerServiceWorker } from '@/lib/push'
import './index.css'

// Apply PWA configuration from Supabase CMS
applyPWAFromCMS().catch(console.warn);

// Register Service Worker for PWA and push notifications
registerServiceWorker().catch(console.warn);

createRoot(document.getElementById("root")!).render(
  <AuthProvider>
    <App />
  </AuthProvider>
);
