export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "13.0.4"
  }
  public: {
    Tables: {
      appointments: {
        Row: {
          appointment_date: string
          cancellation_reason: string | null
          cancelled_at: string | null
          client_id: string | null
          client_name: string | null
          client_phone: string | null
          completed_at: string | null
          confirmed_at: string | null
          created_at: string
          end_at: string | null
          end_time: string
          establishment_id: string
          id: string
          notes: string | null
          professional_id: string
          service_id: string
          start_at: string | null
          start_time: string
          status: Database["public"]["Enums"]["appointment_status"]
          total_price: number
          updated_at: string
        }
        Insert: {
          appointment_date: string
          cancellation_reason?: string | null
          cancelled_at?: string | null
          client_id?: string | null
          client_name?: string | null
          client_phone?: string | null
          completed_at?: string | null
          confirmed_at?: string | null
          created_at?: string
          end_at?: string | null
          end_time: string
          establishment_id: string
          id?: string
          notes?: string | null
          professional_id: string
          service_id: string
          start_at?: string | null
          start_time: string
          status?: Database["public"]["Enums"]["appointment_status"]
          total_price: number
          updated_at?: string
        }
        Update: {
          appointment_date?: string
          cancellation_reason?: string | null
          cancelled_at?: string | null
          client_id?: string | null
          client_name?: string | null
          client_phone?: string | null
          completed_at?: string | null
          confirmed_at?: string | null
          created_at?: string
          end_at?: string | null
          end_time?: string
          establishment_id?: string
          id?: string
          notes?: string | null
          professional_id?: string
          service_id?: string
          start_at?: string | null
          start_time?: string
          status?: Database["public"]["Enums"]["appointment_status"]
          total_price?: number
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "appointments_client_id_fkey"
            columns: ["client_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "appointments_establishment_id_fkey"
            columns: ["establishment_id"]
            isOneToOne: false
            referencedRelation: "establishments"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "appointments_professional_id_fkey"
            columns: ["professional_id"]
            isOneToOne: false
            referencedRelation: "professionals"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "appointments_service_id_fkey"
            columns: ["service_id"]
            isOneToOne: false
            referencedRelation: "services"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "appointments_service_id_fkey"
            columns: ["service_id"]
            isOneToOne: false
            referencedRelation: "v_professional_services_effective"
            referencedColumns: ["service_id"]
          },
        ]
      }
      blocked_periods: {
        Row: {
          created_at: string
          end_at: string | null
          end_date: string
          end_time: string | null
          id: string
          is_all_day: boolean
          professional_id: string
          reason: string | null
          start_at: string | null
          start_date: string
          start_time: string | null
          type: Database["public"]["Enums"]["blocked_period_type"]
          updated_at: string
        }
        Insert: {
          created_at?: string
          end_at?: string | null
          end_date: string
          end_time?: string | null
          id?: string
          is_all_day?: boolean
          professional_id: string
          reason?: string | null
          start_at?: string | null
          start_date: string
          start_time?: string | null
          type?: Database["public"]["Enums"]["blocked_period_type"]
          updated_at?: string
        }
        Update: {
          created_at?: string
          end_at?: string | null
          end_date?: string
          end_time?: string | null
          id?: string
          is_all_day?: boolean
          professional_id?: string
          reason?: string | null
          start_at?: string | null
          start_date?: string
          start_time?: string | null
          type?: Database["public"]["Enums"]["blocked_period_type"]
          updated_at?: string
        }
        Relationships: []
      }
      categories: {
        Row: {
          active: boolean
          created_at: string
          id: string
          image_url: string | null
          name: string
          updated_at: string
        }
        Insert: {
          active?: boolean
          created_at?: string
          id?: string
          image_url?: string | null
          name: string
          updated_at?: string
        }
        Update: {
          active?: boolean
          created_at?: string
          id?: string
          image_url?: string | null
          name?: string
          updated_at?: string
        }
        Relationships: []
      }
      cities: {
        Row: {
          created_at: string
          id: string
          name: string
          updated_at: string
          visible: boolean
        }
        Insert: {
          created_at?: string
          id?: string
          name: string
          updated_at?: string
          visible?: boolean
        }
        Update: {
          created_at?: string
          id?: string
          name?: string
          updated_at?: string
          visible?: boolean
        }
        Relationships: []
      }
      cms_settings: {
        Row: {
          created_at: string
          description: string | null
          id: string
          key: string
          updated_at: string
          value: string
        }
        Insert: {
          created_at?: string
          description?: string | null
          id?: string
          key: string
          updated_at?: string
          value: string
        }
        Update: {
          created_at?: string
          description?: string | null
          id?: string
          key?: string
          updated_at?: string
          value?: string
        }
        Relationships: []
      }
      establishment_categories: {
        Row: {
          category_id: string
          created_at: string
          establishment_id: string
          id: string
          is_primary: boolean
        }
        Insert: {
          category_id: string
          created_at?: string
          establishment_id: string
          id?: string
          is_primary?: boolean
        }
        Update: {
          category_id?: string
          created_at?: string
          establishment_id?: string
          id?: string
          is_primary?: boolean
        }
        Relationships: [
          {
            foreignKeyName: "establishment_categories_category_id_fkey"
            columns: ["category_id"]
            isOneToOne: false
            referencedRelation: "categories"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "establishment_categories_establishment_id_fkey"
            columns: ["establishment_id"]
            isOneToOne: false
            referencedRelation: "establishments"
            referencedColumns: ["id"]
          },
        ]
      }
      establishment_hours: {
        Row: {
          close_time: string | null
          created_at: string
          day_of_week: number
          establishment_id: string
          id: string
          is_closed: boolean
          open_time: string | null
        }
        Insert: {
          close_time?: string | null
          created_at?: string
          day_of_week: number
          establishment_id: string
          id?: string
          is_closed?: boolean
          open_time?: string | null
        }
        Update: {
          close_time?: string | null
          created_at?: string
          day_of_week?: number
          establishment_id?: string
          id?: string
          is_closed?: boolean
          open_time?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "establishment_hours_establishment_id_fkey"
            columns: ["establishment_id"]
            isOneToOne: false
            referencedRelation: "establishments"
            referencedColumns: ["id"]
          },
        ]
      }
      establishment_photos: {
        Row: {
          caption: string | null
          created_at: string
          establishment_id: string
          id: string
          sort_order: number
          url: string
        }
        Insert: {
          caption?: string | null
          created_at?: string
          establishment_id: string
          id?: string
          sort_order?: number
          url: string
        }
        Update: {
          caption?: string | null
          created_at?: string
          establishment_id?: string
          id?: string
          sort_order?: number
          url?: string
        }
        Relationships: [
          {
            foreignKeyName: "establishment_photos_establishment_id_fkey"
            columns: ["establishment_id"]
            isOneToOne: false
            referencedRelation: "establishments"
            referencedColumns: ["id"]
          },
        ]
      }
      establishments: {
        Row: {
          address: string
          category_id: string | null
          city: string
          cover_image_url: string | null
          created_at: string
          description: string | null
          email: string | null
          id: string
          is_featured: boolean
          logo_url: string | null
          monthly_fee: number
          name: string
          next_payment_date: string
          phone: string | null
          slug: string | null
          state: string
          status: Database["public"]["Enums"]["establishment_status"]
          subscription_start_date: string
          updated_at: string
          website: string | null
        }
        Insert: {
          address: string
          category_id?: string | null
          city: string
          cover_image_url?: string | null
          created_at?: string
          description?: string | null
          email?: string | null
          id?: string
          is_featured?: boolean
          logo_url?: string | null
          monthly_fee?: number
          name: string
          next_payment_date?: string
          phone?: string | null
          slug?: string | null
          state: string
          status?: Database["public"]["Enums"]["establishment_status"]
          subscription_start_date?: string
          updated_at?: string
          website?: string | null
        }
        Update: {
          address?: string
          category_id?: string | null
          city?: string
          cover_image_url?: string | null
          created_at?: string
          description?: string | null
          email?: string | null
          id?: string
          is_featured?: boolean
          logo_url?: string | null
          monthly_fee?: number
          name?: string
          next_payment_date?: string
          phone?: string | null
          slug?: string | null
          state?: string
          status?: Database["public"]["Enums"]["establishment_status"]
          subscription_start_date?: string
          updated_at?: string
          website?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "establishments_category_id_fkey"
            columns: ["category_id"]
            isOneToOne: false
            referencedRelation: "categories"
            referencedColumns: ["id"]
          },
        ]
      }
      global_settings: {
        Row: {
          created_at: string
          description: string | null
          id: string
          key: string
          updated_at: string
          value: string
        }
        Insert: {
          created_at?: string
          description?: string | null
          id?: string
          key: string
          updated_at?: string
          value: string
        }
        Update: {
          created_at?: string
          description?: string | null
          id?: string
          key?: string
          updated_at?: string
          value?: string
        }
        Relationships: []
      }
      leads: {
        Row: {
          cidade: string
          created_at: string
          estabelecimento: string
          foto_url: string | null
          id: string
          responsavel: string
          servicos_json: Json
          status: string
          tipo: string
          updated_at: string
          whatsapp: string
        }
        Insert: {
          cidade: string
          created_at?: string
          estabelecimento: string
          foto_url?: string | null
          id?: string
          responsavel: string
          servicos_json?: Json
          status?: string
          tipo: string
          updated_at?: string
          whatsapp: string
        }
        Update: {
          cidade?: string
          created_at?: string
          estabelecimento?: string
          foto_url?: string | null
          id?: string
          responsavel?: string
          servicos_json?: Json
          status?: string
          tipo?: string
          updated_at?: string
          whatsapp?: string
        }
        Relationships: []
      }
      notifications: {
        Row: {
          created_at: string
          data: Json | null
          id: string
          message: string
          professional_id: string
          read: boolean
          title: string
          type: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          data?: Json | null
          id?: string
          message: string
          professional_id: string
          read?: boolean
          title: string
          type?: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          data?: Json | null
          id?: string
          message?: string
          professional_id?: string
          read?: boolean
          title?: string
          type?: string
          updated_at?: string
        }
        Relationships: []
      }
      plans: {
        Row: {
          active: boolean
          booking_limit: number
          created_at: string
          extras: string[] | null
          id: string
          name: string
          period: string
          price: number
          trial_days: number
          updated_at: string
        }
        Insert: {
          active?: boolean
          booking_limit?: number
          created_at?: string
          extras?: string[] | null
          id?: string
          name: string
          period: string
          price: number
          trial_days?: number
          updated_at?: string
        }
        Update: {
          active?: boolean
          booking_limit?: number
          created_at?: string
          extras?: string[] | null
          id?: string
          name?: string
          period?: string
          price?: number
          trial_days?: number
          updated_at?: string
        }
        Relationships: []
      }
      professional_services: {
        Row: {
          created_at: string | null
          custom_duration_minutes: number | null
          custom_price: number | null
          establishment_id: string
          id: string
          is_active: boolean
          professional_id: string
          service_id: string
          updated_at: string | null
        }
        Insert: {
          created_at?: string | null
          custom_duration_minutes?: number | null
          custom_price?: number | null
          establishment_id: string
          id?: string
          is_active?: boolean
          professional_id: string
          service_id: string
          updated_at?: string | null
        }
        Update: {
          created_at?: string | null
          custom_duration_minutes?: number | null
          custom_price?: number | null
          establishment_id?: string
          id?: string
          is_active?: boolean
          professional_id?: string
          service_id?: string
          updated_at?: string | null
        }
        Relationships: []
      }
      professionals: {
        Row: {
          active: boolean
          avatar_path: string | null
          avatar_url: string | null
          bio: string | null
          created_at: string
          establishment_id: string
          id: string
          is_public: boolean
          slug: string | null
          specialties: string[] | null
          updated_at: string
          user_id: string
        }
        Insert: {
          active?: boolean
          avatar_path?: string | null
          avatar_url?: string | null
          bio?: string | null
          created_at?: string
          establishment_id: string
          id?: string
          is_public?: boolean
          slug?: string | null
          specialties?: string[] | null
          updated_at?: string
          user_id: string
        }
        Update: {
          active?: boolean
          avatar_path?: string | null
          avatar_url?: string | null
          bio?: string | null
          created_at?: string
          establishment_id?: string
          id?: string
          is_public?: boolean
          slug?: string | null
          specialties?: string[] | null
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      profiles: {
        Row: {
          created_at: string
          deleted_at: string | null
          email: string
          establishment_id: string | null
          full_name: string
          id: string
          phone: string | null
          role: Database["public"]["Enums"]["user_role"]
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          deleted_at?: string | null
          email: string
          establishment_id?: string | null
          full_name: string
          id?: string
          phone?: string | null
          role?: Database["public"]["Enums"]["user_role"]
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          deleted_at?: string | null
          email?: string
          establishment_id?: string | null
          full_name?: string
          id?: string
          phone?: string | null
          role?: Database["public"]["Enums"]["user_role"]
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "fk_profiles_establishment"
            columns: ["establishment_id"]
            isOneToOne: false
            referencedRelation: "establishments"
            referencedColumns: ["id"]
          },
        ]
      }
      push_subscriptions: {
        Row: {
          auth: string
          created_at: string | null
          customer_id: string | null
          endpoint: string
          establishment_id: string
          id: string
          p256dh: string
          platform: string | null
          professional_id: string | null
          updated_at: string | null
          user_agent: string | null
          user_id: string
        }
        Insert: {
          auth: string
          created_at?: string | null
          customer_id?: string | null
          endpoint: string
          establishment_id: string
          id?: string
          p256dh: string
          platform?: string | null
          professional_id?: string | null
          updated_at?: string | null
          user_agent?: string | null
          user_id: string
        }
        Update: {
          auth?: string
          created_at?: string | null
          customer_id?: string | null
          endpoint?: string
          establishment_id?: string
          id?: string
          p256dh?: string
          platform?: string | null
          professional_id?: string | null
          updated_at?: string | null
          user_agent?: string | null
          user_id?: string
        }
        Relationships: []
      }
      reviews: {
        Row: {
          appointment_id: string | null
          client_id: string | null
          client_name: string | null
          comment: string | null
          created_at: string
          establishment_id: string
          establishment_rating: number
          id: string
          professional_id: string | null
          professional_rating: number
          updated_at: string
        }
        Insert: {
          appointment_id?: string | null
          client_id?: string | null
          client_name?: string | null
          comment?: string | null
          created_at?: string
          establishment_id: string
          establishment_rating: number
          id?: string
          professional_id?: string | null
          professional_rating: number
          updated_at?: string
        }
        Update: {
          appointment_id?: string | null
          client_id?: string | null
          client_name?: string | null
          comment?: string | null
          created_at?: string
          establishment_id?: string
          establishment_rating?: number
          id?: string
          professional_id?: string | null
          professional_rating?: number
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "reviews_establishment_id_fkey"
            columns: ["establishment_id"]
            isOneToOne: false
            referencedRelation: "establishments"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "reviews_professional_id_fkey"
            columns: ["professional_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      services: {
        Row: {
          created_at: string
          description: string | null
          duration_minutes: number
          establishment_id: string
          id: string
          image_url: string | null
          is_active: boolean
          name: string
          price: number
          sort_order: number
          updated_at: string
        }
        Insert: {
          created_at?: string
          description?: string | null
          duration_minutes: number
          establishment_id: string
          id?: string
          image_url?: string | null
          is_active?: boolean
          name: string
          price: number
          sort_order?: number
          updated_at?: string
        }
        Update: {
          created_at?: string
          description?: string | null
          duration_minutes?: number
          establishment_id?: string
          id?: string
          image_url?: string | null
          is_active?: boolean
          name?: string
          price?: number
          sort_order?: number
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "services_establishment_id_fkey"
            columns: ["establishment_id"]
            isOneToOne: false
            referencedRelation: "establishments"
            referencedColumns: ["id"]
          },
        ]
      }
      tenant_services: {
        Row: {
          active: boolean
          created_at: string
          duracao_min: number
          id: string
          nome: string
          preco: number
          tenant_id: string
          updated_at: string
        }
        Insert: {
          active?: boolean
          created_at?: string
          duracao_min?: number
          id?: string
          nome: string
          preco?: number
          tenant_id: string
          updated_at?: string
        }
        Update: {
          active?: boolean
          created_at?: string
          duracao_min?: number
          id?: string
          nome?: string
          preco?: number
          tenant_id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "tenant_services_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "tenants"
            referencedColumns: ["id"]
          },
        ]
      }
      tenant_settings: {
        Row: {
          created_at: string
          horario_funcionamento_json: Json
          id: string
          notificacoes_json: Json
          slot_duracao_min: number
          tenant_id: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          horario_funcionamento_json?: Json
          id?: string
          notificacoes_json?: Json
          slot_duracao_min?: number
          tenant_id: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          horario_funcionamento_json?: Json
          id?: string
          notificacoes_json?: Json
          slot_duracao_min?: number
          tenant_id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "tenant_settings_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: true
            referencedRelation: "tenants"
            referencedColumns: ["id"]
          },
        ]
      }
      tenant_users: {
        Row: {
          created_at: string
          first_login_at: string | null
          id: string
          login: string
          must_reset_password: boolean
          phone: string | null
          role: string
          senha_hash: string
          tenant_id: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          first_login_at?: string | null
          id?: string
          login: string
          must_reset_password?: boolean
          phone?: string | null
          role?: string
          senha_hash: string
          tenant_id: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          first_login_at?: string | null
          id?: string
          login?: string
          must_reset_password?: boolean
          phone?: string | null
          role?: string
          senha_hash?: string
          tenant_id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "tenant_users_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "tenants"
            referencedColumns: ["id"]
          },
        ]
      }
      tenants: {
        Row: {
          active: boolean
          cover_url: string | null
          created_at: string
          id: string
          lead_id: string
          plano: string
          slug: string
          trial_ends_at: string
          updated_at: string
          url_admin: string
          url_publica: string
        }
        Insert: {
          active?: boolean
          cover_url?: string | null
          created_at?: string
          id?: string
          lead_id: string
          plano?: string
          slug: string
          trial_ends_at?: string
          updated_at?: string
          url_admin: string
          url_publica: string
        }
        Update: {
          active?: boolean
          cover_url?: string | null
          created_at?: string
          id?: string
          lead_id?: string
          plano?: string
          slug?: string
          trial_ends_at?: string
          updated_at?: string
          url_admin?: string
          url_publica?: string
        }
        Relationships: [
          {
            foreignKeyName: "tenants_lead_id_fkey"
            columns: ["lead_id"]
            isOneToOne: false
            referencedRelation: "leads"
            referencedColumns: ["id"]
          },
        ]
      }
      user_roles: {
        Row: {
          created_at: string | null
          establishment_id: string
          id: string
          professional_id: string | null
          role: string
          user_id: string
        }
        Insert: {
          created_at?: string | null
          establishment_id: string
          id?: string
          professional_id?: string | null
          role: string
          user_id: string
        }
        Update: {
          created_at?: string | null
          establishment_id?: string
          id?: string
          professional_id?: string | null
          role?: string
          user_id?: string
        }
        Relationships: []
      }
    }
    Views: {
      v_appointments_finalized: {
        Row: {
          amount_cents: number | null
          end_at: string | null
          establishment_id: string | null
          id: string | null
          professional_id: string | null
          start_at: string | null
          status: Database["public"]["Enums"]["appointment_status"] | null
        }
        Insert: {
          amount_cents?: never
          end_at?: string | null
          establishment_id?: string | null
          id?: string | null
          professional_id?: string | null
          start_at?: string | null
          status?: Database["public"]["Enums"]["appointment_status"] | null
        }
        Update: {
          amount_cents?: never
          end_at?: string | null
          establishment_id?: string | null
          id?: string | null
          professional_id?: string | null
          start_at?: string | null
          status?: Database["public"]["Enums"]["appointment_status"] | null
        }
        Relationships: [
          {
            foreignKeyName: "appointments_establishment_id_fkey"
            columns: ["establishment_id"]
            isOneToOne: false
            referencedRelation: "establishments"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "appointments_professional_id_fkey"
            columns: ["professional_id"]
            isOneToOne: false
            referencedRelation: "professionals"
            referencedColumns: ["id"]
          },
        ]
      }
      v_finance_total_by_establishment: {
        Row: {
          establishment_id: string | null
          total_cents: number | null
        }
        Relationships: [
          {
            foreignKeyName: "appointments_establishment_id_fkey"
            columns: ["establishment_id"]
            isOneToOne: false
            referencedRelation: "establishments"
            referencedColumns: ["id"]
          },
        ]
      }
      v_finance_total_by_professional: {
        Row: {
          professional_id: string | null
          total_cents: number | null
        }
        Relationships: [
          {
            foreignKeyName: "appointments_professional_id_fkey"
            columns: ["professional_id"]
            isOneToOne: false
            referencedRelation: "professionals"
            referencedColumns: ["id"]
          },
        ]
      }
      v_professional_services_effective: {
        Row: {
          description: string | null
          duration_minutes: number | null
          establishment_id: string | null
          image_url: string | null
          is_active: boolean | null
          name: string | null
          price: number | null
          professional_id: string | null
          professional_service_id: string | null
          service_id: string | null
        }
        Relationships: []
      }
    }
    Functions: {
      create_appointment_rpc: {
        Args: {
          p_appointment_date: string
          p_client_id?: string
          p_client_name?: string
          p_client_phone?: string
          p_duration_minutes: number
          p_establishment_id: string
          p_professional_id: string
          p_service_id: string
          p_start_time: string
          p_status?: string
        }
        Returns: string
      }
      create_user_with_credentials: {
        Args: {
          p_email: string
          p_establishment_id?: string
          p_full_name: string
          p_password: string
          p_role: Database["public"]["Enums"]["user_role"]
        }
        Returns: Json
      }
      finance_breakdown_by_professional: {
        Args: { p_end?: string; p_establishment_id: string; p_start?: string }
        Returns: {
          professional_id: string
          total_cents: number
        }[]
      }
      finance_total_for_establishment: {
        Args: { p_end?: string; p_establishment_id: string; p_start?: string }
        Returns: number
      }
      finance_total_for_professional: {
        Args: { p_end?: string; p_professional_id: string; p_start?: string }
        Returns: number
      }
      gbt_bit_compress: {
        Args: { "": unknown }
        Returns: unknown
      }
      gbt_bool_compress: {
        Args: { "": unknown }
        Returns: unknown
      }
      gbt_bool_fetch: {
        Args: { "": unknown }
        Returns: unknown
      }
      gbt_bpchar_compress: {
        Args: { "": unknown }
        Returns: unknown
      }
      gbt_bytea_compress: {
        Args: { "": unknown }
        Returns: unknown
      }
      gbt_cash_compress: {
        Args: { "": unknown }
        Returns: unknown
      }
      gbt_cash_fetch: {
        Args: { "": unknown }
        Returns: unknown
      }
      gbt_date_compress: {
        Args: { "": unknown }
        Returns: unknown
      }
      gbt_date_fetch: {
        Args: { "": unknown }
        Returns: unknown
      }
      gbt_decompress: {
        Args: { "": unknown }
        Returns: unknown
      }
      gbt_enum_compress: {
        Args: { "": unknown }
        Returns: unknown
      }
      gbt_enum_fetch: {
        Args: { "": unknown }
        Returns: unknown
      }
      gbt_float4_compress: {
        Args: { "": unknown }
        Returns: unknown
      }
      gbt_float4_fetch: {
        Args: { "": unknown }
        Returns: unknown
      }
      gbt_float8_compress: {
        Args: { "": unknown }
        Returns: unknown
      }
      gbt_float8_fetch: {
        Args: { "": unknown }
        Returns: unknown
      }
      gbt_inet_compress: {
        Args: { "": unknown }
        Returns: unknown
      }
      gbt_int2_compress: {
        Args: { "": unknown }
        Returns: unknown
      }
      gbt_int2_fetch: {
        Args: { "": unknown }
        Returns: unknown
      }
      gbt_int4_compress: {
        Args: { "": unknown }
        Returns: unknown
      }
      gbt_int4_fetch: {
        Args: { "": unknown }
        Returns: unknown
      }
      gbt_int8_compress: {
        Args: { "": unknown }
        Returns: unknown
      }
      gbt_int8_fetch: {
        Args: { "": unknown }
        Returns: unknown
      }
      gbt_intv_compress: {
        Args: { "": unknown }
        Returns: unknown
      }
      gbt_intv_decompress: {
        Args: { "": unknown }
        Returns: unknown
      }
      gbt_intv_fetch: {
        Args: { "": unknown }
        Returns: unknown
      }
      gbt_macad_compress: {
        Args: { "": unknown }
        Returns: unknown
      }
      gbt_macad_fetch: {
        Args: { "": unknown }
        Returns: unknown
      }
      gbt_macad8_compress: {
        Args: { "": unknown }
        Returns: unknown
      }
      gbt_macad8_fetch: {
        Args: { "": unknown }
        Returns: unknown
      }
      gbt_numeric_compress: {
        Args: { "": unknown }
        Returns: unknown
      }
      gbt_oid_compress: {
        Args: { "": unknown }
        Returns: unknown
      }
      gbt_oid_fetch: {
        Args: { "": unknown }
        Returns: unknown
      }
      gbt_text_compress: {
        Args: { "": unknown }
        Returns: unknown
      }
      gbt_time_compress: {
        Args: { "": unknown }
        Returns: unknown
      }
      gbt_time_fetch: {
        Args: { "": unknown }
        Returns: unknown
      }
      gbt_timetz_compress: {
        Args: { "": unknown }
        Returns: unknown
      }
      gbt_ts_compress: {
        Args: { "": unknown }
        Returns: unknown
      }
      gbt_ts_fetch: {
        Args: { "": unknown }
        Returns: unknown
      }
      gbt_tstz_compress: {
        Args: { "": unknown }
        Returns: unknown
      }
      gbt_uuid_compress: {
        Args: { "": unknown }
        Returns: unknown
      }
      gbt_uuid_fetch: {
        Args: { "": unknown }
        Returns: unknown
      }
      gbt_var_decompress: {
        Args: { "": unknown }
        Returns: unknown
      }
      gbt_var_fetch: {
        Args: { "": unknown }
        Returns: unknown
      }
      gbtreekey_var_in: {
        Args: { "": unknown }
        Returns: unknown
      }
      gbtreekey_var_out: {
        Args: { "": unknown }
        Returns: unknown
      }
      gbtreekey16_in: {
        Args: { "": unknown }
        Returns: unknown
      }
      gbtreekey16_out: {
        Args: { "": unknown }
        Returns: unknown
      }
      gbtreekey2_in: {
        Args: { "": unknown }
        Returns: unknown
      }
      gbtreekey2_out: {
        Args: { "": unknown }
        Returns: unknown
      }
      gbtreekey32_in: {
        Args: { "": unknown }
        Returns: unknown
      }
      gbtreekey32_out: {
        Args: { "": unknown }
        Returns: unknown
      }
      gbtreekey4_in: {
        Args: { "": unknown }
        Returns: unknown
      }
      gbtreekey4_out: {
        Args: { "": unknown }
        Returns: unknown
      }
      gbtreekey8_in: {
        Args: { "": unknown }
        Returns: unknown
      }
      gbtreekey8_out: {
        Args: { "": unknown }
        Returns: unknown
      }
      get_establishment_professionals: {
        Args: { establishment_uuid: string }
        Returns: {
          created_at: string
          email: string
          establishment_id: string
          id: string
          name: string
          updated_at: string
        }[]
      }
      get_establishment_working_hours: {
        Args: { establishment_uuid: string }
        Returns: Json
      }
      get_super_admin_metrics: {
        Args: Record<PropertyKey, never>
        Returns: Json
      }
      get_user_establishment_id: {
        Args: { user_uuid?: string }
        Returns: string
      }
      get_user_role: {
        Args: { user_uuid?: string }
        Returns: Database["public"]["Enums"]["user_role"]
      }
      get_whatsapp_message_logs: {
        Args: { limit_count?: number }
        Returns: {
          body: Json
          created_at: string
          id: string
        }[]
      }
      rpc_activate_admin_professional_mode: {
        Args: { p_establishment_id: string; p_user_id: string }
        Returns: string
      }
      rpc_get_admin_professional_id: {
        Args: { p_establishment_id: string; p_user_id: string }
        Returns: string
      }
      rpc_get_available_services_for_professional: {
        Args: { p_establishment_id: string; p_professional_id: string }
        Returns: {
          description: string
          duration_minutes: number
          image_url: string
          name: string
          price: number
          service_id: string
        }[]
      }
      rpc_list_establishment_services: {
        Args: { p_establishment_id: string }
        Returns: {
          description: string
          duration_minutes: number
          image_url: string
          is_active: boolean
          name: string
          price: number
          service_id: string
        }[]
      }
    }
    Enums: {
      appointment_status: "scheduled" | "confirmed" | "completed" | "cancelled"
      blocked_period_type:
        | "vacation"
        | "sick_leave"
        | "personal"
        | "maintenance"
        | "other"
      establishment_status: "active" | "overdue" | "blocked"
      user_role: "super_admin" | "admin" | "professional" | "client" | "pro"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      appointment_status: ["scheduled", "confirmed", "completed", "cancelled"],
      blocked_period_type: [
        "vacation",
        "sick_leave",
        "personal",
        "maintenance",
        "other",
      ],
      establishment_status: ["active", "overdue", "blocked"],
      user_role: ["super_admin", "admin", "professional", "client", "pro"],
    },
  },
} as const
