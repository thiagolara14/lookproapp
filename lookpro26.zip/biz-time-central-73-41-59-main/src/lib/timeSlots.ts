export function generateTimeSlots(
  workingHours: { start: string; end: string },
  serviceDurationMin: number,
  busy: string[] = []
) {
  const toMinutes = (t: string) => {
    const [h, m] = t.split(":").map(Number);
    return h * 60 + m;
  };
  const toTime = (m: number) =>
    `${String(Math.floor(m / 60)).padStart(2, "0")}:${String(m % 60).padStart(2, "0")}`;

  const start = toMinutes(workingHours.start);
  const end = toMinutes(workingHours.end);
  const slots: { time: string; available: boolean }[] = [];
  for (let t = start; t + serviceDurationMin <= end; t += serviceDurationMin) {
    const time = toTime(t);
    slots.push({ time, available: !busy.includes(time) });
  }
  return slots;
}