import { supabase } from "@/integrations/supabase/client";

// VAPID Public Key - esta chave será substituída pelas keys reais no ambiente de produção
// Para gerar suas próprias chaves VAPID, use: npx web-push generate-vapid-keys
const VAPID_PUBLIC_KEY = "BN2CjBCJ8QWJfkYT8IHlYcEyYfUelCKvjqEXD2YLOjGDzVnaNLSzMnQjX8m3J5BtGhE6JYLpC8nZX7oNMjhLdHk";

interface EnsurePushSubscriptionParams {
  user: { id: string };
  professionalId?: string | null;
  customerId?: string | null;
  establishmentId: string;
}

// Utilitário para converter VAPID key para Uint8Array
function urlBase64ToUint8Array(base64String: string): Uint8Array {
  const padding = '='.repeat((4 - base64String.length % 4) % 4);
  const base64 = (base64String + padding).replace(/-/g, '+').replace(/_/g, '/');
  const rawData = atob(base64);
  const outputArray = new Uint8Array(rawData.length);
  for (let i = 0; i < rawData.length; ++i) {
    outputArray[i] = rawData.charCodeAt(i);
  }
  return outputArray;
}

// Registrar Service Worker se necessário
export async function registerServiceWorker(): Promise<ServiceWorkerRegistration | null> {
  if (!('serviceWorker' in navigator)) {
    console.warn('Service Worker não suportado');
    return null;
  }

  try {
    const registration = await navigator.serviceWorker.register('/sw.js');
    console.log('Service Worker registrado:', registration);
    return registration;
  } catch (error) {
    console.error('Erro ao registrar Service Worker:', error);
    return null;
  }
}

// Verificar se push notifications são suportadas
export function isPushNotificationSupported(): boolean {
  return 'serviceWorker' in navigator && 
         'PushManager' in window && 
         'Notification' in window;
}

// Solicitar permissão de notificação
export async function requestNotificationPermission(): Promise<NotificationPermission> {
  if (!('Notification' in window)) {
    return 'denied';
  }
  
  return await Notification.requestPermission();
}

// Garantir que push subscription está ativa e salvar no Supabase
export async function ensurePushSubscription({
  user,
  professionalId,
  customerId,
  establishmentId
}: EnsurePushSubscriptionParams): Promise<PushSubscription | null> {
  console.log('Ensuring push subscription for:', { user: user.id, professionalId, customerId, establishmentId });

  if (!isPushNotificationSupported()) {
    console.warn('Push notifications não suportadas');
    return null;
  }

  // Solicitar permissão
  const permission = await requestNotificationPermission();
  if (permission !== 'granted') {
    console.warn('Permissão de notificação negada:', permission);
    return null;
  }

  try {
    // Registrar Service Worker
    const registration = await registerServiceWorker();
    if (!registration) {
      console.error('Falha ao registrar Service Worker');
      return null;
    }

    // Aguardar Service Worker estar pronto
    const serviceWorkerReady = await navigator.serviceWorker.ready;
    
    // Converter VAPID key
    const applicationServerKey = urlBase64ToUint8Array(VAPID_PUBLIC_KEY);
    
    // Criar subscription
    const subscription = await serviceWorkerReady.pushManager.subscribe({
      userVisibleOnly: true,
      applicationServerKey
    });

    console.log('Push subscription criada:', subscription);

    // Extrair dados da subscription
    const { endpoint } = subscription;
    const subscriptionJSON = subscription.toJSON();
    const p256dh = subscriptionJSON?.keys?.p256dh;
    const auth = subscriptionJSON?.keys?.auth;

    if (!endpoint || !p256dh || !auth) {
      console.error('Dados de subscription inválidos');
      return null;
    }

    // Salvar no Supabase
    const { error } = await supabase
      .from('push_subscriptions')
      .upsert({
        user_id: user.id,
        professional_id: professionalId || null,
        customer_id: customerId || null,
        establishment_id: establishmentId,
        endpoint,
        p256dh,
        auth,
        user_agent: navigator.userAgent,
        platform: (navigator as any).userAgentData?.platform || null
      }, { 
        onConflict: 'endpoint' 
      });

    if (error) {
      console.error('Erro ao salvar subscription no Supabase:', error);
      return null;
    }

    console.log('Push subscription salva com sucesso no Supabase');
    return subscription;

  } catch (error) {
    console.error('Erro ao criar push subscription:', error);
    return null;
  }
}

// Remover subscription do usuário atual
export async function removePushSubscription(userId: string): Promise<boolean> {
  try {
    // Remover do browser
    const registration = await navigator.serviceWorker.ready;
    const subscription = await registration.pushManager.getSubscription();
    
    if (subscription) {
      await subscription.unsubscribe();
    }

    // Remover do Supabase
    const { error } = await supabase
      .from('push_subscriptions')
      .delete()
      .eq('user_id', userId);

    if (error) {
      console.error('Erro ao remover subscription do Supabase:', error);
      return false;
    }

    console.log('Push subscription removida com sucesso');
    return true;

  } catch (error) {
    console.error('Erro ao remover push subscription:', error);
    return false;
  }
}

// Verificar se já existe subscription ativa
export async function getExistingSubscription(): Promise<PushSubscription | null> {
  if (!isPushNotificationSupported()) {
    return null;
  }

  try {
    const registration = await navigator.serviceWorker.ready;
    return await registration.pushManager.getSubscription();
  } catch (error) {
    console.error('Erro ao verificar subscription existente:', error);
    return null;
  }
}

// Enviar notificação de broadcast (apenas para admins)
export async function sendBroadcastNotification({
  establishmentId,
  title,
  body,
  url
}: {
  establishmentId: string;
  title: string;
  body: string;
  url?: string;
}): Promise<{ success: boolean; error?: string }> {
  try {
    const session = await supabase.auth.getSession();
    if (!session.data.session?.access_token) {
      return { success: false, error: 'Usuário não autenticado' };
    }

    const response = await fetch(`https://fdxmegjbmglkbpylfeso.functions.supabase.co/push_dispatch`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${session.data.session.access_token}`
      },
      body: JSON.stringify({
        type: 'broadcast_admin',
        establishment_id: establishmentId,
        title,
        body,
        url: url || '/'
      })
    });

    const result = await response.json();
    
    if (!response.ok) {
      return { success: false, error: result.error || 'Erro ao enviar notificação' };
    }

    console.log('Broadcast enviado com sucesso:', result);
    return { success: true };

  } catch (error) {
    console.error('Erro ao enviar broadcast:', error);
    return { success: false, error: 'Erro de conexão' };
  }
}