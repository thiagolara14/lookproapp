// Feature flags configuration
export const FeatureFlags = {
  ONBOARDING_SELF_SERVE: true, // Enable self-serve onboarding
} as const;

// Onboarding configuration
export const OnboardingConfig = {
  SUPABASE_URL: "https://fdxmegjbmglkbpylfeso.supabase.co",
  SUPABASE_ANON_KEY: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImZkeG1lZ2pibWdsa2JweWxmZXNvIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTQ0MjY0MzUsImV4cCI6MjA3MDAwMjQzNX0.e9pKJeBp-FTaAfe5gG2lABhRW5SeUk2uEObX8SqsRLU",
  APP_PUBLIC_BASE_URL: "https://lookproapp.com.br",
  SUPPORT_WHATSAPP: "5511999999999"
} as const;

export type BackendDriver = 'firebase' | 'supabase';

export const BackendConfig = {
  DRIVER: (import.meta.env.VITE_BACKEND_DRIVER as BackendDriver) || 'supabase',
} as const;