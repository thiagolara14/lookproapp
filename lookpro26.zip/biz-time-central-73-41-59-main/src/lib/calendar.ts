function pad(n: number) {
  return String(n).padStart(2, "0");
}

function toICSDate(d: Date) {
  // Convert to UTC YYYYMMDDTHHMMSSZ
  const yyyy = d.getUTCFullYear();
  const mm = pad(d.getUTCMonth() + 1);
  const dd = pad(d.getUTCDate());
  const hh = pad(d.getUTCHours());
  const min = pad(d.getUTCMinutes());
  const ss = pad(d.getUTCSeconds());
  return `${yyyy}${mm}${dd}T${hh}${min}${ss}Z`;
}

export function buildICS(options: {
  title: string;
  description?: string;
  location?: string;
  start: Date;
  durationMin: number;
}) {
  const { title, description = "", location = "", start, durationMin } = options;
  const end = new Date(start.getTime() + durationMin * 60 * 1000);
  const uid = `${start.getTime()}@lookpro`;
  const dtstamp = toICSDate(new Date());
  const dtstart = toICSDate(start);
  const dtend = toICSDate(end);

  return `BEGIN:VCALENDAR\nVERSION:2.0\nPRODID:-//LookPro//BR\nCALSCALE:GREGORIAN\nBEGIN:VEVENT\nUID:${uid}\nDTSTAMP:${dtstamp}\nDTSTART:${dtstart}\nDTEND:${dtend}\nSUMMARY:${title.replace(/\n/g, " ")}\nDESCRIPTION:${description.replace(/\n/g, " ")}\nLOCATION:${location.replace(/\n/g, " ")}\nEND:VEVENT\nEND:VCALENDAR`;
}

export function downloadICS(filename: string, icsContent: string) {
  const blob = new Blob([icsContent], { type: "text/calendar;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename.endsWith(".ics") ? filename : `${filename}.ics`;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}
