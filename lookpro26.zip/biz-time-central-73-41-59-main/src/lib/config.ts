export type BackendProvider = "memory" | "firebase" | "supabase";

export const backend: { provider: BackendProvider } = {
  // All data now stored in Supabase - complete migration
  provider: "supabase",
};
