// Error reporting middleware for onboarding flow
import { FeatureFlags } from "@/lib/featureFlags";

export interface OnboardingError {
  correlationId: string;
  timestamp: string;
  phase: 'validation' | 'submission' | 'processing';
  payload?: Record<string, any>; // Sanitized payload
  httpStatus?: number;
  responseBody?: string;
  errorMessage: string;
  stack?: string;
}

// Generate correlation ID for error tracking
function generateCorrelationId(): string {
  return `ONB_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
}

// Sanitize payload by removing sensitive data
function sanitizePayload(payload: any): Record<string, any> {
  if (!payload || typeof payload !== 'object') return {};
  
  const sanitized = { ...payload };
  
  // Remove sensitive fields
  const sensitiveFields = ['foto_base64', 'password', 'token', 'recaptcha_token'];
  sensitiveFields.forEach(field => {
    if (sanitized[field]) {
      sanitized[field] = '[REDACTED]';
    }
  });
  
  // Mask phone numbers (keep only first 4 digits)
  if (sanitized.whatsapp && typeof sanitized.whatsapp === 'string') {
    const digits = sanitized.whatsapp.replace(/\D/g, '');
    if (digits.length > 4) {
      sanitized.whatsapp = `${digits.slice(0, 4)}****`;
    }
  }
  
  return sanitized;
}

// Report error with appropriate detail level based on environment
export function reportOnboardingError(error: {
  phase: OnboardingError['phase'];
  error: Error | string;
  payload?: any;
  httpStatus?: number;
  responseBody?: string;
}): string {
  const correlationId = generateCorrelationId();
  const isDev = process.env.NODE_ENV === 'development';
  
  const errorReport: OnboardingError = {
    correlationId,
    timestamp: new Date().toISOString(),
    phase: error.phase,
    payload: sanitizePayload(error.payload),
    httpStatus: error.httpStatus,
    responseBody: error.responseBody,
    errorMessage: typeof error.error === 'string' ? error.error : error.error.message,
    stack: isDev && typeof error.error !== 'string' ? error.error.stack : undefined
  };
  
  // Log different levels based on environment
  if (isDev) {
    console.error('🔥 Onboarding Error [DEV]:', errorReport);
  } else {
    console.error(`🔥 Onboarding Error [${correlationId}]:`, {
      phase: errorReport.phase,
      message: errorReport.errorMessage,
      httpStatus: errorReport.httpStatus
    });
  }
  
  return correlationId;
}

// Wrapper for form submission errors
export function reportSubmissionError(
  error: Error | string,
  payload: any,
  httpStatus?: number,
  responseBody?: string
): string {
  return reportOnboardingError({
    phase: 'submission',
    error,
    payload,
    httpStatus,
    responseBody
  });
}

// Wrapper for validation errors
export function reportValidationError(error: Error | string, payload: any): string {
  return reportOnboardingError({
    phase: 'validation',
    error,
    payload
  });
}

// Get user-friendly error message
export function getUserFriendlyMessage(phase: OnboardingError['phase']): string {
  switch (phase) {
    case 'validation':
      return 'Verifique os dados informados e tente novamente.';
    case 'submission':
      return 'Não conseguimos salvar agora. Revise o telefone e tente novamente.';
    case 'processing':
      return 'Erro no processamento. Tente novamente em alguns instantes.';
    default:
      return 'Erro inesperado. Tente novamente.';
  }
}
