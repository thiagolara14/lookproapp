// DEPRECATED: This file is neutralized in favor of Supabase
// All functionality moved to superAdminAdapters.ts

export type ID = string;

export type City = {
  id: ID;
  name: string;
  visible: boolean;
};

export type Category = {
  id: ID;
  name: string;
  imageUrl?: string;
};

export type PlanPeriod = "monthly" | "yearly";

export type Plan = {
  id: ID;
  name: string;
  price: number;
  period: PlanPeriod;
  trialDays: number;
  bookingLimit: number;
  extras: string[];
};

export type EstablishmentStatus = "active" | "inactive";

export type Establishment = {
  id: ID;
  name: string;
  status: EstablishmentStatus;
  cityId: string;
  categoryId: string;
  logo?: string;
  planId?: string;
  workingHours?: { start: string; end: string };
  lastAccessAt?: number;
};

export type UserRole = "super_admin" | "admin" | "professional" | "client";
export type UserStatus = "active" | "blocked";

export type User = {
  id: ID;
  name: string;
  email: string;
  role: UserRole;
  establishmentId?: string;
  status: UserStatus;
};

export type Review = {
  id: ID;
  establishmentId: string;
  userName: string;
  rating: number;
  comment?: string;
  date: string;
};

export type Booking = {
  id: ID;
  establishmentId: string;
  establishmentName?: string;
  clientName?: string;
  service?: string;
  date: string;
  time?: string;
  status?: string;
  userEmail?: string;
  price?: number;
};

// All functions are neutralized - use superAdminAdapters instead
export const listCities = () => [];
export const addCity = (name: string) => {};
export const toggleCity = (id: ID) => {};
export const updateCity = (id: ID, name: string) => {};
export const deleteCity = (id: ID) => {};

export const listCategories = () => [];
export const addCategory = (name: string, imageUrl?: string) => {};
export const updateCategory = (id: ID, name: string, imageUrl?: string) => {};
export const deleteCategory = (id: ID) => {};

export const listPlans = () => [];
export const upsertPlan = (plan: any) => {};
export const deletePlan = (id: ID) => {};

export const listEstablishments = () => [];
export const upsertEstablishment = (establishment: any) => ({} as Establishment);
export const toggleEstablishment = (id: ID) => {};
export const deleteEstablishment = (id: ID) => {};

export const listUsers = () => [];
export const upsertUser = (payload: any) => {};
export const toggleUserBlock = (id: ID) => {};
export const deleteUser = (id: ID) => {};

export const listReviews = () => [];
export const deleteReview = (id: ID) => {};

export const listBookings = () => [];

export const metrics = () => ({
  totalEst: 0, active: 0, inactive: 0, totalBookings: 0, uniqueUsers: 0,
  mrr: 0, arr: 0, revenueByPlan: [], byCity: [], byCategory: [], byPeriod: []
});

export const exportToCsv = (data: any[] | string, filename?: string) => {
  console.warn('exportToCsv is deprecated - use Supabase directly');
};