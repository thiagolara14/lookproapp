// DEPRECATED: This file is neutralized in favor of Supabase storage
// All functionality moved to direct Supabase operations

export type ServiceDurationConfig = {
  mode: "all" | "perPro";
  durationMin?: number;
  perPro?: Record<string, number>;
};

export type Address = {
  street?: string;
  number?: string;
  neighborhood?: string;
  city?: string;
  state?: string;
  zip?: string;
};

export type EstProfile = {
  socials?: {
    instagram?: string;
    facebook?: string;
    tiktok?: string;
    website?: string;
    whatsapp?: string;
  };
  coverUrl?: string;
  logoUrl?: string;
  gallery?: string[];
  address?: Address;
  serviceDurations?: Record<string, ServiceDurationConfig>;
};

// Neutralized functions - return empty objects
export const getEstProfile = (estId: string): EstProfile => {
  return {};
};

export const updateEstProfile = (estId: string, payload: Partial<EstProfile>) => {
  console.warn('updateEstProfile is deprecated - use Supabase directly');
  return {};
};