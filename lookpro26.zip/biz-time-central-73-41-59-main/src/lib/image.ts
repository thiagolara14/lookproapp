// src/lib/image.ts
export type ProcessedImage = {
  blob: Blob;
  filename: string;
  contentType: string;
};

export async function ensureImageFitsRules(file: File, opts?: { maxEdge?: number; maxBytes?: number }): Promise<ProcessedImage> {
  const maxEdge = opts?.maxEdge ?? 1600;   // redimensiona no máximo para 1600px
  const maxBytes = opts?.maxBytes ?? 5 * 1024 * 1024; // 5MB

  // Se já é imagem e <=5MB, retorna como está
  if (file.type.startsWith("image/") && file.size <= maxBytes) {
    return { blob: file, filename: sanitizeName(file.name), contentType: file.type };
  }

  const img = await fileToImage(file);
  const { width, height } = fitCover(img.width, img.height, maxEdge);
  const canvas = document.createElement("canvas");
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext("2d")!;
  ctx.drawImage(img, 0, 0, width, height);

  // converte para JPEG de forma progressiva caso ultrapasse 5MB
  let quality = 0.9;
  let blob: Blob = await canvasToBlob(canvas, "image/jpeg", quality);
  while (blob.size > maxBytes && quality > 0.4) {
    quality -= 0.1;
    blob = await canvasToBlob(canvas, "image/jpeg", quality);
  }

  const name = file.name.replace(/\.[^.]+$/, "") || "image";
  return { blob, filename: `${name}.jpg`, contentType: "image/jpeg" };
}

function sanitizeName(name: string) {
  return name.normalize("NFKD").replace(/[^\w.\-]+/g, "_");
}

function fitCover(w: number, h: number, max: number) {
  if (Math.max(w, h) <= max) return { width: w, height: h };
  const ratio = w > h ? max / w : max / h;
  return { width: Math.round(w * ratio), height: Math.round(h * ratio) };
}

function fileToImage(file: File): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const url = URL.createObjectURL(file);
    const img = new Image();
    img.onload = () => { URL.revokeObjectURL(url); resolve(img); };
    img.onerror = reject;
    img.src = url;
  });
}

function canvasToBlob(canvas: HTMLCanvasElement, type: string, quality?: number): Promise<Blob> {
  return new Promise((resolve) => canvas.toBlob((b) => resolve(b!), type, quality));
}