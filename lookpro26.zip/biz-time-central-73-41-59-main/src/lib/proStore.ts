// DEPRECATED: This file is neutralized in favor of Supabase
// All functionality should use Supabase adapters directly

export type ID = string;

export type Pro = {
  id: ID;
  name: string;
  email: string;
  establishmentName: string;
  avatarUrl?: string;
  whatsapp?: string;
};

export type ProService = {
  id: ID;
  name: string;
  durationMin: number;
  price?: number;
};

export type AppointmentStatus = "scheduled" | "completed" | "no_show" | "canceled";

export type Appointment = {
  id: ID;
  professionalId: ID;
  clientName: string;
  clientPhone: string;
  serviceId: ID;
  serviceName: string;
  startsAt: string;
  durationMin: number;
  status: AppointmentStatus;
};

export type ProReview = {
  id: ID;
  professionalId: ID;
  rating: number;
  comment?: string;
  clientName?: string;
  serviceName: string;
  date: string;
};

export type ProNotification = {
  id: ID;
  professionalId: ID;
  type: "new" | "canceled" | "rescheduled" | "reminder";
  message: string;
  createdAt: string;
  read: boolean;
  archived: boolean;
};

export type BlockedSlot = {
  id: ID;
  professionalId: ID;
  startsAt: string;
  durationMin: number;
};

// All functions are neutralized - use Supabase adapters instead
export const getSession = (): Pro | null => null;
export const setSession = (proId: ID) => {};
export const clearSession = () => {};

export const getPro = (id: ID) => undefined;
export const listAllPros = () => [];

export const listAppointmentsByPro = (professionalId: ID) => [];
export const setAppointmentStatus = (id: ID, status: AppointmentStatus) => {};
export const createAppointment = (payload: any) => null;

export const listServicesByPro = (professionalId: ID): ProService[] => [];
export const listReviewsByPro = (professionalId: ID) => [];
export const listNotificationsByPro = (professionalId: ID) => [];
export const markNotificationRead = (id: ID) => {};
export const archiveNotification = (id: ID) => {};

export const listBlockedSlotsByPro = (professionalId: ID) => [];
export const isSlotBlocked = (professionalId: ID, startsAt: string) => false;
export const toggleBlockedSlot = (professionalId: ID, startsAt: string, durationMin = 30) => {};

export const updateProfile = (proId: ID, payload: any) => {};