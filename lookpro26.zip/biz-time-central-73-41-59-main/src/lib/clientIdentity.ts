// Cliente Identity via WhatsApp (usando Supabase como backend)
export function normalizePhone(input: string): string {
  const digits = input.replace(/\D/g, "");
  // Regra simples: se começar com 55 assume BR, senão prefixa 55 quando tem 10-11 dígitos
  if (digits.startsWith("55")) return digits;
  if (digits.length === 10 || digits.length === 11) return `55${digits}`;
  return digits; // fallback
}

const KEY = "lookpro_client_key";

export function getClientKey(): string | null {
  if (typeof window === "undefined") return null;
  try {
    return localStorage.getItem(KEY);
  } catch {
    return null;
  }
}

export function setClientKey(phone: string) {
  if (typeof window === "undefined") return;
  const normalized = normalizePhone(phone);
  try {
    localStorage.setItem(KEY, normalized);
  } catch {
    // ignore
  }
}

export function clearClientKey() {
  if (typeof window === "undefined") return;
  try {
    localStorage.removeItem(KEY);
  } catch {}
}

// Optional: store client display name locally for a nicer UX across pages
const NAME_KEY = "lookpro_client_name";
export function getClientName(): string | null {
  if (typeof window === "undefined") return null;
  try {
    return localStorage.getItem(NAME_KEY);
  } catch {
    return null;
  }
}

export function setClientName(name: string) {
  if (typeof window === "undefined") return;
  try {
    localStorage.setItem(NAME_KEY, name.trim());
  } catch {
    // ignore
  }
}