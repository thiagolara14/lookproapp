export type AppointmentStatus = "pendente" | "confirmado" | "concluído" | "cancelado";

export type WorkingHours = {
  start: string; // "09:00"
  end: string;   // "18:00"
};

export type ProfessionalWorkingHours = {
  professionalId: string;
  // Optional per-weekday overrides (0=Sun .. 6=Sat). Fallback to establishment working hours when undefined
  byWeekday?: Partial<Record<number, WorkingHours>>;
};

export type Appointment = {
  id: string;
  establishmentId: string;
  professionalId: string;
  professionalName: string;
  clientId: string;
  clientName: string;
  serviceId: string;
  serviceName: string;
  date: string; // YYYY-MM-DD
  time: string; // HH:mm
  duration?: number; // minutes
  price?: number; // in cents
  status: AppointmentStatus;
  notes?: string;
  reschedules?: number; // how many times rescheduled
  createdAt: string; // ISO
  updatedAt: string; // ISO
};
