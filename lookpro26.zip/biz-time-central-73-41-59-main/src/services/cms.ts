// CMS service using Supabase only
import { supabase } from "@/integrations/supabase/client";

export type CMSFaq = { id: string; q: string; a: string };
export type CMSTheme = {
  primaryColor: string; 
  themeColor: string; 
  backgroundColor: string; 
};
export type CMSBrand = {
  appName: string;
  shortName: string;
  logoUrl?: string; // Storage URL
};
export type CMSHomepage = {
  heroTitle: string;
  heroSubtitle: string;
  heroImageUrl?: string; // Storage URL
};
export type CMSSeo = {
  defaultTitle: string;
  defaultDescription: string;
};

export type CMSConfig = {
  theme: CMSTheme;
  brand: CMSBrand;
  homepage: CMSHomepage;
  seo: CMSSeo;
  faqs: CMSFaq[];
};

const uid = () => crypto.randomUUID();

const defaultConfig = (): CMSConfig => ({
  theme: {
    primaryColor: "hsl(252 95% 60%)",
    themeColor: "#0f172a",
    backgroundColor: "#0b1220",
  },
  brand: {
    appName: "LookPro",
    shortName: "LookPro",
    logoUrl: undefined,
  },
  homepage: {
    heroTitle: "Agende serviços e gerencie seu negócio com LookPro",
    heroSubtitle: "Vitrine pública, agendamento sem conta e painéis para cliente, profissional, admin e super admin.",
    heroImageUrl: undefined,
  },
  seo: {
    defaultTitle: "LookPro — Agendamentos e Gestão Multi-tenant",
    defaultDescription: "Agendamento online, vitrine e gestão completa para serviços locais.",
  },
  faqs: [
    { id: uid(), q: "O que é o LookPro?", a: "Uma plataforma de agendamentos e gestão para serviços locais." },
  ],
});

function mapSettingsToCMSConfig(settings: Record<string, string>): CMSConfig {
  const faqs = JSON.parse(settings.faqs || '[]');
  return {
    theme: {
      primaryColor: settings.theme_primary_color || "hsl(252 95% 60%)",
      themeColor: settings.theme_color || "#0f172a",
      backgroundColor: settings.theme_background_color || "#0b1220",
    },
    brand: {
      appName: settings.brand_app_name || "LookPro",
      shortName: settings.brand_short_name || "LookPro",
      logoUrl: settings.brand_logo_url,
    },
    homepage: {
      heroTitle: settings.homepage_hero_title || "Agende serviços e gerencie seu negócio com LookPro",
      heroSubtitle: settings.homepage_hero_subtitle || "Vitrine pública, agendamento sem conta e painéis para cliente, profissional, admin e super admin.",
      heroImageUrl: settings.homepage_hero_image_url,
    },
    seo: {
      defaultTitle: settings.seo_default_title || "LookPro — Agendamentos e Gestão Multi-tenant",
      defaultDescription: settings.seo_default_description || "Agendamento online, vitrine e gestão completa para serviços locais.",
    },
    faqs: Array.isArray(faqs) ? faqs : [
      { id: uid(), q: "O que é o LookPro?", a: "Uma plataforma de agendamentos e gestão para serviços locais." },
    ],
  };
}

export async function readSupabaseCMSSettings(): Promise<Record<string, string>> {
  const { data, error } = await supabase
    .from('cms_settings')
    .select('key, value');
  
  if (error) throw error;
  
  const settings: Record<string, string> = {};
  data.forEach(item => {
    settings[item.key] = item.value;
  });
  
  return settings;
}

export async function readCMS(): Promise<CMSConfig> {
  try {
    const settings = await readSupabaseCMSSettings();
    return mapSettingsToCMSConfig(settings);
  } catch (error) {
    console.warn('Failed to read CMS from Supabase, using defaults:', error);
    return defaultConfig();
  }
}

export async function updateSupabaseCMSSetting(key: string, value: string): Promise<void> {
  const { error } = await supabase
    .from('cms_settings')
    .upsert({ key, value });
  
  if (error) throw error;
}

export async function updateSupabaseCMSSettings(settings: Record<string, string>): Promise<void> {
  const updates = Object.entries(settings).map(([key, value]) => ({ key, value }));
  
  const { error } = await supabase
    .from('cms_settings')
    .upsert(updates);
  
  if (error) throw error;
}

export async function updateCMS(cfg: CMSConfig): Promise<void> {
  const settings = {
    theme_primary_color: cfg.theme.primaryColor,
    theme_color: cfg.theme.themeColor,
    theme_background_color: cfg.theme.backgroundColor,
    brand_app_name: cfg.brand.appName,
    brand_short_name: cfg.brand.shortName,
    brand_logo_url: cfg.brand.logoUrl || '',
    homepage_hero_title: cfg.homepage.heroTitle,
    homepage_hero_subtitle: cfg.homepage.heroSubtitle,
    homepage_hero_image_url: cfg.homepage.heroImageUrl || '',
    seo_default_title: cfg.seo.defaultTitle,
    seo_default_description: cfg.seo.defaultDescription,
    faqs: JSON.stringify(cfg.faqs),
  };
  
  await updateSupabaseCMSSettings(settings);
}

export async function uploadAsset(file: File, name: string): Promise<string> {
  const fileExt = file.name.split('.').pop();
  const fileName = `${name}.${fileExt}`;
  const filePath = `${fileName}`;

  const { error } = await supabase.storage
    .from('cms-assets')
    .upload(filePath, file, { upsert: true });

  if (error) throw error;

  const { data } = supabase.storage
    .from('cms-assets')
    .getPublicUrl(filePath);

  return data.publicUrl;
}

export async function applyPWAFromCMS(): Promise<void> {
  try {
    const cfg = await readCMS();
    
    // theme-color meta
    let meta = document.querySelector('meta[name="theme-color"]');
    if (!meta) {
      meta = document.createElement('meta');
      meta.setAttribute('name', 'theme-color');
      document.head.appendChild(meta);
    }
    meta.setAttribute('content', cfg.theme.themeColor);

    // dynamic manifest link using data URL
    const manifest: any = {
      name: cfg.brand.appName,
      short_name: cfg.brand.shortName,
      theme_color: cfg.theme.themeColor,
      background_color: cfg.theme.backgroundColor,
      display: 'standalone',
      icons: [],
    };
    
    // Use logo from storage if available
    if (cfg.brand.logoUrl) {
      manifest.icons.push({ 
        src: cfg.brand.logoUrl, 
        sizes: '192x192', 
        type: 'image/png' 
      });
    }
    
    const blob = new Blob([JSON.stringify(manifest)], { type: 'application/manifest+json' });
    let link = document.querySelector('link[rel="manifest"]') as HTMLLinkElement | null;
    if (!link) {
      link = document.createElement('link');
      link.setAttribute('rel', 'manifest');
      document.head.appendChild(link);
    }
    link.href = URL.createObjectURL(blob);
  } catch (error) {
    console.warn('Failed to apply PWA config from CMS:', error);
  }
}