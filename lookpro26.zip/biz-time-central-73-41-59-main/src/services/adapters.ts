import { supabase } from "@/integrations/supabase/client";
import type { Appointment, AppointmentStatus } from "@/types/appointments";
import { backend } from "@/lib/config";
import * as supabaseAppointments from "@/services/supabase/appointments";
import * as supabaseEstablishments from "@/services/supabase/establishments";

// Status mapping helpers
function mapToSupabaseStatus(status: AppointmentStatus): string {
  const statusMap: Record<AppointmentStatus, string> = {
    "pendente": "scheduled",
    "confirmado": "confirmed", 
    "concluído": "completed",
    "cancelado": "cancelled"
  };
  return statusMap[status] || "scheduled";
}

function mapFromSupabaseStatus(status: string): AppointmentStatus {
  const statusMap: Record<string, AppointmentStatus> = {
    "scheduled": "pendente",
    "confirmed": "confirmado",
    "completed": "concluído", 
    "cancelled": "cancelado"
  };
  return statusMap[status] || "pendente";
}

export type ListOptions = { date?: string };

export interface AppointmentsAdapter {
  create(input: {
    establishmentId: string;
    clientId: string;
    clientName: string;
    professionalId: string;
    professionalName: string;
    serviceId: string;
    serviceName: string;
    date: string;
    time: string;
    duration?: number;
    price?: number;
    status?: AppointmentStatus;
    notes?: string;
  }): Promise<Appointment>;
  update(id: string, patch: Partial<Appointment>): Promise<Appointment>;
  delete(id: string): Promise<void>;
  getById(id: string): Promise<Appointment | null>;
  listByProfessional(professionalId: string, opts?: ListOptions): Promise<Appointment[]>;
  listByEstablishment(establishmentId: string, opts?: ListOptions): Promise<Appointment[]>;
  listByClient(clientId: string): Promise<Appointment[]>;
}

// Re-export types that other files need
export type Professional = {
  id: string;
  name: string;
  email: string;
  establishmentId: string;
  services: string[];
  createdAt: string;
  updatedAt: string;
};

export type Service = {
  id: string;
  name: string;
  description: string;
  duration: number;
  price: number;
  establishmentId: string;
  createdAt: string;
  updatedAt: string;
};

export type BlockedPeriod = {
  id: string;
  professionalId: string;
  start: string;
  end: string;
  reason?: string;
};

export type Notification = {
  id: string;
  professionalId: string;
  message: string;
  read: boolean;
  createdAt: string;
};

// Placeholder adapters for Supabase integration
export const professionalsAdapter = {
  async listByEstablishment(establishmentId: string): Promise<any[]> {
    try {
      // Usar função RPC que tem as permissões adequadas
      const { data: professionals, error: proError } = await supabase
        .rpc('get_establishment_professionals', { 
          establishment_uuid: establishmentId 
        });
      
      if (proError) throw proError;
      if (!professionals?.length) return [];

      return professionals.map((p: any) => {
        // Extrair dados estruturados do bio se estiverem em JSON
        let bioData = { whatsapp: '', experienceYears: 1, description: '' };
        try {
          if (p.bio) {
            const parsed = JSON.parse(p.bio);
            bioData = {
              whatsapp: parsed.whatsapp || '',
              experienceYears: parsed.experienceYears || 1,
              description: parsed.description || p.bio
            };
          }
        } catch {
          bioData.description = p.bio || '';
        }

        return {
          id: p.id,
          name: p.name || 'Profissional',
          email: p.email || '',
          phone: '', // Não disponível na função RPC
          whatsapp: bioData.whatsapp,
          bio: bioData.description,
          specialties: p.specialties || [],
          experienceYears: bioData.experienceYears,
          avatarUrl: p.avatar_url || '',
          establishmentId: p.establishment_id,
          services: [],
          createdAt: p.created_at,
          updatedAt: p.updated_at,
        };
      });
    } catch (error) {
      console.error('Error fetching professionals:', error);
      return [];
    }
  },
  
  async getById(id: string): Promise<Professional | null> {
    const { data: p, error: e1 } = await supabase
      .from("professionals")
      .select("id, user_id, establishment_id, created_at, updated_at")
      .eq("id", id)
      .single();
    if (e1) return null;

    const { data: u } = await supabase
      .from("profiles")
      .select("full_name, email")
      .eq("user_id", p.user_id)
      .single();

    return {
      id: p.id,
      name: u?.full_name ?? 'Profissional',
      email: u?.email ?? '',
      establishmentId: p.establishment_id,
      services: [],
      createdAt: p.created_at,
      updatedAt: p.updated_at,
    };
  },
  
  async getByUserId(userId: string): Promise<Professional | null> {
    const { data: p, error } = await supabase
      .from('professionals')
      .select('id, establishment_id, created_at, updated_at')
      .eq('user_id', userId)
      .single();
    if (error) return null;

    const { data: u } = await supabase
      .from('profiles')
      .select('full_name, email')
      .eq('user_id', userId)
      .single();

    return {
      id: p.id,
      name: u?.full_name ?? 'Profissional',
      email: u?.email ?? '',
      establishmentId: p.establishment_id,
      services: [],
      createdAt: p.created_at,
      updatedAt: p.updated_at,
    };
  },
  
  async getByEmail(email: string): Promise<Professional | null> {
    console.log('Getting professional by email:', email);
    
    // First get user by email from profiles
    const { data: profile, error: e1 } = await supabase
      .from('profiles')
      .select('user_id, full_name, email')
      .eq('email', email)
      .eq('role', 'professional') // Changed from 'pro' to 'professional'
      .single();
    
    console.log('Profile found:', profile, 'error:', e1);
    
    if (e1) {
      console.log('Error finding profile:', e1);
      return null;
    }

    // Then get professional record
    const { data: pro, error: e2 } = await supabase
      .from('professionals')
      .select('id, establishment_id, created_at, updated_at')
      .eq('user_id', profile.user_id)
      .single();
    
    console.log('Professional record found:', pro, 'error:', e2);
    
    if (e2) {
      console.log('Error finding professional record:', e2);
      return null;
    }
    
    const result = {
      id: pro.id,
      name: profile.full_name,
      email: profile.email,
      establishmentId: pro.establishment_id,
      services: [],
      createdAt: pro.created_at,
      updatedAt: pro.updated_at,
    };
    
    console.log('Returning professional:', result);
    return result;
  },
  
  async create(professional: Omit<Professional, 'id'>): Promise<Professional> {
    // Implementation would create new professional
    const newProfessional = { ...professional, id: crypto.randomUUID() };
    return newProfessional;
  },
  
  async update(id: string, updates: Partial<Professional>): Promise<Professional> {
    // Implementation would update existing professional
    const existing = await this.getById(id);
    if (!existing) throw new Error('Professional not found');
    return { ...existing, ...updates };
  },
  
  async delete(id: string): Promise<void> {
    // Implementation would delete professional
    console.log('Deleting professional:', id);
  }
};

export const servicesAdapter = {
  async listByEstablishment(establishmentId: string, opts?: { active?: boolean }): Promise<Service[]> {
    let query = supabase
      .from('services')
      .select('*')
      .eq('establishment_id', establishmentId);
    
    // Apply active filter only if explicitly requested
    if (opts?.active !== undefined) {
      query = query.eq('is_active', opts.active);
    } else {
      // Default behavior: only show active services
      query = query.eq('is_active', true);
    }
    
    const { data, error } = await query;
    
    if (error) throw error;
    
    return data.map(service => ({
      id: service.id,
      name: service.name,
      description: service.description || '',
      duration: service.duration_minutes,
      price: Number(service.price),
      establishmentId: service.establishment_id,
      createdAt: service.created_at,
      updatedAt: service.updated_at,
    }));
  },
  
  async getById(id: string): Promise<Service | null> {
    const { data, error } = await supabase
      .from('services')
      .select('*')
      .eq('id', id)
      .single();
    
    if (error) return null;
    
    return {
      id: data.id,
      name: data.name,
      description: data.description || '',
      duration: data.duration_minutes,
      price: Number(data.price),
      establishmentId: data.establishment_id,
      createdAt: data.created_at,
      updatedAt: data.updated_at,
    };
  },
  
  async create(service: Omit<Service, 'id'>): Promise<Service> {
    const { data, error } = await supabase
      .from('services')
      .insert({
        establishment_id: service.establishmentId,
        name: service.name,
        description: service.description,
        price: service.price,
        duration_minutes: service.duration,
        is_active: true
      })
      .select()
      .single();
    
    if (error) throw error;
    
    return {
      id: data.id,
      name: data.name,
      description: data.description || '',
      duration: data.duration_minutes,
      price: Number(data.price),
      establishmentId: data.establishment_id,
      createdAt: data.created_at,
      updatedAt: data.updated_at,
    };
  },
  
  async update(id: string, updates: Partial<Service>): Promise<Service> {
    const updateData: any = {};
    if (updates.name) updateData.name = updates.name;
    if (updates.description !== undefined) updateData.description = updates.description;
    if (updates.price !== undefined) updateData.price = updates.price;
    if (updates.duration !== undefined) updateData.duration_minutes = updates.duration;
    
    const { data, error } = await supabase
      .from('services')
      .update(updateData)
      .eq('id', id)
      .select()
      .single();
    
    if (error) throw error;
    
    return {
      id: data.id,
      name: data.name,
      description: data.description || '',
      duration: data.duration_minutes,
      price: Number(data.price),
      establishmentId: data.establishment_id,
      createdAt: data.created_at,
      updatedAt: data.updated_at,
    };
  },
  
  async delete(id: string): Promise<void> {
    const { error } = await supabase
      .from('services')
      .update({ is_active: false })
      .eq('id', id);
    
    if (error) throw error;
  }
};

export const establishmentsAdapter = {
  async getWorkingHours(establishmentId: string) {
    const { data, error } = await supabase.rpc('get_establishment_working_hours', {
      establishment_uuid: establishmentId
    });

    if (!error && data && Object.keys(data || {}).length > 0) {
      return data;
    }

    // Fallback: read directly from establishment_hours table
    const { data: hours, error: hoursError } = await supabase
      .from('establishment_hours')
      .select('*')
      .eq('establishment_id', establishmentId);

    if (hoursError || !hours || hours.length === 0) {
      console.error('Error fetching working hours (RPC and fallback failed):', error || hoursError);
      return {};
    }

    const workingHours: any = {};
    hours.forEach((h: any) => {
      const key = String(h.day_of_week);
      workingHours[key] = {
        start: h.open_time || '00:00',
        end: h.close_time || '00:00',
        closed: !!h.is_closed,
      };
    });

    return workingHours;
  },

  async getById(id: string) {
    const { data: est, error: e1 } = await supabase
      .from('establishments')
      .select('*')
      .eq('id', id)
      .maybeSingle();
    if (e1) throw e1;
    if (!est) return null;
    
    // Get working hours and reviews in parallel
    const [hoursRes, reviewsRes] = await Promise.all([
      supabase.from('establishment_hours').select('*').eq('establishment_id', id),
      supabase.from('reviews').select('establishment_rating, professional_rating').eq('establishment_id', id)
    ]);
    
    const workingHours = hoursRes.data?.reduce((acc, h) => {
      acc[h.day_of_week] = {
        start: h.open_time || '00:00',
        end: h.close_time || '00:00',
        closed: h.is_closed
      };
      return acc;
    }, {} as any) || { start: '00:00', end: '00:00' };
    
    // Calculate real rating
    let rating = undefined;
    const reviews = reviewsRes.data || [];
    if (reviews.length > 0) {
      const totalRating = reviews.reduce((sum, review) => {
        return sum + (review.establishment_rating || review.professional_rating || 0);
      }, 0);
      rating = Math.round((totalRating / reviews.length) * 10) / 10;
    }
    
    return {
      id: est.id,
      name: est.name,
      address: est.address,
      city: est.city,
      phone: est.phone,
      email: est.email,
      category: 'Barbearia' as any,
      logoUrl: est.logo_url,
      coverImageUrl: est.cover_image_url,
      isActive: est.status === 'active',
      status: est.status,
      services: [],
      professionals: [],
      workingHours,
      rating,
    };
  },
  
  async list(filters?: { cityId?: string; categoryId?: string }) {
    let query = supabase.from('establishments').select('*').eq('status', 'active');
    
    if (filters?.cityId) {
      query = query.eq('city', filters.cityId);
    }
    
    const { data, error } = await query;
    if (error) throw error;
    
    // Fetch all reviews for rating calculation
    const estIds = data?.map(est => est.id) || [];
    const { data: allReviews } = await supabase
      .from('reviews')
      .select('establishment_id, establishment_rating, professional_rating')
      .in('establishment_id', estIds);
    
    // Group reviews by establishment
    const reviewsByEst = new Map();
    (allReviews || []).forEach(review => {
      if (!reviewsByEst.has(review.establishment_id)) {
        reviewsByEst.set(review.establishment_id, []);
      }
      reviewsByEst.get(review.establishment_id).push(review);
    });
    
    return data?.map(est => {
      // Calculate real rating for this establishment
      const reviews = reviewsByEst.get(est.id) || [];
      let rating = undefined;
      if (reviews.length > 0) {
        const totalRating = reviews.reduce((sum: number, review: any) => {
          return sum + (review.establishment_rating || review.professional_rating || 0);
        }, 0);
        rating = Math.round((totalRating / reviews.length) * 10) / 10;
      }
      
      return {
        id: est.id,
        name: est.name,
        address: est.address,
        city: est.city,
        phone: est.phone,
        email: est.email,
        category: 'Barbearia' as any,
        logoUrl: est.logo_url,
        coverImageUrl: est.cover_image_url,
        isActive: est.status === 'active',
        status: est.status,
        services: [],
        professionals: [],
        workingHours: { start: '00:00', end: '00:00' },
        rating,
      };
    }) || [];
  }
};

export const blockedPeriodsAdapter = {
  async listByProfessional(professionalId: string): Promise<BlockedPeriod[]> {
    if (backend.provider === "supabase") {
      const { data, error } = await supabase
        .from('blocked_periods')
        .select('*')
        .eq('professional_id', professionalId);
        
      if (error) throw error;
      
      return data.map(bp => ({
        id: bp.id,
        professionalId: bp.professional_id,
        start: bp.start_date && bp.start_time ? `${bp.start_date}T${bp.start_time}:00.000Z` : 
               bp.start_date ? `${bp.start_date}T00:00:00.000Z` : new Date().toISOString(),
        end: bp.end_date && bp.end_time ? `${bp.end_date}T${bp.end_time}:00.000Z` : 
             bp.end_date ? `${bp.end_date}T23:59:59.000Z` : new Date().toISOString(),
        reason: bp.reason,
      }));
    }
    return [];
  },
  
  async listOverlaps(professionalId: string, dayKey: string): Promise<BlockedPeriod[]> {
    if (backend.provider === "supabase") {
      const { data, error } = await supabase
        .from('blocked_periods')
        .select('*')
        .eq('professional_id', professionalId)
        .lte('start_date', dayKey)
        .gte('end_date', dayKey);
        
      if (error) throw error;
      
      return data.map(bp => ({
        id: bp.id,
        professionalId: bp.professional_id,
        start: bp.start_date && bp.start_time ? `${bp.start_date}T${bp.start_time}:00.000Z` : 
               bp.start_date ? `${bp.start_date}T00:00:00.000Z` : new Date().toISOString(),
        end: bp.end_date && bp.end_time ? `${bp.end_date}T${bp.end_time}:00.000Z` : 
             bp.end_date ? `${bp.end_date}T23:59:59.000Z` : new Date().toISOString(),
        reason: bp.reason,
      }));
    }
    return [];
  },
  
  async create(payload: {
    professionalId: string;
    establishmentId?: string;
    start: string;
    end: string;
    reason?: string;
  }): Promise<BlockedPeriod> {
    if (backend.provider === "supabase") {
      try {
        // Extrair data e hora do ISO string
        const startDate = payload.start.split('T')[0];
        const startTime = payload.start.split('T')[1]?.substring(0, 5) || '00:00';
        const endDate = payload.end.split('T')[0];
        const endTime = payload.end.split('T')[1]?.substring(0, 5) || '23:59';
        
        // Verificar se não há agendamento conflitante
        const { data: existingAppointment, error: appointmentError } = await supabase
          .from('appointments')
          .select('id, client_name')
          .eq('professional_id', payload.professionalId)
          .eq('appointment_date', startDate)
          .eq('start_time', startTime)
          .neq('status', 'cancelled')
          .maybeSingle();

        if (appointmentError && appointmentError.code !== 'PGRST116') {
          console.error('[blockedPeriods/create] appointment check error:', appointmentError);
          throw new Error('Erro ao verificar agendamentos existentes');
        }

        if (existingAppointment) {
          throw new Error(`Não é possível bloquear este horário. Existe um agendamento com ${existingAppointment.client_name}`);
        }
        
        const insertData: any = {
          professional_id: payload.professionalId,
          start_date: startDate,
          end_date: endDate,
          start_time: startTime,
          end_time: endTime,
          reason: payload.reason || 'Bloqueio manual',
          type: 'personal'
        };

        const { data: result, error } = await supabase
          .from('blocked_periods')
          .insert(insertData)
          .select()
          .single();
          
        if (error) {
          console.error('[blockedPeriods/create] insert error:', error);
          // Tratar erro de duplicidade de forma idempotente
          if (error.code === '23505' || error.message?.includes('duplicate')) {
            console.log('[blockedPeriods/create] duplicate block ignored (idempotent)');
            // Buscar o bloqueio existente e retorná-lo
            const { data: existing } = await supabase
              .from('blocked_periods')
              .select('*')
              .eq('professional_id', payload.professionalId)
              .eq('start_date', startDate)
              .eq('start_time', startTime)
              .single();
            
            if (existing) {
              return {
                id: existing.id,
                professionalId: existing.professional_id,
                start: `${existing.start_date}T${existing.start_time}:00.000Z`,
                end: `${existing.end_date}T${existing.end_time}:00.000Z`,
                reason: existing.reason,
              };
            }
          }
          throw error;
        }

        // Disparar evento customizado para notificar outras telas
        window.dispatchEvent(new CustomEvent('blockingUpdated', {
          detail: { professionalId: payload.professionalId, action: 'created' }
        }));
        
        return {
          id: result.id,
          professionalId: result.professional_id,
          start: `${result.start_date}T${result.start_time}:00.000Z`,
          end: `${result.end_date}T${result.end_time}:00.000Z`,
          reason: result.reason,
        };
      } catch (e: any) {
        console.error('[blockedPeriods/create] error:', e);
        throw e;
      }
    }
    return { ...payload, id: crypto.randomUUID() };
  },
  
  async remove(id: string): Promise<void> {
    if (backend.provider === "supabase") {
      try {
        // Obter dados do período bloqueado antes de removê-lo
        const { data: blocked, error: selectError } = await supabase
          .from('blocked_periods')
          .select('professional_id')
          .eq('id', id)
          .maybeSingle();

        if (selectError) {
          console.error('[blockedPeriods/remove] select error:', selectError);
          throw selectError;
        }

        const { error } = await supabase
          .from('blocked_periods')
          .delete()
          .eq('id', id);
          
        if (error) {
          console.error('[blockedPeriods/remove] delete error:', error);
          throw error;
        }

        // Disparar evento customizado para notificar outras telas
        if (blocked) {
          window.dispatchEvent(new CustomEvent('blockingUpdated', {
            detail: { professionalId: blocked.professional_id, action: 'deleted' }
          }));
        }
      } catch (e: any) {
        console.error('[blockedPeriods/remove] error:', e);
        throw e;
      }
    }
  }
};

export const notificationsAdapter = {
  async listByProfessional(professionalId: string): Promise<Notification[]> {
    if (backend.provider === "supabase") {
      const { data, error } = await supabase
        .from('notifications')
        .select('*')
        .eq('professional_id', professionalId)
        .order('created_at', { ascending: false });
        
      if (error) throw error;
      
      return data.map(n => ({
        id: n.id,
        professionalId: n.professional_id,
        message: n.message,
        read: n.read,
        createdAt: n.created_at,
      }));
    }
    return [];
  },
  
  async markAsRead(id: string): Promise<void> {
    if (backend.provider === "supabase") {
      const { error } = await supabase
        .from('notifications')
        .update({ read: true })
        .eq('id', id);
        
      if (error) throw error;
    }
  }
};

export const reviewsAdapter = {
  async listByProfessional(professionalId: string) {
    const { data, error } = await supabase
      .from('reviews')
      .select('*')
      .eq('professional_id', professionalId);
    
    if (error) throw error;
    return data;
  },
  
  async listByEstablishment(establishmentId: string) {
    const { data, error } = await supabase
      .from('reviews')
      .select('*')
      .eq('establishment_id', establishmentId);
    
    if (error) throw error;
    return data;
  },
  
  async create(data: { establishmentId: string; professionalId: string; clientName: string; score: number; comment?: string; createdAt: string; appointmentId: string }) {
    const { error } = await supabase
      .from('reviews')
      .insert({
        appointment_id: data.appointmentId,
        establishment_id: data.establishmentId,
        professional_id: data.professionalId,
        client_id: '', // Could be improved with actual client ID
        professional_rating: data.score,
        establishment_rating: data.score,
        comment: data.comment || '',
      });
    
    if (error) throw error;
  }
};

export const usersAdapter = {
  async getById(id: string) {
    const { data, error } = await supabase
      .from('profiles')
      .select('*')
      .eq('user_id', id)
      .single();
    
    if (error) return null;
    return data;
  }
};

export const supabaseAppointmentsAdapter: AppointmentsAdapter = {
  async create(input) {
    // CRITICAL: Check for conflicts before creating appointment
    const { data: conflicts } = await supabase
      .from('appointments')
      .select('id')
      .eq('professional_id', input.professionalId)
      .eq('appointment_date', input.date)
      .eq('start_time', input.time)
      .neq('status', 'cancelled');

    if (conflicts && conflicts.length > 0) {
      throw new Error('Este horário já está ocupado. Escolha outro horário.');
    }

    // Check if time slot is available (not blocked)
    const { data: blockedPeriods } = await supabase
      .from('blocked_periods')
      .select('*')
      .eq('professional_id', input.professionalId)
      .lte('start_date', input.date)
      .gte('end_date', input.date);

    if (blockedPeriods && blockedPeriods.length > 0) {
      const slotDateTime = new Date(`${input.date}T${input.time}:00`);
      const isBlocked = blockedPeriods.some(block => {
        const blockStart = new Date(`${block.start_date}T${block.start_time || '00:00'}:00`);
        const blockEnd = new Date(`${block.end_date}T${block.end_time || '23:59'}:59`);
        return slotDateTime >= blockStart && slotDateTime <= blockEnd;
      });
      
      if (isBlocked) {
        throw new Error('Este horário está bloqueado para agendamentos.');
      }
    }

    const appointmentData = {
      establishment_id: input.establishmentId,
      professional_id: input.professionalId,
      service_id: input.serviceId,
      appointment_date: input.date,
      start_time: input.time,
      end_time: input.time, // Will be calculated if duration provided
      total_price: input.price || 0,
      status: mapToSupabaseStatus(input.status || "pendente") as any,
      notes: input.notes || null,
      // Support for anonymous client via phone
      client_id: null,  // Anonymous booking
      client_phone: input.clientId,   // Phone number as client identifier
      client_name: input.clientName,
    };

    console.log('Inserting appointment data:', appointmentData);

    const { data, error } = await supabase
      .from("appointments")
      .insert(appointmentData)
      .select()
      .single();

    if (error) {
      console.error('Supabase appointment creation error:', error);
      throw error;
    }

    console.log('Appointment created successfully in Supabase:', data);

    return {
      id: data.id,
      establishmentId: data.establishment_id,
      clientId: data.client_phone || data.client_id || '',
      clientName: input.clientName,
      professionalId: data.professional_id,
      professionalName: input.professionalName,
      serviceId: data.service_id,
      serviceName: input.serviceName,
      date: data.appointment_date,
      time: data.start_time,
      duration: input.duration || 60,
      price: Number(data.total_price),
      status: mapFromSupabaseStatus(data.status),
      notes: data.notes,
      reschedules: 0,
      createdAt: data.created_at,
      updatedAt: data.updated_at,
    };
  },

  async update(id, patch) {
    const updateData: any = {};
    
    if (patch.date) updateData.appointment_date = patch.date;
    if (patch.time) updateData.start_time = patch.time;
    if ((patch as any).price !== undefined) updateData.total_price = (patch as any).price;
    if (patch.status) updateData.status = mapToSupabaseStatus(patch.status);
    if (patch.notes !== undefined) updateData.notes = patch.notes;

    const { data, error } = await supabase
      .from("appointments")
      .update(updateData)
      .eq("id", id)
      .select()
      .single();

    if (error) throw error;

    return {
      id: data.id,
      establishmentId: data.establishment_id,
      clientId: data.client_id,
      clientName: patch.clientName || "",
      professionalId: data.professional_id,
      professionalName: patch.professionalName || "",
      serviceId: data.service_id,
      serviceName: patch.serviceName || "",
      date: data.appointment_date,
      time: data.start_time,
      duration: (patch as any).duration || 60,
      price: Number(data.total_price),
      status: mapFromSupabaseStatus(data.status),
      notes: data.notes,
      reschedules: patch.reschedules || 0,
      createdAt: data.created_at,
      updatedAt: data.updated_at,
    };
  },

  async getById(id) {
    const { data, error } = await supabase
      .from("appointments")
      .select("*")
      .eq("id", id)
      .single();

    if (error) {
      if (error.code === "PGRST116") return null; // Not found
      throw error;
    }

    return {
      id: data.id,
      establishmentId: data.establishment_id,
      clientId: data.client_id,
      clientName: "", // Will need to be fetched separately if needed
      professionalId: data.professional_id,
      professionalName: "", // Will need to be fetched separately if needed
      serviceId: data.service_id,
      serviceName: "", // Will need to be fetched separately if needed
      date: data.appointment_date,
      time: data.start_time,
      duration: 60, // Default duration
      price: Number(data.total_price),
      status: mapFromSupabaseStatus(data.status),
      notes: data.notes,
      reschedules: 0,
      createdAt: data.created_at,
      updatedAt: data.updated_at,
    };
  },

  async listByProfessional(professionalId, opts) {
    console.log('Listing appointments for professional ID:', professionalId, 'options:', opts);
    
    let query = supabase
      .from("appointments")
      .select("*")
      .eq("professional_id", professionalId);

    if (opts?.date) {
      query = query.eq("appointment_date", opts.date);
    }

    const { data, error } = await query.order("appointment_date", { ascending: true });

    if (error) {
      console.error('Error loading appointments for professional:', error);
      throw error;
    }

    console.log('Raw appointments data for professional:', data);

    // Fetch services and professional data separately
    const serviceIds = [...new Set(data.map(a => a.service_id))];

    let services = [];
    let professionalName = 'Profissional';

    if (serviceIds.length > 0) {
      const { data: servicesData } = await supabase
        .from("services")
        .select("id, name, price, duration_minutes")
        .in("id", serviceIds);
      services = servicesData || [];
    }

    // Get professional name
    const { data: profData } = await supabase
      .from("professionals")
      .select("user_id")
      .eq("id", professionalId)
      .single();

    if (profData?.user_id) {
      const { data: profileData } = await supabase
        .from("profiles")
        .select("full_name")
        .eq("user_id", profData.user_id)
        .single();
      
      if (profileData?.full_name) {
        professionalName = profileData.full_name;
      }
    }

    const result = data.map(appointment => {
      const service = services.find(s => s.id === appointment.service_id);

      return {
        id: appointment.id,
        establishmentId: appointment.establishment_id,
        clientId: appointment.client_id || appointment.client_phone || '',
        clientName: appointment.client_name || 'Cliente não informado',
        professionalId: appointment.professional_id,
        professionalName,
        serviceId: appointment.service_id,
        serviceName: service?.name || 'Serviço não informado',
        date: appointment.appointment_date,
        time: appointment.start_time,
        duration: service?.duration_minutes || 60,
        price: Number(service?.price || appointment.total_price || 0),
        status: mapFromSupabaseStatus(appointment.status),
        notes: appointment.notes,
        reschedules: 0,
        createdAt: appointment.created_at,
        updatedAt: appointment.updated_at,
      };
    });

    console.log('Mapped appointments for professional:', result);
    return result;
  },

  async listByEstablishment(establishmentId, opts) {
    let query = supabase
      .from("appointments")
      .select("*")
      .eq("establishment_id", establishmentId);

    if (opts?.date) {
      query = query.eq("appointment_date", opts.date);
    }

    const { data, error } = await query.order("appointment_date", { ascending: true });

    if (error) {
      console.error('Error loading appointments for establishment:', error);
      throw error;
    }

    console.log('Raw appointments data for establishment:', data);

    // Fetch services and professionals data separately
    const serviceIds = [...new Set(data.map(a => a.service_id))];
    const professionalIds = [...new Set(data.map(a => a.professional_id))];

    let services = [];
    let professionals = [];

    if (serviceIds.length > 0) {
      const { data: servicesData } = await supabase
        .from("services")
        .select("id, name, price, duration_minutes")
        .in("id", serviceIds);
      services = servicesData || [];
    }

    if (professionalIds.length > 0) {
      const { data: professionalsData } = await supabase
        .from("professionals")
        .select("id, user_id")
        .in("id", professionalIds);

      if (professionalsData?.length > 0) {
        const userIds = professionalsData.map(p => p.user_id);
        const { data: profilesData } = await supabase
          .from("profiles")
          .select("user_id, full_name")
          .in("user_id", userIds);

        professionals = professionalsData.map(prof => {
          const profile = profilesData?.find(p => p.user_id === prof.user_id);
          return {
            ...prof,
            name: profile?.full_name || 'Profissional'
          };
        });
      }
    }

    return data.map(appointment => {
      const service = services.find(s => s.id === appointment.service_id);
      const professional = professionals.find(p => p.id === appointment.professional_id);

      return {
        id: appointment.id,
        establishmentId: appointment.establishment_id,
        clientId: appointment.client_id || appointment.client_phone || '',
        clientName: appointment.client_name || 'Cliente não informado',
        professionalId: appointment.professional_id,
        professionalName: professional?.name || 'Profissional',
        serviceId: appointment.service_id,
        serviceName: service?.name || 'Serviço não informado',
        date: appointment.appointment_date,
        time: appointment.start_time,
        duration: service?.duration_minutes || 60,
        price: Number(service?.price || appointment.total_price || 0),
        status: mapFromSupabaseStatus(appointment.status),
        notes: appointment.notes,
        reschedules: 0,
        createdAt: appointment.created_at,
        updatedAt: appointment.updated_at,
      };
    });
  },

  async listByClient(clientKey) {
    let query = supabase.from("appointments").select("*")
      .or(`client_id.eq.${clientKey},client_phone.eq.${clientKey}`)
      .order("appointment_date", { ascending: false });
    const { data, error } = await query;
    if (error) throw error;
    
    return (data || []).map(appointment => ({
      id: appointment.id,
      establishmentId: appointment.establishment_id,
      clientId: appointment.client_id || appointment.client_phone,
      clientName: appointment.client_name || "",
      professionalId: appointment.professional_id,
      professionalName: "",
      serviceId: appointment.service_id,
      serviceName: "",
      date: appointment.appointment_date,
      time: appointment.start_time,
      duration: 60, // TODO: fetch from service
      price: Number(appointment.total_price),
      status: mapFromSupabaseStatus(appointment.status),
      notes: appointment.notes,
      reschedules: 0,
      createdAt: appointment.created_at,
      updatedAt: appointment.updated_at,
    }));
  },

  async delete(id) {
    const { error } = await supabase
      .from("appointments")
      .delete()
      .eq("id", id);

    if (error) {
      console.error('Error deleting appointment:', error);
      throw error;
    }
  },
};

// Full Supabase implementation for appointments
function getAppointmentsAdapterForSupabase(): AppointmentsAdapter {
  return supabaseAppointmentsAdapter; // Use the adapter that matches the interface
}

// Fallback memory store implementation using localStorage
function getAppointmentsAdapterForMemory(): AppointmentsAdapter {
  return supabaseAppointmentsAdapter; // Use existing implementation as fallback
}

export function getAppointmentsAdapter(): AppointmentsAdapter {
  if (backend.provider === "supabase") {
    return getAppointmentsAdapterForSupabase();
  }
  // Fallback to memory implementation
  return getAppointmentsAdapterForMemory();
}