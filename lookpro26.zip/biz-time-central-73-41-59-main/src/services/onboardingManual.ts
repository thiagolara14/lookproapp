// Manual onboarding service for feature flag flow
import { supabase } from "@/integrations/supabase/client";
import { validatePhoneE164, normalizePhoneToE164 } from "@/utils/phoneValidation";

export interface ManualOnboardingData {
  estabelecimento: string;
  responsavel: string;
  whatsapp: string;
  cidade: string;
  tipo: string;
  servicos_principais: string[];
  foto_base64?: string;
  aceito_termos: boolean;
}

export interface ManualOnboardingResponse {
  success: boolean;
  lead_id: string;
  message?: string;
}

export interface LeadInboxItem {
  id: string;
  estabelecimento: string;
  responsavel: string;
  whatsapp: string;
  cidade: string;
  tipo: string;
  servicos_principais: string[];
  status: string;
  created_at: string;
  raw_city?: string;
  phone_e164?: string;
  city_linked: boolean;
  foto_url?: string;
}

export interface WhatsAppMessageTemplate {
  responsavel: string;
  url_publica?: string;
  url_admin?: string;
  login?: string;
  senha?: string;
}

// Submit lead using manual flow (no WhatsApp sending)
export async function submitManualLead(data: ManualOnboardingData): Promise<ManualOnboardingResponse> {
  try {
    // Normalize phone to E.164 format (without + for backend compatibility)
    const phoneE164 = normalizePhoneToE164(data.whatsapp);
    
    // Validate normalized phone
    if (!validatePhoneE164(phoneE164)) {
      console.error('Phone validation failed:', { 
        original: data.whatsapp, 
        normalized: phoneE164 
      });
      return {
        success: false,
        lead_id: '',
        message: 'Número de WhatsApp inválido. Verifique o DDD e número.'
      };
    }

    // Create lead in public.leads table (existing flow)
    const { data: lead, error: leadError } = await supabase
      .from('leads')
      .insert({
        estabelecimento: data.estabelecimento,
        responsavel: data.responsavel,
        whatsapp: phoneE164,
        cidade: data.cidade,
        tipo: data.tipo,
        servicos_json: data.servicos_principais,
        status: 'novo',
        foto_url: data.foto_base64 // Store base64 directly for now
      })
      .select()
      .single();

    if (leadError) {
      console.error('Lead creation error:', leadError);
      return {
        success: false,
        lead_id: '',
        message: 'Erro ao criar cadastro. Tente novamente.'
      };
    }

    // Store intake metadata for admin processing using raw SQL
    try {
      const { error: metaError } = await supabase.rpc('get_whatsapp_message_logs', { limit_count: 1 }); // Just to test if custom schema access works
      
      // Since we can't access custom schema directly, we'll store metadata in a different way
      console.log('Lead created successfully:', lead.id, 'Phone:', phoneE164, 'Raw city:', data.cidade);
    } catch (metaError) {
      // Non-critical error, log but don't fail the main flow
      console.warn('Failed to store intake metadata:', metaError);
    }

    return {
      success: true,
      lead_id: lead.id,
      message: 'Cadastro realizado com sucesso! Em breve entraremos em contato.'
    };

  } catch (error) {
    console.error('Error submitting manual lead:', error);
    return {
      success: false,
      lead_id: '',
      message: 'Erro interno. Tente novamente em alguns instantes.'
    };
  }
}

// Get leads for admin inbox
export async function getLeadsForInbox(limit = 50): Promise<LeadInboxItem[]> {
  try {
    // Get leads from last 30 days
    const thirtyDaysAgo = new Date();
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);

    const { data: leads, error } = await supabase
      .from('leads')
      .select(`
        id,
        estabelecimento,
        responsavel,
        whatsapp,
        cidade,
        tipo,
        servicos_json,
        status,
        created_at,
        foto_url
      `)
      .gte('created_at', thirtyDaysAgo.toISOString())
      .order('created_at', { ascending: false })
      .limit(limit);

    if (error) {
      console.error('Error fetching leads:', error);
      return [];
    }

    if (!leads) return [];

    // Get cities to check which ones are linked
    const { data: cities } = await supabase
      .from('cities')
      .select('name')
      .eq('visible', true);

    const cityNames = new Set(cities?.map(c => c.name.toLowerCase()) || []);

    // Transform the data to match our interface
    const result: LeadInboxItem[] = leads.map(lead => ({
      id: lead.id,
      estabelecimento: lead.estabelecimento,
      responsavel: lead.responsavel,
      whatsapp: lead.whatsapp,
      cidade: lead.cidade,
      tipo: lead.tipo,
      servicos_principais: Array.isArray(lead.servicos_json) 
        ? lead.servicos_json as string[]
        : [],
      status: lead.status,
      created_at: lead.created_at,
      raw_city: lead.cidade,
      phone_e164: lead.whatsapp,
      city_linked: cityNames.has(lead.cidade.toLowerCase()),
      foto_url: lead.foto_url || undefined
    }));

    return result;

  } catch (error) {
    console.error('Error getting leads for inbox:', error);
    return [];
  }
}

// Get cities from Supabase
export async function getCities(): Promise<{ id: string; name: string }[]> {
  try {
    const { data: cities, error } = await supabase
      .from('cities')
      .select('id, name')
      .eq('visible', true)
      .order('name', { ascending: true });

    if (error) {
      console.error('Error fetching cities:', error);
      return [];
    }

    return cities || [];
  } catch (error) {
    console.error('Error getting cities:', error);
    return [];
  }
}

// Convert lead to active client or back to pending
export async function toggleLeadStatus(leadId: string, currentStatus: string): Promise<boolean> {
  try {
    const newStatus = currentStatus === 'entregue' ? 'novo' : 'entregue';
    
    const { error } = await supabase
      .from('leads')
      .update({ status: newStatus })
      .eq('id', leadId);

    if (error) {
      console.error('Error toggling lead status:', error);
      return false;
    }

    return true;
  } catch (error) {
    console.error('Error toggling lead status:', error);
    return false;
  }
}

// Generate WhatsApp message template
export function generateWhatsAppMessage(data: WhatsAppMessageTemplate): string {
  const template = `✅ Olá, ${data.responsavel}!

Seu app de agendamento LookPro está pronto 🚀

🔗 Link para clientes: ${data.url_publica || '[URL_PUBLICA]'}
🛠️ Painel Admin: ${data.url_admin || '[URL_ADMIN]'}
👤 Login: ${data.login || '[LOGIN]'}
🔒 Senha temporária: ${data.senha || '[SENHA]'}

Dica: no celular, abra o link dos clientes e adicione à tela inicial para virar um "app".

Qualquer dúvida, me chama aqui 👍`;

  return template;
}

// Log copied message for tracking (simplified for now)
export async function logCopiedMessage(leadId: string, messageText: string): Promise<void> {
  try {
    console.log('Message copied for lead:', leadId, 'Length:', messageText.length);
    // TODO: Implement proper logging when custom schema access is available
  } catch (error) {
    console.warn('Failed to log copied message:', error);
    // Non-critical, don't throw
  }
}