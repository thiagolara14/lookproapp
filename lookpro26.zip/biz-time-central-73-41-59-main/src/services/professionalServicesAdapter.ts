import { supabase } from "@/integrations/supabase/client";

export type ProfessionalService = {
  id: string;
  professionalId: string;
  establishmentId: string;
  serviceId: string;
  name: string;
  description?: string;
  imageUrl?: string;
  durationMinutes: number;
  price: number;
  isActive: boolean;
  customDurationMinutes?: number;
  customPrice?: number;
  createdAt: string;
  updatedAt: string;
};

export type AvailableService = {
  serviceId: string;
  name: string;
  description?: string;
  imageUrl?: string;
  durationMinutes: number;
  price: number;
};

export const professionalServicesAdapter = {
  /**
   * Lista serviços efetivos de um profissional
   */
  async listByProfessional(professionalId: string): Promise<ProfessionalService[]> {
    const { data, error } = await supabase
      .from('v_professional_services_effective')
      .select('*')
      .eq('professional_id', professionalId)
      .eq('is_active', true)
      .order('name');

    if (error) {
      console.error('Error fetching professional services:', error);
      throw error;
    }

    return (data || []).map((item: any) => ({
      id: item.professional_service_id,
      professionalId: item.professional_id,
      establishmentId: item.establishment_id,
      serviceId: item.service_id,
      name: item.name,
      description: item.description,
      imageUrl: item.image_url,
      durationMinutes: item.duration_minutes,
      price: item.price,
      isActive: item.is_active,
      customDurationMinutes: item.custom_duration_minutes,
      customPrice: item.custom_price,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    }));
  },

  /**
   * Lista serviços disponíveis para vínculo (não vinculados ainda)
   */
  async listAvailableServices(professionalId: string, establishmentId: string): Promise<AvailableService[]> {
    // Buscar todos os serviços do estabelecimento
    const { data: allServices, error: servicesError } = await supabase
      .from('services')
      .select('id, name, description, image_url, duration_minutes, price')
      .eq('establishment_id', establishmentId)
      .eq('is_active', true);

    if (servicesError) {
      console.error('Error fetching establishment services:', servicesError);
      throw servicesError;
    }

    // Buscar serviços já vinculados
    const { data: linkedServices, error: linkedError } = await supabase
      .from('professional_services')
      .select('service_id')
      .eq('professional_id', professionalId);

    if (linkedError) {
      console.error('Error fetching linked services:', linkedError);
      throw linkedError;
    }

    const linkedServiceIds = new Set(linkedServices?.map(ls => ls.service_id) || []);

    // Filtrar serviços não vinculados
    const availableServices = (allServices || []).filter(service => 
      !linkedServiceIds.has(service.id)
    );

    return availableServices.map((item: any) => ({
      serviceId: item.id,
      name: item.name,
      description: item.description,
      imageUrl: item.image_url,
      durationMinutes: item.duration_minutes,
      price: item.price,
    }));
  },

  /**
   * Vincula um serviço existente ao profissional
   */
  async linkService(professionalId: string, establishmentId: string, serviceId: string, customizations?: {
    customDurationMinutes?: number;
    customPrice?: number;
  }): Promise<ProfessionalService> {
    const { data, error } = await supabase
      .from('professional_services')
      .insert({
        professional_id: professionalId,
        establishment_id: establishmentId,
        service_id: serviceId,
        custom_duration_minutes: customizations?.customDurationMinutes,
        custom_price: customizations?.customPrice,
        is_active: true
      })
      .select()
      .single();

    if (error) {
      console.error('Error linking service:', error);
      throw error;
    }

    // Buscar dados completos do serviço vinculado
    const linkedServices = await this.listByProfessional(professionalId);
    const linkedService = linkedServices.find(s => s.id === data.id);
    
    if (!linkedService) {
      // Fallback: construir o objeto manualmente se não encontrar na lista
      const { data: serviceData } = await supabase
        .from('services')
        .select('name, description, image_url, duration_minutes, price')
        .eq('id', serviceId)
        .single();

      return {
        id: data.id,
        professionalId: data.professional_id,
        establishmentId: data.establishment_id,
        serviceId: data.service_id,
        name: serviceData?.name || '',
        description: serviceData?.description,
        imageUrl: serviceData?.image_url,
        durationMinutes: customizations?.customDurationMinutes || serviceData?.duration_minutes || 0,
        price: customizations?.customPrice || serviceData?.price || 0,
        isActive: true,
        customDurationMinutes: customizations?.customDurationMinutes,
        customPrice: customizations?.customPrice,
        createdAt: data.created_at || new Date().toISOString(),
        updatedAt: data.updated_at || new Date().toISOString(),
      };
    }

    return linkedService;
  },

  /**
   * Atualiza customizações de um serviço do profissional
   */
  async updateCustomizations(professionalServiceId: string, updates: {
    customDurationMinutes?: number;
    customPrice?: number;
    isActive?: boolean;
  }): Promise<void> {
    const updateData: any = {};
    
    if (updates.customDurationMinutes !== undefined) {
      updateData.custom_duration_minutes = updates.customDurationMinutes;
    }
    if (updates.customPrice !== undefined) {
      updateData.custom_price = updates.customPrice;
    }
    // Note: is_active updates are handled via unlink/reactivate operations to avoid DB trigger issues

    const { error } = await supabase
      .from('professional_services')
      .update(updateData)
      .eq('id', professionalServiceId);

    if (error) {
      console.error('Error updating professional service:', error);
      throw error;
    }
  },

  /**
   * Remove vínculo entre profissional e serviço (desativa)
   */
  async unlinkService(professionalServiceId: string): Promise<void> {
    const { error } = await supabase
      .from('professional_services')
      .delete()
      .eq('id', professionalServiceId);

    if (error) {
      console.error('Error unlinking service:', error);
      throw error;
    }
  },

  /**
   * Reativa um serviço desativado
   */
  async reactivateService(professionalServiceId: string): Promise<void> {
    const { error } = await supabase
      .from('professional_services')
      .update({ is_active: true })
      .eq('id', professionalServiceId);

    if (error) {
      console.error('Error reactivating service:', error);
      throw error;
    }
  }
};