// Onboarding client service
import { OnboardingConfig } from "@/lib/featureFlags";

export interface OnboardingFormData {
  estabelecimento: string;
  responsavel: string;
  whatsapp: string;
  cidade: string;
  tipo: string;
  servicos_principais: string[];
  foto_base64?: string;
  aceito_termos: boolean;
  recaptcha_token?: string;
}

export interface OnboardingResponse {
  success: boolean;
  lead_id: string;
  status?: string;
  message?: string;
}

export interface LeadStatusResponse {
  success: boolean;
  lead_id: string;
  status: 'novo' | 'em_provisionamento' | 'entregue' | 'erro';
  tenant_data?: {
    url_publica: string;
    url_admin: string;
    login: string;
  };
  message?: string;
}

// Real API implementation using Supabase Edge Functions
export async function submitLead(data: OnboardingFormData): Promise<OnboardingResponse> {
  try {
    const response = await fetch(`${OnboardingConfig.SUPABASE_URL}/functions/v1/onboarding-lead`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${OnboardingConfig.SUPABASE_ANON_KEY}`
      },
      body: JSON.stringify(data)
    });

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`HTTP ${response.status}: ${errorText}`);
    }

    const result = await response.json();
    return result;
    
  } catch (error) {
    console.error('Error submitting lead:', error);
    return {
      success: false,
      lead_id: '',
      message: error instanceof Error ? error.message : 'Erro interno. Tente novamente.'
    };
  }
}

export async function getLeadStatus(leadId: string): Promise<LeadStatusResponse> {
  try {
    const response = await fetch(`${OnboardingConfig.SUPABASE_URL}/functions/v1/onboarding-lead-status?lead_id=${leadId}`, {
      headers: {
        'Authorization': `Bearer ${OnboardingConfig.SUPABASE_ANON_KEY}`
      }
    });

    if (!response.ok) {
      throw new Error(`HTTP ${response.status}`);
    }

    const result = await response.json();
    return result;
    
  } catch (error) {
    console.error('Error getting lead status:', error);
    return {
      success: false,
      lead_id: leadId,
      status: 'erro',
      message: 'Erro ao consultar status.'
    };
  }
}