// Lightweight client-side Runware WebSocket service
// Stores API key in localStorage; no Supabase required

export const RUNWARE_KEY_STORAGE = "RUNWARE_API_KEY";
export const getRunwareKey = () => localStorage.getItem(RUNWARE_KEY_STORAGE) || "";
export const setRunwareKey = (key: string) => localStorage.setItem(RUNWARE_KEY_STORAGE, key);

const API_ENDPOINT = "wss://ws-api.runware.ai/v1";

export interface GenerateImageParams {
  positivePrompt: string;
  model?: string; // default: runware:100@1
  width?: number; // multiples of 32 (min 512, max 1920)
  height?: number; // multiples of 32 (min 512, max 1920)
  numberResults?: number;
  outputFormat?: string;
  CFGScale?: number;
  scheduler?: string;
  strength?: number;
  seed?: number | null;
  lora?: string[];
}

export type GeneratedImageResponse = {
  taskType: string;
  taskUUID: string;
  imageUUID?: string;
  imageURL?: string;
  error?: boolean;
  errorMessage?: string;
  NSFWContent?: boolean;
  seed?: number;
};

export class RunwareService {
  private ws: WebSocket | null = null;
  private apiKey: string;
  private connectionSessionUUID: string | null = null;
  private callbacks = new Map<string, (data: GeneratedImageResponse) => void>();
  private isAuthenticated = false;
  private connectionPromise: Promise<void> | null = null;

  constructor(apiKey: string) {
    this.apiKey = apiKey;
    this.connectionPromise = this.connect();
  }

  private connect(): Promise<void> {
    return new Promise((resolve, reject) => {
      this.ws = new WebSocket(API_ENDPOINT);

      this.ws.onopen = () => {
        this.authenticate().then(resolve).catch(reject);
      };

      this.ws.onmessage = (event) => {
        try {
          const response = JSON.parse(event.data);
          if (response?.data) {
            for (const item of response.data as GeneratedImageResponse[]) {
              if (item.taskType === "authentication") {
                this.isAuthenticated = true;
                this.connectionSessionUUID = (item as any).connectionSessionUUID ?? null;
                continue;
              }
              const cb = this.callbacks.get(item.taskUUID);
              if (cb) {
                cb(item);
                this.callbacks.delete(item.taskUUID);
              }
            }
          }
        } catch (e) {
          console.error("Runware WS parse error", e);
        }
      };

      this.ws.onerror = (err) => {
        console.error("Runware WS error", err);
        reject(err);
      };

      this.ws.onclose = () => {
        this.isAuthenticated = false;
        // auto-reconnect after short delay
        setTimeout(() => {
          this.connectionPromise = this.connect();
        }, 1000);
      };
    });
  }

  private authenticate(): Promise<void> {
    return new Promise((resolve, reject) => {
      if (!this.ws || this.ws.readyState !== WebSocket.OPEN) {
        reject(new Error("WebSocket not ready"));
        return;
      }
      const authMsg = [
        {
          taskType: "authentication",
          apiKey: this.apiKey,
          ...(this.connectionSessionUUID ? { connectionSessionUUID: this.connectionSessionUUID } : {}),
        },
      ];

      const onAuth = (event: MessageEvent) => {
        try {
          const res = JSON.parse(event.data);
          const ok = res?.data?.[0]?.taskType === "authentication";
          if (ok) {
            this.ws?.removeEventListener("message", onAuth);
            resolve();
          }
        } catch {}
      };

      this.ws.addEventListener("message", onAuth);
      this.ws.send(JSON.stringify(authMsg));
    });
  }

  async generateImage(params: GenerateImageParams): Promise<GeneratedImageResponse> {
    await this.connectionPromise;
    if (!this.ws || this.ws.readyState !== WebSocket.OPEN || !this.isAuthenticated) {
      this.connectionPromise = this.connect();
      await this.connectionPromise;
    }

    const taskUUID = crypto.randomUUID();

    const message = [
      {
        taskType: "imageInference",
        taskUUID,
        model: params.model || "runware:100@1",
        width: params.width ?? 1024,
        height: params.height ?? 1024,
        numberResults: params.numberResults ?? 1,
        outputFormat: params.outputFormat || "WEBP",
        steps: 4,
        CFGScale: params.CFGScale ?? 1,
        scheduler: params.scheduler || "FlowMatchEulerDiscreteScheduler",
        strength: params.strength ?? 0.8,
        lora: params.lora || [],
        positivePrompt: params.positivePrompt,
        ...(params.seed ? { seed: params.seed } : {}),
      },
    ];

    return new Promise((resolve, reject) => {
      this.callbacks.set(taskUUID, (data) => {
        if ((data as any).error) {
          reject(new Error((data as any).errorMessage || "Runware error"));
        } else {
          resolve(data);
        }
      });

      this.ws!.send(JSON.stringify(message));
    });
  }
}

export async function urlToDataUrl(url: string): Promise<string> {
  const resp = await fetch(url);
  const blob = await resp.blob();
  return await new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result));
    reader.onerror = reject;
    reader.readAsDataURL(blob);
  });
}
