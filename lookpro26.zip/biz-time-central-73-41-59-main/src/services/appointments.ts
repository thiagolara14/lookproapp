import type { Appointment, AppointmentStatus } from "@/types/appointments";
import { getAppointmentsAdapter, establishmentsAdapter } from "@/services/adapters";
import { supabase } from "@/integrations/supabase/client";

const TIMEZONE = "America/Sao_Paulo"; // reservado para futura integração
const CANCEL_WINDOW_HOURS = 2;
const MAX_RESCHEDULES = 1;

const adapter = getAppointmentsAdapter();
function toDateTime(date: string, time: string) {
  // Construção simples; em produção use date-fns-tz com o TZ acima
  return new Date(`${date}T${time}:00`);
}

function toMinutes(t: string) {
  const [h, m] = t.split(":").map(Number);
  return h * 60 + m;
}

export async function listAppointmentsByEstablishment(establishmentId: string, opts?: { date?: string }) {
  return adapter.listByEstablishment(establishmentId, opts);
}

export async function listAppointmentsByProfessional(professionalId: string, opts?: { date?: string }) {
  return adapter.listByProfessional(professionalId, opts);
}

export async function listAppointmentsByClient(clientId: string) {
  return adapter.listByClient(clientId);
}

export async function createAppointment(input: Omit<Appointment, "id" | "createdAt" | "updatedAt">) {
  // Supabase implementation
  return adapter.create(input);
}

export async function updateAppointmentStatus(id: string, status: AppointmentStatus) {
  return adapter.update(id, { status });
}

export async function cancelAppointment(id: string) {
  const appt = await adapter.getById(id);
  if (!appt) throw new Error("Agendamento não encontrado");
  const when = toDateTime(appt.date, appt.time);
  const diffH = (when.getTime() - Date.now()) / (1000 * 60 * 60);
  if (diffH < CANCEL_WINDOW_HOURS) {
    throw new Error("Cancelamento permitido apenas até 2 horas antes");
  }
  return adapter.update(id, { status: "cancelado" });
}

export async function cancelAppointmentAsClient(id: string, actorClientId: string) {
  const appt = await adapter.getById(id);
  if (!appt) throw new Error("Agendamento não encontrado");
  if (appt.clientId !== actorClientId) {
    throw new Error("Você não tem permissão para cancelar este agendamento");
  }
  return cancelAppointment(id);
}

export async function concludeAppointment(id: string) {
  return adapter.update(id, { status: "concluído" });
}

export async function editAppointment(
  id: string,
  changes: Partial<Pick<Appointment, "date" | "time" | "professionalId" | "professionalName">>
) {
  const appt = await adapter.getById(id);
  if (!appt) throw new Error("Agendamento não encontrado");

  // Regras de reagendamento (genéricas)
  const reschedules = appt.reschedules ?? 0;
  const when = toDateTime(appt.date, appt.time);
  const diffH = (when.getTime() - Date.now()) / (1000 * 60 * 60);
  if (diffH < CANCEL_WINDOW_HOURS) {
    throw new Error("Reagendamento permitido apenas até 2 horas antes");
  }
  if (reschedules >= MAX_RESCHEDULES) {
    throw new Error("Limite de 1 reagendamento atingido");
  }

  // Validação de conflito para novo slot
  const newDate = changes.date ?? appt.date;
  const newTime = changes.time ?? appt.time;
  const newProfId = changes.professionalId ?? appt.professionalId;
  const conflicts = await adapter.listByProfessional(newProfId, { date: newDate });
  if (conflicts.some((a) => a.id !== id && a.time === newTime && a.status !== "cancelado")) {
    throw new Error("Novo horário já está ocupado");
  }

  return adapter.update(id, { ...changes, reschedules: reschedules + 1 });
}

// Versão com checagem de identidade do cliente (usando Supabase)
export async function editAppointmentAsClient(
  id: string,
  changes: Partial<Pick<Appointment, "date" | "time" | "professionalId" | "professionalName">>,
  actorClientId: string
) {
  const appt = await adapter.getById(id);
  if (!appt) throw new Error("Agendamento não encontrado");
  if (appt.clientId !== actorClientId) {
    throw new Error("Você não tem permissão para editar este agendamento");
  }
  if (!(appt.status === "pendente" || appt.status === "confirmado")) {
    throw new Error("Apenas agendamentos pendentes ou confirmados podem ser editados");
  }
  return editAppointment(id, changes);
}

export async function deleteAppointment(id: string) {
  return adapter.delete(id);
}

export async function getEstablishmentMeta(establishmentId: string) {
  // Supabase implementation
  return await establishmentsAdapter.getById(establishmentId);
}

// Aggregations & helpers for revenue and reporting
export async function listAllAppointments(opts?: { dateFrom?: string; dateTo?: string; status?: AppointmentStatus; establishmentId?: string; professionalId?: string }) {
  const adapter = getAppointmentsAdapter();
  
  // Use the most appropriate method based on what's provided
  if (opts?.establishmentId) {
    return await adapter.listByEstablishment(opts.establishmentId);
  } else if (opts?.professionalId) {
    return await adapter.listByProfessional(opts.professionalId);
  }
  
  // For now, return empty array if no specific ID is provided
  // In a real implementation, you'd have a "list all" method or use RPC
  return [];
}

export async function getAppointmentPrice(appt: Appointment) {
  // Get service price from the service table
  const { data: service, error } = await supabase
    .from('services')
    .select('price')
    .eq('id', appt.serviceId)
    .single();
    
  if (error) {
    console.error('Error fetching service price:', error);
    return appt.price || 0; // fallback to appointment price
  }
  
  return Number(service?.price) || appt.price || 0;
}

export async function revenueByEstablishment(establishmentId: string, opts?: { dateFrom?: string; dateTo?: string }) {
  const list = await adapter.listByEstablishment(establishmentId);
  return list
    .filter((a) => a.status === "concluído")
    .filter((a) => {
      if (!opts?.dateFrom && !opts?.dateTo) return true;
      const when = toDateTime(a.date, a.time);
      if (opts?.dateFrom && when < new Date(opts.dateFrom)) return false;
      if (opts?.dateTo && when > new Date(opts.dateTo)) return false;
      return true;
    })
    .reduce((sum, a) => sum + (a.price || 0), 0);
}

export async function revenueByProfessional(professionalId: string, opts?: { dateFrom?: string; dateTo?: string }) {
  const list = await adapter.listByProfessional(professionalId);
  return list
    .filter((a) => a.status === "concluído")
    .filter((a) => {
      if (!opts?.dateFrom && !opts?.dateTo) return true;
      const when = toDateTime(a.date, a.time);
      if (opts?.dateFrom && when < new Date(opts.dateFrom)) return false;
      if (opts?.dateTo && when > new Date(opts.dateTo)) return false;
      return true;
    })
    .reduce(async (sum, a) => (await sum) + (await getAppointmentPrice(a)), Promise.resolve(0));
}
