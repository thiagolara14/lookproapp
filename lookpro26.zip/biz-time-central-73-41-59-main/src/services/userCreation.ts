import { supabase } from "@/integrations/supabase/client";

export interface CreateUserData {
  email: string;
  password: string;
  full_name: string;
  role: 'admin' | 'professional';
  establishment_id: string; // Agora obrigatório
}

export interface CreateUserResult {
  success: boolean;
  user?: {
    id: string;
    email: string;
    role: string;
    establishment_id?: string;
  };
  error?: string;
  message: string;
}

export async function createUserWithCredentials(userData: CreateUserData): Promise<CreateUserResult> {
  try {
    // Validação dos dados obrigatórios
    if (!userData.email || !userData.password || !userData.full_name || !userData.role) {
      return {
        success: false,
        error: 'Dados obrigatórios não preenchidos',
        message: 'Email, senha, nome e role são obrigatórios'
      };
    }

    if (!userData.establishment_id) {
      return {
        success: false,
        error: 'Estabelecimento é obrigatório',
        message: 'Selecione um estabelecimento válido'
      };
    }

    // Get current session to pass auth token
    const { data: { session } } = await supabase.auth.getSession();
    
    if (!session) {
      return {
        success: false,
        error: 'Not authenticated',
        message: 'You must be logged in to create users'
      };
    }

    // Call the edge function to create user
    const { data, error } = await supabase.functions.invoke('create-user', {
      body: userData,
      headers: {
        Authorization: `Bearer ${session.access_token}`,
      },
    });

    if (error) {
      console.error('Edge function error:', error);
      return {
        success: false,
        error: error.message,
        message: 'Failed to create user'
      };
    }

    if (!data.success) {
      return {
        success: false,
        error: data.error,
        message: data.error || 'Failed to create user'
      };
    }

    return {
      success: true,
      user: data.user,
      message: data.message
    };

  } catch (error: any) {
    console.error('User creation error:', error);
    return {
      success: false,
      error: error.message,
      message: 'Unexpected error occurred'
    };
  }
}