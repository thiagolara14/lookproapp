// DEPRECATED: This file is neutralized in favor of Supabase
// All functionality moved to direct Supabase operations

// Legacy types for compatibility
type PublicEst = any;
type Service = any;
type Professional = any;
type Review = any;

export type WorkingHoursByDay = {
  monFri: { start: string; end: string };
  saturday?: { start: string; end: string } | null;
  sunday?: { start: string; end: string } | null;
};

export type EstablishmentOverrides = Partial<
  Omit<PublicEst, "id" | "services" | "professionals"> & {
    services: Service[];
    professionals: (Professional & { avatarUrl?: string; whatsapp?: string })[];
    workingHoursByDay: WorkingHoursByDay;
  }
>;

export type ExtProfessional = Professional & { avatarUrl?: string; whatsapp?: string };

// All functions neutralized - use Supabase directly
export function mergeEstablishment(base: PublicEst, ov?: EstablishmentOverrides | null): PublicEst {
  return base;
}

export async function listEstablishments(): Promise<PublicEst[]> {
  console.warn('listEstablishments is deprecated - use Supabase directly');
  return [];
}

export async function getEstablishmentById(id: string): Promise<PublicEst | undefined> {
  console.warn('getEstablishmentById is deprecated - use Supabase directly');
  return undefined;
}

export async function updateEstablishment(id: string, patch: EstablishmentOverrides): Promise<PublicEst | undefined> {
  console.warn('updateEstablishment is deprecated - use Supabase directly');
  return undefined;
}

export async function listServices(estId: string): Promise<Service[]> {
  console.warn('listServices is deprecated - use Supabase directly');
  return [];
}

export async function upsertService(estId: string, service: any): Promise<Service[]> {
  console.warn('upsertService is deprecated - use Supabase directly');
  return [];
}

export async function deleteService(estId: string, serviceId: string): Promise<Service[]> {
  console.warn('deleteService is deprecated - use Supabase directly');
  return [];
}

export async function listProfessionals(estId: string): Promise<ExtProfessional[]> {
  console.warn('listProfessionals is deprecated - use Supabase directly');
  return [];
}

export async function upsertProfessional(estId: string, pro: any): Promise<ExtProfessional[]> {
  console.warn('upsertProfessional is deprecated - use Supabase directly');
  return [];
}

export async function deleteProfessional(estId: string, proId: string): Promise<ExtProfessional[]> {
  console.warn('deleteProfessional is deprecated - use Supabase directly');
  return [];
}

export async function listReviews(estId: string): Promise<Review[]> {
  console.warn('listReviews is deprecated - use Supabase directly');
  return [];
}

export async function upsertReview(estId: string, review: any): Promise<Review[]> {
  console.warn('upsertReview is deprecated - use Supabase directly');
  return [];
}

export async function deleteReview(estId: string, reviewId: string): Promise<Review[]> {
  console.warn('deleteReview is deprecated - use Supabase directly');
  return [];
}