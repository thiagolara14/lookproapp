// WhatsApp Test Client - não expõe tokens no browser
import { supabase } from "@/integrations/supabase/client";

export interface SendTestMessageParams {
  to: string;
  text?: string;
}

export interface SendTestMessageResponse {
  success: boolean;
  messageId?: string;
  error?: string;
  details?: any;
}

export async function sendTestMessage(
  params: SendTestMessageParams
): Promise<SendTestMessageResponse> {
  try {
    const { data, error } = await supabase.functions.invoke('wa-send-test', {
      body: {
        to: params.to,
        text: params.text || "Hello World from LookPro!"
      },
      headers: {
        'Authorization': `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`
      }
    });

    if (error) {
      console.error('Error calling wa-send-test function:', error);
      return {
        success: false,
        error: error.message || 'Erro ao chamar função de envio',
      };
    }

    return data;
  } catch (error) {
    console.error('Error in sendTestMessage:', error);
    return {
      success: false,
      error: error instanceof Error ? error.message : 'Erro interno',
    };
  }
}

export function validateE164(phone: string): boolean {
  // Remove caracteres não numéricos
  const digits = phone.replace(/\D/g, '');
  
  // Deve ter entre 10 e 15 dígitos
  return digits.length >= 10 && digits.length <= 15;
}

export function formatE164(phone: string): string {
  // Remove caracteres não numéricos
  const digits = phone.replace(/\D/g, '');
  
  // Adiciona + se não tiver
  return `+${digits}`;
}