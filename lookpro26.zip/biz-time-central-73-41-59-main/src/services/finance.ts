/**
 * Serviços financeiros - integração com Supabase RPCs
 */

import { supabase } from "@/integrations/supabase/client";

export interface FinanceBreakdownItem {
  professional_id: string;
  total_cents: number;
}

/**
 * Busca o total de agendamentos finalizados de um profissional
 * @param professionalId ID do profissional
 * @param startDate Data de início (opcional)
 * @param endDate Data de fim (opcional)
 * @returns Total em centavos
 */
export async function fetchProfessionalTotalCents(
  professionalId: string, 
  startDate?: Date, 
  endDate?: Date
): Promise<number> {
  const { data, error } = await supabase.rpc("finance_total_for_professional", {
    p_professional_id: professionalId,
    p_start: startDate ? startDate.toISOString() : null,
    p_end: endDate ? endDate.toISOString() : null,
  });

  if (error) throw error;
  return Number(data || 0);
}

/**
 * Busca o total de agendamentos finalizados de um estabelecimento
 * @param establishmentId ID do estabelecimento
 * @param startDate Data de início (opcional)
 * @param endDate Data de fim (opcional)
 * @returns Total em centavos
 */
export async function fetchEstablishmentTotalCents(
  establishmentId: string, 
  startDate?: Date, 
  endDate?: Date
): Promise<number> {
  const { data, error } = await supabase.rpc("finance_total_for_establishment", {
    p_establishment_id: establishmentId,
    p_start: startDate ? startDate.toISOString() : null,
    p_end: endDate ? endDate.toISOString() : null,
  });

  if (error) throw error;
  return Number(data || 0);
}

/**
 * Busca o breakdown financeiro por profissional de um estabelecimento
 * @param establishmentId ID do estabelecimento
 * @param startDate Data de início (opcional)
 * @param endDate Data de fim (opcional)
 * @returns Array com breakdown por profissional
 */
export async function fetchEstablishmentBreakdownByProfessional(
  establishmentId: string,
  startDate?: Date,
  endDate?: Date
): Promise<FinanceBreakdownItem[]> {
  const { data, error } = await supabase.rpc("finance_breakdown_by_professional", {
    p_establishment_id: establishmentId,
    p_start: startDate ? startDate.toISOString() : null,
    p_end: endDate ? endDate.toISOString() : null,
  });

  if (error) throw error;
  return data || [];
}

/**
 * Utilitários de período para relatórios financeiros
 */
export const FinancePeriodUtils = {
  /**
   * Retorna o primeiro e último dia do mês atual
   */
  getCurrentMonth(): { start: Date; end: Date } {
    const now = new Date();
    const start = new Date(now.getFullYear(), now.getMonth(), 1);
    const end = new Date(now.getFullYear(), now.getMonth() + 1, 0, 23, 59, 59);
    return { start, end };
  },

  /**
   * Retorna os últimos N dias
   */
  getLastDays(days: number): { start: Date; end: Date } {
    const end = new Date();
    const start = new Date();
    start.setDate(end.getDate() - days);
    start.setHours(0, 0, 0, 0);
    end.setHours(23, 59, 59, 999);
    return { start, end };
  },

  /**
   * Retorna o período personalizado
   */
  getCustomPeriod(startDate: Date, endDate: Date): { start: Date; end: Date } {
    const start = new Date(startDate);
    start.setHours(0, 0, 0, 0);
    const end = new Date(endDate);
    end.setHours(23, 59, 59, 999);
    return { start, end };
  }
};