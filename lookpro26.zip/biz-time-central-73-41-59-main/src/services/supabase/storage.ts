// Supabase storage helpers for file uploads
import { supabase } from "@/integrations/supabase/client";

export type StorageBucket = 
  | 'establishment-photos'
  | 'establishment-logos' 
  | 'establishment-covers'
  | 'service-photos'
  | 'professional-avatars';

export async function uploadFile(
  bucket: StorageBucket,
  file: File,
  path: string
): Promise<string> {
  const { data, error } = await supabase.storage
    .from(bucket)
    .upload(path, file, {
      cacheControl: '3600',
      upsert: true
    });

  if (error) throw error;

  // Get public URL
  const { data: { publicUrl } } = supabase.storage
    .from(bucket)
    .getPublicUrl(data.path);

  return publicUrl;
}

export async function deleteFile(
  bucket: StorageBucket,
  path: string
): Promise<void> {
  const { error } = await supabase.storage
    .from(bucket)
    .remove([path]);

  if (error) throw error;
}

export async function listFiles(
  bucket: StorageBucket,
  folder?: string
): Promise<string[]> {
  const { data, error } = await supabase.storage
    .from(bucket)
    .list(folder);

  if (error) throw error;

  return data.map(file => {
    const { data: { publicUrl } } = supabase.storage
      .from(bucket)
      .getPublicUrl(folder ? `${folder}/${file.name}` : file.name);
    return publicUrl;
  });
}

export function getPublicUrl(bucket: StorageBucket, path: string): string {
  const { data: { publicUrl } } = supabase.storage
    .from(bucket)
    .getPublicUrl(path);
  
  return publicUrl;
}

// Professional avatar utilities
export function toPublicAvatarUrl(path?: string): string {
  if (!path) return '';
  const { data } = supabase.storage.from('professional-avatars').getPublicUrl(path);
  return data.publicUrl;
}

export async function getSignedAvatarUrl(path?: string, expiresInSec = 3600): Promise<string> {
  if (!path) return '';
  const { data, error } = await supabase.storage.from('professional-avatars').createSignedUrl(path, expiresInSec);
  if (error) return '';
  return data.signedUrl;
}

// Specific helpers for each type of photo
export async function uploadEstablishmentLogo(establishmentId: string, file: File): Promise<string> {
  const path = `${establishmentId}/logo-${Date.now()}.${file.name.split('.').pop()}`;
  return uploadFile('establishment-logos', file, path);
}

export async function uploadEstablishmentCover(establishmentId: string, file: File): Promise<string> {
  const path = `${establishmentId}/cover-${Date.now()}.${file.name.split('.').pop()}`;
  return uploadFile('establishment-covers', file, path);
}

export async function uploadEstablishmentPhoto(establishmentId: string, file: File): Promise<string> {
  const path = `${establishmentId}/photo-${Date.now()}.${file.name.split('.').pop()}`;
  return uploadFile('establishment-photos', file, path);
}

export async function uploadServicePhoto(serviceId: string, file: File): Promise<string> {
  const path = `${serviceId}/service-${Date.now()}.${file.name.split('.').pop()}`;
  return uploadFile('service-photos', file, path);
}

export async function uploadProfessionalAvatar(professionalId: string, file: File): Promise<string> {
  const path = `${professionalId}/avatar-${Date.now()}.${file.name.split('.').pop()}`;
  return uploadFile('professional-avatars', file, path);
}