// Complete Supabase establishments adapter
import { supabase } from "@/integrations/supabase/client";

type Establishment = {
  id: string;
  name: string;
  city: string;
  category: string;
  logoUrl?: string;
  coverUrl?: string;
  isActive: boolean;
  services: { id: string; name: string; durationMin: number; price: number }[];
  professionals: { id: string; name: string }[];
  workingHours: { start: string; end: string };
  workingHoursByDay?: {
    monFri: { start: string; end: string };
    saturday?: { start: string; end: string } | null;
    sunday?: { start: string; end: string } | null;
  };
  rating?: number;
  gallery?: string[];
  reviews?: any[];
  whatsapp?: string;
  email?: string;
  phone?: string;
  address?: string;
  state?: string;
  description?: string;
};

export interface SupabaseEstablishment {
  id: string;
  name: string;
  description?: string;
  logo_url?: string;
  cover_image_url?: string;
  email?: string;
  phone?: string;
  address: string;
  city: string;
  state: string;
  status: 'active' | 'inactive';
  created_at?: string;
  updated_at?: string;
}

export async function getEstablishmentById(id: string): Promise<Establishment | null> {
  try {
    // Fetch establishment
    const { data: est, error: e1 } = await supabase
      .from('establishments')
      .select('*, categories(name)')
      .eq('id', id)
      .maybeSingle();
    
    if (e1) throw e1;
    if (!est) return null;

    // Fetch related data in parallel
    const [servicesRes, prosRes, hoursRes, photosRes, reviewsRes] = await Promise.all([
      supabase.from('services').select('*').eq('establishment_id', id).eq('is_active', true),
      supabase.from('professionals').select('id, user_id, establishment_id, active').eq('establishment_id', id).eq('active', true),
      supabase.from('establishment_hours').select('*').eq('establishment_id', id),
      supabase.from('establishment_photos').select('*').eq('establishment_id', id).order('sort_order', { ascending: true }),
      supabase.from('reviews').select('establishment_rating, professional_rating').eq('establishment_id', id)
    ]);

    if (servicesRes.error) throw servicesRes.error;
    if (prosRes.error) throw prosRes.error;
    if (hoursRes.error) throw hoursRes.error;
    if (photosRes.error) throw photosRes.error;
    if (reviewsRes.error) throw reviewsRes.error;

    // Build services (price in decimal)
    const services = (servicesRes.data || []).map(s => ({
      id: s.id,
      name: s.name,
      durationMin: s.duration_minutes,
      price: Number(s.price),
    }));

    // Resolve professional names via profiles
    const userIds = (prosRes.data || []).map(p => p.user_id);
    let namesByUser = new Map<string, { full_name?: string; email?: string }>();
    if (userIds.length) {
      const { data: profiles } = await supabase
        .from('profiles')
        .select('user_id, full_name, email')
        .in('user_id', userIds);
      namesByUser = new Map((profiles || []).map(u => [u.user_id, { full_name: u.full_name, email: u.email }]));
    }
    const professionals = (prosRes.data || []).map((p, index) => ({
      id: p.id,
      name: namesByUser.get(p.user_id)?.full_name || '-',
    }));

    // Build working hours summary
    const hours = (hoursRes.data || []);
    // Don't calculate working hours here - let components use the hook
    const workingHours = { start: '00:00', end: '00:00' }; // Placeholder, components will use the hook

    const gallery = photosRes.data?.length ? photosRes.data.map(ph => ph.url) : (est.cover_image_url ? [est.cover_image_url] : undefined);

    // Calculate real average rating from reviews
    const reviews = reviewsRes.data || [];
    let averageRating = undefined;
    if (reviews.length > 0) {
      const totalRating = reviews.reduce((sum, review) => {
        return sum + (review.establishment_rating || review.professional_rating || 0);
      }, 0);
      averageRating = Math.round((totalRating / reviews.length) * 10) / 10;
    }

    return {
      id: est.id,
      name: est.name,
      city: est.city,
      category: (est as any).categories?.name || 'Barbearia',
      logoUrl: est.logo_url,
      coverUrl: est.cover_image_url,
      isActive: est.status === 'active',
      services,
      professionals,
      workingHours, // Placeholder - components use the hook
      rating: averageRating,
      gallery,
      description: est.description,
      address: est.address,
      state: est.state,
      phone: est.phone,
      email: est.email,
      whatsapp: est.phone,
    } as Establishment;
  } catch (error) {
    console.error('Error fetching establishment:', error);
    return null;
  }
}

export async function listEstablishments(filters?: { cityId?: string; categoryId?: string }): Promise<Establishment[]> {
  try {
    console.log('listEstablishments called with filters:', filters);
    let query = supabase
      .from('establishments')
      .select('*, categories(name)')
      .eq('status', 'active');

    if (filters?.cityId) {
      // Find city name by ID for filtering
      const { data: cityData } = await supabase
        .from('cities')
        .select('name')
        .eq('id', filters.cityId)
        .single();
      if (cityData) {
        query = query.eq('city', cityData.name);
      }
    }

    if (filters?.categoryId) {
      query = query.eq('category_id', filters.categoryId);
    }

    const { data, error } = await query;
    if (error) throw error;
    
    console.log('Raw establishments from Supabase:', data);
    console.log('Looking for Kabra:', data?.filter(e => e.name.toLowerCase().includes('kabra')));
    console.log('Looking for Bonini:', data?.filter(e => e.name.toLowerCase().includes('bonini')));
    
    // Detailed comparison for debugging
    const kabra = data?.find(e => e.name.toLowerCase().includes('kabra'));
    const bonini = data?.find(e => e.name.toLowerCase().includes('bonini'));
    
    if (kabra) {
      console.log('Kabra establishment details:', {
        id: kabra.id,
        name: kabra.name,
        category_id: kabra.category_id,
        categories: (kabra as any).categories,
        status: kabra.status,
        city: kabra.city
      });
    } else {
      console.log('Kabra not found in raw data');
    }
    
    if (bonini) {
      console.log('Bonini establishment details:', {
        id: bonini.id,
        name: bonini.name,
        category_id: bonini.category_id,
        categories: (bonini as any).categories,
        status: bonini.status,
        city: bonini.city
      });
    } else {
      console.log('Bonini not found in raw data');
    }

    const ids = (data || []).map(e => e.id);
    if (!ids.length) {
      console.log('No establishments found with current filters');
      return [];
    }

    // Parallel fetch related data
    const [servicesRes, prosRes, hoursRes, photosRes, reviewsRes] = await Promise.all([
      supabase.from('services').select('*').in('establishment_id', ids).eq('is_active', true),
      supabase.from('professionals').select('id, user_id, establishment_id, active').in('establishment_id', ids).eq('active', true),
      supabase.from('establishment_hours').select('*').in('establishment_id', ids),
      supabase.from('establishment_photos').select('*').in('establishment_id', ids).order('sort_order', { ascending: true }),
      supabase.from('reviews').select('establishment_id, establishment_rating, professional_rating').in('establishment_id', ids)
    ]);

    if (servicesRes.error) throw servicesRes.error;
    if (prosRes.error) throw prosRes.error;
    if (hoursRes.error) throw hoursRes.error;
    if (photosRes.error) throw photosRes.error;
    if (reviewsRes.error) throw reviewsRes.error;

    // Group services
    const servicesByEst = new Map<string, any[]>();
    (servicesRes.data || []).forEach(s => {
      const arr = servicesByEst.get(s.establishment_id) || [];
      arr.push({ id: s.id, name: s.name, durationMin: s.duration_minutes, price: Number(s.price) });
      servicesByEst.set(s.establishment_id, arr);
    });

    // Group professionals and resolve names
    const userIds = (prosRes.data || []).map(p => p.user_id);
    let namesByUser = new Map<string, { full_name?: string }>();
    if (userIds.length) {
      const { data: profiles } = await supabase
        .from('profiles')
        .select('user_id, full_name')
        .in('user_id', userIds);
      namesByUser = new Map((profiles || []).map(u => [u.user_id, { full_name: u.full_name }]));
    }
    
    const prosByEst = new Map<string, any[]>();
    (prosRes.data || []).forEach((p, index) => {
      const arr = prosByEst.get(p.establishment_id) || [];
      arr.push({ id: p.id, name: namesByUser.get(p.user_id)?.full_name || '-' });
      prosByEst.set(p.establishment_id, arr);
    });

    // Group hours
    const hoursByEst = new Map<string, any[]>();
    (hoursRes.data || []).forEach(h => {
      const arr = hoursByEst.get(h.establishment_id) || [];
      arr.push(h);
      hoursByEst.set(h.establishment_id, arr);
    });

    // Group photos
    const photosByEst = new Map<string, any[]>();
    (photosRes.data || []).forEach(ph => {
      const arr = photosByEst.get(ph.establishment_id) || [];
      arr.push(ph.url);
      photosByEst.set(ph.establishment_id, arr);
    });

    // Group reviews and calculate ratings
    const ratingsByEst = new Map<string, number>();
    const reviewsByEstablishment = new Map<string, any[]>();
    (reviewsRes.data || []).forEach(review => {
      const arr = reviewsByEstablishment.get(review.establishment_id) || [];
      arr.push(review);
      reviewsByEstablishment.set(review.establishment_id, arr);
    });

    // Calculate average ratings
    reviewsByEstablishment.forEach((reviews, estId) => {
      if (reviews.length > 0) {
        const totalRating = reviews.reduce((sum, review) => {
          return sum + (review.establishment_rating || review.professional_rating || 0);
        }, 0);
        const averageRating = Math.round((totalRating / reviews.length) * 10) / 10;
        ratingsByEst.set(estId, averageRating);
      }
    });

    // Map establishments
    return data.map(est => {
      const gallery = photosByEst.get(est.id) || (est.cover_image_url ? [est.cover_image_url] : undefined);

      return {
        id: est.id,
        name: est.name,
        city: est.city,
        category: (est as any).categories?.name || 'Barbearia',
        logoUrl: est.logo_url,
        coverUrl: est.cover_image_url,
        isActive: est.status === 'active',
        services: servicesByEst.get(est.id) || [],
        professionals: prosByEst.get(est.id) || [],
        workingHours: { start: '00:00', end: '00:00' }, // Placeholder - components use the hook
        rating: ratingsByEst.get(est.id), // Real rating or undefined if no reviews
        gallery,
      } as Establishment;
    });
  } catch (error) {
    console.error('Error listing establishments:', error);
    return [];
  }
}

export async function createEstablishment(input: {
  name: string;
  category: string;
  city: string;
  description?: string;
  address?: string;
  state?: string;
  phone?: string;
  email?: string;
}): Promise<string> {
  const { data, error } = await supabase
    .from('establishments')
    .insert({
      name: input.name,
      description: input.description || '',
      address: input.address || '',
      city: input.city,
      state: input.state || '',
      phone: input.phone || '',
      email: input.email || '',
      status: 'active'
    })
    .select()
    .single();

  if (error) throw error;
  return data.id;
}

export async function updateEstablishment(id: string, updates: Partial<SupabaseEstablishment>): Promise<void> {
  // Remove status from updates to avoid type conflict
  const { status, ...safeUpdates } = updates;
  const updateData = {
    ...safeUpdates,
    ...(status && { status: status as "active" })
  };
  
  const { error } = await supabase
    .from('establishments')
    .update(updateData)
    .eq('id', id);

  if (error) throw error;
}

export async function deleteEstablishment(id: string): Promise<void> {
  const { error } = await supabase
    .from('establishments')
    .update({ status: 'active' }) // Note: Supabase schema only allows 'active', 'overdue', 'blocked'
    .eq('id', id);

  if (error) throw error;
}