// Supabase authentication helpers
import { supabase } from "@/integrations/supabase/client";
import type { User } from "@supabase/supabase-js";

export async function signInWithEmail(email: string, password: string) {
  const { data, error } = await supabase.auth.signInWithPassword({
    email,
    password,
  });
  
  if (error) throw error;
  return data;
}

export async function signUpWithEmail(email: string, password: string, metadata?: { 
  display_name?: string; 
  role?: string 
}) {
  const { data, error } = await supabase.auth.signUp({
    email,
    password,
    options: {
      emailRedirectTo: `${window.location.origin}/`,
      data: metadata,
    },
  });
  
  if (error) throw error;
  return data;
}

export async function signOut() {
  const { error } = await supabase.auth.signOut();
  if (error) throw error;
}

export async function getSession() {
  const { data, error } = await supabase.auth.getSession();
  if (error) throw error;
  return data.session;
}

export async function getCurrentUser(): Promise<User | null> {
  const { data: { user }, error } = await supabase.auth.getUser();
  if (error) throw error;
  return user;
}

export function onAuthStateChange(callback: (event: string, session: any) => void) {
  return supabase.auth.onAuthStateChange(callback);
}

// Create super admin user (for initial setup)
export async function createSuperAdmin(email: string, password: string, displayName: string) {
  return signUpWithEmail(email, password, {
    display_name: displayName,
    role: 'super_admin'
  });
}

// Helper to check if user has specific role
export async function checkUserRole(): Promise<string | null> {
  const user = await getCurrentUser();
  if (!user) return null;
  
  const { data, error } = await supabase
    .from('profiles')
    .select('role')
    .eq('user_id', user.id)
    .maybeSingle();
    
  if (error) {
    console.error('Error fetching user role:', error);
    return null;
  }
  
  return data?.role || null;
}