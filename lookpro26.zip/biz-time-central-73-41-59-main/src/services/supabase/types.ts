// Types that map legacy types to Supabase equivalents
export type ID = string;

export type City = { 
  id: ID; 
  name: string; 
  state?: string;
  visible: boolean;
  created_at?: string;
  updated_at?: string;
};

export type Category = { 
  id: ID; 
  name: string; 
  image_url?: string;
  active?: boolean;
  created_at?: string;
  updated_at?: string;
};

export type PlanPeriod = "monthly" | "yearly";
export type Plan = {
  id: ID;
  name: string;
  price: number; // in BRL
  period: PlanPeriod;
  trial_days: number;
  booking_limit: number;
  extras: string[];
  active?: boolean;
  created_at?: string;
  updated_at?: string;
};

export type EstablishmentStatus = "active" | "inactive";
export type Establishment = {
  id: ID;
  name: string;
  description?: string;
  logo_url?: string;
  cover_image_url?: string;
  email?: string;
  phone?: string;
  address: string;
  city: string;
  state: string;
  city_id?: ID;
  category_id?: ID;
  plan_id?: ID;
  status: EstablishmentStatus;
  last_access_at?: string;
  is_featured?: boolean;
  website?: string;
  slug?: string;
  monthly_fee?: number;
  subscription_start_date?: string;
  next_payment_date?: string;
  created_at?: string;
  updated_at?: string;
};

export type UserRole = "super_admin" | "admin" | "pro" | "client";
export type UserStatus = "active" | "blocked";
export type User = {
  id: ID;
  email: string;
  display_name?: string;
  photo_url?: string;
  role: UserRole;
  establishment_id?: ID;
  created_at?: string;
  updated_at?: string;
  // Legacy compatibility
  name?: string;
  status?: UserStatus;
};

export type Professional = {
  id: ID;
  user_id: ID;
  establishment_id: ID;
  avatar_url?: string;
  bio?: string;
  specialties?: string[];
  active?: boolean;
  created_at?: string;
  updated_at?: string;
};

export type Service = {
  id: ID;
  establishment_id: ID;
  category_id?: ID;
  name: string;
  description?: string;
  price: number;
  duration_minutes: number;
  image_url?: string;
  is_active?: boolean;
  sort_order?: number;
  created_at?: string;
  updated_at?: string;
};

export type AppointmentStatus = "scheduled" | "confirmed" | "cancelled" | "completed";
export type Appointment = {
  id: ID;
  establishment_id: ID;
  professional_id?: ID;
  client_id: ID;
  service_id?: ID;
  appointment_date: string;
  start_time: string;
  end_time: string;
  total_price: number;
  status: AppointmentStatus;
  notes?: string;
  cancelled_at?: string;
  confirmed_at?: string;
  completed_at?: string;
  cancellation_reason?: string;
  created_at?: string;
  updated_at?: string;
};

export type Review = {
  id: ID;
  establishment_id: ID;
  professional_id?: ID;
  client_id: ID;
  appointment_id?: ID;
  establishment_rating: number;
  professional_rating: number;
  comment?: string;
  created_at?: string;
  updated_at?: string;
  // Legacy compatibility
  rating?: number;
  date?: string;
  userName?: string;
};

export type Booking = {
  id: ID;
  establishment_id: ID;
  date: string; // ISO
  price: number;
  user_email: string;
};

export type EstablishmentHours = {
  id: ID;
  establishment_id: ID;
  day_of_week: number; // 0 = Sunday
  open_time?: string;
  close_time?: string;
  is_closed: boolean;
  created_at?: string;
};

export type EstablishmentPhoto = {
  id: ID;
  establishment_id: ID;
  url: string;
  caption?: string;
  sort_order: number;
  created_at?: string;
};