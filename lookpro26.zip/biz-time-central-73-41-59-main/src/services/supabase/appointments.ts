// Complete Supabase appointments adapter
import { supabase } from "@/integrations/supabase/client";
import type { Appointment, AppointmentStatus } from "@/types/appointments";

// Status mapping helpers
function mapToSupabaseStatus(status: AppointmentStatus): string {
  const statusMap: Record<AppointmentStatus, string> = {
    "pendente": "scheduled",
    "confirmado": "confirmed", 
    "concluído": "completed",
    "cancelado": "cancelled"
  };
  return statusMap[status] || "scheduled";
}

function mapFromSupabaseStatus(status: string): AppointmentStatus {
  const statusMap: Record<string, AppointmentStatus> = {
    "scheduled": "pendente",
    "confirmed": "confirmado",
    "completed": "concluído", 
    "cancelled": "cancelado"
  };
  return statusMap[status] || "pendente";
}

export async function createAppointment(input: {
  establishmentId: string;
  clientId?: string;
  clientName?: string;
  clientPhone?: string;
  professionalId: string;
  serviceId: string;
  date: string;
  time: string;
  duration?: number;
  price?: number;
  status?: AppointmentStatus;
  notes?: string;
}): Promise<Appointment> {
  try {
    // Get service duration if not provided
    let serviceDuration = input.duration;
    if (!serviceDuration) {
      const { data: serviceData } = await supabase
        .from('services')
        .select('duration_minutes')
        .eq('id', input.serviceId)
        .single();
      serviceDuration = serviceData?.duration_minutes || 60;
    }

    // Use the RPC function for atomic appointment creation with conflict checking
    const appointmentId = await supabase.rpc('create_appointment_rpc', {
      p_establishment_id: input.establishmentId,
      p_professional_id: input.professionalId,
      p_service_id: input.serviceId,
      p_appointment_date: input.date,
      p_start_time: input.time,
      p_duration_minutes: serviceDuration,
      p_client_id: input.clientId || null,
      p_client_name: input.clientName || null,
      p_client_phone: input.clientPhone || null,
      p_status: mapToSupabaseStatus(input.status || "pendente")
    });

    if (appointmentId.error) {
      throw new Error(appointmentId.error.message);
    }

    // Fetch the created appointment to return in expected format
    const { data, error } = await supabase
      .from('appointments')
      .select('*')
      .eq('id', appointmentId.data)
      .single();

    if (error) throw error;

    // Get additional data for the appointment
    const [serviceData, professionalData] = await Promise.all([
      supabase.from('services').select('name').eq('id', input.serviceId).single(),
      supabase.from('professionals').select('user_id').eq('id', input.professionalId).single()
    ]);

    let professionalName = 'Profissional';
    if (professionalData.data) {
      const { data: profile } = await supabase
        .from('profiles')
        .select('full_name')
        .eq('user_id', professionalData.data.user_id)
        .single();
      professionalName = profile?.full_name || 'Profissional';
    }

    return {
      id: data.id,
      establishmentId: data.establishment_id,
      clientId: data.client_id || input.clientPhone || '',
      clientName: data.client_name || input.clientName || '',
      professionalId: data.professional_id,
      professionalName,
      serviceId: data.service_id,
      serviceName: serviceData.data?.name || 'Serviço',
      date: data.appointment_date,
      time: data.start_time,
      status: mapFromSupabaseStatus(data.status),
      notes: data.notes,
      createdAt: data.created_at,
      updatedAt: data.updated_at,
    };
  } catch (error: any) {
    // Handle specific error types
    if (error.code === 'P0001') {
      throw new Error('Horário indisponível (conflito com outro agendamento).');
    } else if (error.code === 'P0002') {
      throw new Error('Horário não disponível (bloqueado ou inválido).');
    } else {
      throw new Error(error.message || 'Erro ao criar agendamento.');
    }
  }
}

export async function updateAppointment(id: string, updates: Partial<Appointment>): Promise<Appointment> {
  const updateData: any = {};
  
  if (updates.status) updateData.status = mapToSupabaseStatus(updates.status);
  if (updates.notes) updateData.notes = updates.notes;
  if (updates.date) updateData.appointment_date = updates.date;
  if (updates.time) updateData.start_time = updates.time;
  // Remove price update as it doesn't exist in Appointment type

  const { data, error } = await supabase
    .from('appointments')
    .update(updateData)
    .eq('id', id)
    .select('*')
    .single();

  if (error) throw error;

  // Get additional data for the appointment
  const [serviceData, professionalData] = await Promise.all([
    supabase.from('services').select('name').eq('id', data.service_id).single(),
    supabase.from('professionals').select('user_id').eq('id', data.professional_id).single()
  ]);

  let professionalName = 'Profissional';
  if (professionalData.data) {
    const { data: profile } = await supabase
      .from('profiles')
      .select('full_name')
      .eq('user_id', professionalData.data.user_id)
      .single();
    professionalName = profile?.full_name || 'Profissional';
  }

  return {
    id: data.id,
    establishmentId: data.establishment_id,
    clientId: data.client_id || data.client_phone || '',
    clientName: data.client_name || '',
    professionalId: data.professional_id,
    professionalName,
    serviceId: data.service_id,
    serviceName: serviceData.data?.name || 'Serviço',
    date: data.appointment_date,
    time: data.start_time,
    // duration: 60, // Remove this property as it doesn't exist in Appointment type
    // price: Number(data.total_price), // Remove - not in Appointment type
    status: mapFromSupabaseStatus(data.status),
    notes: data.notes,
    createdAt: data.created_at,
    updatedAt: data.updated_at,
  };
}

export async function getAppointmentById(id: string): Promise<Appointment | null> {
  const { data, error } = await supabase
    .from('appointments')
    .select('*')
    .eq('id', id)
    .single();

  if (error) return null;

  // Get additional data for the appointment
  const [serviceData, professionalData] = await Promise.all([
    supabase.from('services').select('name').eq('id', data.service_id).single(),
    supabase.from('professionals').select('user_id').eq('id', data.professional_id).single()
  ]);

  let professionalName = 'Profissional';
  if (professionalData.data) {
    const { data: profile } = await supabase
      .from('profiles')
      .select('full_name')
      .eq('user_id', professionalData.data.user_id)
      .single();
    professionalName = profile?.full_name || 'Profissional';
  }

  return {
    id: data.id,
    establishmentId: data.establishment_id,
    clientId: data.client_id || data.client_phone || '',
    clientName: data.client_name || '',
    professionalId: data.professional_id,
    professionalName,
    serviceId: data.service_id,
    serviceName: serviceData.data?.name || 'Serviço',
    date: data.appointment_date,
    time: data.start_time,
    // duration: 60, // Remove this property as it doesn't exist in Appointment type
    // price: Number(data.total_price), // Remove - not in Appointment type
    status: mapFromSupabaseStatus(data.status),
    notes: data.notes,
    createdAt: data.created_at,
    updatedAt: data.updated_at,
  };
}

export async function listAppointmentsByProfessional(professionalId: string, opts?: { date?: string }): Promise<Appointment[]> {
  let query = supabase
    .from('appointments')
    .select('*')
    .eq('professional_id', professionalId);

  if (opts?.date) {
    query = query.eq('appointment_date', opts.date);
  }

  const { data, error } = await query.order('appointment_date', { ascending: true }).order('start_time', { ascending: true });

  if (error) throw error;

  // Get additional data for all appointments
  const serviceIds = [...new Set(data.map(a => a.service_id))];
  const professionalIds = [...new Set(data.map(a => a.professional_id))];

  const [servicesData, professionalsData] = await Promise.all([
    supabase.from('services').select('id, name, price, duration_minutes').in('id', serviceIds),
    supabase.from('professionals').select('id, user_id').in('id', professionalIds)
  ]);

  const serviceNames = new Map(servicesData.data?.map(s => [s.id, s.name]) || []);
  const professionalUserIds = new Map(professionalsData.data?.map(p => [p.id, p.user_id]) || []);

  // Get professional names
  const userIds = [...professionalUserIds.values()];
  const { data: profiles } = await supabase
    .from('profiles')
    .select('user_id, full_name')
    .in('user_id', userIds);

  const userNames = new Map(profiles?.map(p => [p.user_id, p.full_name]) || []);

  return data.map(appointment => ({
    id: appointment.id,
    establishmentId: appointment.establishment_id,
    clientId: appointment.client_id || appointment.client_phone || '',
    clientName: appointment.client_name || '',
    professionalId: appointment.professional_id,
    professionalName: userNames.get(professionalUserIds.get(appointment.professional_id) || '') || 'Profissional',
    serviceId: appointment.service_id,
    serviceName: serviceNames.get(appointment.service_id) || 'Serviço',
    date: appointment.appointment_date,
    time: appointment.start_time,
    duration: servicesData.data?.find(s => s.id === appointment.service_id)?.duration_minutes || 60,
    price: Number(servicesData.data?.find(s => s.id === appointment.service_id)?.price || appointment.total_price),
    status: mapFromSupabaseStatus(appointment.status),
    notes: appointment.notes,
    createdAt: appointment.created_at,
    updatedAt: appointment.updated_at,
  }));
}

export async function listAppointmentsByEstablishment(establishmentId: string, opts?: { date?: string }): Promise<Appointment[]> {
  let query = supabase
    .from('appointments')
    .select('*')
    .eq('establishment_id', establishmentId);

  if (opts?.date) {
    query = query.eq('appointment_date', opts.date);
  }

  const { data, error } = await query.order('appointment_date', { ascending: true }).order('start_time', { ascending: true });

  if (error) throw error;

  // Get additional data for all appointments
  const serviceIds = [...new Set(data.map(a => a.service_id))];
  const professionalIds = [...new Set(data.map(a => a.professional_id))];

  const [servicesData, professionalsData] = await Promise.all([
    supabase.from('services').select('id, name, price, duration_minutes').in('id', serviceIds),
    supabase.from('professionals').select('id, user_id').in('id', professionalIds)
  ]);

  const serviceNames = new Map(servicesData.data?.map(s => [s.id, s.name]) || []);
  const professionalUserIds = new Map(professionalsData.data?.map(p => [p.id, p.user_id]) || []);

  // Get professional names
  const userIds = [...professionalUserIds.values()];
  const { data: profiles } = await supabase
    .from('profiles')
    .select('user_id, full_name')
    .in('user_id', userIds);

  const userNames = new Map(profiles?.map(p => [p.user_id, p.full_name]) || []);

  return data.map(appointment => ({
    id: appointment.id,
    establishmentId: appointment.establishment_id,
    clientId: appointment.client_id || appointment.client_phone || '',
    clientName: appointment.client_name || '',
    professionalId: appointment.professional_id,
    professionalName: userNames.get(professionalUserIds.get(appointment.professional_id) || '') || 'Profissional',
    serviceId: appointment.service_id,
    serviceName: serviceNames.get(appointment.service_id) || 'Serviço',
    date: appointment.appointment_date,
    time: appointment.start_time,
    duration: servicesData.data?.find(s => s.id === appointment.service_id)?.duration_minutes || 60,
    price: Number(servicesData.data?.find(s => s.id === appointment.service_id)?.price || appointment.total_price),
    status: mapFromSupabaseStatus(appointment.status),
    notes: appointment.notes,
    createdAt: appointment.created_at,
    updatedAt: appointment.updated_at,
  }));
}

export async function listAppointmentsByClient(clientId: string): Promise<Appointment[]> {
  const { data, error } = await supabase
    .from('appointments')
    .select('*')
    .or(`client_id.eq.${clientId},client_phone.eq.${clientId}`)
    .order('appointment_date', { ascending: false })
    .order('start_time', { ascending: false });

  if (error) throw error;

  // Get additional data for all appointments
  const serviceIds = [...new Set(data.map(a => a.service_id))];
  const professionalIds = [...new Set(data.map(a => a.professional_id))];

  const [servicesData, professionalsData] = await Promise.all([
    supabase.from('services').select('id, name, price, duration_minutes').in('id', serviceIds),
    supabase.from('professionals').select('id, user_id').in('id', professionalIds)
  ]);

  const serviceNames = new Map(servicesData.data?.map(s => [s.id, s.name]) || []);
  const professionalUserIds = new Map(professionalsData.data?.map(p => [p.id, p.user_id]) || []);

  // Get professional names
  const userIds = [...professionalUserIds.values()];
  const { data: profiles } = await supabase
    .from('profiles')
    .select('user_id, full_name')
    .in('user_id', userIds);

  const userNames = new Map(profiles?.map(p => [p.user_id, p.full_name]) || []);

  return data.map(appointment => ({
    id: appointment.id,
    establishmentId: appointment.establishment_id,
    clientId: appointment.client_id || appointment.client_phone || '',
    clientName: appointment.client_name || '',
    professionalId: appointment.professional_id,
    professionalName: userNames.get(professionalUserIds.get(appointment.professional_id) || '') || 'Profissional',
    serviceId: appointment.service_id,
    serviceName: serviceNames.get(appointment.service_id) || 'Serviço',
    date: appointment.appointment_date,
    time: appointment.start_time,
    duration: 60,
    price: Number(appointment.total_price),
    status: mapFromSupabaseStatus(appointment.status),
    notes: appointment.notes,
    createdAt: appointment.created_at,
    updatedAt: appointment.updated_at,
  }));
}