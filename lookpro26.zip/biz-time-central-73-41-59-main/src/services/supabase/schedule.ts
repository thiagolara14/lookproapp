import { supabase } from "@/integrations/supabase/client";
import type { Appointment } from "@/types/appointments";

export type EstablishmentWorkingHours = {
  [dayOfWeek: string]: {
    start: string;
    end: string;
    closed: boolean;
  };
};

export type TimeSlot = {
  time: string;
  available: boolean;
  blocked: boolean;
  appointment?: Appointment;
};

export type ScheduleDay = {
  date: string;
  dayOfWeek: number;
  workingHours: { start: string; end: string; closed: boolean };
  timeSlots: TimeSlot[];
};

/**
 * Obter horários de funcionamento do estabelecimento
 */
export async function getEstablishmentWorkingHours(establishmentId: string): Promise<EstablishmentWorkingHours> {
  const { data, error } = await supabase.rpc('get_establishment_working_hours', {
    establishment_uuid: establishmentId
  });

  if (!error && data && Object.keys(data || {}).length > 0) {
    return data as EstablishmentWorkingHours;
  }

  // Fallback: read directly from establishment_hours table
  const { data: hours, error: hoursError } = await supabase
    .from('establishment_hours')
    .select('*')
    .eq('establishment_id', establishmentId);

  if (hoursError || !hours || hours.length === 0) {
    console.error('Error fetching working hours (RPC and fallback failed):', error || hoursError);
    return {};
  }

  const workingHours: EstablishmentWorkingHours = {};
  hours.forEach((h: any) => {
    const key = String(h.day_of_week);
    workingHours[key] = {
      start: h.open_time || '00:00',
      end: h.close_time || '00:00',
      closed: !!h.is_closed,
    };
  });

  return workingHours;
}

/**
 * Gerar slots de tempo baseados no horário de funcionamento
 */
export function generateTimeSlots(
  workingHours: { start: string; end: string; closed: boolean },
  intervalMinutes: number = 30
): string[] {
  if (workingHours.closed) return [];

  const slots: string[] = [];
  const [startHour, startMin] = workingHours.start.split(':').map(Number);
  const [endHour, endMin] = workingHours.end.split(':').map(Number);
  
  const startMinutes = startHour * 60 + startMin;
  const endMinutes = endHour * 60 + endMin;
  
  for (let minutes = startMinutes; minutes < endMinutes; minutes += intervalMinutes) {
    const hours = Math.floor(minutes / 60);
    const mins = minutes % 60;
    const timeString = `${hours.toString().padStart(2, '0')}:${mins.toString().padStart(2, '0')}`;
    slots.push(timeString);
  }
  
  return slots;
}

/**
 * Obter agenda completa do profissional para uma data específica
 */
export async function getProfessionalSchedule(
  professionalId: string,
  date: string
): Promise<ScheduleDay> {
  // Obter profissional e dados do estabelecimento
  const { data: professional } = await supabase
    .from('professionals')
    .select('establishment_id')
    .eq('id', professionalId)
    .single();

  if (!professional) {
    throw new Error('Profissional não encontrado');
  }

  // Obter horários de funcionamento do estabelecimento
  const workingHours = await getEstablishmentWorkingHours(professional.establishment_id);
  
  // Calcular dia da semana (0=domingo, 1=segunda, etc.)
  const dateObj = new Date(date + 'T00:00:00');
  const dayOfWeek = dateObj.getDay();
  const dayWorkingHours = workingHours[dayOfWeek.toString()] ?? { start: '00:00', end: '00:00', closed: true };

  // Gerar slots de tempo baseados no horário de funcionamento
  const availableSlots = generateTimeSlots(dayWorkingHours);

  // Buscar agendamentos existentes para o dia
  const { data: appointments } = await supabase
    .from('appointments')
    .select('*, services(name)')
    .eq('professional_id', professionalId)
    .eq('appointment_date', date);

  // Buscar períodos bloqueados
  const { data: blockedPeriods } = await supabase
    .from('blocked_periods')
    .select('*')
    .eq('professional_id', professionalId)
    .lte('start_date', date)
    .gte('end_date', date);

  // Processar cada slot de tempo
  const timeSlots: TimeSlot[] = availableSlots.map(time => {
    const slotDateTime = new Date(`${date}T${time}:00`);
    
    // Verificar se há agendamento neste horário
    const appointment = appointments?.find(apt => apt.start_time === time);
    
    // Verificar se está bloqueado
    const isBlocked = blockedPeriods?.some(block => {
      const blockStart = new Date(`${block.start_date}T${block.start_time || '00:00'}:00`);
      const blockEnd = new Date(`${block.end_date}T${block.end_time || '23:59'}:59`);
      return slotDateTime >= blockStart && slotDateTime <= blockEnd;
    }) || false;

    return {
      time,
      available: !appointment && !isBlocked,
      blocked: isBlocked,
      appointment: appointment ? {
        id: appointment.id,
        establishmentId: appointment.establishment_id,
        professionalId: appointment.professional_id,
        professionalName: '', // Será preenchido conforme necessário
        clientId: appointment.client_id || appointment.client_phone || '',
        clientName: appointment.client_name || '',
        serviceId: appointment.service_id,
        serviceName: appointment.services?.name || '',
        date: appointment.appointment_date,
        time: appointment.start_time,
        status: (() => {
          switch (appointment.status) {
            case 'scheduled': return 'pendente';
            case 'confirmed': return 'confirmado';
            case 'completed': return 'concluído';
            case 'cancelled': return 'cancelado';
            default: return 'pendente';
          }
        })(),
        notes: appointment.notes,
        createdAt: appointment.created_at,
        updatedAt: appointment.updated_at,
      } : undefined
    };
  });

  return {
    date,
    dayOfWeek,
    workingHours: dayWorkingHours,
    timeSlots
  };
}

/**
 * Obter agenda semanal do profissional
 */
export async function getProfessionalWeeklySchedule(
  professionalId: string,
  startDate: string
): Promise<ScheduleDay[]> {
  const schedules: ScheduleDay[] = [];
  
  for (let i = 0; i < 7; i++) {
    const currentDate = new Date(startDate);
    currentDate.setDate(currentDate.getDate() + i);
    const dateString = currentDate.toISOString().split('T')[0];
    
    const daySchedule = await getProfessionalSchedule(professionalId, dateString);
    schedules.push(daySchedule);
  }
  
  return schedules;
}

/**
 * Validar se um horário está disponível para agendamento
 */
export async function isTimeSlotAvailable(
  professionalId: string,
  date: string,
  time: string
): Promise<{ available: boolean; reason?: string }> {
  // Obter dados do profissional
  const { data: professional } = await supabase
    .from('professionals')
    .select('establishment_id')
    .eq('id', professionalId)
    .single();

  if (!professional) {
    return { available: false, reason: 'Profissional não encontrado' };
  }

  // Verificar horário de funcionamento
  const workingHours = await getEstablishmentWorkingHours(professional.establishment_id);
  const dayOfWeek = new Date(date + 'T00:00:00').getDay();
  const dayHours = workingHours[dayOfWeek.toString()];
  
  if (!dayHours || dayHours.closed) {
    return { available: false, reason: 'Estabelecimento fechado neste dia' };
  }

  if (time < dayHours.start || time >= dayHours.end) {
    return { available: false, reason: 'Fora do horário de funcionamento' };
  }

  // Verificar agendamentos existentes
  const { data: existingAppointment } = await supabase
    .from('appointments')
    .select('id')
    .eq('professional_id', professionalId)
    .eq('appointment_date', date)
    .eq('start_time', time)
    .neq('status', 'cancelled')
    .maybeSingle();

  if (existingAppointment) {
    return { available: false, reason: 'Horário já agendado' };
  }

  // Verificar períodos bloqueados
  const slotDateTime = new Date(`${date}T${time}:00`);
  
  const { data: blockedPeriods } = await supabase
    .from('blocked_periods')
    .select('*')
    .eq('professional_id', professionalId)
    .lte('start_date', date)
    .gte('end_date', date);

  const isBlocked = blockedPeriods?.some(block => {
    const blockStart = new Date(`${block.start_date}T${block.start_time || '00:00'}:00`);
    const blockEnd = new Date(`${block.end_date}T${block.end_time || '23:59'}:59`);
    return slotDateTime >= blockStart && slotDateTime <= blockEnd;
  });

  if (isBlocked) {
    return { available: false, reason: 'Horário bloqueado' };
  }

  return { available: true };
}