import { supabase } from "@/integrations/supabase/client";
import type { Appointment } from "@/types/appointments";

/**
 * Validates if a time slot is available for booking
 * Enforces the rule: no two actions for the same date/time for the same professional
 */
export async function validateScheduleConflict(
  professionalId: string,
  date: string,
  time: string,
  excludeAppointmentId?: string
): Promise<{ isValid: boolean; reason?: string }> {
  try {
    // Check for existing appointments at this time
    let appointmentQuery = supabase
      .from('appointments')
      .select('id, status')
      .eq('professional_id', professionalId)
      .eq('appointment_date', date)
      .eq('start_time', time)
      .neq('status', 'cancelled');

    // Exclude current appointment if editing
    if (excludeAppointmentId) {
      appointmentQuery = appointmentQuery.neq('id', excludeAppointmentId);
    }

    const { data: existingAppointments, error: appointmentError } = await appointmentQuery;

    if (appointmentError) {
      console.error('Error checking appointments:', appointmentError);
      return { isValid: false, reason: 'Erro ao verificar disponibilidade' };
    }

    if (existingAppointments && existingAppointments.length > 0) {
      return { isValid: false, reason: 'Este horário já está ocupado com outro agendamento' };
    }

    // Check for blocked periods
    const slotDateTime = new Date(`${date}T${time}:00`);
    
    const { data: blockedPeriods, error: blockError } = await supabase
      .from('blocked_periods')
      .select('*')
      .eq('professional_id', professionalId)
      .lte('start_date', date)
      .gte('end_date', date);

    if (blockError) {
      console.error('Error checking blocked periods:', blockError);
      return { isValid: false, reason: 'Erro ao verificar bloqueios' };
    }

    if (blockedPeriods && blockedPeriods.length > 0) {
      const isBlocked = blockedPeriods.some(block => {
        const blockStart = new Date(`${block.start_date}T${block.start_time || '00:00'}:00`);
        const blockEnd = new Date(`${block.end_date}T${block.end_time || '23:59'}:59`);
        return slotDateTime >= blockStart && slotDateTime <= blockEnd;
      });

      if (isBlocked) {
        return { isValid: false, reason: 'Este horário está bloqueado para agendamentos' };
      }
    }

    // Check if it's in the past
    const now = new Date();
    const appointmentDateTime = new Date(`${date}T${time}:00`);
    
    if (appointmentDateTime <= now) {
      return { isValid: false, reason: 'Não é possível agendar para datas/horários no passado' };
    }

    return { isValid: true };
  } catch (error) {
    console.error('Error validating schedule conflict:', error);
    return { isValid: false, reason: 'Erro interno ao validar disponibilidade' };
  }
}

/**
 * Validates if a blocking action can be performed
 * Enforces the rule: cannot block a time slot that has an active appointment
 */
export async function validateBlockingAction(
  professionalId: string,
  date: string,
  time: string
): Promise<{ canBlock: boolean; reason?: string }> {
  try {
    // Check for existing appointments at this time
    const { data: existingAppointments, error } = await supabase
      .from('appointments')
      .select('id, status, client_name')
      .eq('professional_id', professionalId)
      .eq('appointment_date', date)
      .eq('start_time', time)
      .neq('status', 'cancelled');

    if (error) {
      console.error('Error checking appointments for blocking:', error);
      return { canBlock: false, reason: 'Erro ao verificar agendamentos' };
    }

    if (existingAppointments && existingAppointments.length > 0) {
      const appointment = existingAppointments[0];
      return { 
        canBlock: false, 
        reason: `Este horário tem um agendamento ativo com ${appointment.client_name}. Cancele o agendamento primeiro.` 
      };
    }

    return { canBlock: true };
  } catch (error) {
    console.error('Error validating blocking action:', error);
    return { canBlock: false, reason: 'Erro interno ao validar bloqueio' };
  }
}

/**
 * Get all time conflicts for a professional on a specific date
 */
export async function getTimeConflicts(
  professionalId: string,
  date: string
): Promise<{
  appointments: Array<{ time: string; clientName: string; status: string }>;
  blockedPeriods: Array<{ startTime: string; endTime: string; reason: string }>;
}> {
  try {
    const [appointmentsResult, blockedResult] = await Promise.all([
      supabase
        .from('appointments')
        .select('start_time, client_name, status')
        .eq('professional_id', professionalId)
        .eq('appointment_date', date)
        .neq('status', 'cancelled'),
      
      supabase
        .from('blocked_periods')
        .select('start_time, end_time, reason')
        .eq('professional_id', professionalId)
        .lte('start_date', date)
        .gte('end_date', date)
    ]);

    const appointments = appointmentsResult.data?.map(apt => ({
      time: apt.start_time,
      clientName: apt.client_name || 'Cliente',
      status: apt.status
    })) || [];

    const blockedPeriods = blockedResult.data?.map(block => ({
      startTime: block.start_time || '00:00',
      endTime: block.end_time || '23:59',
      reason: block.reason || 'Bloqueado'
    })) || [];

    return { appointments, blockedPeriods };
  } catch (error) {
    console.error('Error getting time conflicts:', error);
    return { appointments: [], blockedPeriods: [] };
  }
}