// Complete Supabase adapters for Super Admin operations
import { supabase } from "@/integrations/supabase/client";
import type { 
  City, Category, Plan, Establishment, User, Booking, Review, 
  ID, EstablishmentStatus, UserRole, UserStatus, PlanPeriod 
} from "@/lib/superStore";

// Password generator utility
export function generateRandomPassword(length: number = 12): string {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%&*';
  let password = '';
  for (let i = 0; i < length; i++) {
    password += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return password;
}

// Cities adapter
export const supabaseCitiesAdapter = {
  async listCities(): Promise<City[]> {
    const { data, error } = await supabase
      .from('cities')
      .select('*')
      .order('name', { ascending: true });
    
    if (error) throw error;
    
    return data.map(city => ({
      id: city.id,
      name: city.name,
      visible: city.visible
    }));
  },
  
  async addCity(name: string): Promise<void> {
    const { error } = await supabase
      .from('cities')
      .insert({ name, visible: true });
    
    if (error) throw error;
  },
  
  async toggleCity(id: ID): Promise<void> {
    const { data: city, error: fetchError } = await supabase
      .from('cities')
      .select('visible')
      .eq('id', id)
      .single();
      
    if (fetchError) throw fetchError;
    
    const { error } = await supabase
      .from('cities')
      .update({ visible: !city.visible })
      .eq('id', id);
      
    if (error) throw error;
  },
  
  async updateCity(id: ID, name: string): Promise<void> {
    const { error } = await supabase
      .from('cities')
      .update({ name })
      .eq('id', id);
      
    if (error) throw error;
  },
  
  async deleteCity(id: ID): Promise<void> {
    const { error } = await supabase
      .from('cities')
      .delete()
      .eq('id', id);
      
    if (error) throw error;
  },
};

// Categories adapter
export const supabaseCategoriesAdapter = {
  async listCategories(): Promise<Category[]> {
    const { data, error } = await supabase
      .from('categories')
      .select('*')
      .order('name', { ascending: true });
    
    if (error) throw error;
    
    return data.map(cat => ({
      id: cat.id,
      name: cat.name,
      imageUrl: cat.image_url
    }));
  },
  
  async addCategory(name: string, imageUrl?: string): Promise<void> {
    const { error } = await supabase
      .from('categories')
      .insert({ name, image_url: imageUrl, active: true });
    
    if (error) throw error;
  },
  
  async updateCategory(id: ID, name: string, imageUrl?: string): Promise<void> {
    const updateData: any = { name };
    if (imageUrl !== undefined) {
      updateData.image_url = imageUrl;
    }
    
    const { error } = await supabase
      .from('categories')
      .update(updateData)
      .eq('id', id);
      
    if (error) throw error;
  },
  
  async deleteCategory(id: ID): Promise<void> {
    const { error } = await supabase
      .from('categories')
      .delete()
      .eq('id', id);
      
    if (error) throw error;
  },
};

// Plans adapter
export const supabasePlansAdapter = {
  async listPlans(): Promise<Plan[]> {
    const { data, error } = await supabase
      .from('plans')
      .select('*')
      .order('name', { ascending: true });
    
    if (error) throw error;
    
    return data.map(plan => ({
      id: plan.id,
      name: plan.name,
      price: plan.price,
      period: plan.period as PlanPeriod,
      trialDays: plan.trial_days,
      bookingLimit: plan.booking_limit,
      extras: plan.extras || []
    }));
  },
  
  async upsertPlan(plan: Partial<Plan> & { name: string; price: number; period: PlanPeriod; trialDays: number; bookingLimit: number; extras?: string[]; id?: ID }): Promise<void> {
    const planData = {
      name: plan.name,
      price: plan.price,
      period: plan.period,
      trial_days: plan.trialDays,
      booking_limit: plan.bookingLimit,
      extras: plan.extras || []
    };
    
    if (plan.id) {
      const { error } = await supabase
        .from('plans')
        .update(planData)
        .eq('id', plan.id);
      if (error) throw error;
    } else {
      const { error } = await supabase
        .from('plans')
        .insert(planData);
      if (error) throw error;
    }
  },
  
  async deletePlan(id: ID): Promise<void> {
    const { error } = await supabase
      .from('plans')
      .delete()
      .eq('id', id);
    if (error) throw error;
  },
};

// Establishments adapter
export const supabaseEstablishmentsAdapter = {
  async listEstablishments(): Promise<Establishment[]> {
    const { data, error } = await supabase
      .from('establishments')
      .select(`
        *,
        establishment_categories (
          category_id,
          is_primary,
          categories (id, name)
        )
      `)
      .order('name', { ascending: true });
    
    if (error) throw error;
    
    return data.map(est => {
      const primaryCategory = est.establishment_categories?.find((ec: any) => ec.is_primary);
      return {
        id: est.id,
        name: est.name,
        status: (est.status === 'active' ? 'active' : 'inactive') as EstablishmentStatus,
        cityId: est.city,
        categoryId: primaryCategory?.category_id || '',
        logo: est.logo_url || '',
        planId: '', // Will be filled later when we have plan relationships
        workingHours: { start: '00:00', end: '00:00' },
        lastAccessAt: new Date(est.updated_at).getTime()
      };
    });
  },
  
  async upsertEstablishment(establishment: Partial<Establishment> & { 
    name: string; 
    cityId: string; 
    categoryId: string;
    categoriesIds?: string[];
    status?: EstablishmentStatus;
    logo?: string;
    planId?: string;
    id?: string;
    address?: string;
    state?: string;
    description?: string;
    workingHours?: { start: string; end: string };
  }): Promise<Establishment | void> {
    const dbStatus = establishment.status === 'inactive' ? 'blocked' : 'active';
    
    const establishmentData = {
      name: establishment.name,
      status: dbStatus as "active" | "overdue" | "blocked",
      address: establishment.address || 'Endereço não informado',
      city: establishment.cityId,
      state: establishment.state || 'SP',
      logo_url: establishment.logo || null,
      description: establishment.description || ''
    };
    
    let estId = establishment.id;
    
    if (establishment.id) {
      const { data, error } = await supabase
        .from('establishments')
        .update(establishmentData)
        .eq('id', establishment.id)
        .select()
        .single();
      if (error) throw error;
      estId = data.id;
    } else {
      const { data, error } = await supabase
        .from('establishments')
        .insert(establishmentData)
        .select()
        .single();
      if (error) throw error;
      estId = data.id;
    }
    
    // Handle categories - remove existing and add new ones
    if (estId && (establishment.categoryId || establishment.categoriesIds)) {
      await supabase
        .from('establishment_categories')
        .delete()
        .eq('establishment_id', estId);
      
      const categoriesToAdd = establishment.categoriesIds || [establishment.categoryId];
      const categoryInserts = categoriesToAdd.map((catId, index) => ({
        establishment_id: estId,
        category_id: catId,
        is_primary: index === 0 || catId === establishment.categoryId
      }));
      
      const { error: catError } = await supabase
        .from('establishment_categories')
        .insert(categoryInserts);
      
      if (catError) throw catError;
    }
    
    return {
      id: estId!,
      name: establishment.name,
      status: establishment.status || 'active',
      cityId: establishment.cityId,
      categoryId: establishment.categoryId,
      logo: establishment.logo,
      planId: establishment.planId,
      workingHours: establishment.workingHours,
      lastAccessAt: Date.now()
    };
  },
  
  async toggleEstablishment(id: ID): Promise<void> {
    const { data: establishment, error: fetchError } = await supabase
      .from('establishments')
      .select('status')
      .eq('id', id)
      .single();
      
    if (fetchError) throw fetchError;
    
    const newStatus = establishment.status === 'active' ? 'blocked' : 'active';
    
    const { error } = await supabase
      .from('establishments')
      .update({ status: newStatus })
      .eq('id', id);
      
    if (error) throw error;
  },
  
  async deleteEstablishment(id: ID): Promise<void> {
    const { error } = await supabase
      .from('establishments')
      .delete()
      .eq('id', id);
      
    if (error) throw error;
  },
};

// Users adapter
export const supabaseUsersAdapter = {
  async listUsers(): Promise<User[]> {
    const { data, error } = await supabase
      .from('profiles')
      .select('*')
      .order('full_name', { ascending: true });
    
    if (error) throw error;
    
    return data.map(profile => ({
      id: profile.id,
      name: profile.full_name,
      email: profile.email,
      role: profile.role as UserRole,
      establishmentId: profile.establishment_id || '',
      status: 'active' as UserStatus // Default to active
    }));
  },
  
  async upsertUser(payload: Partial<User> & { name: string; email: string; role: UserRole; establishmentId: ID; status?: UserStatus; id?: ID }): Promise<void> {
    if (payload.id) {
      const { error } = await supabase
        .from('profiles')
        .update({
          full_name: payload.name,
          email: payload.email,
          role: payload.role,
          establishment_id: payload.establishmentId
        })
        .eq('id', payload.id);
      if (error) throw error;
    } else {
      // For new users, we'll handle this through the create-user edge function
      throw new Error('Use createUserWithCredentials for new users');
    }
  },
  
  async toggleUserBlock(id: ID): Promise<void> {
    // This would need additional implementation for user blocking
    console.log('Toggle user block not implemented yet for:', id);
  },
  
  async deleteUser(id: ID): Promise<void> {
    // First deactivate/delete any professional records associated with this user
    const { error: profError } = await supabase
      .from('professionals')
      .delete()
      .eq('user_id', id);
    
    if (profError) {
      console.warn('Error deleting professionals for user:', profError);
      // Continue with profile deletion even if professional deletion fails
    }

    // Then delete from profiles
    const { error } = await supabase
      .from('profiles')
      .delete()
      .eq('id', id);
    if (error) throw error;

    // Also delete from auth.users to completely remove the user
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (session) {
        await supabase.functions.invoke('delete-user', {
          body: { user_id: id },
          headers: {
            Authorization: `Bearer ${session.access_token}`
          }
        });
      }
    } catch (authError) {
      console.warn('Warning: Could not delete from auth.users:', authError);
      // Don't throw here since the main profile deletion succeeded
    }
  },
};

// Metrics adapter
export const supabaseMetricsAdapter = {
  async metrics(): Promise<any> {
    const { data, error } = await supabase.rpc('get_super_admin_metrics');
    if (error) throw error;
    return data;
  },
};

// CMS adapter for editable homepage content
export const supabaseCMSAdapter = {
  async getSettings(): Promise<Record<string, string>> {
    const { data, error } = await supabase
      .from('cms_settings')
      .select('key, value');
    
    if (error) throw error;
    
    const settings: Record<string, string> = {};
    data.forEach(item => {
      settings[item.key] = item.value;
    });
    
    return settings;
  },
  
  async updateSetting(key: string, value: string): Promise<void> {
    const { error } = await supabase
      .from('cms_settings')
      .upsert({ key, value })
      .eq('key', key);
    
    if (error) throw error;
  },
  
  async updateMultipleSettings(settings: Record<string, string>): Promise<void> {
    const updates = Object.entries(settings).map(([key, value]) => ({ key, value }));
    
    const { error } = await supabase
      .from('cms_settings')
      .upsert(updates);
    
    if (error) throw error;
  },
};

// Reviews adapter
export const supabaseReviewsAdapter = {
  async listReviews(): Promise<Review[]> {
    const { data, error } = await supabase
      .from('reviews')
      .select('*')
      .order('created_at', { ascending: false });
    
    if (error) throw error;
    
    return data.map(review => ({
      id: review.id,
      establishmentId: review.establishment_id,
      userName: 'Cliente anônimo',
      rating: review.professional_rating,
      comment: review.comment,
      date: review.created_at
    }));
  },
  
  async deleteReview(id: ID): Promise<void> {
    const { error } = await supabase
      .from('reviews')
      .delete()
      .eq('id', id);
    if (error) throw error;
  },
};

// Bookings adapter
export const supabaseBookingsAdapter = {
  async listBookings(): Promise<Booking[]> {
    const { data, error } = await supabase
      .from('appointments')
      .select(`
        *,
        establishments (name),
        services (name),
        client_profiles:profiles!appointments_client_id_fkey (full_name, email)
      `)
      .order('created_at', { ascending: false });
    
    if (error) throw error;
    
    return data.map(appointment => ({
      id: appointment.id,
      establishmentId: appointment.establishment_id,
      establishmentName: appointment.establishments?.name || 'Estabelecimento',
      clientName: appointment.client_profiles?.full_name || appointment.client_name || 'Cliente anônimo',
      service: appointment.services?.name || 'Serviço',
      date: appointment.appointment_date,
      time: appointment.start_time,
      status: appointment.status,
      userEmail: appointment.client_profiles?.email || appointment.client_phone || '',
      price: appointment.total_price || 0
    }));
  },
};