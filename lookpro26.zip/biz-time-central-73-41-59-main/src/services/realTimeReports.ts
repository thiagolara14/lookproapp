import { supabase } from "@/integrations/supabase/client";
import { format, startOfMonth, endOfMonth, subDays, eachDayOfInterval } from "date-fns";

export interface RevenueMetrics {
  totalRevenue: number;
  totalAppointments: number;
  uniqueClients: number;
  averageTicket: number;
  growthRate: number;
}

export interface ServiceStats {
  serviceId: string;
  serviceName: string;
  appointmentCount: number;
  revenue: number;
  averagePrice: number;
}

export interface ProfessionalStats {
  professionalId: string;
  professionalName: string;
  appointmentCount: number;
  revenue: number;
  averageTicket: number;
}

export interface DailyRevenue {
  date: string;
  revenue: number;
  appointments: number;
}

export interface HourlyStats {
  hour: string;
  appointmentCount: number;
}

/**
 * Get comprehensive revenue metrics for an establishment
 */
export async function getEstablishmentRevenueMetrics(
  establishmentId: string,
  startDate?: Date,
  endDate?: Date
): Promise<RevenueMetrics> {
  const start = startDate || startOfMonth(new Date());
  const end = endDate || endOfMonth(new Date());
  
  const { data: appointments, error } = await supabase
    .from('appointments')
    .select(`
      id,
      total_price,
      status,
      appointment_date,
      client_id,
      client_phone,
      client_name
    `)
    .eq('establishment_id', establishmentId)
    .gte('appointment_date', format(start, 'yyyy-MM-dd'))
    .lte('appointment_date', format(end, 'yyyy-MM-dd'));

  if (error) throw error;

  const completedAppointments = appointments?.filter(apt => apt.status === 'completed') || [];
  const totalRevenue = completedAppointments.reduce((sum, apt) => sum + Number(apt.total_price || 0), 0);
  const totalAppointments = appointments?.length || 0;
  
  // Calculate unique clients (by phone or client_id)
  const uniqueClientsSet = new Set();
  appointments?.forEach(apt => {
    const clientKey = apt.client_id || apt.client_phone || apt.client_name;
    if (clientKey) uniqueClientsSet.add(clientKey);
  });
  
  const averageTicket = completedAppointments.length > 0 ? totalRevenue / completedAppointments.length : 0;
  
  // Calculate growth rate (compared to previous period)
  const periodLength = Math.ceil((end.getTime() - start.getTime()) / (1000 * 60 * 60 * 24));
  const previousStart = new Date(start);
  previousStart.setDate(start.getDate() - periodLength);
  const previousEnd = new Date(start);
  previousEnd.setDate(start.getDate() - 1);
  
  const { data: previousAppointments } = await supabase
    .from('appointments')
    .select('total_price, status')
    .eq('establishment_id', establishmentId)
    .eq('status', 'completed')
    .gte('appointment_date', format(previousStart, 'yyyy-MM-dd'))
    .lte('appointment_date', format(previousEnd, 'yyyy-MM-dd'));
  
  const previousRevenue = previousAppointments?.reduce((sum, apt) => sum + Number(apt.total_price || 0), 0) || 0;
  const growthRate = previousRevenue > 0 ? ((totalRevenue - previousRevenue) / previousRevenue) * 100 : 0;

  return {
    totalRevenue,
    totalAppointments,
    uniqueClients: uniqueClientsSet.size,
    averageTicket,
    growthRate
  };
}

/**
 * Get service performance statistics
 */
export async function getServiceStatistics(
  establishmentId: string,
  startDate?: Date,
  endDate?: Date
): Promise<ServiceStats[]> {
  const start = startDate || subDays(new Date(), 30);
  const end = endDate || new Date();
  
  const { data: appointments, error } = await supabase
    .from('appointments')
    .select(`
      service_id,
      total_price,
      status,
      services(name, price)
    `)
    .eq('establishment_id', establishmentId)
    .gte('appointment_date', format(start, 'yyyy-MM-dd'))
    .lte('appointment_date', format(end, 'yyyy-MM-dd'));

  if (error) throw error;

  // Group by service
  const serviceStats: Record<string, ServiceStats> = {};
  
  appointments?.forEach(apt => {
    const serviceId = apt.service_id;
    const serviceName = apt.services?.name || 'Serviço';
    
    if (!serviceStats[serviceId]) {
      serviceStats[serviceId] = {
        serviceId,
        serviceName,
        appointmentCount: 0,
        revenue: 0,
        averagePrice: 0
      };
    }
    
    serviceStats[serviceId].appointmentCount++;
    
    if (apt.status === 'completed') {
      serviceStats[serviceId].revenue += Number(apt.total_price || 0);
    }
  });
  
  // Calculate average prices
  Object.values(serviceStats).forEach(stats => {
    stats.averagePrice = stats.appointmentCount > 0 ? stats.revenue / stats.appointmentCount : 0;
  });
  
  return Object.values(serviceStats).sort((a, b) => b.appointmentCount - a.appointmentCount);
}

/**
 * Get professional performance statistics
 */
export async function getProfessionalStatistics(
  establishmentId: string,
  startDate?: Date,
  endDate?: Date
): Promise<ProfessionalStats[]> {
  const start = startDate || subDays(new Date(), 30);
  const end = endDate || new Date();
  
  const { data: appointments, error } = await supabase
    .from('appointments')
    .select(`
      professional_id,
      total_price,
      status,
      professionals(profiles!professionals_user_id_fkey(full_name))
    `)
    .eq('establishment_id', establishmentId)
    .gte('appointment_date', format(start, 'yyyy-MM-dd'))
    .lte('appointment_date', format(end, 'yyyy-MM-dd'));

  if (error) throw error;

  // Group by professional
  const professionalStats: Record<string, ProfessionalStats> = {};
  
  appointments?.forEach(apt => {
    const professionalId = apt.professional_id;
    let professionalName = 'Profissional';
    
    if (apt.professionals?.profiles) {
      if (Array.isArray(apt.professionals.profiles) && apt.professionals.profiles[0]) {
        professionalName = apt.professionals.profiles[0].full_name || 'Profissional';
      } else if (typeof apt.professionals.profiles === 'object' && 'full_name' in apt.professionals.profiles) {
        professionalName = (apt.professionals.profiles as any).full_name || 'Profissional';
      }
    }
    
    if (!professionalStats[professionalId]) {
      professionalStats[professionalId] = {
        professionalId,
        professionalName,
        appointmentCount: 0,
        revenue: 0,
        averageTicket: 0
      };
    }
    
    professionalStats[professionalId].appointmentCount++;
    
    if (apt.status === 'completed') {
      professionalStats[professionalId].revenue += Number(apt.total_price || 0);
    }
  });
  
  // Calculate average tickets
  Object.values(professionalStats).forEach(stats => {
    stats.averageTicket = stats.appointmentCount > 0 ? stats.revenue / stats.appointmentCount : 0;
  });
  
  return Object.values(professionalStats).sort((a, b) => b.appointmentCount - a.appointmentCount);
}

/**
 * Get daily revenue data for charts
 */
export async function getDailyRevenueData(
  establishmentId: string,
  startDate?: Date,
  endDate?: Date
): Promise<DailyRevenue[]> {
  const start = startDate || subDays(new Date(), 30);
  const end = endDate || new Date();
  
  const { data: appointments, error } = await supabase
    .from('appointments')
    .select('appointment_date, total_price, status')
    .eq('establishment_id', establishmentId)
    .gte('appointment_date', format(start, 'yyyy-MM-dd'))
    .lte('appointment_date', format(end, 'yyyy-MM-dd'));

  if (error) throw error;

  // Generate all days in the range
  const days = eachDayOfInterval({ start, end });
  
  return days.map(day => {
    const dayStr = format(day, 'yyyy-MM-dd');
    const dayAppointments = appointments?.filter(apt => apt.appointment_date === dayStr) || [];
    const completedAppointments = dayAppointments.filter(apt => apt.status === 'completed');
    
    return {
      date: format(day, 'dd/MM'),
      revenue: completedAppointments.reduce((sum, apt) => sum + Number(apt.total_price || 0), 0),
      appointments: dayAppointments.length
    };
  });
}

/**
 * Get hourly appointment distribution
 */
export async function getHourlyDistribution(
  establishmentId: string,
  startDate?: Date,
  endDate?: Date
): Promise<HourlyStats[]> {
  const start = startDate || subDays(new Date(), 30);
  const end = endDate || new Date();
  
  const { data: appointments, error } = await supabase
    .from('appointments')
    .select('start_time')
    .eq('establishment_id', establishmentId)
    .gte('appointment_date', format(start, 'yyyy-MM-dd'))
    .lte('appointment_date', format(end, 'yyyy-MM-dd'));

  if (error) throw error;

  // Group by hour
  const hourlyStats: Record<string, number> = {};
  
  appointments?.forEach(apt => {
    const hour = apt.start_time?.split(':')[0] + ':00';
    hourlyStats[hour] = (hourlyStats[hour] || 0) + 1;
  });
  
  return Object.entries(hourlyStats)
    .map(([hour, count]) => ({ hour, appointmentCount: count }))
    .sort((a, b) => a.hour.localeCompare(b.hour));
}