// @deprecated - This file is deprecated when using backend.provider = "supabase"
// Use @/context/AuthContext instead for Supabase authentication

import { backend } from "@/lib/config";

export type AuthRole = "super" | "admin" | "pro";
export type AuthUser = {
  id: string;
  email: string;
  role?: AuthRole;
  establishmentId?: string;
};

export interface AuthAdapter {
  signIn(email: string, password: string): Promise<AuthUser>;
  signOut(): Promise<void>;
  currentUser(): Promise<AuthUser | null>;
  // For Super Admin provisioning
  createUser(email: string, password: string, meta?: { role?: AuthRole; establishmentId?: string; name?: string }): Promise<AuthUser>;
}

const KEY = "lp_auth_user";

export const inMemoryAuthAdapter: AuthAdapter = {
  async signIn(email, _password) {
    const existing = JSON.parse(localStorage.getItem(KEY) || "null");
    const user: AuthUser = existing ?? { id: crypto.randomUUID(), email };
    localStorage.setItem(KEY, JSON.stringify(user));
    return user;
  },
  async signOut() {
    localStorage.removeItem(KEY);
  },
  async currentUser() {
    const raw = localStorage.getItem(KEY);
    return raw ? (JSON.parse(raw) as AuthUser) : null;
  },
  async createUser(email, _password, meta) {
    const user: AuthUser = { id: crypto.randomUUID(), email, role: meta?.role, establishmentId: meta?.establishmentId };
    // no-op persistence; in real Supabase, use edge functions or RPC calls
    return user;
  },
};

export const supabaseAuthAdapter: AuthAdapter = {
  async signIn(email: string, password: string): Promise<AuthUser> {
    const { supabase } = await import("@/integrations/supabase/client");
    const { data, error } = await supabase.auth.signInWithPassword({ email, password });
    
    if (error) throw error;
    if (!data.user) throw new Error("Authentication failed");
    
    return {
      id: data.user.id,
      email: data.user.email!,
      role: undefined, // Will be fetched separately
      establishmentId: undefined,
    };
  },

  async signOut(): Promise<void> {
    const { supabase } = await import("@/integrations/supabase/client");
    await supabase.auth.signOut();
  },

  async currentUser(): Promise<AuthUser | null> {
    const { supabase } = await import("@/integrations/supabase/client");
    const { data } = await supabase.auth.getUser();
    
    if (!data.user) return null;
    
    return {
      id: data.user.id,
      email: data.user.email!,
      role: undefined, // Will be fetched separately
      establishmentId: undefined,
    };
  },

  async createUser(email: string, password: string, meta?: { role?: AuthRole; establishmentId?: string; name?: string }): Promise<AuthUser> {
    const { supabase } = await import("@/integrations/supabase/client");
    const { data, error } = await supabase.auth.signUp({ 
      email, 
      password,
      options: {
        data: {
          role: meta?.role,
          establishment_id: meta?.establishmentId,
          full_name: meta?.name,
        }
      }
    });
    
    if (error) throw error;
    if (!data.user) throw new Error("User creation failed");
    
    return {
      id: data.user.id,
      email: data.user.email!,
      role: meta?.role,
      establishmentId: meta?.establishmentId,
    };
  },
};

export function getAuthAdapter(): AuthAdapter {
  return backend.provider === "supabase" ? supabaseAuthAdapter : inMemoryAuthAdapter;
}
