// Service to sync all data with Supabase
import { supabase } from "@/integrations/supabase/client";

export interface EstablishmentData {
  id: string;
  name: string;
  address: string;
  city: string;
  state: string;
  phone?: string;
  email?: string;
  website?: string;
  description?: string;
  logo_url?: string;
  cover_image_url?: string;
  category_id?: string;
  status: 'active' | 'blocked' | 'overdue';
}

export interface ServiceData {
  id?: string;
  establishment_id: string;
  name: string;
  description?: string;
  price: number;
  duration_minutes: number;
  image_url?: string;
  is_active?: boolean;
}

export interface ProfessionalData {
  id?: string;
  user_id: string;
  establishment_id: string;
  specialties?: string[];
  bio?: string;
  avatar_url?: string;
  active?: boolean;
}

export interface NotificationData {
  id?: string;
  professional_id: string;
  title: string;
  message: string;
  type?: string;
  data?: any;
  read?: boolean;
  created_at?: string;
}

export interface BlockedPeriodData {
  id?: string;
  professional_id: string;
  start_date: string;
  end_date: string;
  start_time?: string;
  end_time?: string;
  is_all_day?: boolean;
  reason?: string;
  type?: 'personal' | 'vacation' | 'sick_leave' | 'maintenance' | 'other';
}

// Establishments
export async function getEstablishment(id: string): Promise<EstablishmentData | null> {
  const { data, error } = await supabase
    .from('establishments')
    .select('*')
    .eq('id', id)
    .single();
  
  if (error || !data) return null;
  return data;
}

export async function updateEstablishment(id: string, data: Partial<EstablishmentData>): Promise<boolean> {
  const { error } = await supabase
    .from('establishments')
    .update(data)
    .eq('id', id);
  
  return !error;
}

// Services
export async function getServicesByEstablishment(establishmentId: string): Promise<ServiceData[]> {
  const { data, error } = await supabase
    .from('services')
    .select('*')
    .eq('establishment_id', establishmentId)
    .eq('is_active', true)
    .order('name');
  
  if (error) return [];
  return data || [];
}

export async function createService(serviceData: ServiceData): Promise<ServiceData | null> {
  const { data, error } = await supabase
    .from('services')
    .insert(serviceData)
    .select()
    .single();
  
  if (error) return null;
  return data;
}

export async function updateService(id: string, serviceData: Partial<ServiceData>): Promise<boolean> {
  const { error } = await supabase
    .from('services')
    .update(serviceData)
    .eq('id', id);
  
  return !error;
}

export async function deleteService(id: string): Promise<boolean> {
  const { error } = await supabase
    .from('services')
    .update({ is_active: false })
    .eq('id', id);
  
  return !error;
}

// Professionals
export async function getProfessionalsByEstablishment(establishmentId: string): Promise<ProfessionalData[]> {
  const { data, error } = await supabase
    .from('professionals')
    .select(`
      *,
      profiles!inner(full_name, email)
    `)
    .eq('establishment_id', establishmentId)
    .eq('active', true);
  
  if (error) return [];
  return data || [];
}

export async function createProfessional(professionalData: ProfessionalData): Promise<ProfessionalData | null> {
  const { data, error } = await supabase
    .from('professionals')
    .insert(professionalData)
    .select()
    .single();
  
  if (error) return null;
  return data;
}

export async function updateProfessional(id: string, professionalData: Partial<ProfessionalData>): Promise<boolean> {
  const { error } = await supabase
    .from('professionals')
    .update(professionalData)
    .eq('id', id);
  
  return !error;
}

// Notifications
export async function getNotificationsByProfessional(professionalId: string): Promise<NotificationData[]> {
  const { data, error } = await supabase
    .from('notifications')
    .select('*')
    .eq('professional_id', professionalId)
    .order('created_at', { ascending: false });
  
  if (error) return [];
  return data || [];
}

export async function createNotification(notificationData: NotificationData): Promise<boolean> {
  const { error } = await supabase
    .from('notifications')
    .insert(notificationData);
  
  return !error;
}

export async function markNotificationAsRead(id: string): Promise<boolean> {
  const { error } = await supabase
    .from('notifications')
    .update({ read: true })
    .eq('id', id);
  
  return !error;
}

// Blocked Periods
export async function getBlockedPeriodsByProfessional(professionalId: string): Promise<BlockedPeriodData[]> {
  const { data, error } = await supabase
    .from('blocked_periods')
    .select('*')
    .eq('professional_id', professionalId)
    .order('start_date');
  
  if (error) return [];
  return data || [];
}

export async function createBlockedPeriod(periodData: BlockedPeriodData): Promise<boolean> {
  const { error } = await supabase
    .from('blocked_periods')
    .insert(periodData as any);
  
  return !error;
}

export async function updateBlockedPeriod(id: string, periodData: Partial<BlockedPeriodData>): Promise<boolean> {
  const { error } = await supabase
    .from('blocked_periods')
    .update(periodData as any)
    .eq('id', id);
  
  return !error;
}

export async function deleteBlockedPeriod(id: string): Promise<boolean> {
  const { error } = await supabase
    .from('blocked_periods')
    .delete()
    .eq('id', id);
  
  return !error;
}

// Helper function to get current user's establishment ID
export async function getCurrentUserEstablishmentId(): Promise<string | null> {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return null;
  
  const { data, error } = await supabase
    .from('profiles')
    .select('establishment_id')
    .eq('user_id', user.id)
    .single();
  
  if (error || !data) return null;
  return data.establishment_id;
}

// Helper function to get current user's professional profile
export async function getCurrentUserProfessionalId(): Promise<string | null> {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return null;
  
  const { data, error } = await supabase
    .from('professionals')
    .select('id')
    .eq('user_id', user.id)
    .single();
  
  if (error || !data) return null;
  return data.id;
}

// Marcar todas as notificações como lidas
export async function markAllNotificationsAsRead(userId: string): Promise<boolean> {
  const { data: pro } = await supabase
    .from('professionals')
    .select('id')
    .eq('user_id', userId)
    .maybeSingle();
    
  if (!pro?.id) return false;
  
  const { error } = await supabase
    .from('notifications')
    .update({ read: true })
    .eq('professional_id', pro.id);
    
  return !error;
}

// Excluir notificação
export async function deleteNotification(id: string): Promise<boolean> {
  const { error } = await supabase
    .from('notifications')
    .delete()
    .eq('id', id);
    
  return !error;
}

// Listar notificações do usuário/profissional
export async function listNotifications(userId: string): Promise<NotificationData[]> {
  const { data: pro } = await supabase
    .from('professionals')
    .select('id')
    .eq('user_id', userId)
    .maybeSingle();

  const { data, error } = await supabase
    .from('notifications')
    .select('*')
    .eq('professional_id', pro?.id || '00000000-0000-0000-0000-000000000000')
    .order('created_at', { ascending: false });

  if (error) return [];
  return data || [];
}