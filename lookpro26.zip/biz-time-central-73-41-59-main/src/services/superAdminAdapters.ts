// Complete Supabase adapters for Super Admin operations
import { supabase } from "@/integrations/supabase/client";
import type { 
  City, Category, Plan, Establishment, User, Booking, Review, 
  ID, EstablishmentStatus, UserRole, UserStatus, PlanPeriod 
} from "@/lib/superStore";

// Cities adapter
export interface CitiesAdapter {
  listCities(): Promise<City[]>;
  addCity(name: string): Promise<void>;
  toggleCity(id: ID): Promise<void>;
  updateCity(id: ID, name: string): Promise<void>;
  deleteCity(id: ID): Promise<void>;
}

export const citiesAdapter: CitiesAdapter = {
  async listCities() {
    const { data, error } = await supabase
      .from('cities')
      .select('*')
      .order('name', { ascending: true });
    
    if (error) throw error;
    
    return data.map(city => ({
      id: city.id,
      name: city.name,
      visible: city.visible
    }));
  },
  
  async addCity(name: string) {
    const { error } = await supabase
      .from('cities')
      .insert({ name, visible: true });
    
    if (error) throw error;
  },
  
  async toggleCity(id: ID) {
    const { data: city, error: fetchError } = await supabase
      .from('cities')
      .select('visible')
      .eq('id', id)
      .single();
      
    if (fetchError) throw fetchError;
    
    const { error } = await supabase
      .from('cities')
      .update({ visible: !city.visible })
      .eq('id', id);
      
    if (error) throw error;
  },
  
  async updateCity(id: ID, name: string) {
    const { error } = await supabase
      .from('cities')
      .update({ name })
      .eq('id', id);
      
    if (error) throw error;
  },
  
  async deleteCity(id: ID) {
    const { error } = await supabase
      .from('cities')
      .delete()
      .eq('id', id);
      
    if (error) throw error;
  },
};

// Categories adapter
export interface CategoriesAdapter {
  listCategories(): Promise<Category[]>;
  addCategory(name: string, imageUrl?: string): Promise<void>;
  updateCategory(id: ID, name: string, imageUrl?: string): Promise<void>;
  deleteCategory(id: ID): Promise<void>;
}

export const categoriesAdapter: CategoriesAdapter = {
  async listCategories() {
    const { data, error } = await supabase
      .from('categories')
      .select('*')
      .order('name', { ascending: true });
    
    if (error) throw error;
    
    return data.map(cat => ({
      id: cat.id,
      name: cat.name,
      imageUrl: cat.image_url
    }));
  },
  
  async addCategory(name: string, imageUrl?: string) {
    const { error } = await supabase
      .from('categories')
      .insert({ name, image_url: imageUrl, active: true });
    
    if (error) throw error;
  },
  
  async updateCategory(id: ID, name: string, imageUrl?: string) {
    const updateData: any = { name };
    if (imageUrl !== undefined) {
      updateData.image_url = imageUrl;
    }
    
    const { error } = await supabase
      .from('categories')
      .update(updateData)
      .eq('id', id);
      
    if (error) throw error;
  },
  
  async deleteCategory(id: ID) {
    const { error } = await supabase
      .from('categories')
      .delete()
      .eq('id', id);
      
    if (error) throw error;
  },
};

// Plans adapter
export interface PlansAdapter {
  listPlans(): Promise<Plan[]>;
  upsertPlan(plan: Partial<Plan> & { name: string; price: number; period: PlanPeriod; trialDays: number; bookingLimit: number; extras?: string[]; id?: ID }): Promise<void>;
  deletePlan(id: ID): Promise<void>;
}

export const plansAdapter: PlansAdapter = {
  async listPlans() {
    const { data, error } = await supabase
      .from('plans')
      .select('*')
      .order('name', { ascending: true });
    
    if (error) throw error;
    
    return data.map(plan => ({
      id: plan.id,
      name: plan.name,
      price: Number(plan.price),
      period: plan.period as PlanPeriod,
      trialDays: plan.trial_days,
      bookingLimit: plan.booking_limit,
      extras: plan.extras || []
    }));
  },
  
  async upsertPlan(plan) {
    const planData = {
      name: plan.name,
      price: plan.price,
      period: plan.period,
      trial_days: plan.trialDays,
      booking_limit: plan.bookingLimit,
      extras: plan.extras || [],
      active: true
    };
    
    if (plan.id) {
      const { error } = await supabase
        .from('plans')
        .update(planData)
        .eq('id', plan.id);
      if (error) throw error;
    } else {
      const { error } = await supabase
        .from('plans')
        .insert(planData);
      if (error) throw error;
    }
  },
  
  async deletePlan(id: ID) {
    const { error } = await supabase
      .from('plans')
      .delete()
      .eq('id', id);
      
    if (error) throw error;
  },
};

// Establishments adapter
export interface EstablishmentsAdapter {
  listEstablishments(): Promise<Establishment[]>;
  upsertEstablishment(establishment: Partial<Establishment> & { 
    name: string; 
    cityId: string; 
    categoryId: string;
    categoriesIds?: string[];
    status?: EstablishmentStatus;
    logo?: string;
    planId?: string;
    id?: string;
    address?: string;
    state?: string;
    description?: string;
    workingHours?: { start: string; end: string };
  }): Promise<Establishment>;
  toggleEstablishment(id: ID): Promise<void>;
  deleteEstablishment(id: ID): Promise<void>;
}

export const establishmentsAdapter: EstablishmentsAdapter = {
  async listEstablishments() {
    const { data, error } = await supabase
      .from('establishments')
      .select(`
        *,
        establishment_categories (
          category_id,
          is_primary,
          categories (id, name)
        )
      `)
      .order('name', { ascending: true });
    
    if (error) throw error;
    
    // Buscar todas as cidades para fazer o mapeamento nome -> ID
    const { data: cities, error: citiesError } = await supabase
      .from('cities')
      .select('id, name');
    
    const cityMap = new Map();
    if (!citiesError && cities) {
      cities.forEach(city => cityMap.set(city.name, city.id));
    }
    
    return data.map(est => {
      const primaryCategory = est.establishment_categories?.find((ec: any) => ec.is_primary);
      return {
        id: est.id,
        name: est.name,
        status: (est.status === 'active' ? 'active' : 'inactive') as EstablishmentStatus,
        cityId: cityMap.get(est.city) || est.city, // Buscar ID pelo nome da cidade
        categoryId: primaryCategory?.category_id || '',
        logo: est.logo_url || '',
        planId: '', // Will be filled later when we have plan relationships
        workingHours: { start: '00:00', end: '00:00' },
        lastAccessAt: new Date(est.updated_at).getTime()
      };
    });
  },
  
  async upsertEstablishment(establishment) {
    const dbStatus = establishment.status === 'inactive' ? 'blocked' : 'active';
    
    // Buscar o nome da cidade pelo ID
    let cityName = establishment.cityId;
    if (establishment.cityId) {
      const { data: cityData, error: cityError } = await supabase
        .from('cities')
        .select('name')
        .eq('id', establishment.cityId)
        .maybeSingle();
      
      if (!cityError && cityData) {
        cityName = cityData.name;
      }
    }
    
    const establishmentData = {
      name: establishment.name,
      status: dbStatus as "active" | "overdue" | "blocked",
      address: establishment.address || 'Endereço não informado',
      city: cityName,
      state: establishment.state || 'SP',
      logo_url: establishment.logo || null,
      description: establishment.description || '',
      category_id: establishment.categoryId || null // Ensure category is set
    };
    
    let estId = establishment.id;
    
    if (establishment.id) {
      const { data, error } = await supabase
        .from('establishments')
        .update(establishmentData)
        .eq('id', establishment.id)
        .select()
        .single();
      if (error) throw error;
      estId = data.id;
    } else {
      const { data, error } = await supabase
        .from('establishments')
        .insert(establishmentData)
        .select()
        .single();
      if (error) throw error;
      estId = data.id;
    }
    
    // Handle categories - remove existing and add new ones
    if (estId && (establishment.categoryId || establishment.categoriesIds)) {
      await supabase
        .from('establishment_categories')
        .delete()
        .eq('establishment_id', estId);
      
      const categoriesToAdd = establishment.categoriesIds?.length > 0 
        ? establishment.categoriesIds 
        : [establishment.categoryId].filter(Boolean);
      
      if (categoriesToAdd.length > 0) {
        const categoryInserts = categoriesToAdd.map((catId, index) => ({
          establishment_id: estId,
          category_id: catId,
          is_primary: index === 0 || catId === establishment.categoryId
        }));
        
        const { error: catError } = await supabase
          .from('establishment_categories')
          .insert(categoryInserts);
        
        if (catError) throw catError;
      }
    }
    
    return {
      id: estId!,
      name: establishment.name,
      status: establishment.status || 'active',
      cityId: establishment.cityId,
      categoryId: establishment.categoryId,
      logo: establishment.logo,
      planId: establishment.planId,
      workingHours: establishment.workingHours,
      lastAccessAt: Date.now()
    };
  },
  
  async toggleEstablishment(id: ID) {
    const { data: establishment, error: fetchError } = await supabase
      .from('establishments')
      .select('status')
      .eq('id', id)
      .single();
      
    if (fetchError) throw fetchError;
    
    const newStatus = establishment.status === 'active' ? 'blocked' : 'active';
    
    const { error } = await supabase
      .from('establishments')
      .update({ status: newStatus })
      .eq('id', id);
      
    if (error) throw error;
  },
  
  async deleteEstablishment(id: ID) {
    const { error } = await supabase
      .from('establishments')
      .delete()
      .eq('id', id);
      
    if (error) throw error;
  },
};

// Users adapter
export interface UsersAdapter {
  listUsers(): Promise<User[]>;
  upsertUser(payload: Partial<User> & { name: string; email: string; role: UserRole; establishmentId?: ID; status?: UserStatus; id?: ID }): Promise<void>;
  toggleUserBlock(id: ID): Promise<void>;
  deleteUser(id: ID): Promise<void>;
}

export const usersAdapter: UsersAdapter = {
  async listUsers() {
    const { data, error } = await supabase
      .from('profiles')
      .select('*')
      .order('full_name', { ascending: true });
    
    if (error) throw error;
    
    return data.map(profile => ({
      id: profile.id,
      name: profile.full_name,
      email: profile.email,
      role: profile.role as UserRole,
      establishmentId: profile.establishment_id || '',
      status: 'active' as UserStatus
    }));
  },
  
  async upsertUser(payload) {
    if (payload.id) {
      const { error } = await supabase
        .from('profiles')
        .update({
          full_name: payload.name,
          email: payload.email,
          role: payload.role,
          establishment_id: payload.establishmentId
        })
        .eq('id', payload.id);
      if (error) throw error;
    } else {
      throw new Error('Use createUserWithCredentials for new users');
    }
  },
  
  async toggleUserBlock(id: ID) {
    console.log('Toggle user block not implemented yet for:', id);
  },
  
  async deleteUser(id: ID) {
    const { error } = await supabase
      .from('profiles')
      .delete()
      .eq('id', id);
    if (error) throw error;
  },
};

// Reviews adapter
export interface ReviewsAdapter {
  listReviews(): Promise<Review[]>;
  deleteReview(id: ID): Promise<void>;
}

export const reviewsAdapter: ReviewsAdapter = {
  async listReviews() {
    const { data, error } = await supabase
      .from('reviews')
      .select('*')
      .order('created_at', { ascending: false });
    
    if (error) throw error;
    
    return data.map(review => ({
      id: review.id,
      establishmentId: review.establishment_id,
      userName: 'Cliente anônimo',
      rating: review.professional_rating,
      comment: review.comment,
      date: review.created_at
    }));
  },
  
  async deleteReview(id: ID) {
    const { error } = await supabase
      .from('reviews')
      .delete()
      .eq('id', id);
    if (error) throw error;
  },
};

// Bookings adapter
export interface BookingsAdapter {
  listBookings(): Promise<Booking[]>;
}

export const bookingsAdapter: BookingsAdapter = {
  async listBookings() {
    const { data, error } = await supabase
      .from('appointments')
      .select(`
        *,
        establishments (name),
        services (name),
        client_profiles:profiles!appointments_client_id_fkey (full_name, email)
      `)
      .order('created_at', { ascending: false });
    
    if (error) throw error;
    
    return data.map(appointment => ({
      id: appointment.id,
      establishmentId: appointment.establishment_id,
      establishmentName: appointment.establishments?.name || 'Estabelecimento',
      clientName: appointment.client_profiles?.full_name || appointment.client_name || 'Cliente anônimo',
      service: appointment.services?.name || 'Serviço',
      date: appointment.appointment_date,
      time: appointment.start_time,
      status: appointment.status,
      userEmail: appointment.client_profiles?.email || appointment.client_phone || '',
      price: appointment.total_price || 0
    }));
  },
};

// Metrics adapter
export interface MetricsAdapter {
  metrics(): Promise<any>;
}

export const metricsAdapter: MetricsAdapter = {
  async metrics() {
    const { data, error } = await supabase.rpc('get_super_admin_metrics');
    if (error) throw error;
    return data;
  },
};

// CMS adapter for editable homepage content
export interface CMSAdapter {
  getSettings(): Promise<Record<string, string>>;
  updateSetting(key: string, value: string): Promise<void>;
  updateMultipleSettings(settings: Record<string, string>): Promise<void>;
}

export const cmsAdapter: CMSAdapter = {
  async getSettings() {
    const { data, error } = await supabase
      .from('cms_settings')
      .select('key, value');
    
    if (error) throw error;
    
    const settings: Record<string, string> = {};
    data.forEach(item => {
      settings[item.key] = item.value;
    });
    
    return settings;
  },
  
  async updateSetting(key: string, value: string) {
    const { error } = await supabase
      .from('cms_settings')
      .upsert({ key, value })
      .eq('key', key);
    
    if (error) throw error;
  },
  
  async updateMultipleSettings(settings: Record<string, string>) {
    const updates = Object.entries(settings).map(([key, value]) => ({ key, value }));
    
    const { error } = await supabase
      .from('cms_settings')
      .upsert(updates);
    
    if (error) throw error;
  },
};

// Legacy exports for compatibility
export const getCitiesAdapter = () => citiesAdapter;
export const getCategoriesAdapter = () => categoriesAdapter;
export const getPlansAdapter = () => plansAdapter;
export const getEstablishmentsAdapter = () => establishmentsAdapter;
export const getUsersAdapter = () => usersAdapter;
export const getReviewsAdapter = () => reviewsAdapter;
export const getBookingsAdapter = () => bookingsAdapter;
export const getMetricsAdapter = () => metricsAdapter;
export const getCMSAdapter = () => cmsAdapter;