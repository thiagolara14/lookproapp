// Complete Supabase adapters for Admin operations
import { supabase } from "@/integrations/supabase/client";
import type { Appointment } from "@/types/appointments";

export interface AdminAdapter {
  listEstablishments(): Promise<any[]>;
  getEstablishmentById(id: string): Promise<any | null>;
  updateEstablishment(id: string, data: any): Promise<void>;
  upsertEstablishment(data: any): Promise<any>;
  toggleEstablishment(id: string): Promise<void>;
  deleteEstablishment(id: string): Promise<void>;
  listProfessionals(establishmentId: string): Promise<any[]>;
  createProfessional(data: any): Promise<any>;
  updateProfessional(id: string, data: any): Promise<void>;
  deleteProfessional(id: string): Promise<void>;
  listServices(establishmentId: string): Promise<any[]>;
  createService(data: any): Promise<any>;
  updateService(id: string, data: any): Promise<void>;
  deleteService(id: string): Promise<void>;
  listAppointments(establishmentId: string, opts?: any): Promise<Appointment[]>;
  updateAppointment(id: string, data: any): Promise<void>;
  listClients(establishmentId: string): Promise<any[]>;
  listUsers(): Promise<any[]>;
  upsertUser(data: any): Promise<any>;
  toggleUserBlock(id: string): Promise<void>;
  deleteUser(id: string): Promise<void>;
  getAppointmentMetrics(establishmentId: string): Promise<any>;
  getRevenue(establishmentId: string, period: string): Promise<number>;
}

export const adminAdapter: AdminAdapter = {
  async listEstablishments() {
    const { data, error } = await supabase
      .from('establishments')
      .select('*')
      .order('name', { ascending: true });
    
    if (error) throw error;
    return data;
  },

  async getEstablishmentById(id: string) {
    const { data, error } = await supabase
      .from('establishments')
      .select('*')
      .eq('id', id)
      .maybeSingle();
    
    if (error) throw error;
    return data;
  },

  async updateEstablishment(id: string, data: any) {
    const { error } = await supabase
      .from('establishments')
      .update(data)
      .eq('id', id);
    
    if (error) throw error;
  },

  async upsertEstablishment(data: any) {
    if (data.id) {
      const { data: result, error } = await supabase
        .from('establishments')
        .update(data)
        .eq('id', data.id)
        .select()
        .single();
      
      if (error) throw error;
      return result;
    } else {
      const { data: result, error } = await supabase
        .from('establishments')
        .insert(data)
        .select()
        .single();
      
      if (error) throw error;
      return result;
    }
  },

  async toggleEstablishment(id: string) {
    const { data: establishment, error: fetchError } = await supabase
      .from('establishments')
      .select('status')
      .eq('id', id)
      .single();
      
    if (fetchError) throw fetchError;
    
    const newStatus = establishment.status === 'active' ? 'blocked' : 'active';
    
    const { error } = await supabase
      .from('establishments')
      .update({ status: newStatus })
      .eq('id', id);
      
    if (error) throw error;
  },

  async deleteEstablishment(id: string) {
    const { error } = await supabase
      .from('establishments')
      .delete()
      .eq('id', id);
      
    if (error) throw error;
  },

  async listProfessionals(establishmentId: string) {
    console.log('AdminAdapter - listProfessionals called with establishmentId:', establishmentId);
    
    if (!establishmentId) {
      console.log('AdminAdapter - No establishmentId provided, returning empty array');
      return [];
    }
    
    // Buscar profissionais do estabelecimento
    const { data: pros, error: e1 } = await supabase
      .from('professionals')
      .select('id, user_id, establishment_id, avatar_url, bio, specialties, active, created_at')
      .eq('establishment_id', establishmentId)
      .order('created_at', { ascending: false });
    
    console.log('AdminAdapter - professionals query result:', { pros, error: e1 });
    if (e1) throw e1;

    if (!pros?.length) {
      console.log('AdminAdapter - No professionals found, returning empty array');
      return [];
    }

    // Buscar perfis correspondentes (nome/email)
    const userIds = pros.map(p => p.user_id);
    console.log('AdminAdapter - Looking for profiles with userIds:', userIds);
    
    const { data: profs, error: e2 } = await supabase
      .from('profiles')
      .select('user_id, full_name, email')
      .in('user_id', userIds);
    
    console.log('AdminAdapter - profiles query result:', { profs, error: e2 });
    if (e2) throw e2;

    const byUser = new Map((profs || []).map(p => [p.user_id, p]));
    console.log('AdminAdapter - profiles map:', byUser);

    const result = pros.map(p => ({
      id: p.id,
      name: byUser.get(p.user_id)?.full_name || 'Profissional',
      email: byUser.get(p.user_id)?.email || '',
      avatar: p.avatar_url,
      bio: p.bio,
      specialties: p.specialties || [],
      active: p.active
    }));
    
    console.log('AdminAdapter - final result:', result);
    return result;
  },

  async createProfessional(data: any) {
    const { data: result, error } = await supabase
      .from('professionals')
      .insert({
        establishment_id: data.establishmentId,
        user_id: data.userId,
        bio: data.bio,
        specialties: data.specialties,
        active: true
      })
      .select()
      .single();
    
    if (error) throw error;
    return result;
  },

  async updateProfessional(id: string, data: any) {
    const { error } = await supabase
      .from('professionals')
      .update({
        bio: data.bio,
        specialties: data.specialties,
        active: data.active
      })
      .eq('id', id);
    
    if (error) throw error;
  },

  async deleteProfessional(id: string) {
    // Soft delete: marcar profile como deletado em vez de hard delete
    const { data: professional, error: fetchError } = await supabase
      .from('professionals')
      .select('user_id')
      .eq('id', id)
      .single();
      
    if (fetchError) throw fetchError;
    if (!professional) throw new Error('Profissional não encontrado');

    // Marcar profile como deletado (soft delete)
    const { error: deleteError } = await supabase
      .from('profiles')
      .update({ deleted_at: new Date().toISOString() })
      .eq('user_id', professional.user_id);
      
    if (deleteError) throw deleteError;
  },

  async listServices(establishmentId: string) {
    const { data, error } = await supabase
      .from('services')
      .select('*')
      .eq('establishment_id', establishmentId)
      .order('name', { ascending: true });
    
    if (error) throw error;
    
    return data.map(service => ({
      id: service.id,
      name: service.name,
      description: service.description,
      price: Number(service.price),
      duration: service.duration_minutes,
      durationMin: service.duration_minutes,
      active: service.is_active,
      imageUrl: service.image_url
    }));
  },

  async createService(data: any) {
    const { data: result, error } = await supabase
      .from('services')
      .insert({
        establishment_id: data.establishmentId,
        name: data.name,
        description: data.description,
        price: data.price,
        duration_minutes: data.duration || data.durationMin,
        image_url: data.image,
        is_active: true
      })
      .select()
      .single();
    
    if (error) throw error;
    return result;
  },

  async updateService(id: string, data: any) {
    const { error } = await supabase
      .from('services')
      .update({
        name: data.name,
        description: data.description,
        price: data.price,
        duration_minutes: data.duration || data.durationMin,
        image_url: data.image,
        is_active: data.active !== undefined ? data.active : true
      })
      .eq('id', id);
    
    if (error) throw error;
  },

  async deleteService(id: string) {
    const { error } = await supabase
      .from('services')
      .delete()
      .eq('id', id);
      
    if (error) throw error;
  },

  async listAppointments(establishmentId: string, opts?: any) {
    let query = supabase
      .from('appointments')
      .select(`
        *,
        services (name),
        professionals:profiles!appointments_professional_id_fkey (full_name),
        clients:profiles!appointments_client_id_fkey (full_name)
      `)
      .eq('establishment_id', establishmentId);

    if (opts?.startDate) {
      query = query.gte('appointment_date', opts.startDate);
    }
    if (opts?.endDate) {
      query = query.lte('appointment_date', opts.endDate);
    }

    query = query.order('appointment_date', { ascending: false });

    const { data, error } = await query;
    
    if (error) throw error;
    
      return data.map(appointment => ({
        id: appointment.id,
        establishmentId: appointment.establishment_id,
        professionalId: appointment.professional_id,
        professionalName: (appointment.professionals as any)?.full_name || 'Profissional',
        clientId: appointment.client_id,
        clientName: (appointment.clients as any)?.full_name || appointment.client_name || 'Cliente',
        serviceId: appointment.service_id,
        serviceName: (appointment.services as any)?.name || 'Serviço',
        date: appointment.appointment_date,
        time: appointment.start_time,
        status: (() => {
          switch (appointment.status) {
            case 'scheduled': return 'pendente';
            case 'confirmed': return 'confirmado';
            case 'completed': return 'concluído';
            case 'cancelled': return 'cancelado';
            default: return 'pendente';
          }
        })(),
        notes: appointment.notes,
        price: Number(appointment.total_price),
        duration: 30, // Default duration
        createdAt: appointment.created_at,
        updatedAt: appointment.updated_at,
        reschedules: 0
      }));
  },

  async updateAppointment(id: string, data: any) {
    const updateData: any = {};
    
    if (data.status) {
      switch (data.status) {
        case 'pendente': updateData.status = 'scheduled'; break;
        case 'confirmado': updateData.status = 'confirmed'; break;
        case 'concluído': updateData.status = 'completed'; break;
        case 'cancelado': updateData.status = 'cancelled'; break;
        default: updateData.status = data.status;
      }
    }
    
    if (data.date) updateData.appointment_date = data.date;
    if (data.time) updateData.start_time = data.time;
    if (data.notes) updateData.notes = data.notes;
    
    const { error } = await supabase
      .from('appointments')
      .update(updateData)
      .eq('id', id);
    
    if (error) throw error;
  },

  async listClients(establishmentId: string) {
    const { data, error } = await supabase
      .from('appointments')
      .select(`
        client_id,
        client_name,
        client_phone,
        clients:profiles!appointments_client_id_fkey (full_name, email, phone)
      `)
      .eq('establishment_id', establishmentId);
    
    if (error) throw error;
    
    const uniqueClients = new Map();
    
    data.forEach(appointment => {
      const clientId = appointment.client_id || `phone_${appointment.client_phone}`;
      if (!uniqueClients.has(clientId)) {
        uniqueClients.set(clientId, {
          id: clientId,
          name: (appointment.clients as any)?.full_name || appointment.client_name || 'Cliente',
          email: (appointment.clients as any)?.email || '',
          phone: (appointment.clients as any)?.phone || appointment.client_phone || ''
        });
      }
    });
    
    return Array.from(uniqueClients.values());
  },

  async listUsers() {
    const { data, error } = await supabase
      .from('profiles')
      .select('*')
      .order('full_name', { ascending: true });
    
    if (error) throw error;
    
    return data.map(profile => ({
      id: profile.id,
      name: profile.full_name,
      email: profile.email,
      role: profile.role,
      establishmentId: profile.establishment_id
    }));
  },

  async upsertUser(data: any) {
    if (data.id) {
      const { data: result, error } = await supabase
        .from('profiles')
        .update({
          full_name: data.name,
          email: data.email,
          role: data.role,
          establishment_id: data.establishmentId
        })
        .eq('id', data.id)
        .select()
        .single();
      
      if (error) throw error;
      return result;
    } else {
      throw new Error('Use createUserWithCredentials for new users');
    }
  },

  async toggleUserBlock(id: string) {
    console.log('Toggle user block not implemented yet for:', id);
  },

  async deleteUser(id: string) {
    // First deactivate/delete any professional records associated with this user
    const { error: profError } = await supabase
      .from('professionals')
      .delete()
      .eq('user_id', id);
    
    if (profError) {
      console.warn('Error deleting professionals for user:', profError);
      // Continue with profile deletion even if professional deletion fails
    }

    // Then delete from profiles
    const { error } = await supabase
      .from('profiles')
      .delete()
      .eq('id', id);
    if (error) throw error;
  },

  async getAppointmentMetrics(establishmentId: string) {
    const { data, error } = await supabase
      .from('appointments')
      .select('status')
      .eq('establishment_id', establishmentId);
    
    if (error) throw error;
    
    const total = data.length;
    const confirmed = data.filter(apt => apt.status === 'confirmed').length;
    const completed = data.filter(apt => apt.status === 'completed').length;
    const cancelled = data.filter(apt => apt.status === 'cancelled').length;
    
    return { total, confirmed, completed, cancelled };
  },

  async getRevenue(establishmentId: string, period: string) {
    let query = supabase
      .from('appointments')
      .select('total_price')
      .eq('establishment_id', establishmentId)
      .eq('status', 'completed');

    // Add date filters based on period
    const now = new Date();
    const startOfPeriod = new Date();
    
    switch (period) {
      case 'week':
        startOfPeriod.setDate(now.getDate() - 7);
        break;
      case 'month':
        startOfPeriod.setMonth(now.getMonth() - 1);
        break;
      case 'year':
        startOfPeriod.setFullYear(now.getFullYear() - 1);
        break;
    }
    
    query = query.gte('appointment_date', startOfPeriod.toISOString().split('T')[0]);

    const { data, error } = await query;
    
    if (error) throw error;
    
    return data.reduce((sum, appointment) => sum + Number(appointment.total_price), 0);
  }
};

export function getAdminDirectory() {
  return adminAdapter;
}