import { supabase } from "@/integrations/supabase/client";

export interface GlobalSetting {
  id: string;
  key: string;
  value: string;
  description?: string;
  created_at: string;
  updated_at: string;
}

export async function getGlobalSettings(): Promise<Record<string, string>> {
  const { data, error } = await supabase
    .from('global_settings')
    .select('key, value');
  
  if (error) throw error;
  
  const settings: Record<string, string> = {};
  data?.forEach(setting => {
    settings[setting.key] = setting.value;
  });
  
  return settings;
}

export async function getGlobalSetting(key: string): Promise<string | null> {
  const { data, error } = await supabase
    .from('global_settings')
    .select('value')
    .eq('key', key)
    .maybeSingle();
  
  if (error) throw error;
  return data?.value || null;
}

export async function updateGlobalSetting(key: string, value: string): Promise<void> {
  const { error } = await supabase
    .from('global_settings')
    .update({ value, updated_at: new Date().toISOString() })
    .eq('key', key);
  
  if (error) throw error;
}

export async function listAllGlobalSettings(): Promise<GlobalSetting[]> {
  const { data, error } = await supabase
    .from('global_settings')
    .select('*')
    .order('key');
  
  if (error) throw error;
  return data || [];
}

export async function createGlobalSetting(key: string, value: string, description?: string): Promise<void> {
  const { error } = await supabase
    .from('global_settings')
    .insert({ key, value, description });
  
  if (error) throw error;
}