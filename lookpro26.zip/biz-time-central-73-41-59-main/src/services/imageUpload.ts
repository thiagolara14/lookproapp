import { uploadFile, type StorageBucket } from "@/services/supabase/storage";

export interface ImageUploadOptions {
  maxWidth?: number;
  maxHeight?: number;
  quality?: number;
  format?: 'jpeg' | 'png' | 'webp';
}

const DEFAULT_OPTIONS: Required<ImageUploadOptions> = {
  maxWidth: 1920,
  maxHeight: 1920,
  quality: 0.8,
  format: 'jpeg'
};

/**
 * Resize and optimize image before upload
 */
export function resizeImage(file: File, options: ImageUploadOptions = {}): Promise<File> {
  const opts = { ...DEFAULT_OPTIONS, ...options };

  return new Promise((resolve, reject) => {
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    const img = new Image();

    img.onload = () => {
      // Calculate new dimensions
      let { width, height } = img;
      
      if (width > opts.maxWidth || height > opts.maxHeight) {
        const ratio = Math.min(opts.maxWidth / width, opts.maxHeight / height);
        width *= ratio;
        height *= ratio;
      }

      // Set canvas dimensions
      canvas.width = width;
      canvas.height = height;

      // Draw and compress image
      ctx?.drawImage(img, 0, 0, width, height);

      canvas.toBlob(
        (blob) => {
          if (!blob) {
            reject(new Error('Failed to compress image'));
            return;
          }

          const extension = opts.format === 'jpeg' ? 'jpg' : opts.format;
          const fileName = file.name.replace(/\.[^/.]+$/, `.${extension}`);
          
          const compressedFile = new File([blob], fileName, {
            type: `image/${opts.format}`,
            lastModified: Date.now(),
          });

          resolve(compressedFile);
        },
        `image/${opts.format}`,
        opts.quality
      );
    };

    img.onerror = () => reject(new Error('Failed to load image'));
    img.src = URL.createObjectURL(file);
  });
}

/**
 * Upload image with automatic resizing and optimization
 */
export async function uploadOptimizedImage(
  bucket: StorageBucket,
  file: File,
  path: string,
  options: ImageUploadOptions = {}
): Promise<string> {
  // Check if file is an image
  if (!file.type.startsWith('image/')) {
    throw new Error('File must be an image');
  }

  try {
    // Resize and optimize the image
    const optimizedFile = await resizeImage(file, options);
    
    // Upload to Supabase Storage
    const publicUrl = await uploadFile(bucket, optimizedFile, path);
    
    return publicUrl;
  } catch (error) {
    console.error('Image upload error:', error);
    throw new Error('Failed to upload image');
  }
}

/**
 * Helper functions for specific image types
 */
export async function uploadEstablishmentLogo(establishmentId: string, file: File): Promise<string> {
  const path = `${establishmentId}/logo-${Date.now()}.jpg`;
  return uploadOptimizedImage('establishment-logos', file, path, {
    maxWidth: 300,
    maxHeight: 300,
    quality: 0.9
  });
}

export async function uploadEstablishmentCover(establishmentId: string, file: File): Promise<string> {
  const path = `${establishmentId}/cover-${Date.now()}.jpg`;
  return uploadOptimizedImage('establishment-covers', file, path, {
    maxWidth: 1920,
    maxHeight: 1080,
    quality: 0.8
  });
}

export async function uploadEstablishmentPhoto(establishmentId: string, file: File): Promise<string> {
  const path = `${establishmentId}/photo-${Date.now()}.jpg`;
  return uploadOptimizedImage('establishment-photos', file, path, {
    maxWidth: 800,
    maxHeight: 600,
    quality: 0.8
  });
}

export async function uploadServicePhoto(serviceId: string, file: File): Promise<string> {
  const path = `${serviceId}/service-${Date.now()}.jpg`;
  return uploadOptimizedImage('service-photos', file, path, {
    maxWidth: 600,
    maxHeight: 400,
    quality: 0.8
  });
}

export async function uploadProfessionalAvatar(professionalId: string, file: File): Promise<string> {
  const path = `${professionalId}/avatar-${Date.now()}.jpg`;
  return uploadOptimizedImage('professional-avatars', file, path, {
    maxWidth: 400,
    maxHeight: 400,
    quality: 0.9
  });
}