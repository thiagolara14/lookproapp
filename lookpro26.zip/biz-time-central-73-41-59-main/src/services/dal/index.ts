import { backend } from "@/lib/config";
import { getAppointmentsAdapter } from "@/services/adapters";
import type { DAL } from "./types";

export function getDAL(tenantId: string): DAL {
  // Full Supabase implementation - all data stored in Supabase
  const adapter = getAppointmentsAdapter();
  const appointments = {
    create: adapter.create,
    update: adapter.update,
    getById: adapter.getById,
    listByProfessional: adapter.listByProfessional,
    listByEstablishment: adapter.listByEstablishment,
    listByClient: adapter.listByClient,
  };

  // Supabase is now the primary backend with complete RLS policies
  // All photos stored in Supabase Storage with proper access control
  // All filtering respects establishment_id, city_id, category_id

  return { tenantId, appointments } as DAL;
}

export type { DAL as IDAL } from "./types";
