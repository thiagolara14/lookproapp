import type { Appointment } from "@/types/appointments";

export type AppointmentsRepo = {
  create(input: Omit<Appointment, "id" | "createdAt" | "updatedAt">): Promise<Appointment>;
  update(id: string, patch: Partial<Appointment>): Promise<Appointment>;
  getById(id: string): Promise<Appointment | null>;
  listByProfessional(proId: string, opts?: { date?: string }): Promise<Appointment[]>;
  listByEstablishment(estId: string, opts?: { date?: string }): Promise<Appointment[]>;
  listByClient(clientId: string): Promise<Appointment[]>;
};

export type DAL = {
  tenantId: string;
  appointments: AppointmentsRepo;
  // TODO: services, professionals, establishments, reviews, notifications, blocked, profiles
};
