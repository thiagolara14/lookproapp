// Real Supabase adapters (replacing stubs)
export { 
  citiesAdapter as supabaseCitiesAdapter,
  categoriesAdapter as supabaseCategoriesAdapter,
  plansAdapter as supabasePlansAdapter,
  establishmentsAdapter as supabaseEstablishmentsAdapter,
  usersAdapter as supabaseUsersAdapter,
  reviewsAdapter as supabaseReviewsAdapter,
  bookingsAdapter as supabaseBookingsAdapter,
  metricsAdapter as supabaseMetricsAdapter
} from "./superAdminAdapters";