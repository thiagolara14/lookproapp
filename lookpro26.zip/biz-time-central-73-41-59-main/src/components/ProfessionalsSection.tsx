import { PublicProfessional } from '@/data/professionals';
import { toPublicAvatarUrl } from '@/services/supabase/storage';
import { Link } from 'react-router-dom';

type Props = { 
  pros: PublicProfessional[] 
};

export default function ProfessionalsSection({ pros }: Props) {
  if (!pros?.length) return null;

  return (
    <section aria-label="Profissionais do estabelecimento" className="mb-8">
      <h2 className="text-xl font-bold mb-4">Nossa Equipe</h2>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {pros.map((p) => {
          const avatar = p.avatar_path || '/placeholder.svg';
          const profileLink = `/profissional/${p.id}`;
          
          return (
            <Link 
              key={p.id}
              to={profileLink} 
              className="group block p-4 border border-border rounded-lg hover:shadow-md transition-shadow"
              aria-label={`Ver perfil de ${p.name}`}
            >
              <div className="flex items-start gap-3">
                <img
                  src={avatar || '/placeholder.svg'}
                  alt={`Foto de perfil de ${p.name}`}
                  className="h-14 w-14 rounded-full object-cover bg-muted"
                  onError={(e) => { 
                    (e.currentTarget as HTMLImageElement).src = '/placeholder.svg';
                  }}
                />
                <div className="flex-1 min-w-0">
                  <h3 className="font-medium text-foreground group-hover:text-primary transition-colors">
                    {p.name}
                  </h3>
                  {p.bio && (
                    <p className="text-sm text-muted-foreground line-clamp-2 mt-1">
                      {p.bio}
                    </p>
                  )}
                  <span className="text-xs text-primary mt-2 inline-block group-hover:underline">
                    Ver perfil →
                  </span>
                </div>
              </div>
            </Link>
          );
        })}
      </div>
    </section>
  );
}