import { PropsWithChildren, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import { SidebarProvider, SidebarTrigger } from "@/components/ui/sidebar";
import { ProSidebar } from "./AppSidebar";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/context/AuthContext";
import { ensurePushSubscription } from "@/lib/push";
import { professionalsAdapter } from "@/services/adapters";

const ProLayout = ({ children }: PropsWithChildren) => {
  const navigate = useNavigate();
  const { user, signOut, loading } = useAuth();

  // Registrar push notifications quando profissional loga
  useEffect(() => {
    const setupPushForProfessional = async () => {
      if (user && user.role === "professional" && user.establishmentId) {
        try {
          // Buscar dados do profissional
          const professional = await professionalsAdapter.getByEmail(user.email);
          if (professional?.id) {
            await ensurePushSubscription({
              user: { id: user.uid },
              professionalId: professional.id,
              customerId: null,
              establishmentId: user.establishmentId
            });
            console.log('Push notifications configuradas para profissional');
          }
        } catch (error) {
          console.error('Erro ao configurar push para profissional:', error);
        }
      }
    };

    setupPushForProfessional();
  }, [user]);

  useEffect(() => {
    if (!loading && (!user || user.role !== "professional")) {
      navigate("/login/pro", { replace: true });
    }
  }, [user, loading, navigate]);

  const handleSignOut = async () => {
    await signOut();
    navigate("/login/pro", { replace: true });
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-lg">Carregando...</div>
      </div>
    );
  }

  return (
    <SidebarProvider>
      <div className="min-h-svh flex w-full max-w-full overflow-hidden">
        <ProSidebar />
        <main className="flex min-h-0 flex-1 flex-col min-w-0">
          <header className="h-14 border-b flex items-center justify-between px-2 sm:px-4 pwa-header">
            <div className="flex items-center gap-1 sm:gap-2 min-w-0">
              <SidebarTrigger />
              <Link to="/dashboard/pro/agenda" className="font-bold text-sm sm:text-base truncate">LookPro — Profissional</Link>
            </div>
            <div className="flex items-center gap-1 sm:gap-3 text-sm">
              {user && (
                <span className="text-muted-foreground hidden lg:inline text-xs">
                  {user.email} • EST {user.establishmentId}
                </span>
              )}
              <Button
                variant="outline"
                size="sm"
                onClick={handleSignOut}
                className="text-xs px-2"
              >
                Sair
              </Button>
            </div>
          </header>
          <div className="p-2 sm:p-4 flex-1 min-h-0 overflow-y-auto overflow-x-hidden">{children}</div>
        </main>
      </div>
    </SidebarProvider>
  );
};

export default ProLayout;