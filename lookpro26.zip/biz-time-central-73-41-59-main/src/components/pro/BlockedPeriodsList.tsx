import { useState, useEffect } from "react";
import { format } from "date-fns";
import { Button } from "@/components/ui/button";
import { blockedPeriodsAdapter } from "@/services/adapters";
import { toast } from "sonner";

type Props = {
  proId: string | undefined;
  slots: string[];
  version: number;
  onChanged?: () => void;
};

const toIsoFor = (day: Date, time: string) => new Date(`${day.toISOString().slice(0, 10)}T${time}:00`).toISOString();

export default function BlockedPeriodsList({ proId, slots, version, onChanged }: Props) {
  const [ranges, setRanges] = useState<{ from: Date; to: Date }[]>([]);

  useEffect(() => {
    (async () => {
      if (!proId) {
        setRanges([]);
        return;
      }
      
      // Buscar períodos bloqueados e agrupar por dias consecutivos
      const today = new Date();
      const endDate = new Date(today);
      endDate.setDate(today.getDate() + 365); // próximo ano
      
      const allBlocked: { day: string; items: any[] }[] = [];
      
      // Verificar cada dia no período
      for (let d = new Date(today); d <= endDate; d.setDate(d.getDate() + 1)) {
        const dayKey = format(d, "yyyy-MM-dd");
        const items = await blockedPeriodsAdapter.listOverlaps(proId, dayKey);
        if (items.length > 0) {
          allBlocked.push({ day: dayKey, items });
        }
      }
      
      if (allBlocked.length === 0) {
        setRanges([]);
        return;
      }
      
      // Agrupar dias consecutivos
      const dates = allBlocked.map(b => new Date(`${b.day}T00:00:00`)).sort((a, b) => a.getTime() - b.getTime());
      const out: { from: Date; to: Date }[] = [];
      let start = dates[0];
      let prev = dates[0];

      for (let i = 1; i < dates.length; i++) {
        const cur = dates[i];
        const nextOfPrev = new Date(prev);
        nextOfPrev.setDate(prev.getDate() + 1);
        if (cur.toDateString() === nextOfPrev.toDateString()) {
          prev = cur;
        } else {
          out.push({ from: start, to: prev });
          start = cur;
          prev = cur;
        }
      }
      out.push({ from: start, to: prev });
      setRanges(out);
    })();
  }, [proId, version]);

  const handleUnblock = async (from: Date, to: Date) => {
    if (!proId) return;
    
    try {
      const d = new Date(from);
      while (d <= to) {
        const dayKey = format(d, "yyyy-MM-dd");
        const items = await blockedPeriodsAdapter.listOverlaps(proId, dayKey);
        await Promise.all(items.map(i => blockedPeriodsAdapter.remove(i.id)));
        d.setDate(d.getDate() + 1);
      }
      toast.success("Período desbloqueado");
      onChanged?.();
    } catch (error) {
      toast.error("Erro ao desbloquear período");
    }
  };

  if (!proId) return <p className="text-muted-foreground text-sm">Sessão não encontrada.</p>;

  if (ranges.length === 0) {
    return <p className="text-muted-foreground text-sm">Nenhum período bloqueado.</p>;
  }

  return (
    <div className="grid gap-2">
      {ranges.map((r, idx) => (
        <div key={idx} className="flex items-center justify-between rounded-md border p-3">
          <div className="text-sm">
            <div className="font-medium">
              {format(r.from, "dd/MM/yyyy")} {r.from.toDateString() !== r.to.toDateString() ? `— ${format(r.to, "dd/MM/yyyy")}` : ""}
            </div>
            <div className="text-muted-foreground text-xs">Dia(s) inteiro(s) bloqueado(s)</div>
          </div>
          <Button variant="outline" onClick={() => handleUnblock(r.from, r.to)}>
            Desbloquear
          </Button>
        </div>
      ))}
    </div>
  );
}
