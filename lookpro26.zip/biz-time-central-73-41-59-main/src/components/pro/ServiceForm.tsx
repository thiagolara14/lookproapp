import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { toast } from "@/hooks/use-toast";
import { Loader2, Plus, Link } from "lucide-react";
import type { ProfessionalService, AvailableService } from "@/services/professionalServicesAdapter";

interface ServiceFormProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (data: ServiceFormData) => Promise<void>;
  initialData?: ProfessionalService;
  availableServices?: AvailableService[];
  mode: 'create' | 'edit' | 'link';
  loading?: boolean;
}

export interface ServiceFormData {
  serviceId?: string;
  customDurationMinutes?: number;
  customPrice?: number;
  isActive?: boolean;
}

const formatPrice = (value: number) => {
  return new Intl.NumberFormat('pt-BR', {
    style: 'currency',
    currency: 'BRL',
  }).format(value);
};

const parsePrice = (value: string): number => {
  return parseFloat(value.replace(/[^\d,]/g, '').replace(',', '.')) || 0;
};

export default function ServiceForm({
  isOpen,
  onClose,
  onSubmit,
  initialData,
  availableServices = [],
  mode,
  loading = false
}: ServiceFormProps) {
  const [formData, setFormData] = useState<ServiceFormData>({
    serviceId: initialData?.serviceId || '',
    customDurationMinutes: initialData?.customDurationMinutes || undefined,
    customPrice: initialData?.customPrice || undefined,
    isActive: initialData?.isActive ?? true
  });

  const [selectedService, setSelectedService] = useState<AvailableService | null>(
    availableServices.find(s => s.serviceId === formData.serviceId) || null
  );

  const handleServiceSelect = (serviceId: string) => {
    const service = availableServices.find(s => s.serviceId === serviceId);
    setSelectedService(service || null);
    setFormData(prev => ({
      ...prev,
      serviceId,
      customDurationMinutes: undefined,
      customPrice: undefined
    }));
  };

  const handlePriceChange = (value: string) => {
    const numericValue = parsePrice(value);
    setFormData(prev => ({ ...prev, customPrice: numericValue }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (mode === 'link' && !formData.serviceId) {
      toast({
        title: "Erro",
        description: "Selecione um serviço para vincular.",
        variant: "destructive"
      });
      return;
    }

    if (formData.customDurationMinutes && formData.customDurationMinutes <= 0) {
      toast({
        title: "Erro", 
        description: "Duração deve ser maior que zero.",
        variant: "destructive"
      });
      return;
    }

    if (formData.customPrice && formData.customPrice < 0) {
      toast({
        title: "Erro",
        description: "Preço não pode ser negativo.",
        variant: "destructive"
      });
      return;
    }

    try {
      await onSubmit(formData);
      onClose();
      toast({
        title: "Sucesso",
        description: mode === 'create' ? "Serviço criado com sucesso!" : 
                    mode === 'link' ? "Serviço vinculado com sucesso!" :
                    "Serviço atualizado com sucesso!"
      });
    } catch (error) {
      console.error('Error submitting form:', error);
      toast({
        title: "Erro",
        description: "Ocorreu um erro ao salvar. Tente novamente.",
        variant: "destructive"
      });
    }
  };

  const getTitle = () => {
    switch (mode) {
      case 'create': return 'Criar Novo Serviço';
      case 'link': return 'Vincular Serviço';
      case 'edit': return 'Editar Serviço';
      default: return 'Serviço';
    }
  };

  const effectivePrice = formData.customPrice ?? selectedService?.price ?? initialData?.price;
  const effectiveDuration = formData.customDurationMinutes ?? selectedService?.durationMinutes ?? initialData?.durationMinutes;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            {mode === 'link' ? <Link className="h-5 w-5" /> : <Plus className="h-5 w-5" />}
            {getTitle()}
          </DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          {mode === 'link' && (
            <div className="space-y-2">
              <Label htmlFor="serviceId">Serviço do Estabelecimento</Label>
              <Select value={formData.serviceId} onValueChange={handleServiceSelect}>
                <SelectTrigger>
                  <SelectValue placeholder="Selecione um serviço para vincular" />
                </SelectTrigger>
                <SelectContent>
                  {availableServices.map((service) => (
                    <SelectItem key={service.serviceId} value={service.serviceId}>
                      <div className="flex flex-col">
                        <span className="font-medium">{service.name}</span>
                        <span className="text-sm text-muted-foreground">
                          {service.durationMinutes}min • {formatPrice(service.price)}
                        </span>
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {selectedService && (
                <div className="p-3 bg-muted rounded-lg">
                  <p className="text-sm"><strong>Descrição:</strong> {selectedService.description || 'Sem descrição'}</p>
                  <p className="text-sm"><strong>Duração padrão:</strong> {selectedService.durationMinutes} minutos</p>
                  <p className="text-sm"><strong>Preço padrão:</strong> {formatPrice(selectedService.price)}</p>
                </div>
              )}
            </div>
          )}

          {mode === 'edit' && initialData && (
            <div className="p-3 bg-muted rounded-lg">
              <h4 className="font-medium">{initialData.name}</h4>
              <p className="text-sm text-muted-foreground">{initialData.description || 'Sem descrição'}</p>
              <div className="flex gap-4 text-sm mt-2">
                <span><strong>Duração original:</strong> {initialData.durationMinutes}min</span>
                <span><strong>Preço original:</strong> {formatPrice(initialData.price)}</span>
              </div>
            </div>
          )}

          {(selectedService || initialData) && (
            <>
              <div className="space-y-2">
                <Label htmlFor="customDuration">Duração Personalizada (minutos)</Label>
                <Input
                  id="customDuration"
                  type="number"
                  min="0"
                  step="15"
                  value={formData.customDurationMinutes || ''}
                  onChange={(e) => setFormData(prev => ({ 
                    ...prev, 
                    customDurationMinutes: e.target.value ? parseInt(e.target.value) : undefined 
                  }))}
                  placeholder={`Padrão: ${effectiveDuration} minutos`}
                />
                <p className="text-xs text-muted-foreground">
                  Deixe vazio para usar a duração padrão ({effectiveDuration} min)
                </p>
              </div>

              <div className="space-y-2">
                <Label htmlFor="customPrice">Preço Personalizado</Label>
                <Input
                  id="customPrice"
                  type="text"
                  value={formData.customPrice ? formatPrice(formData.customPrice) : ''}
                  onChange={(e) => handlePriceChange(e.target.value)}
                  placeholder={`Padrão: ${formatPrice(effectivePrice || 0)}`}
                />
                <p className="text-xs text-muted-foreground">
                  Deixe vazio para usar o preço padrão ({formatPrice(effectivePrice || 0)})
                </p>
              </div>

              {mode === 'edit' && (
                <div className="flex items-center space-x-2">
                  <Switch
                    checked={formData.isActive}
                    onCheckedChange={(checked) => setFormData(prev => ({ ...prev, isActive: checked }))}
                  />
                  <Label>Serviço ativo</Label>
                </div>
              )}
            </>
          )}

          <DialogFooter className="gap-2">
            <Button type="button" variant="outline" onClick={onClose}>
              Cancelar
            </Button>
            <Button type="submit" disabled={loading}>
              {loading && <Loader2 className="h-4 w-4 animate-spin mr-2" />}
              {mode === 'create' ? 'Criar' : mode === 'link' ? 'Vincular' : 'Salvar'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}