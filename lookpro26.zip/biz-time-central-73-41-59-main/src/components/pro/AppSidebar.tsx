import { NavLink, useLocation } from "react-router-dom";
import { CalendarClock, ScissorsSquare, Star, Bell, User2, Lock, Plus } from "lucide-react";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  useSidebar,
} from "@/components/ui/sidebar";

const items = [
  { title: "Agenda", url: "/dashboard/pro/agenda", icon: CalendarClock },
  { title: "Novo Agendamento", url: "/dashboard/pro/novo-agendamento", icon: Plus },
  { title: "Bloqueios", url: "/dashboard/pro/bloqueios", icon: Lock },
  { title: "Serviços", url: "/dashboard/pro/servicos", icon: ScissorsSquare },
  { title: "Avaliações", url: "/dashboard/pro/avaliacoes", icon: Star },
  { title: "Notificações", url: "/dashboard/pro/notificacoes", icon: Bell },
  { title: "Perfil", url: "/dashboard/pro/perfil", icon: User2 },
];

export const ProSidebar = () => {
  const { state } = useSidebar();
  const collapsed = state === "collapsed";
  const location = useLocation();
  const currentPath = location.pathname;
  const isActive = (path: string) => currentPath === path;
  const isExpanded = items.some((i) => isActive(i.url));
  const getNavCls = ({ isActive }: { isActive: boolean }) =>
    isActive ? "bg-muted text-primary font-medium" : "hover:bg-muted/50";

  return (
    <Sidebar className={collapsed ? "w-14" : "w-64"} collapsible="icon">
      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupLabel>Profissional</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {items.map((item) => (
                <SidebarMenuItem key={item.title}>
                  <SidebarMenuButton asChild>
                    <NavLink to={item.url} end className={getNavCls}>
                      <item.icon className="mr-2 h-4 w-4" />
                      {!collapsed && <span>{item.title}</span>}
                    </NavLink>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>
    </Sidebar>
  );
};
