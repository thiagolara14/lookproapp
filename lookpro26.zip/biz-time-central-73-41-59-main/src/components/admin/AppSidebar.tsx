import { NavLink, useLocation } from "react-router-dom";
import { LayoutDashboard, CalendarClock, ScissorsSquare, Users, Star, FileSpreadsheet, Clock, Settings, Bell, MessageSquare } from "lucide-react";
import { FeatureFlags } from "@/lib/featureFlags";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarTrigger,
  useSidebar,
} from "@/components/ui/sidebar";

const items = [
  { title: "Dashboard", url: "/dashboard/admin", icon: LayoutDashboard },
  { title: "Agendamentos", url: "/dashboard/admin/agendamentos", icon: CalendarClock },
  { title: "Serviços", url: "/dashboard/admin/servicos", icon: ScissorsSquare },
  { title: "Profissionais", url: "/dashboard/admin/profissionais", icon: Users },
  { title: "Clientes", url: "/dashboard/admin/clientes", icon: Users },
  { title: "Notificações", url: "/dashboard/admin/notificacoes", icon: Bell },
  { title: "Avaliações", url: "/dashboard/admin/avaliacoes", icon: Star },
  { title: "Relatórios", url: "/dashboard/admin/relatorios", icon: FileSpreadsheet },
  { title: "Horários", url: "/dashboard/admin/horarios", icon: Clock },
  ...(FeatureFlags.ONBOARDING_SELF_SERVE ? [{ title: "Novos Cadastros", url: "/dashboard/admin/onboarding/inbox", icon: MessageSquare }] : []),
  { title: "Configurações", url: "/dashboard/admin/configuracoes", icon: Settings },
] as const;

export const AdminSidebar = () => {
  const { state } = useSidebar();
  const collapsed = state === "collapsed";
  const location = useLocation();
  const currentPath = location.pathname;
  const isActive = (path: string) => currentPath === path;
  const isExpanded = items.some((i) => isActive(i.url));
  const getNavCls = ({ isActive }: { isActive: boolean }) =>
    isActive ? "bg-muted text-primary font-medium" : "hover:bg-muted/50";

  return (
    <Sidebar className={collapsed ? "w-14" : "w-64"} collapsible="icon">
      {/* fallback trigger inside the sidebar (visible in mini state) */}
      <SidebarTrigger className="m-2 self-end" />
      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupLabel>Admin</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {items.map((item) => (
                <SidebarMenuItem key={item.title}>
                  <SidebarMenuButton asChild>
                    <NavLink to={item.url} end className={getNavCls}>
                      <item.icon className="mr-2 h-4 w-4" />
                      {!collapsed && <span>{item.title}</span>}
                    </NavLink>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>
    </Sidebar>
  );
};
