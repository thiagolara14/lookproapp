import { PropsWithChildren, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import { SidebarProvider, SidebarTrigger } from "@/components/ui/sidebar";
import { AdminSidebar } from "./AppSidebar";
import { useAuth } from "@/context/AuthContext";
import { Button } from "@/components/ui/button";
import { ensurePushSubscription } from "@/lib/push";

const AdminLayout = ({ children }: PropsWithChildren) => {
  const navigate = useNavigate();
  const { user, signOut, loading } = useAuth();

  // Registrar push notifications quando admin loga
  useEffect(() => {
    if (user && user.role === "admin" && user.establishmentId) {
      ensurePushSubscription({
        user: { id: user.uid },
        professionalId: null,
        customerId: null, // Admin pode receber notificações mas não é cliente
        establishmentId: user.establishmentId
      }).catch(console.error);
    }
  }, [user]);

  useEffect(() => {
    if (!loading && (!user || user.role !== "admin")) {
      navigate("/login/admin", { replace: true });
    }
  }, [user, loading, navigate]);

  const handleSignOut = async () => {
    await signOut();
    navigate("/login/admin", { replace: true });
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-lg">Carregando...</div>
      </div>
    );
  }

  return (
    <SidebarProvider>
      <div className="min-h-svh flex w-full max-w-full overflow-hidden">
        <AdminSidebar />
        <main className="flex min-h-0 flex-1 flex-col min-w-0">
          <header className="h-14 border-b flex items-center justify-between px-2 sm:px-4 pwa-header">
            <div className="flex items-center gap-1 sm:gap-2 min-w-0">
              <SidebarTrigger />
              <Link to="/dashboard/admin" className="font-bold text-sm sm:text-base truncate">LookPro — Admin</Link>
            </div>
            <div className="flex items-center gap-1 sm:gap-3">
              {user?.establishmentId && (
                <span className="text-xs text-muted-foreground hidden lg:inline">EST • {user.establishmentId}</span>
              )}
              <Button
                variant="outline"
                size="sm"
                onClick={handleSignOut}
                className="text-xs px-2"
              >
                Sair
              </Button>
            </div>
          </header>
          <div className="p-2 sm:p-4 flex-1 min-h-0 overflow-y-auto overflow-x-hidden">{children}</div>
        </main>
      </div>
    </SidebarProvider>
  );
};

export default AdminLayout;