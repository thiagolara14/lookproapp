import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogTrigger } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import type { Appointment } from "@/types/appointments";
import { generateTimeSlots } from "@/lib/timeSlots";
import { listAppointmentsByProfessional } from "@/services/appointments";
import { professionalsAdapter, servicesAdapter } from "@/services/adapters";
import { getEstablishmentWorkingHours } from "@/services/supabase/schedule";
type Props = {
  appointment: Appointment;
  open: boolean;
  onOpenChange: (v: boolean) => void;
  onSave: (changes: { date: string; time: string; professionalId: string; professionalName: string }) => Promise<void>;
};

export default function EditAppointmentDialog({ appointment, open, onOpenChange, onSave }: Props) {
  const [date, setDate] = useState<string>(appointment.date);
  const [time, setTime] = useState<string>(appointment.time);
  const [professionalId, setProfessionalId] = useState<string>(appointment.professionalId);
  const [busyTimes, setBusyTimes] = useState<string[]>([]);
  const [professionals, setProfessionals] = useState<{ id: string; name: string }[]>([]);
  const [serviceDuration, setServiceDuration] = useState<number>(30);
  const [dayHours, setDayHours] = useState<{ start: string; end: string } | null>(null);
  // Load professionals and service/working hours
  useEffect(() => {
    async function load() {
      try {
        const [pros, service] = await Promise.all([
          professionalsAdapter.listByEstablishment(appointment.establishmentId),
          servicesAdapter.getById(appointment.serviceId)
        ]);
        setProfessionals(pros.map(p => ({ id: p.id, name: p.name })));
        if (service) setServiceDuration(service.duration);
        // Working hours for the selected date
        const wh = await getEstablishmentWorkingHours(appointment.establishmentId);
        const dow = new Date(appointment.date + 'T00:00:00').getDay().toString();
        const h = (wh as any)[dow];
        setDayHours(h && !h.closed ? { start: h.start, end: h.end } : null);
      } catch (e) {
        console.error('Error loading dialog data:', e);
      }
    }
    load();
  }, [appointment.establishmentId, appointment.serviceId, appointment.date]);
  // Load busy times for the selected professional/date excluding current appointment
  useEffect(() => {
    async function load() {
      if (!professionalId || !date) { setBusyTimes([]); return; }
      const appts = await listAppointmentsByProfessional(professionalId, { date });
      setBusyTimes(appts.filter((a) => a.status !== "cancelado" && a.id !== appointment.id).map((a) => a.time));
    }
    load();
  }, [professionalId, date, appointment.id]);

  // simplistic: recompute slots ignoring busy here; validation happens in service
  const slots = dayHours ? generateTimeSlots(dayHours, serviceDuration, busyTimes) : [];

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="w-[calc(100vw-1rem)] max-w-[95vw] sm:max-w-[560px] max-h-[calc(100svh-env(safe-area-inset-top)-env(safe-area-inset-bottom)-2rem)] overflow-y-auto p-4 sm:p-6" aria-describedby={undefined}>
        <DialogHeader>
          <DialogTitle>Editar agendamento</DialogTitle>
        </DialogHeader>
        <div className="grid gap-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <label className="text-sm">Data</label>
              <Input type="date" value={date} onChange={(e) => setDate(e.target.value)} />
            </div>
            <div className="space-y-2">
              <label className="text-sm">Profissional</label>
              <Select value={professionalId} onValueChange={setProfessionalId}>
                <SelectTrigger><SelectValue placeholder="Selecione" /></SelectTrigger>
                <SelectContent>
                  {professionals.map((p) => (
                    <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-sm">Horário</label>
            <div className="grid grid-cols-3 sm:grid-cols-4 gap-2">
              {slots.map((s) => (
                <button
                  key={s.time}
                  onClick={() => s.available && setTime(s.time)}
                  className={
                    `h-10 rounded-md border text-sm transition-colors ${
                      s.available 
                        ? (time === s.time 
                            ? 'bg-primary text-primary-foreground border-transparent' 
                            : 'bg-background hover:bg-accent hover:text-accent-foreground')
                        : 'opacity-50 cursor-not-allowed bg-muted text-muted-foreground'
                    }`
                  }
                >
                  {s.time}
                </button>
              ))}
            </div>
          </div>

          <div className="flex justify-end gap-3 pt-2">
            <Button variant="soft" onClick={() => onOpenChange(false)}>Cancelar</Button>
            <Button
              variant="hero"
              onClick={async () => {
                const prof = professionals.find((p) => p.id === professionalId);
                await onSave({ date, time, professionalId, professionalName: prof?.name ?? appointment.professionalName });
                onOpenChange(false);
              }}
            >Salvar</Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
