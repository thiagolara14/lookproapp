import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Calendar } from "@/components/ui/calendar";
import { Card, CardContent } from "@/components/ui/card";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { validateScheduleConflict } from "@/services/scheduleValidator";
import { getEstablishmentWorkingHours, generateTimeSlots } from "@/services/supabase/schedule";
import { createAppointment } from "@/services/supabase/appointments";
import { format } from "date-fns";

type Props = {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  establishmentId: string;
  onSuccess?: () => void;
};

export default function CreateAppointmentDialog({ open, onOpenChange, establishmentId, onSuccess }: Props) {
  const [form, setForm] = useState({
    clientName: "",
    clientPhone: "",
    professionalId: "",
    serviceId: "",
    date: undefined as Date | undefined,
    time: "",
    notes: ""
  });

  const [professionals, setProfessionals] = useState<Array<{ id: string; name: string }>>([]);
  const [services, setServices] = useState<Array<{ id: string; name: string; price: number; duration: number }>>([]);
  const [timeSlots, setTimeSlots] = useState<string[]>([]);
  const [busyTimes, setBusyTimes] = useState<string[]>([]);
  const [blockedTimes, setBlockedTimes] = useState<string[]>([]);
  const [loading, setLoading] = useState(false);

  // Load professionals and services when dialog opens
  useEffect(() => {
    if (open && establishmentId) {
      loadProfessionalsAndServices();
    }
  }, [open, establishmentId]);

  // Load time slots when dependencies change
  useEffect(() => {
    if (form.date && form.professionalId && establishmentId) {
      loadTimeSlots();
    }
  }, [form.date, form.professionalId, establishmentId]);

  // Load busy and blocked times when professional and date change
  useEffect(() => {
    if (form.professionalId && form.date) {
      loadBusyAndBlockedTimes();
    }
  }, [form.professionalId, form.date]);

  const loadProfessionalsAndServices = async () => {
    try {
      const [profResult, servicesResult] = await Promise.all([
        supabase
          .from('professionals')
          .select(`
            id,
            profiles!professionals_user_id_fkey(full_name)
          `)
          .eq('establishment_id', establishmentId)
          .eq('active', true),
        supabase
          .from('services')
          .select('id, name, price, duration_minutes')
          .eq('establishment_id', establishmentId)
          .eq('is_active', true)
      ]);

      if (profResult.data) {
        const profsData = profResult.data.map(prof => ({
          id: prof.id,
          name: Array.isArray(prof.profiles) && prof.profiles[0] 
            ? prof.profiles[0].full_name || 'Profissional'
            : (prof.profiles && typeof prof.profiles === 'object' && 'full_name' in prof.profiles)
              ? (prof.profiles as any).full_name || 'Profissional' 
              : 'Profissional'
        }));
        setProfessionals(profsData);
      }

      if (servicesResult.data) {
        const servicesData = servicesResult.data.map(service => ({
          id: service.id,
          name: service.name,
          price: Number(service.price),
          duration: service.duration_minutes || 60
        }));
        setServices(servicesData);
      }
    } catch (error) {
      console.error('Error loading professionals and services:', error);
      toast.error('Erro ao carregar dados');
    }
  };

  const loadTimeSlots = async () => {
    if (!form.date || !establishmentId) return;

    try {
      const workingHours = await getEstablishmentWorkingHours(establishmentId);
      const dayOfWeek = form.date.getDay();
      const dayHours = workingHours[dayOfWeek.toString()];

      if (dayHours && !dayHours.closed) {
        const slots = generateTimeSlots(dayHours, 30);
        setTimeSlots(slots);
      } else {
        setTimeSlots([]);
      }
    } catch (error) {
      console.error('Error loading time slots:', error);
      setTimeSlots([]);
    }
  };

  const loadBusyAndBlockedTimes = async () => {
    if (!form.professionalId || !form.date) return;

    try {
      const dateStr = format(form.date, 'yyyy-MM-dd');

      const [appointmentsResult, blockedResult] = await Promise.all([
        supabase
          .from('appointments')
          .select('start_time')
          .eq('professional_id', form.professionalId)
          .eq('appointment_date', dateStr)
          .neq('status', 'cancelled'),
        supabase
          .from('blocked_periods')
          .select('start_time, end_time')
          .eq('professional_id', form.professionalId)
          .lte('start_date', dateStr)
          .gte('end_date', dateStr)
      ]);

      setBusyTimes(appointmentsResult.data?.map(apt => apt.start_time) || []);

      // Process blocked periods into individual time slots
      const blocked = new Set<string>();
      blockedResult.data?.forEach(block => {
        const startTime = block.start_time || '00:00';
        const endTime = block.end_time || '23:59';
        
        // Add all 30-minute slots within the blocked period
        timeSlots.forEach(slot => {
          if (slot >= startTime && slot <= endTime) {
            blocked.add(slot);
          }
        });
      });

      setBlockedTimes(Array.from(blocked));
    } catch (error) {
      console.error('Error loading busy and blocked times:', error);
      setBusyTimes([]);
      setBlockedTimes([]);
    }
  };

  const handleSubmit = async () => {
    if (!form.clientName || !form.clientPhone || !form.professionalId || !form.serviceId || !form.date || !form.time) {
      toast.error('Preencha todos os campos obrigatórios');
      return;
    }

    setLoading(true);
    try {
      const dateStr = format(form.date, 'yyyy-MM-dd');

      // Validate schedule conflict
      const validation = await validateScheduleConflict(form.professionalId, dateStr, form.time);
      if (!validation.isValid) {
        toast.error(validation.reason || 'Horário não disponível');
        return;
      }

      // Create appointment
      await createAppointment({
        establishmentId,
        professionalId: form.professionalId,
        serviceId: form.serviceId,
        date: dateStr,
        time: form.time,
        clientName: form.clientName,
        clientPhone: form.clientPhone,
        notes: form.notes,
        status: 'confirmado'
      });

      toast.success('Agendamento criado com sucesso!');
      
      // Reset form
      setForm({
        clientName: "",
        clientPhone: "",
        professionalId: "",
        serviceId: "",
        date: undefined,
        time: "",
        notes: ""
      });

      onOpenChange(false);
      if (onSuccess) onSuccess();

      // Trigger refresh event
      window.dispatchEvent(new CustomEvent('appointmentCreated', { 
        detail: { 
          professionalId: form.professionalId, 
          appointmentDate: dateStr 
        } 
      }));

    } catch (error: any) {
      console.error('Error creating appointment:', error);
      toast.error(error.message || 'Erro ao criar agendamento');
    } finally {
      setLoading(false);
    }
  };

  const today = new Date();
  today.setHours(0, 0, 0, 0);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="w-[calc(100vw-1rem)] max-w-[95vw] sm:max-w-[600px] max-h-[calc(100svh-env(safe-area-inset-top)-env(safe-area-inset-bottom)-2rem)] overflow-y-auto p-4 sm:p-6">
        <DialogHeader>
          <DialogTitle>Criar Novo Agendamento</DialogTitle>
        </DialogHeader>

        <div className="grid gap-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Profissional *</label>
              <Select value={form.professionalId} onValueChange={(v) => setForm({ ...form, professionalId: v })}>
                <SelectTrigger>
                  <SelectValue placeholder="Selecione um profissional" />
                </SelectTrigger>
                <SelectContent>
                  {professionals.map((prof) => (
                    <SelectItem key={prof.id} value={prof.id}>
                      {prof.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium">Serviço *</label>
              <Select value={form.serviceId} onValueChange={(v) => setForm({ ...form, serviceId: v })}>
                <SelectTrigger>
                  <SelectValue placeholder="Selecione um serviço" />
                </SelectTrigger>
                <SelectContent>
                  {services.map((service) => (
                    <SelectItem key={service.id} value={service.id}>
                      {service.name} - {service.duration}min
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium">Data *</label>
            <Card>
              <CardContent className="p-0">
                <Calendar
                  mode="single"
                  selected={form.date}
                  onSelect={(date) => setForm({ ...form, date, time: "" })}
                  disabled={(date) => date < today}
                  className="rounded-md"
                />
              </CardContent>
            </Card>
          </div>

          {form.date && (
            <div className="space-y-2">
              <label className="text-sm font-medium">Horário *</label>
              <div className="grid grid-cols-4 gap-2">
                {timeSlots.map((slot) => {
                  const isBusy = busyTimes.includes(slot);
                  const isBlocked = blockedTimes.includes(slot);
                  const isUnavailable = isBusy || isBlocked;

                  return (
                    <button
                      key={slot}
                      type="button"
                      onClick={() => !isUnavailable && setForm({ ...form, time: slot })}
                      disabled={isUnavailable}
                      className={`
                        h-10 rounded-md border text-sm transition-colors
                        ${form.time === slot 
                          ? 'bg-primary text-primary-foreground border-transparent' 
                          : isUnavailable
                            ? 'opacity-50 cursor-not-allowed bg-muted text-muted-foreground'
                            : 'bg-background hover:bg-accent hover:text-accent-foreground'
                        }
                      `}
                      title={isBusy ? 'Horário ocupado' : isBlocked ? 'Horário bloqueado' : ''}
                    >
                      {slot}
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Nome do Cliente *</label>
              <Input
                value={form.clientName}
                onChange={(e) => setForm({ ...form, clientName: e.target.value })}
                placeholder="Ex: Ana Silva"
              />
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium">Telefone *</label>
              <Input
                value={form.clientPhone}
                onChange={(e) => setForm({ ...form, clientPhone: e.target.value })}
                placeholder="(11) 99999-0000"
              />
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium">Observações</label>
            <Input
              value={form.notes}
              onChange={(e) => setForm({ ...form, notes: e.target.value })}
              placeholder="Observações adicionais (opcional)"
            />
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancelar
          </Button>
          <Button onClick={handleSubmit} disabled={loading}>
            {loading ? 'Criando...' : 'Criar Agendamento'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}