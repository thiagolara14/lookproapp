import { NavLink, useLocation } from "react-router-dom";
import { LayoutDashboard, Building2, Users, Tags, MapPin, CreditCard, MessageSquare as MessageSquareSquare, FileSpreadsheet, FlaskConical, Settings, Edit3, MessageCircle, UserPlus } from "lucide-react";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  useSidebar,
} from "@/components/ui/sidebar";

const items = [
  { title: "Dashboard", url: "/dashboard/super", icon: LayoutDashboard },
  { title: "Cadastros", url: "/dashboard/super/cadastros", icon: UserPlus },
  { title: "Estabelecimentos", url: "/dashboard/super/estabelecimentos", icon: Building2 },
  { title: "Usuários", url: "/dashboard/super/usuarios", icon: Users },
  { title: "Planos", url: "/dashboard/super/planos", icon: CreditCard },
  { title: "Categorias", url: "/dashboard/super/categorias", icon: Tags },
  { title: "Cidades", url: "/dashboard/super/cidades", icon: MapPin },
  { title: "Editor de Conteúdo", url: "/dashboard/super/cms-editor", icon: Edit3 },
  { title: "Avaliações", url: "/dashboard/super/avaliacoes", icon: MessageSquareSquare },
  { title: "Relatórios", url: "/dashboard/super/relatorios", icon: FileSpreadsheet },
  { title: "Ferramentas", url: "/dashboard/super/ferramentas", icon: FlaskConical },
  { title: "Configurações", url: "/dashboard/super/configuracoes", icon: Settings },
];

// Debug items (only shown when feature flag is enabled)
const debugItems = import.meta.env.VITE_FEATURE_ONBOARDING_SELF_SERVE === 'true' ? [
  { title: "WhatsApp Debug", url: "/debug/whatsapp", icon: MessageCircle },
] : [];

export const SuperSidebar = () => {
  const { state } = useSidebar();
  const collapsed = state === "collapsed";
  const location = useLocation();
  const currentPath = location.pathname;
  const isActive = (path: string) => currentPath === path;
  const isExpanded = items.some((i) => isActive(i.url));
  const getNavCls = ({ isActive }: { isActive: boolean }) =>
    isActive ? "bg-muted text-primary font-medium" : "hover:bg-muted/50";

  return (
    <Sidebar className={collapsed ? "w-14" : "w-64"} collapsible="icon">
      
      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupLabel>Super Admin</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {items.map((item) => (
                <SidebarMenuItem key={item.title}>
                  <SidebarMenuButton asChild>
                    <NavLink to={item.url} end className={getNavCls}>
                      <item.icon className="mr-2 h-4 w-4" />
                      {!collapsed && <span>{item.title}</span>}
                    </NavLink>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
        
        {/* Debug Group - only shown when feature flag is enabled */}
        {debugItems.length > 0 && (
          <SidebarGroup>
            <SidebarGroupLabel>Debug</SidebarGroupLabel>
            <SidebarGroupContent>
              <SidebarMenu>
                {debugItems.map((item) => (
                  <SidebarMenuItem key={item.title}>
                    <SidebarMenuButton asChild>
                      <NavLink to={item.url} end className={getNavCls}>
                        <item.icon className="mr-2 h-4 w-4" />
                        {!collapsed && <span>{item.title}</span>}
                      </NavLink>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                ))}
              </SidebarMenu>
            </SidebarGroupContent>
          </SidebarGroup>
        )}
      </SidebarContent>
    </Sidebar>
  );
};
