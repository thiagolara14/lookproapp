import { useState } from "react";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { X } from "lucide-react";
import type { Category } from "@/lib/superStore";

interface MultiCategorySelectProps {
  categories: Category[];
  selectedCategoryIds: string[];
  primaryCategoryId: string;
  onSelectionChange: (categoryIds: string[], primaryId: string) => void;
  maxCategories?: number;
}

export default function MultiCategorySelect({
  categories,
  selectedCategoryIds,
  primaryCategoryId,
  onSelectionChange,
  maxCategories = 3
}: MultiCategorySelectProps) {
  const [selectedCategory, setSelectedCategory] = useState("");

  const addCategory = () => {
    if (!selectedCategory || selectedCategoryIds.includes(selectedCategory)) return;
    if (selectedCategoryIds.length >= maxCategories) return;

    const newSelection = [...selectedCategoryIds, selectedCategory];
    const newPrimaryId = selectedCategoryIds.length === 0 ? selectedCategory : primaryCategoryId;
    
    onSelectionChange(newSelection, newPrimaryId);
    setSelectedCategory("");
  };

  const removeCategory = (categoryId: string) => {
    const newSelection = selectedCategoryIds.filter(id => id !== categoryId);
    let newPrimaryId = primaryCategoryId;
    
    // If removing the primary category, set the first remaining as primary
    if (categoryId === primaryCategoryId && newSelection.length > 0) {
      newPrimaryId = newSelection[0];
    } else if (newSelection.length === 0) {
      newPrimaryId = "";
    }
    
    onSelectionChange(newSelection, newPrimaryId);
  };

  const setPrimaryCategory = (categoryId: string) => {
    onSelectionChange(selectedCategoryIds, categoryId);
  };

  const availableCategories = categories.filter(cat => !selectedCategoryIds.includes(cat.id));

  return (
    <div className="space-y-3">
      <Label>Categorias do Estabelecimento (máx. {maxCategories})</Label>
      
      {/* Selected categories */}
      <div className="space-y-2">
        {selectedCategoryIds.map(categoryId => {
          const category = categories.find(c => c.id === categoryId);
          if (!category) return null;
          
          const isPrimary = categoryId === primaryCategoryId;
          
          return (
            <div key={categoryId} className="flex items-center gap-2">
              <Badge variant={isPrimary ? "default" : "secondary"} className="gap-1">
                {category.name}
                {isPrimary && <span className="text-xs">(Principal)</span>}
                <button
                  type="button"
                  onClick={() => removeCategory(categoryId)}
                  className="ml-1 hover:bg-white/20 rounded-full p-0.5"
                >
                  <X size={12} />
                </button>
              </Badge>
              {!isPrimary && selectedCategoryIds.length > 1 && (
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  onClick={() => setPrimaryCategory(categoryId)}
                  className="h-6 text-xs"
                >
                  Definir como principal
                </Button>
              )}
            </div>
          );
        })}
      </div>

      {/* Add new category */}
      {selectedCategoryIds.length < maxCategories && availableCategories.length > 0 && (
        <div className="flex gap-2">
          <Select value={selectedCategory} onValueChange={setSelectedCategory}>
            <SelectTrigger className="flex-1">
              <SelectValue placeholder="Selecione uma categoria" />
            </SelectTrigger>
            <SelectContent>
              {availableCategories.map(category => (
                <SelectItem key={category.id} value={category.id}>
                  {category.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Button 
            type="button"
            onClick={addCategory} 
            disabled={!selectedCategory}
            variant="outline"
          >
            Adicionar
          </Button>
        </div>
      )}

      <p className="text-xs text-muted-foreground">
        {selectedCategoryIds.length === 0 && "Selecione pelo menos uma categoria (obrigatório)."}
        {selectedCategoryIds.length > 0 && `${selectedCategoryIds.length}/${maxCategories} categorias selecionadas.`}
        {selectedCategoryIds.length > 1 && " A categoria principal aparece em destaque na busca."}
      </p>
    </div>
  );
}