import { PropsWithChildren, useEffect } from "react";
import { useNavigate, Link } from "react-router-dom";
import { SidebarProvider, SidebarTrigger } from "@/components/ui/sidebar";
import { SuperSidebar } from "./AppSidebar";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";

const SuperLayout = ({ children }: PropsWithChildren) => {
  const navigate = useNavigate();

  useEffect(() => {
    (async () => {
      const { data } = await supabase.auth.getUser();
      if (!data?.user) {
        navigate("/super/login", { replace: true });
        return;
      }
      
      // Check if user has super_admin role
      const { data: profile } = await supabase
        .from('profiles')
        .select('role')
        .eq('user_id', data.user.id)
        .single();
        
      if (!profile || profile.role !== 'super_admin') {
        navigate("/super/login", { replace: true });
      }
    })();
  }, [navigate]);

  return (
    <SidebarProvider>
      <div className="min-h-screen flex w-full max-w-full overflow-hidden">
        <SuperSidebar />
        <main className="flex min-h-0 flex-1 flex-col min-w-0">
          <header className="h-14 border-b flex items-center justify-between px-2 sm:px-4 pwa-header">
            <div className="flex items-center gap-1 sm:gap-2 min-w-0">
              <SidebarTrigger />
              <Link to="/dashboard/super" className="font-bold text-sm sm:text-base truncate">LookPro — Super Admin</Link>
            </div>
            <Button
              variant="outline"
              size="sm"
              onClick={async () => {
                await supabase.auth.signOut();
                navigate("/super/login");
              }}
              className="text-xs px-2"
            >
              Sair
            </Button>
          </header>
          <div className="p-2 sm:p-4 flex-1 min-h-0 overflow-y-auto overflow-x-hidden">{children}</div>
        </main>
      </div>
    </SidebarProvider>
  );
};

export default SuperLayout;
