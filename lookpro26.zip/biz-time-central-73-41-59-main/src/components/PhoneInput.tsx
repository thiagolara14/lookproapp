import { useState, useEffect } from "react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { cn } from "@/lib/utils";

interface PhoneInputProps {
  value: string;
  onChange: (value: string) => void;
  className?: string;
  error?: string;
}

export function PhoneInput({ value, onChange, className, error }: PhoneInputProps) {
  const [ddd, setDdd] = useState("");
  const [phone, setPhone] = useState("");

  // Parse existing value into DDD and phone when component mounts or value changes externally
  useEffect(() => {
    if (value && value.length >= 10) {
      // Remove country code prefix (55 or +55) and extract DDD and phone
      const cleanValue = value.replace(/^\+?55/, '').replace(/\D/g, '');
      if (cleanValue.length >= 10) {
        setDdd(cleanValue.slice(0, 2));
        setPhone(cleanValue.slice(2));
      }
    }
  }, [value]);

  const formatPhone = (phoneValue: string): string => {
    const digits = phoneValue.replace(/\D/g, '');
    
    if (digits.length <= 4) {
      return digits;
    } else if (digits.length <= 8) {
      return `${digits.slice(0, 4)}-${digits.slice(4)}`;
    } else if (digits.length === 9) {
      // Mobile: 9XXXX-XXXX
      return `${digits.slice(0, 5)}-${digits.slice(5)}`;
    } else {
      // Limit to 9 digits for mobile
      const truncated = digits.slice(0, 9);
      return `${truncated.slice(0, 5)}-${truncated.slice(5)}`;
    }
  };

  const handleDddChange = (newDdd: string) => {
    const cleanDdd = newDdd.replace(/\D/g, '').slice(0, 2);
    setDdd(cleanDdd);
    
    if (cleanDdd.length === 2) {
      updateFullValue(cleanDdd, phone);
    }
  };

  const handlePhoneChange = (newPhone: string) => {
    const cleanPhone = newPhone.replace(/\D/g, '');
    const formattedPhone = formatPhone(cleanPhone);
    setPhone(formattedPhone);
    
    if (ddd.length === 2) {
      const phoneDigits = cleanPhone.slice(0, 9); // Max 9 digits
      updateFullValue(ddd, phoneDigits);
    }
  };

  const updateFullValue = (dddValue: string, phoneValue: string) => {
    if (dddValue.length === 2 && phoneValue.length >= 8) {
      // Generate E.164 format WITHOUT + for backend compatibility: 55DDNUMBER
      const cleanPhone = phoneValue.replace(/\D/g, '');
      const e164 = `55${dddValue}${cleanPhone}`;
      onChange(e164);
    } else {
      onChange("");
    }
  };

  const isValidDdd = (dddValue: string): boolean => {
    const dddNum = parseInt(dddValue);
    return dddValue.length === 2 && dddNum >= 11 && dddNum <= 99;
  };

  const isValidPhone = (phoneValue: string): boolean => {
    const digits = phoneValue.replace(/\D/g, '');
    return digits.length >= 8 && digits.length <= 9;
  };

  return (
    <div className={cn("space-y-2", className)}>
      <Label htmlFor="whatsapp">WhatsApp (com DDD) *</Label>
      
      <div className="flex gap-2 items-center">
        {/* Fixed country prefix */}
        <div className="bg-muted px-3 py-2 rounded-md border text-sm text-muted-foreground min-w-[60px] text-center">
          +55
        </div>
        
        {/* DDD Input */}
        <div className="flex-shrink-0">
          <Input
            id="ddd"
            placeholder="11"
            value={ddd}
            onChange={(e) => handleDddChange(e.target.value)}
            className={cn(
              "w-16 text-center",
              ddd && !isValidDdd(ddd) && "border-destructive"
            )}
            maxLength={2}
          />
        </div>
        
        {/* Phone Input */}
        <div className="flex-1">
          <Input
            id="phone"
            placeholder="91234-5678"
            value={phone}
            onChange={(e) => handlePhoneChange(e.target.value)}
            className={cn(
              phone && !isValidPhone(phone) && "border-destructive"
            )}
          />
        </div>
      </div>
      
      {error && (
        <p className="text-sm text-destructive">{error}</p>
      )}
      
      {/* Validation hints */}
      <div className="text-xs text-muted-foreground space-y-1">
        <p>• DDD: código da sua região (ex: 11 para SP)</p>
        <p>• Celular: 9 dígitos (ex: 91234-5678)</p>
        <p>• Fixo: 8 dígitos (ex: 1234-5678)</p>
      </div>
    </div>
  );
}