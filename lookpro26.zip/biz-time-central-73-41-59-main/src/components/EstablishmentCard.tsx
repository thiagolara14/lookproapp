import React, { useEffect, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { MapPin, Star, Clock } from "lucide-react";
import BookingDialog from "@/components/BookingDialog";
import { supabase } from "@/integrations/supabase/client";
import { useEstablishmentSchedule } from "@/hooks/useEstablishmentSchedule";
import EstablishmentWorkingHours from "@/components/EstablishmentWorkingHours";
type EstablishmentDisplay = {
  id: string;
  name: string;
  city: string;
  category: string;
  logoUrl?: string;
  coverUrl?: string;
  isActive: boolean;
  services: { id: string; name: string; durationMin: number; price: number }[];
  professionals: { id: string; name: string }[];
  workingHours: { start: string; end: string };
  workingHoursByDay?: {
    monFri: { start: string; end: string };
    saturday?: { start: string; end: string } | null;
    sunday?: { start: string; end: string } | null;
  };
  rating?: number;
  gallery?: string[];
};
import { Link } from "react-router-dom";
interface Props {
  est: EstablishmentDisplay;
}

const EstablishmentCard: React.FC<Props> = ({ est }) => {
  const [realRating, setRealRating] = useState<number | null>(null);
  const [reviewCount, setReviewCount] = useState<number>(0);
  const { workingHours, loading } = useEstablishmentSchedule(est.id);
  
  useEffect(() => {
    async function fetchRating() {
      try {
        const { data: reviews, error } = await supabase
          .from('reviews')
          .select('establishment_rating, professional_rating')
          .eq('establishment_id', est.id);

        if (error) {
          console.error('Error fetching reviews:', error);
          return;
        }

        if (reviews && reviews.length > 0) {
          const sum = reviews.reduce((acc: number, review: any) => 
            acc + (review.establishment_rating || review.professional_rating || 0), 0
          );
          const average = Math.round((sum / reviews.length) * 10) / 10;
          setRealRating(average);
          setReviewCount(reviews.length);
        }
      } catch (error) {
        console.error('Error fetching reviews:', error);
      }
    }

    fetchRating();
  }, [est.id]);

  const cover = est.coverUrl || est.logoUrl || "";
  
  // Generate hours summary from Supabase working hours
  const hoursSummary = React.useMemo(() => {
    if (loading) return "Carregando...";
    if (!workingHours || Object.keys(workingHours).length === 0) {
      return "Horário não informado";
    }

    const days = {
      1: 'Seg', 2: 'Ter', 3: 'Qua', 4: 'Qui', 5: 'Sex', 6: 'Sáb', 0: 'Dom'
    };

    const openDays = Object.entries(workingHours)
      .filter(([_, hours]) => !(hours as any).closed)
      .map(([dayNum, hours]) => ({
        day: days[parseInt(dayNum) as keyof typeof days],
        start: (hours as any).start,
        end: (hours as any).end
      }));

    if (openDays.length === 0) return "Fechado";
    if (openDays.length === 1) return `${openDays[0].day} ${openDays[0].start}–${openDays[0].end}`;
    
    // Group consecutive weekdays
    const weekdays = openDays.filter(d => !['Sáb', 'Dom'].includes(d.day));
    const weekend = openDays.filter(d => ['Sáb', 'Dom'].includes(d.day));
    
    const parts = [];
    if (weekdays.length > 0) {
      if (weekdays.length >= 3) {
        parts.push(`Seg–Sex ${weekdays[0].start}–${weekdays[0].end}`);
      } else {
        parts.push(weekdays.map(d => `${d.day} ${d.start}–${d.end}`).join(', '));
      }
    }
    
    weekend.forEach(d => {
      parts.push(`${d.day} ${d.start}–${d.end}`);
    });
    
    return parts.join(' • ');
  }, [workingHours, loading]);
  
  const displayRating = realRating !== null ? realRating : est.rating;
  
  return (
    <Card className="flex flex-col h-full bg-card/70 backdrop-blur border-border/60 hover:shadow-xl hover:shadow-[var(--shadow-soft)] transition-shadow hover-scale animate-fade-in">
      {cover && (
        <div className="aspect-[16/9] w-full overflow-hidden rounded-t-lg">
          <img
            src={cover}
            alt={`Foto de ${est.name}`}
            className="w-full h-full object-cover"
            loading="lazy"
          />
        </div>
      )}
      
      <CardHeader className="flex-1 space-y-3">
        <CardTitle className="text-lg leading-tight">{est.name}</CardTitle>
        
        {/* Informações principais organizadas em grid */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-1 text-sm text-muted-foreground">
              <MapPin className="size-4 flex-shrink-0" />
              <span className="truncate">{est.city}</span>
            </div>
            <Badge variant="secondary" className="text-xs">{est.category}</Badge>
          </div>
          
          {displayRating !== null && (
            <div className="flex items-center gap-1 text-sm">
              <Star className="size-4 text-primary fill-primary flex-shrink-0" />
              <span className="font-medium">{displayRating}</span>
              <span className="text-muted-foreground text-xs ml-1">
                ({reviewCount} {reviewCount === 1 ? 'avaliação' : 'avaliações'})
              </span>
            </div>
          )}
          
          <div className="flex items-center gap-1 text-xs text-muted-foreground">
            <Clock className="size-4 flex-shrink-0" />
            <span className="truncate">{hoursSummary}</span>
          </div>
        </div>
      </CardHeader>
      
      <CardContent className="pt-0 space-y-3">
        {/* Estatísticas dos serviços */}
        <div className="flex items-center justify-between text-xs text-muted-foreground bg-muted/30 rounded-md px-3 py-2">
          <span>{est.services.length} serviços</span>
          <div className="w-px h-4 bg-border"></div>
          <span>{est.professionals.length} profissionais</span>
        </div>
        
        {/* Botões de ação */}
        <div className="flex items-center gap-2">
          <Link to={`/e/${est.id}`} className="flex-1">
            <Button variant="outline" size="sm" className="w-full">
              Ver detalhes
            </Button>
          </Link>
          <BookingDialog establishment={est} />
        </div>
      </CardContent>
    </Card>
  );
};

export default EstablishmentCard;
