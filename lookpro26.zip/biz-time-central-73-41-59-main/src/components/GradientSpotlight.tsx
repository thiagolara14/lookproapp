import React from "react";

/*****
 * GradientSpotlight
 * Signature interaction: subtle spotlight following the pointer.
 * Respects prefers-reduced-motion by disabling tracking.
 */
const GradientSpotlight: React.FC = () => {
  React.useEffect(() => {
    const onMove = (e: MouseEvent) => {
      const x = (e.clientX / window.innerWidth) * 100;
      const y = (e.clientY / window.innerHeight) * 100;
      document.documentElement.style.setProperty("--spotlight-x", `${x}%`);
      document.documentElement.style.setProperty("--spotlight-y", `${y}%`);
    };

    const media = window.matchMedia("(prefers-reduced-motion: reduce)");
    if (!media.matches) window.addEventListener("pointermove", onMove);
    return () => window.removeEventListener("pointermove", onMove);
  }, []);

  return (
    <div
      aria-hidden
      className="pointer-events-none absolute inset-0 -z-10"
      style={{ background: "var(--gradient-surface)" }}
    />
  );
};

export default GradientSpotlight;
