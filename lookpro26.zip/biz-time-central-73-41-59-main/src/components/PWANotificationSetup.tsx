import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Bell, BellOff } from "lucide-react";
import { ensurePushSubscription, isPushNotificationSupported, getExistingSubscription } from "@/lib/push";
import { useAuth } from "@/context/AuthContext";

interface PWANotificationSetupProps {
  establishmentId: string;
  onSuccess?: () => void;
}

export function PWANotificationSetup({ establishmentId, onSuccess }: PWANotificationSetupProps) {
  const { user } = useAuth();
  const [hasSubscription, setHasSubscription] = useState(false);
  const [loading, setLoading] = useState(false);
  const [supported, setSupported] = useState(false);

  useEffect(() => {
    setSupported(isPushNotificationSupported());
    checkExistingSubscription();
  }, []);

  const checkExistingSubscription = async () => {
    const existing = await getExistingSubscription();
    setHasSubscription(!!existing);
  };

  const handleEnableNotifications = async () => {
    if (!user) return;
    
    setLoading(true);
    try {
      const subscription = await ensurePushSubscription({
        user: { id: user.uid },
        professionalId: null,
        customerId: user.uid, // Cliente
        establishmentId
      });
      
      if (subscription) {
        setHasSubscription(true);
        onSuccess?.();
      }
    } catch (error) {
      console.error('Erro ao ativar notificações:', error);
    } finally {
      setLoading(false);
    }
  };

  if (!supported) return null;

  return (
    <Card className="mb-4">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Bell className="h-5 w-5" />
          Notificações
        </CardTitle>
      </CardHeader>
      <CardContent>
        {hasSubscription ? (
          <div className="flex items-center gap-2 text-sm text-green-600">
            <Bell className="h-4 w-4" />
            Notificações ativadas! Você receberá atualizações importantes.
          </div>
        ) : (
          <div className="space-y-3">
            <p className="text-sm text-muted-foreground">
              Ative as notificações para receber atualizações sobre seus agendamentos e promoções.
            </p>
            <Button 
              onClick={handleEnableNotifications}
              disabled={loading}
              size="sm"
            >
              <Bell className="h-4 w-4 mr-2" />
              {loading ? "Ativando..." : "Ativar notificações"}
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  );
}