import React from "react";

const Logo = () => {
  return (
    <a href="/" aria-label="LookPro" className="inline-flex items-center gap-2">
      <span className="inline-flex h-9 w-9 items-center justify-center rounded-md bg-primary text-primary-foreground font-extrabold tracking-tight">
        LP
      </span>
      <span className="sr-only">LookPro</span>
    </a>
  );
};

export default Logo;
