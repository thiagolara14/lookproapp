import React from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Smartphone, X, Download, Share, Plus } from 'lucide-react';
import { usePWAInstall } from '@/hooks/usePWAInstall';

export function PWAInstallPrompt() {
  const { showInstallPrompt, installPWA, dismissInstallPrompt, canInstall } = usePWAInstall();
  
  // Detect if it's iOS Safari
  const isIOSSafari = /iPad|iPhone|iPod/.test(navigator.userAgent) && !(window as any).MSStream;
  const isInWebAppiOS = (window.navigator as any).standalone === true;

  if (!showInstallPrompt || isInWebAppiOS) {
    return null;
  }

  return (
    <Dialog open={showInstallPrompt} onOpenChange={() => {}}>
      <DialogContent className="w-[calc(100vw-1rem)] max-w-[95vw] sm:max-w-md max-h-[calc(100svh-env(safe-area-inset-top)-env(safe-area-inset-bottom)-2rem)] overflow-y-auto p-4 sm:p-6">
        <DialogHeader>
          <div className="flex items-center gap-3 mb-2">
            <div className="size-12 rounded-lg bg-primary flex items-center justify-center">
              <Smartphone className="size-6 text-primary-foreground" />
            </div>
            <div>
              <DialogTitle className="text-lg">Instalar LookPro</DialogTitle>
              <DialogDescription className="text-sm">
                Adicione à tela inicial para uma experiência completa
              </DialogDescription>
            </div>
          </div>
        </DialogHeader>
        
        <div className="space-y-4">
          <div className="text-sm text-muted-foreground">
            <p className="mb-2">Vantagens do app:</p>
            <ul className="space-y-1 ml-4">
              <li>• Acesso rápido e offline</li>
              <li>• Notificações de agendamentos</li>
              <li>• Interface otimizada</li>
              <li>• Sem anúncios do navegador</li>
            </ul>
          </div>
          
          {isIOSSafari ? (
            <div className="space-y-3">
              <div className="text-sm text-muted-foreground">
                <p className="font-medium mb-2">Como instalar no iOS:</p>
                <ol className="space-y-1 ml-4 list-decimal">
                  <li>Toque no botão <Share className="inline w-4 h-4 mx-1" /> (Compartilhar)</li>
                  <li>Role para baixo e toque em "Adicionar à Tela de Início"</li>
                  <li>Toque em "Adicionar" para confirmar</li>
                </ol>
              </div>
              
              <div className="flex gap-2 pt-2">
                <Button
                  onClick={dismissInstallPrompt}
                  className="flex-1"
                  variant="outline"
                >
                  <X className="size-4 mr-2" />
                  Entendi
                </Button>
              </div>
            </div>
          ) : (
            <div className="flex gap-2 pt-2">
              <Button
                variant="outline"
                onClick={dismissInstallPrompt}
                className="flex-1"
              >
                <X className="size-4 mr-2" />
                Agora não
              </Button>
              <Button
                onClick={installPWA}
                className="flex-1"
                variant="hero"
                disabled={!canInstall}
              >
                <Download className="size-4 mr-2" />
                Instalar
              </Button>
            </div>
          )}
          
          <p className="text-xs text-muted-foreground text-center">
            Esta mensagem aparece novamente em 7 dias se não for instalado
          </p>
        </div>
      </DialogContent>
    </Dialog>
  );
}