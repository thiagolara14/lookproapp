import { useEffect, useState } from "react";
import { readCMS } from "@/services/cms";
import type { CMSConfig } from "@/services/cms";

interface SeoProps {
  title?: string;
  description?: string;
  canonicalPath?: string; // e.g. "/e/est-id"
}

const Seo = ({ title, description, canonicalPath }: SeoProps) => {
  const [cms, setCms] = useState<CMSConfig | null>(null);

  useEffect(() => {
    const loadCms = async () => {
      try {
        const cmsData = await readCMS();
        setCms(cmsData);
      } catch (error) {
        console.error('Error loading CMS:', error);
      }
    };
    loadCms();
  }, []);

  useEffect(() => {
    if (!cms) return;
    
    const pageTitle = title || cms.seo.defaultTitle;
    const pageDesc = description || cms.seo.defaultDescription;

    document.title = pageTitle;

    if (pageDesc) {
      let meta = document.querySelector('meta[name="description"]');
      if (!meta) {
        meta = document.createElement('meta');
        meta.setAttribute('name', 'description');
        document.head.appendChild(meta);
      }
      meta.setAttribute('content', pageDesc);
    }

    // theme-color from CMS
    let theme = document.querySelector('meta[name="theme-color"]');
    if (!theme) {
      theme = document.createElement('meta');
      theme.setAttribute('name', 'theme-color');
      document.head.appendChild(theme);
    }
    theme.setAttribute('content', cms.theme.themeColor);

    if (canonicalPath) {
      let link = document.querySelector('link[rel="canonical"]');
      if (!link) {
        link = document.createElement('link');
        link.setAttribute('rel', 'canonical');
        document.head.appendChild(link);
      }
      const url = new URL(canonicalPath, window.location.origin);
      link.setAttribute('href', url.toString());
    }
  }, [cms, title, description, canonicalPath]);

  return null;
};

export default Seo;
