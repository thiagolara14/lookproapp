import React from "react";
import { Clock } from "lucide-react";
import { useEstablishmentSchedule } from "@/hooks/useEstablishmentSchedule";

interface EstablishmentWorkingHoursProps {
  establishmentId: string;
  compact?: boolean;
}

export const EstablishmentWorkingHours: React.FC<EstablishmentWorkingHoursProps> = ({ 
  establishmentId, 
  compact = false 
}) => {
  const { workingHours, loading } = useEstablishmentSchedule(establishmentId);

  if (loading) {
    return <p className="text-sm text-muted-foreground">Carregando horários...</p>;
  }

  if (!workingHours || Object.keys(workingHours).length === 0) {
    return <p className="text-sm text-muted-foreground">Horário não informado</p>;
  }

  const daysOfWeek = [
    { key: '1', name: 'Segunda-feira', short: 'Seg' },
    { key: '2', name: 'Terça-feira', short: 'Ter' },
    { key: '3', name: 'Quarta-feira', short: 'Qua' },
    { key: '4', name: 'Quinta-feira', short: 'Qui' },
    { key: '5', name: 'Sexta-feira', short: 'Sex' },
    { key: '6', name: 'Sábado', short: 'Sáb' },
    { key: '0', name: 'Domingo', short: 'Dom' }
  ];

  if (compact) {
    // Compact format for cards
    const openDays = daysOfWeek
      .filter(day => {
        const dayHours = workingHours[day.key];
        return dayHours && !(dayHours as any).closed;
      })
      .map(day => {
        const dayHours = workingHours[day.key];
        return {
          ...day,
          hours: `${(dayHours as any).start}–${(dayHours as any).end}`
        };
      });

    if (openDays.length === 0) return <span className="text-xs text-muted-foreground">Fechado</span>;

    // Group consecutive weekdays with same hours
    const weekdays = openDays.filter(d => !['Sáb', 'Dom'].includes(d.short));
    const weekend = openDays.filter(d => ['Sáb', 'Dom'].includes(d.short));
    
    const parts = [];
    if (weekdays.length >= 3 && weekdays.every(d => d.hours === weekdays[0].hours)) {
      parts.push(`Seg–Sex ${weekdays[0].hours}`);
    } else if (weekdays.length > 0) {
      parts.push(weekdays.map(d => `${d.short} ${d.hours}`).join(', '));
    }
    
    weekend.forEach(d => {
      parts.push(`${d.short} ${d.hours}`);
    });
    
    return <span className="text-xs text-muted-foreground">{parts.join(' • ')}</span>;
  }

  return (
    <ul className="text-sm space-y-1">
      {daysOfWeek.map((day) => {
        const dayHours = workingHours[day.key];
        return (
          <li key={day.key} className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Clock className="size-4" />
              <span className="min-w-[3rem]">{day.short}:</span>
            </div>
            <span className="text-muted-foreground">
              {dayHours && !(dayHours as any).closed 
                ? `${(dayHours as any).start}–${(dayHours as any).end}`
                : "Fechado"
              }
            </span>
          </li>
        );
      })}
    </ul>
  );
};

export default EstablishmentWorkingHours;