import React from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Calendar } from "@/components/ui/calendar";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { toast } from "@/hooks/use-toast";
import { ToastAction } from "@/components/ui/toast";
type EstablishmentLite = {
  id: string;
  name: string;
  city: string;
  services: { id: string; name: string; durationMin: number; price: number }[];
};
import { buildICS, downloadICS } from "@/lib/calendar";
import { useNavigate } from "react-router-dom";
import { format } from "date-fns";

import { listAppointmentsByProfessional } from "@/services/appointments";
import { getAppointmentsAdapter, blockedPeriodsAdapter, professionalsAdapter } from "@/services/adapters";
import { professionalServicesAdapter } from "@/services/professionalServicesAdapter";
import { useEstablishmentSchedule } from "@/hooks/useEstablishmentSchedule";
import { useEstablishmentAvailability } from "@/hooks/useEstablishmentAvailability";
import { normalizePhone, setClientKey, setClientName } from "@/lib/clientIdentity";
import { supabase } from "@/integrations/supabase/client";
import { computeAvailableStarts, generateTimeSlots, ymdLocal, type AppointmentSlot, type BlockedPeriod } from "@/utils/scheduleUtils";

interface Props {
  establishment: EstablishmentLite;
  preselectedServiceId?: string;
}

const BookingDialog: React.FC<Props> = ({ establishment, preselectedServiceId }) => {
  const [open, setOpen] = React.useState(false);
  const navigate = useNavigate();
  const [serviceId, setServiceId] = React.useState<string | undefined>(undefined);
  const [professionalId, setProfessionalId] = React.useState<string | undefined>(undefined);
  const [date, setDate] = React.useState<Date | undefined>(undefined);
  const [time, setTime] = React.useState<string | undefined>(undefined);
  const [name, setName] = React.useState("");
  const [phone, setPhone] = React.useState("");
  const [busyTimes, setBusyTimes] = React.useState<string[]>([]);
  const [blockedTimes, setBlockedTimes] = React.useState<string[]>([]);
  const [invoiceOpen, setInvoiceOpen] = React.useState(false);
  const [reviewed, setReviewed] = React.useState(false);
  const [professionals, setProfessionals] = React.useState<any[]>([]);
  const [availableServices, setAvailableServices] = React.useState<{ id: string; name: string; durationMin: number; price: number }[]>([]);
  const brl = React.useMemo(() => new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" }), []);
  
  React.useEffect(() => {
    if (open && preselectedServiceId) setServiceId(preselectedServiceId);
  }, [open, preselectedServiceId]);

  // Load services based on selected professional or establishment
  React.useEffect(() => {
    async function loadServices() {
      try {
        if (professionalId) {
          // Load professional's services
          const profServices = await professionalServicesAdapter.listByProfessional(professionalId);
          const formattedServices = profServices.map(service => ({
            id: service.serviceId,
            name: service.name,
            durationMin: service.durationMinutes,
            price: service.price
          }));
          setAvailableServices(formattedServices);
        } else {
          // Load establishment services as fallback
          setAvailableServices(establishment.services || []);
        }
      } catch (error) {
        console.error('Error loading services:', error);
        setAvailableServices(establishment.services || []);
      }
    }
    
    loadServices();
  }, [professionalId, establishment.services]);

  // Reset service selection when professional changes
  React.useEffect(() => {
    if (serviceId && availableServices.length > 0) {
      const serviceExists = availableServices.some(s => s.id === serviceId);
      if (!serviceExists) {
        setServiceId(undefined);
      }
    }
  }, [serviceId, availableServices]);

  // Reset selected time when dependencies change
  React.useEffect(() => {
    setTime(undefined);
  }, [serviceId, date, professionalId]);

  // Force invoice review again if details change
  React.useEffect(() => {
    setReviewed(false);
  }, [serviceId, professionalId, date, time]);
  // Load appointments and blocked periods for availability calculation
  const [appointments, setAppointments] = React.useState<AppointmentSlot[]>([]);
  const [blockedPeriods, setBlockedPeriods] = React.useState<BlockedPeriod[]>([]);

  React.useEffect(() => {
    async function loadScheduleData() {
      if (!professionalId || !date) {
        setAppointments([]);
        setBlockedPeriods([]);
        setBusyTimes([]);
        setBlockedTimes([]);
        return;
      }

      const dateStr = ymdLocal(date);

      try {
        // Load appointments
        const appts = await listAppointmentsByProfessional(professionalId, { date: dateStr });
        const activeAppointments = appts
          .filter((a) => a.status !== "cancelado")
          .map(a => ({
            time: a.time,
            duration: a.duration || 60,
            status: a.status
          }));
        
        setAppointments(activeAppointments);
        setBusyTimes(activeAppointments.map(a => a.time));

        // Load blocked periods
        const blocked = await blockedPeriodsAdapter.listOverlaps(professionalId, dateStr);
        const blockedPeriods = blocked.map(b => ({
          start: b.start,
          end: b.end
        }));
        
        setBlockedPeriods(blockedPeriods);
        
        // Convert blocked periods to time slots for backward compatibility
        const blockedTimes = new Set<string>();
        blocked.forEach(b => {
          const start = new Date(b.start);
          const end = new Date(b.end);
          for (let d = new Date(start); d <= end; d.setMinutes(d.getMinutes() + 30)) {
            blockedTimes.add(d.toISOString().slice(11, 16)); // "HH:mm"
          }
        });
        setBlockedTimes([...blockedTimes]);
      } catch (error) {
        console.error('Error loading schedule data:', error);
      }
    }

    loadScheduleData();
  }, [professionalId, date]);

  const today = React.useMemo(() => {
    const t = new Date();
    t.setHours(0, 0, 0, 0);
    return t;
  }, []);

  const service = availableServices?.find((s) => s.id === serviceId);

  const selectedPro = React.useMemo(() => professionals?.find((p) => p.id === professionalId), [professionals, professionalId]);

  

  const effectiveDuration = React.useMemo(() => {
    const service = availableServices?.find((s) => s.id === serviceId);
    if (!service) return 30;
    
    // Use service duration directly from professional services or establishment services
    return service.durationMin || 30;
  }, [serviceId, availableServices]);

  // Use Supabase directly for available slots
  const [slots, setSlots] = React.useState<{time: string; available: boolean}[]>([]);
  const { getAvailableSlots } = useEstablishmentSchedule(establishment.id);
  const { isDateAvailable } = useEstablishmentAvailability(establishment.id, professionalId);

  // Load professionals from Supabase
  React.useEffect(() => {
    async function loadProfessionals() {
      try {
        const pros = await professionalsAdapter.listByEstablishment(establishment.id);
        setProfessionals(pros);
        console.log('Profissionais carregados:', pros);
      } catch (error) {
        console.error('Error loading professionals:', error);
        setProfessionals([]);
      }
    }
    loadProfessionals();
  }, [establishment.id]);

  React.useEffect(() => {
    async function loadSlots() {
      if (!service || !date || !professionalId) {
        setSlots([]);
        return;
      }
      
      try {
        const availableSlots = await getAvailableSlots(date, professionalId, service.id);
        console.log('Base slots for', professionalId, 'on', ymdLocal(date), ':', availableSlots);
        
        // Generate base time slots from working hours
        const allSlots = availableSlots.map(slot => slot.time);
        
        // Calculate which slots can accommodate the full service duration
        const availableStarts = computeAvailableStarts({
          date,
          slots: allSlots,
          appointments,
          blocks: blockedPeriods,
          serviceMinutes: effectiveDuration,
          slotMinutes: 30
        });
        
        console.log('Available starts after conflict checking:', availableStarts);
        
        // Map all slots with availability based on conflict checking
        const filteredSlots = allSlots.map(time => ({
          time,
          available: availableStarts.includes(time)
        }));
        
        setSlots(filteredSlots);
      } catch (error) {
        console.error('Error loading time slots:', error);
        setSlots([]);
      }
    }
    loadSlots();
  }, [service, establishment.id, date, professionalId, getAvailableSlots, appointments, blockedPeriods, effectiveDuration]);

  // Remove finalSlots - already handled in slots state


const canConfirm = !!(service && date && time && name && phone && professionalId);

function getSelectedDateTime(d?: Date, t?: string) {
  if (!d || !t) return undefined;
  const [hh, mm] = t.split(":").map(Number);
  const dt = new Date(d);
  dt.setHours(hh, mm, 0, 0);
  return dt;
}

  function resetState() {
    setServiceId(undefined);
    setProfessionalId(undefined);
    setDate(undefined);
    setTime(undefined);
    setName("");
    setPhone("");
    setBusyTimes([]);
    setReviewed(false);
    setInvoiceOpen(false);
  }

async function onConfirm() {
  if (!canConfirm) {
    toast({
      title: "Revise os dados",
      description: "Selecione profissional, data e horário, e informe nome e WhatsApp.",
    });
    return;
  }
  
  // CRITICAL: Real-time validation with schedule validator
  try {
    const { data: lastMinuteValidation } = await supabase
      .from('appointments')
      .select('id')
      .eq('professional_id', professionalId)
      .eq('appointment_date', format(date, 'yyyy-MM-dd'))
      .eq('start_time', time)
      .neq('status', 'cancelled');

    if (lastMinuteValidation && lastMinuteValidation.length > 0) {
      toast({
        title: "Horário não disponível",
        description: "Este horário acabou de ser reservado. Selecione outro horário.",
      });
      // Refresh slots
      const availableSlots = await getAvailableSlots(date, professionalId, service?.id || '');
      const filteredSlots = availableSlots.map(slot => ({
        ...slot,
        available: slot.available && 
                  !busyTimes.includes(slot.time) && 
                  !blockedTimes.includes(slot.time)
      }));
      setSlots(filteredSlots);
      return;
    }

    // Check if slot is blocked
    const { data: blockedCheck } = await supabase
      .from('blocked_periods')
      .select('*')
      .eq('professional_id', professionalId)
      .lte('start_date', format(date, 'yyyy-MM-dd'))
      .gte('end_date', format(date, 'yyyy-MM-dd'));

    if (blockedCheck && blockedCheck.length > 0) {
      const slotDateTime = new Date(`${format(date, 'yyyy-MM-dd')}T${time}:00`);
      const isBlocked = blockedCheck.some(block => {
        const blockStart = new Date(`${block.start_date}T${block.start_time || '00:00'}:00`);
        const blockEnd = new Date(`${block.end_date}T${block.end_time || '23:59'}:59`);
        return slotDateTime >= blockStart && slotDateTime <= blockEnd;
      });

      if (isBlocked) {
        toast({
          title: "Horário bloqueado",
          description: "Este horário está bloqueado para agendamentos.",
        });
        return;
      }
    }
  } catch (error) {
    console.error('Error validating appointment:', error);
    toast({
      title: "Erro de validação",
      description: "Não foi possível validar o horário. Tente novamente.",
    });
    return;
  }

  const start = getSelectedDateTime(date, time);
  if (!service || !professionalId || !date || !time) return;

  try {
    const pro = professionals?.find((p) => p.id === professionalId);
    const dateStr = format(date, "yyyy-MM-dd");
    const normalized = normalizePhone(phone);
    
    console.log('Creating appointment with data:', {
      establishmentId: establishment.id,
      clientId: normalized,
      clientName: name,
      professionalId,
      professionalName: pro?.name || 'Profissional',
      serviceId: service.id,
      serviceName: service.name,
      date: dateStr,
      time: time,
      duration: effectiveDuration,
      status: "confirmado",
      price: service.price
    });

    const appointmentsAdapter = getAppointmentsAdapter();
    console.log('Creating appointment with professional ID:', professionalId, 'professional data:', pro);
    
    const appointment = await appointmentsAdapter.create({
      establishmentId: establishment.id,
      clientId: normalized,
      clientName: name,
      professionalId,
      professionalName: pro?.name || 'Profissional',
      serviceId: service.id,
      serviceName: service.name,
      date: dateStr,
      time: time,
      duration: effectiveDuration,
      status: "confirmado",
      price: service.price
    });
    
    console.log('Appointment created successfully:', appointment);

    // Persist client identity locally for "Meus Agendamentos"
    setClientKey(normalized);
    setClientName(name);

    // Trigger a refresh of the professional's schedule
    window.dispatchEvent(new CustomEvent('appointmentCreated', { 
      detail: { 
        professionalId, 
        appointmentDate: dateStr 
      } 
    }));

    setOpen(false);
    resetState();

    toast({
      title: "Agendamento realizado com sucesso",
      description: `Para ${format(date, 'dd/MM/yyyy')} às ${time}.`,
      action: (
        <ToastAction
          altText="OK"
          onClick={() => {
            navigate(`/e/${establishment.id}`);
          }}
        >
          OK
        </ToastAction>
      ),
    });

    if (start) {
      const ics = buildICS({
        title: `${establishment.name} — ${service.name}`,
        description: `${name} • Tel: ${phone}`,
        location: `${establishment.city}`,
        start,
        durationMin: Math.round(effectiveDuration || service.durationMin),
      });
      downloadICS(`agendamento-${establishment.id}-${service.id}`, ics);
    }
  } catch (e: any) {
    toast({
      title: "Não foi possível agendar",
      description: e?.message ?? "Tente outro horário",
    });
  }
}

function handleConfirmClick() {
  if (!canConfirm) {
    toast({
      title: "Revise os dados",
      description: "Selecione serviço, profissional, data e horário e informe nome e WhatsApp.",
    });
    return;
  }
  if (!reviewed) {
    setInvoiceOpen(true);
    return;
  }
  onConfirm();
}

  return (
    <>
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogTrigger asChild>
          <Button variant="hero" size="lg">Agendar</Button>
        </DialogTrigger>
        <DialogContent className="w-[calc(100vw-1rem)] max-w-[95vw] sm:max-w-[560px] max-h-[calc(100svh-env(safe-area-inset-top)-env(safe-area-inset-bottom)-2rem)] overflow-y-auto p-4 sm:p-6" aria-describedby={undefined}>
          <DialogHeader>
            <DialogTitle>Agendar em {establishment.name}</DialogTitle>
            <DialogDescription>Selecione serviço, profissional, data e horário.</DialogDescription>
          </DialogHeader>
  <div className="grid gap-4">
    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
      <div className="space-y-4">
        <div className="space-y-2">
          <label className="text-sm">Serviço</label>
          <Select value={serviceId} onValueChange={setServiceId}>
            <SelectTrigger>
              <SelectValue placeholder="Selecione um serviço" />
            </SelectTrigger>
            <SelectContent>
              {availableServices?.map((s) => (
                <SelectItem key={s.id} value={s.id}>
                  {s.name} • {Math.round((s.durationMin || 30))}min • {brl.format(s.price)}
                </SelectItem>
              )) || []}
            </SelectContent>
          </Select>
        </div>
        <div className="space-y-2">
          <label className="text-sm">Profissional</label>
          <Select value={professionalId} onValueChange={setProfessionalId}>
            <SelectTrigger>
              <SelectValue placeholder="Selecione um profissional" />
            </SelectTrigger>
            <SelectContent>
              {professionals?.map((p) => (
                <SelectItem key={p.id} value={p.id}>
                  {p.name}
                </SelectItem>
              )) || []}
            </SelectContent>
          </Select>
        </div>
      </div>
      <div className="space-y-2">
        <label className="text-sm">Data</label>
        <Card>
          <CardContent className="p-0">
            <Calendar
              mode="single"
              selected={date}
              onSelect={setDate}
              className="rounded-md pointer-events-auto"
              disabled={(d) => {
                if (!d) return true;
                
                // Disable past dates
                if (d.getTime() < today.getTime()) return true;
                
                // If professional is selected, check working hours
                if (professionalId && !isDateAvailable(d)) {
                  return true;
                }
                
                return false;
              }}
              modifiers={{
                selected: date ? [date] : [],
              }}
              modifiersStyles={{
                selected: {
                  backgroundColor: 'hsl(var(--primary))',
                  color: 'hsl(var(--primary-foreground))',
                  fontWeight: 'bold',
                  borderRadius: '6px',
                },
              }}
            />
          </CardContent>
        </Card>
      </div>
    </div>

    {service && (
      <div className="space-y-2">
        <label className="text-sm">Horário</label>
        <div className="grid grid-cols-3 sm:grid-cols-4 gap-2">
          {slots.map((s) => (
            <button
              key={s.time}
              onClick={() => s.available && setTime(s.time)}
              className={
                `h-10 rounded-md border text-sm transition-colors ${
                  s.available 
                    ? (time === s.time 
                        ? 'bg-primary text-primary-foreground border-transparent' 
                        : 'bg-background hover:bg-accent hover:text-accent-foreground')
                    : 'opacity-50 cursor-not-allowed bg-muted text-muted-foreground'
                }`
              }
            >
              {s.time}
            </button>
          ))}
        </div>
      </div>
    )}

    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
      <div className="space-y-2">
        <label className="text-sm">Seu nome</label>
        <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="Ex: Ana Silva" />
      </div>
      <div className="space-y-2">
        <label className="text-sm">Telefone (WhatsApp)</label>
        <Input value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="(11) 99999-0000" />
      </div>
    </div>

    <div className="flex justify-end gap-3 pt-2">
      <Button variant="soft" onClick={() => setOpen(false)}>Cancelar</Button>
      <Button variant="hero" onClick={handleConfirmClick} disabled={!canConfirm}>Confirmar</Button>
    </div>
  </div>
</DialogContent>
      </Dialog>

      <Dialog open={invoiceOpen} onOpenChange={setInvoiceOpen}>
        <DialogContent className="w-[calc(100vw-1rem)] max-w-[95vw] sm:max-w-[440px] max-h-[calc(100svh-env(safe-area-inset-top)-env(safe-area-inset-bottom)-2rem)] overflow-y-auto p-4 sm:p-6">
          <DialogHeader>
            <DialogTitle>Fatura do agendamento</DialogTitle>
            <DialogDescription>Revise os detalhes antes de confirmar.</DialogDescription>
          </DialogHeader>
          <div className="space-y-3 text-sm">
            <div className="flex items-center justify-between">
              <span className="font-medium">{service?.name}</span>
              <span className="font-medium">{brl.format(service?.price ?? 0)}</span>
            </div>
            <ul className="text-muted-foreground text-xs space-y-1 list-disc list-inside">
              {selectedPro?.name && <li>Profissional: {selectedPro?.name}</li>}
              {date && time && <li>Data: {format(date, 'dd/MM/yyyy')} às {time}</li>}
              {!!effectiveDuration && <li>Duração: {Math.round(effectiveDuration)} min</li>}
            </ul>
            <div className="border-t pt-2 mt-1 space-y-1">
              <div className="flex items-center justify-between"><span>Subtotal</span><span>{brl.format(service?.price ?? 0)}</span></div>
              <div className="flex items-center justify-between"><span>Taxas</span><span>{brl.format(0)}</span></div>
              <div className="flex items-center justify-between font-bold"><span>Total</span><span>{brl.format(service?.price ?? 0)}</span></div>
            </div>
            <div className="flex justify-end pt-2">
              <Button onClick={async () => { setInvoiceOpen(false); setReviewed(true); await onConfirm(); }}>OK</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
};

export default BookingDialog;
