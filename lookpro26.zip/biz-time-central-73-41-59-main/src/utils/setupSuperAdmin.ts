// Setup script for first Super Admin user
import { supabase } from "@/integrations/supabase/client";

export interface SetupResult {
  success: boolean;
  message: string;
  user?: {
    id: string;
    email: string;
    role: string;
  };
}

const SUPER_ADMIN_EMAIL = "super@lookpro.com";
const SUPER_ADMIN_PASSWORD = "Super123!@#";

export async function createSuperAdminAccount(): Promise<SetupResult> {
  try {
    // Check if super admin already exists
    const { data: existingUser } = await supabase
      .from('profiles')
      .select('*')
      .eq('email', SUPER_ADMIN_EMAIL)
      .eq('role', 'super_admin')
      .single();
    
    if (existingUser) {
      console.log('Super admin already exists');
      return { 
        success: true, 
        message: 'Super admin já existe. Use as credenciais existentes.',
        user: {
          id: existingUser.user_id,
          email: existingUser.email,
          role: existingUser.role
        }
      };
    }

    // Create Supabase Auth user
    const { data: authData, error: authError } = await supabase.auth.signUp({
      email: SUPER_ADMIN_EMAIL,
      password: SUPER_ADMIN_PASSWORD,
    });

    if (authError) {
      throw authError;
    }

    if (authData.user) {
      // Create user profile with super admin role
      const { error: profileError } = await supabase
        .from('profiles')
        .insert({
          user_id: authData.user.id,
          full_name: "Super Admin",
          email: SUPER_ADMIN_EMAIL,
          role: 'super_admin'
        });

      if (profileError) {
        throw profileError;
      }

      console.log('Super admin created successfully');
      return { 
        success: true, 
        message: `Super admin criado! Email: ${SUPER_ADMIN_EMAIL}, Senha: ${SUPER_ADMIN_PASSWORD}`,
        user: {
          id: authData.user.id,
          email: SUPER_ADMIN_EMAIL,
          role: 'super_admin'
        }
      };
    }

    throw new Error('Failed to create user');
  } catch (error: any) {
    console.error('Error creating super admin:', error);
    return { success: false, message: error.message };
  }
}

// Auto-setup function that runs on app load
export async function autoSetupIfNeeded(): Promise<void> {
  try {
    // Only run in development
    if (import.meta.env.PROD) return;

    const result = await createSuperAdminAccount();
    if (result.success && result.user) {
      console.log("🔧 Auto-setup completo:", result.message);
    }
  } catch (error) {
    console.log("Auto-setup skipped:", error);
  }
}