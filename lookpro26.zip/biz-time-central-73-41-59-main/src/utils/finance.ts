import { supabase } from "@/integrations/supabase/client";

/**
 * Formata valor em centavos para BRL
 * @param cents - Valor em centavos
 * @returns String formatada como R$ 50,00
 */
export const formatBRL = (cents: number): string => {
  return new Intl.NumberFormat("pt-BR", { 
    style: "currency", 
    currency: "BRL" 
  }).format((cents || 0) / 100);
};

/**
 * Busca total financeiro do profissional
 * @param professionalId - UUID do profissional
 * @param start - Data início (opcional)
 * @param end - Data fim (opcional)
 * @returns Valor em centavos
 */
export async function fetchProfessionalTotalCents(
  professionalId: string, 
  start?: Date, 
  end?: Date
): Promise<number> {
  const { data, error } = await supabase
    .rpc("finance_total_for_professional", {
      p_professional_id: professionalId,
      p_start: start ? start.toISOString() : null,
      p_end: end ? end.toISOString() : null,
    });

  if (error) throw error;
  return Number(data || 0);
}

/**
 * Busca total financeiro do estabelecimento
 * @param establishmentId - UUID do estabelecimento
 * @param start - Data início (opcional)
 * @param end - Data fim (opcional)
 * @returns Valor em centavos
 */
export async function fetchEstablishmentTotalCents(
  establishmentId: string, 
  start?: Date, 
  end?: Date
): Promise<number> {
  const { data, error } = await supabase
    .rpc("finance_total_for_establishment", {
      p_establishment_id: establishmentId,
      p_start: start ? start.toISOString() : null,
      p_end: end ? end.toISOString() : null,
    });

  if (error) throw error;
  return Number(data || 0);
}

/**
 * Busca breakdown financeiro por profissional (para Admin)
 * @param establishmentId - UUID do estabelecimento
 * @param start - Data início (opcional)
 * @param end - Data fim (opcional)
 * @returns Array com {professional_id, total_cents}
 */
export async function fetchFinanceBreakdownByProfessional(
  establishmentId: string, 
  start?: Date, 
  end?: Date
): Promise<Array<{ professional_id: string; total_cents: number }>> {
  const { data, error } = await supabase
    .rpc("finance_breakdown_by_professional", {
      p_establishment_id: establishmentId,
      p_start: start ? start.toISOString() : null,
      p_end: end ? end.toISOString() : null,
    });

  if (error) throw error;
  return data || [];
}

/**
 * Gera período do mês corrente (timezone Brasil)
 * @returns {start, end} - Datas início e fim do mês atual
 */
export function getCurrentMonthPeriod(): { start: Date; end: Date } {
  const now = new Date();
  const year = now.getFullYear();
  const month = now.getMonth();
  
  // Primeiro dia do mês atual
  const start = new Date(year, month, 1);
  // Primeiro dia do próximo mês
  const end = new Date(year, month + 1, 1);
  
  return { start, end };
}

/**
 * Gera período personalizado (timezone Brasil)
 * @param startDate - Data início
 * @param endDate - Data fim
 * @returns {start, end} - Datas ajustadas
 */
export function getCustomPeriod(startDate: Date, endDate: Date): { start: Date; end: Date } {
  // Início do dia
  const start = new Date(startDate);
  start.setHours(0, 0, 0, 0);
  
  // Fim do dia (próximo dia 00:00)
  const end = new Date(endDate);
  end.setDate(end.getDate() + 1);
  end.setHours(0, 0, 0, 0);
  
  return { start, end };
}