// Setup script for first Super Admin user using Supabase
import { supabase } from "@/integrations/supabase/client";
import { createSuperAdmin, checkUserRole } from "@/services/supabase/auth";

export interface SetupResult {
  success: boolean;
  message: string;
  user?: {
    uid: string;
    email: string;
    role: string;
  };
}

export async function setupFirstSuperAdmin(
  email: string = "super@lookpro.com", 
  password: string = "Super123!@#", 
  displayName: string = "Super Admin"
): Promise<SetupResult> {
  try {
    // Check if super admin already exists
    const { data: existingProfiles, error: queryError } = await supabase
      .from('profiles')
      .select('*')
      .eq('role', 'super_admin')
      .limit(1);

    if (queryError) {
      console.error('Error checking existing super admin:', queryError);
    }

    if (existingProfiles && existingProfiles.length > 0) {
      return {
        success: true,
        message: "Super Admin já existe. Use as credenciais existentes para fazer login.",
        user: {
          uid: existingProfiles[0].user_id,
          email: existingProfiles[0].email || email,
          role: "super_admin"
        }
      };
    }

    // Create Supabase Auth user with super admin role
    const data = await createSuperAdmin(email, password, displayName);

    if (!data.user) {
      throw new Error("Falha ao criar usuário");
    }

    // Create profile record
    const { error: profileError } = await supabase
      .from('profiles')
      .insert({
        user_id: data.user.id,
        email: data.user.email,
        full_name: displayName,
        role: 'super_admin',
      });

    if (profileError) {
      console.error('Error creating profile:', profileError);
      // Continue anyway as the user was created
    }

    console.log("Super Admin criado com sucesso:", data.user.id);

    return {
      success: true,
      message: `Super Admin criado com sucesso! Use ${email} / ${password} para fazer login.`,
      user: {
        uid: data.user.id,
        email: data.user.email!,
        role: "super_admin"
      }
    };

  } catch (error: any) {
    console.error("Erro ao criar Super Admin:", error);
    
    // If user already exists
    if (error.message?.includes("already") || error.message?.includes("já")) {
      return {
        success: false,
        message: "Este e-mail já está em uso. Tente fazer login ou use outro e-mail."
      };
    }

    return {
      success: false,
      message: `Erro ao criar Super Admin: ${error.message}`
    };
  }
}

// Auto-setup function that runs on app load
export async function autoSetupIfNeeded(): Promise<void> {
  try {
    // Only run in development
    if (import.meta.env.PROD) return;

    const result = await setupFirstSuperAdmin();
    if (result.success && result.user) {
      console.log("🔧 Auto-setup completo:", result.message);
    }
  } catch (error) {
    console.log("Auto-setup skipped:", error);
  }
}

// Verify super admin credentials
export async function verifySuperAdmin(email: string, password: string): Promise<SetupResult> {
  try {
    const { supabase } = await import("@/integrations/supabase/client");
    const { data, error } = await supabase.auth.signInWithPassword({
      email,
      password
    });

    if (error) throw error;
    if (!data.user) throw new Error("Authentication failed");

    // Check if user has super admin role
    const { data: profile, error: profileError } = await supabase
      .from('profiles')
      .select('role, full_name')
      .eq('user_id', data.user.id)
      .single();

    if (profileError) {
      throw new Error("Perfil do usuário não encontrado");
    }

    if (profile.role !== 'super_admin') {
      // Sign out the user since they don't have the right role
      await supabase.auth.signOut();
      throw new Error("Usuário não é Super Admin");
    }

    return {
      success: true,
      message: "Login realizado com sucesso",
      user: {
        uid: data.user.id,
        email: data.user.email!,
        role: "super_admin"
      }
    };

  } catch (error: any) {
    return {
      success: false,
      message: error.message || "Credenciais inválidas"
    };
  }
}