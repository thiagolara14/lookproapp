/**
 * Utility functions for schedule conflict detection and slot availability
 */

// Date utilities
export const ymdLocal = (d: Date) =>
  `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;

export const isoForLocal = (day: Date, time: string) => {
  const [H, M] = time.split(":").map(Number);
  const local = new Date(day.getFullYear(), day.getMonth(), day.getDate(), H, M, 0);
  return local.toISOString();
};

// Overlap detection using half-open intervals [start, end)
export const overlaps = (sA: string, eA: string, sB: string, eB: string) =>
  !(eA <= sB || sA >= eB);

// Types for availability calculation
export type AppointmentSlot = { 
  time: string; 
  duration?: number; 
  status?: string;
};

export type BlockedPeriod = { 
  start: string; 
  end: string;
};

interface AvailabilityParams {
  date: Date;
  slots: string[];          // ["09:00","09:30",...]
  appointments: AppointmentSlot[];      // active appointments (status !== "cancelado")
  blocks: BlockedPeriod[];          // blocked periods for the professional
  serviceMinutes: number;   // duration of selected service
  slotMinutes?: number;     // default 30
}

/**
 * Computes available start times considering service duration
 * Only returns slots where the entire service can fit without conflicts
 */
export function computeAvailableStarts(params: AvailabilityParams): string[] {
  const { date, slots, appointments, blocks, serviceMinutes, slotMinutes = 30 } = params;
  
  // Calculate how many slots the service needs
  const slotsNeeded = Math.ceil(serviceMinutes / slotMinutes);
  const availableStarts: string[] = [];

  // Check each possible starting slot
  for (let i = 0; i <= slots.length - slotsNeeded; i++) {
    const windowSlots = slots.slice(i, i + slotsNeeded);
    
    // Create intervals for this time window
    const windowIntervals = windowSlots.map((t) => {
      const start = isoForLocal(date, t);
      const end = new Date(new Date(start).getTime() + slotMinutes * 60 * 1000).toISOString();
      return { start, end, time: t };
    });

    // Check for conflicts with existing appointments
    const hasAppointmentConflict = appointments.some((apt) => {
      const aptStart = isoForLocal(date, apt.time);
      const aptDuration = apt.duration || 60; // Default 60 minutes if not specified
      const aptEnd = new Date(new Date(aptStart).getTime() + aptDuration * 60 * 1000).toISOString();
      
      return windowIntervals.some(({ start, end }) => 
        overlaps(start, end, aptStart, aptEnd)
      );
    });

    if (hasAppointmentConflict) continue;

    // Check for conflicts with blocked periods
    const hasBlockConflict = blocks.some((block) =>
      windowIntervals.some(({ start, end }) => 
        overlaps(start, end, block.start, block.end)
      )
    );

    if (hasBlockConflict) continue;

    // If no conflicts, this start time is available
    availableStarts.push(slots[i]);
  }

  return availableStarts;
}

/**
 * Generates time slots for a given day based on working hours
 */
export function generateTimeSlots(
  workingHours: { start: string; end: string },
  slotDurationMin: number = 30
): string[] {
  const toMinutes = (t: string) => {
    const [h, m] = t.split(":").map(Number);
    return h * 60 + m;
  };
  
  const toTime = (m: number) =>
    `${String(Math.floor(m / 60)).padStart(2, "0")}:${String(m % 60).padStart(2, "0")}`;

  const start = toMinutes(workingHours.start);
  const end = toMinutes(workingHours.end);
  const slots: string[] = [];
  
  for (let t = start; t < end; t += slotDurationMin) {
    slots.push(toTime(t));
  }
  
  return slots;
}