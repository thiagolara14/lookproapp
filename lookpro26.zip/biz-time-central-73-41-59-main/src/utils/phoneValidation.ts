// Phone validation utilities for E.164 format

export function validatePhoneE164(phone: string): boolean {
  // Remove all non-digits
  const digits = phone.replace(/\D/g, '');
  
  // Must have 12-13 total digits and start with 55 (Brazil)
  // Format: 55DDNNNNNNNNN (55 + 2-digit DDD + 8-9 digit number)
  if (digits.length < 12 || digits.length > 13) return false;
  if (!digits.startsWith('55')) return false;
  
  // Extract DDD (positions 2-3)
  const ddd = parseInt(digits.slice(2, 4));
  if (ddd < 11 || ddd > 99) return false;
  
  // Extract phone number (position 4 onwards)
  const phoneNumber = digits.slice(4);
  
  // Phone must be 8 or 9 digits
  if (phoneNumber.length < 8 || phoneNumber.length > 9) return false;
  
  // If 9 digits, must start with 9 (mobile)
  if (phoneNumber.length === 9 && !phoneNumber.startsWith('9')) return false;
  
  return true;
}

// Validate phone with regex as backup validation
export function validatePhoneWithRegex(phone: string): boolean {
  const digits = phone.replace(/\D/g, '');
  // Matches 12-13 digits starting with 55
  const regex = /^55\d{10,11}$/;
  return regex.test(digits);
}

export function formatPhoneForDisplay(phoneE164: string): string {
  const digits = phoneE164.replace(/\D/g, '');
  
  if (!digits.startsWith('55') || digits.length < 12) {
    return phoneE164; // Return as-is if not valid Brazilian number
  }
  
  const ddd = digits.slice(2, 4);
  const phone = digits.slice(4);
  
  if (phone.length === 9) {
    // Mobile: (DD) 9XXXX-XXXX
    return `(${ddd}) ${phone.slice(0, 5)}-${phone.slice(5)}`;
  } else if (phone.length === 8) {
    // Landline: (DD) XXXX-XXXX
    return `(${ddd}) ${phone.slice(0, 4)}-${phone.slice(4)}`;
  }
  
  return phoneE164;
}

export function normalizePhoneToE164(input: string): string {
  // Remove all non-digits
  let digits = input.replace(/\D/g, '');
  
  // If already starts with 55, return WITHOUT + (backend compatibility)
  if (digits.startsWith('55')) {
    return digits;
  }
  
  // If it's 10-11 digits, assume it's DDD + number (missing country code)
  if (digits.length === 10 || digits.length === 11) {
    return `55${digits}`;
  }
  
  return input; // Return as-is if we can't normalize
}

export function extractPhoneComponents(phoneE164: string): { ddd: string; phone: string } | null {
  const digits = phoneE164.replace(/\D/g, '');
  
  if (!digits.startsWith('55') || digits.length < 12) {
    return null;
  }
  
  return {
    ddd: digits.slice(2, 4),
    phone: digits.slice(4)
  };
}