// Image processing utilities for onboarding
const MAX_DIMENSION = 1080;
const QUALITY = 0.8;

export interface ProcessedImage {
  blob: Blob;
  dataUrl: string;
  originalSize: number;
  compressedSize: number;
}

export function isValidImageType(file: File): boolean {
  const validTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/heic', 'image/heif'];
  return validTypes.includes(file.type.toLowerCase());
}

export function isFileSizeValid(file: File): boolean {
  const MAX_SIZE = 5 * 1024 * 1024; // 5MB
  return file.size <= MAX_SIZE;
}

export async function resizeAndCompress(file: File): Promise<ProcessedImage> {
  return new Promise((resolve, reject) => {
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    const img = new Image();

    if (!ctx) {
      reject(new Error('Canvas context not available'));
      return;
    }

    img.onload = () => {
      try {
        // Calculate new dimensions
        let { width, height } = img;
        const maxDim = Math.max(width, height);
        
        if (maxDim > MAX_DIMENSION) {
          const ratio = MAX_DIMENSION / maxDim;
          width = Math.round(width * ratio);
          height = Math.round(height * ratio);
        }

        // Set canvas dimensions
        canvas.width = width;
        canvas.height = height;

        // Draw and compress
        ctx.drawImage(img, 0, 0, width, height);
        
        canvas.toBlob((blob) => {
          if (!blob) {
            reject(new Error('Failed to compress image'));
            return;
          }

          const dataUrl = canvas.toDataURL('image/jpeg', QUALITY);
          
          resolve({
            blob,
            dataUrl,
            originalSize: file.size,
            compressedSize: blob.size
          });
        }, 'image/jpeg', QUALITY);

      } catch (error) {
        reject(error);
      }
    };

    img.onerror = () => reject(new Error('Failed to load image'));
    
    // Handle HEIC files by converting to JPEG
    if (file.type.toLowerCase().includes('heic') || file.type.toLowerCase().includes('heif')) {
      // For HEIC support, we'd need a library like heic2any
      // For now, we'll reject HEIC files and suggest JPG/PNG
      reject(new Error('HEIC files not supported. Please use JPG or PNG format.'));
      return;
    }
    
    img.src = URL.createObjectURL(file);
  });
}

export function createImagePreview(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      if (e.target?.result) {
        resolve(e.target.result as string);
      } else {
        reject(new Error('Failed to create preview'));
      }
    };
    reader.onerror = () => reject(new Error('Failed to read file'));
    reader.readAsDataURL(file);
  });
}