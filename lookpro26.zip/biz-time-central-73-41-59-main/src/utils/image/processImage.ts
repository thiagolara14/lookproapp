// Image processing utilities for onboarding

export interface ProcessedImage {
  blob: Blob;
  base64: string;
  filename: string;
}

export const MAX_IMAGE_SIZE = 5 * 1024 * 1024; // 5MB
export const MAX_DIMENSION = 1080;
export const COMPRESSION_QUALITY = 0.8;

export function isValidImageType(file: File): boolean {
  const validTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/webp'];
  return validTypes.includes(file.type);
}

export function isValidImageSize(file: File): boolean {
  return file.size <= MAX_IMAGE_SIZE;
}

export async function processImage(file: File): Promise<ProcessedImage> {
  // Validate file type
  if (!isValidImageType(file)) {
    throw new Error('Formato não suportado. Use JPG, PNG ou WebP.');
  }

  // Validate file size
  if (!isValidImageSize(file)) {
    throw new Error(`Arquivo muito grande. Máximo ${MAX_IMAGE_SIZE / (1024 * 1024)}MB.`);
  }

  // Load image
  const image = await loadImage(file);
  
  // Calculate new dimensions
  const { width, height } = calculateDimensions(image.width, image.height);
  
  // Create canvas and resize
  const canvas = document.createElement('canvas');
  const ctx = canvas.getContext('2d');
  
  if (!ctx) {
    throw new Error('Não foi possível processar a imagem.');
  }
  
  canvas.width = width;
  canvas.height = height;
  
  // Draw and compress
  ctx.fillStyle = '#FFFFFF';
  ctx.fillRect(0, 0, width, height);
  ctx.drawImage(image, 0, 0, width, height);
  
  // Convert to blob
  const blob = await canvasToBlob(canvas, 'image/jpeg', COMPRESSION_QUALITY);
  
  // Convert to base64
  const base64 = await blobToBase64(blob);
  
  // Generate filename
  const filename = generateFilename(file.name);
  
  return { blob, base64, filename };
}

function loadImage(file: File): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const image = new Image();
    const url = URL.createObjectURL(file);
    
    image.onload = () => {
      URL.revokeObjectURL(url);
      resolve(image);
    };
    
    image.onerror = () => {
      URL.revokeObjectURL(url);
      reject(new Error('Não foi possível carregar a imagem.'));
    };
    
    image.src = url;
  });
}

function calculateDimensions(originalWidth: number, originalHeight: number): { width: number; height: number } {
  if (originalWidth <= MAX_DIMENSION && originalHeight <= MAX_DIMENSION) {
    return { width: originalWidth, height: originalHeight };
  }
  
  const ratio = Math.min(MAX_DIMENSION / originalWidth, MAX_DIMENSION / originalHeight);
  
  return {
    width: Math.round(originalWidth * ratio),
    height: Math.round(originalHeight * ratio)
  };
}

function canvasToBlob(canvas: HTMLCanvasElement, type: string, quality: number): Promise<Blob> {
  return new Promise((resolve, reject) => {
    canvas.toBlob((blob) => {
      if (blob) {
        resolve(blob);
      } else {
        reject(new Error('Falha ao converter imagem.'));
      }
    }, type, quality);
  });
}

function blobToBase64(blob: Blob): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    
    reader.onload = () => {
      const result = reader.result as string;
      resolve(result);
    };
    
    reader.onerror = () => {
      reject(new Error('Falha ao processar imagem.'));
    };
    
    reader.readAsDataURL(blob);
  });
}

function generateFilename(originalName: string): string {
  const name = originalName.replace(/\.[^.]+$/, '') || 'image';
  const sanitized = name
    .normalize('NFKD')
    .replace(/[^\w\-]+/g, '_')
    .toLowerCase();
  
  return `${sanitized}.jpg`;
}

export function createImagePreview(file: File): string {
  return URL.createObjectURL(file);
}