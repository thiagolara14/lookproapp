// Seed initial data for the Super Admin dashboard
import { supabase } from "@/integrations/supabase/client";

export async function seedInitialData() {
  try {
    console.log("🌱 Iniciando seed de dados...");

    // Check if data already exists
    const { data: existingCategories } = await supabase
      .from('categories')
      .select('*')
      .limit(1);
      
    if (existingCategories && existingCategories.length > 0) {
      console.log("📋 Dados já existem, pulando seed");
      return;
    }

    // Seed Categories
    const categories = [
      { name: "Salão de Beleza", image_url: null, active: true },
      { name: "Barbearia", image_url: null, active: true },
      { name: "Spa", image_url: null, active: true },
      { name: "Estética", image_url: null, active: true },
      { name: "Studio de Tatuagem", image_url: null, active: true }
    ];

    const { error: categoriesError } = await supabase
      .from('categories')
      .insert(categories);

    if (categoriesError) throw categoriesError;
    console.log("✅ Categorias criadas");

    // Seed Cities
    const cities = [
      { name: "São Paulo", visible: true },
      { name: "Rio de Janeiro", visible: true },
      { name: "Belo Horizonte", visible: true },
      { name: "Brasília", visible: true },
      { name: "Salvador", visible: true }
    ];

    const { error: citiesError } = await supabase
      .from('cities')
      .insert(cities);

    if (citiesError) throw citiesError;
    console.log("✅ Cidades criadas");

    // Seed Plans
    const plans = [
      {
        name: "Básico",
        price: 2990, // Price in cents
        period: "monthly",
        trial_days: 7,
        booking_limit: 50,
        extras: ["Suporte por email"]
      },
      {
        name: "Profissional",
        price: 5990,
        period: "monthly",
        trial_days: 14,
        booking_limit: 200,
        extras: ["Suporte por WhatsApp", "Relatórios avançados"]
      },
      {
        name: "Premium",
        price: 9990,
        period: "monthly",
        trial_days: 30,
        booking_limit: 500,
        extras: ["Suporte prioritário", "Integração com redes sociais", "App personalizado"]
      }
    ];

    const { error: plansError } = await supabase
      .from('plans')
      .insert(plans);

    if (plansError) throw plansError;
    console.log("✅ Planos criados");

    console.log("🎉 Seed completo!");

  } catch (error) {
    console.error("❌ Erro no seed:", error);
  }
}

// Auto-run seed in development
export async function autoSeedIfNeeded() {
  try {
    // Only run in development
    if (import.meta.env.PROD) return;
    
    await seedInitialData();
  } catch (error) {
    console.log("Auto-seed skipped:", error);
  }
}