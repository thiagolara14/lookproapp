// WhatsApp utilities for validation and formatting

export function formatWhatsApp(value: string): string {
  // Remove all non-digits
  const digits = value.replace(/\D/g, '');
  
  // Apply mask based on length
  if (digits.length <= 2) {
    return `(${digits}`;
  } else if (digits.length <= 7) {
    return `(${digits.slice(0, 2)}) ${digits.slice(2)}`;
  } else if (digits.length <= 11) {
    return `(${digits.slice(0, 2)}) ${digits.slice(2, 7)}-${digits.slice(7)}`;
  } else {
    // Limit to 11 digits (DDD + 9 digits)
    return `(${digits.slice(0, 2)}) ${digits.slice(2, 7)}-${digits.slice(7, 11)}`;
  }
}

export function validateWhatsApp(value: string): boolean {
  const digits = value.replace(/\D/g, '');
  
  // Must have 10 or 11 digits (DDD + phone)
  if (digits.length < 10 || digits.length > 11) {
    return false;
  }
  
  // DDD must be valid (11-99)
  const ddd = parseInt(digits.slice(0, 2));
  if (ddd < 11 || ddd > 99) {
    return false;
  }
  
  // For mobile numbers (11 digits), must start with 9
  if (digits.length === 11 && digits[2] !== '9') {
    return false;
  }
  
  return true;
}

export function cleanWhatsApp(value: string): string {
  return value.replace(/\D/g, '');
}

export function formatWhatsAppForAPI(value: string): string {
  const digits = cleanWhatsApp(value);
  return `+55${digits}`;
}

export function getWhatsAppDigits(value: string): string {
  return value.replace(/\D/g, '');
}