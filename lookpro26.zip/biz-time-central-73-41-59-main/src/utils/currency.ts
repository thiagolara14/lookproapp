/**
 * Formatação de moeda em BRL (Real Brasileiro)
 */

/**
 * Formata valor em centavos para formato BRL
 * @param cents Valor em centavos (ex: 5000 = R$ 50,00)
 * @returns String formatada em BRL (ex: "R$ 50,00")
 */
export const formatBRL = (cents: number): string => {
  return new Intl.NumberFormat("pt-BR", { 
    style: "currency", 
    currency: "BRL" 
  }).format((cents || 0) / 100);
};

/**
 * Converte valor em reais para centavos
 * @param reais Valor em reais (ex: 50.00)
 * @returns Valor em centavos (ex: 5000)
 */
export const reaisToCents = (reais: number): number => {
  return Math.round((reais || 0) * 100);
};

/**
 * Converte valor em centavos para reais
 * @param cents Valor em centavos (ex: 5000)
 * @returns Valor em reais (ex: 50.00)
 */
export const centsToReais = (cents: number): number => {
  return (cents || 0) / 100;
};