/**
 * Utility functions for professional profile synchronization
 */

/**
 * Trigger professional profile update event across tabs/components
 */
export function triggerProfessionalProfileUpdate(professionalId: string, slug?: string) {
  // Dispatch custom event for real-time sync
  window.dispatchEvent(new CustomEvent('professionalProfileUpdated', {
    detail: { 
      professionalId, 
      slug,
      timestamp: Date.now()
    }
  }));

  // Clear relevant caches
  if ('caches' in window) {
    caches.keys().then(names => {
      names.forEach(name => {
        if (name.includes('professionals') || name.includes('professional')) {
          caches.delete(name);
        }
      });
    });
  }

  console.log('Professional profile update event triggered for:', professionalId);
}

/**
 * Listen for professional profile updates
 */
export function listenForProfessionalProfileUpdates(callback: (data: any) => void) {
  const handleUpdate = (event: CustomEvent) => {
    console.log('Professional profile update received:', event.detail);
    callback(event.detail);
  };

  window.addEventListener('professionalProfileUpdated', handleUpdate);
  
  return () => {
    window.removeEventListener('professionalProfileUpdated', handleUpdate);
  };
}