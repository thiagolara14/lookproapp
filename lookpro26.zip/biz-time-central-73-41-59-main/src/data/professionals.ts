import { supabase } from "@/integrations/supabase/client";

export type PublicProfessional = {
  id: string;
  user_id?: string;
  name: string;
  slug: string;
  bio: string | null;
  phone?: string;
  whatsapp?: string;
  experienceYears?: number;
  specialties?: string[];
  avatar_path: string | null;
  establishment_id: string;
};

export async function fetchPublicProfessionalsByEstablishment(establishmentId: string): Promise<PublicProfessional[]> {
  console.log('Fetching professionals for establishment:', establishmentId);
  
  const { data, error } = await supabase
    .from('professionals')
    .select(`
      id, 
      bio, 
      slug, 
      avatar_path, 
      avatar_url, 
      establishment_id, 
      user_id,
      specialties
    `)
    .eq('establishment_id', establishmentId)
    .eq('is_public', true)
    .eq('active', true);

  if (error) throw error;
  if (!data) return [];
  
  console.log('Raw professional data:', data);
  
  // Filtrar profissionais cujos profiles foram soft deleted
  const professionalIds = data.map(p => p.user_id);
  const { data: profilesData } = await supabase
    .from('profiles')
    .select('user_id, deleted_at')
    .in('user_id', professionalIds);
  
  const activeProfessionals = data.filter(item => {
    const profile = profilesData?.find(p => p.user_id === item.user_id);
    return !profile?.deleted_at; // Só incluir se não foi soft deleted
  });
  
  console.log('Filtered active professionals:', activeProfessionals);
  
  // Use the working function to get professional names
  const { data: professionalData } = await supabase.rpc('get_establishment_professionals', {
    establishment_uuid: establishmentId
  });
  
  console.log('Professional names data:', professionalData);
  
  return activeProfessionals.map(item => {
    // Find the professional data with correct name
    const professionalInfo = professionalData?.find((p: any) => p.id === item.id);
    console.log(`Professional ${item.id}: info found:`, professionalInfo);
    
    // Parse bio if it's JSON
    let bioText = item.bio;
    let whatsapp = '';
    let experienceYears = 0;
    
    if (item.bio) {
      try {
        const bioData = JSON.parse(item.bio);
        bioText = bioData.description || item.bio;
        whatsapp = bioData.whatsapp || '';
        experienceYears = bioData.experienceYears || 0;
      } catch {
        // If not JSON, keep as simple text
        bioText = item.bio;
      }
    }
    
    const finalName = professionalInfo?.name || `Profissional ${item.id.slice(0, 8)}`;
    console.log(`Final name for professional ${item.id}:`, finalName);
    
    return {
      id: item.id,
      user_id: item.user_id,
      name: finalName,
      slug: item.slug || item.id,
      bio: bioText,
      phone: '',
      whatsapp: whatsapp,
      experienceYears: experienceYears,
      specialties: item.specialties || [],
      avatar_path: item.avatar_url || item.avatar_path, // Priorizar avatar_url
      establishment_id: item.establishment_id
    };
  }).filter(professional => {
    // Filtrar profissionais que não têm dados válidos
    const hasValidName = professional.name && 
      professional.name !== `Profissional ${professional.id.slice(0, 8)}` &&
      professional.name !== 'Profissional';
    
    console.log(`Professional ${professional.id} (${professional.name}): hasValidName=${hasValidName}`);
    return hasValidName;
  });
}

export async function fetchProfessionalBySlug(slugOrId: string) {
  console.log('Fetching professional by slug:', slugOrId);
  
  // First try to find by slug
  let { data, error } = await supabase
    .from('professionals')
    .select(`
      id, 
      bio, 
      slug, 
      avatar_path, 
      avatar_url, 
      establishment_id, 
      user_id, 
      specialties,
      updated_at
    `)
    .eq('slug', slugOrId)
    .eq('is_public', true)
    .eq('active', true)
    .maybeSingle();

  console.log('Professional data from DB:', data);

  // If not found by slug, try by ID
  if (!data && !error) {
    ({ data, error } = await supabase
      .from('professionals')
      .select(`
        id, 
        bio, 
        slug, 
        avatar_path, 
        avatar_url, 
        establishment_id, 
        user_id, 
        specialties,
        updated_at
      `)
      .eq('id', slugOrId)
      .eq('is_public', true)
      .eq('active', true)
      .maybeSingle());
  }

  if (error) throw error;
  if (!data) throw new Error('Profissional não encontrado');
  
  // Check if profile is soft deleted
  const { data: profileData, error: profileError } = await supabase
    .from('profiles')
    .select('full_name, phone, email, updated_at, deleted_at')
    .eq('user_id', data.user_id)
    .maybeSingle();

  if (profileError) {
    console.warn('Profile fetch error:', profileError);
  }
  
  // Se o profile foi soft deleted, não mostrar o profissional
  if (profileData?.deleted_at) {
    throw new Error('Profissional não encontrado');
  }

  console.log('Profile data from DB:', profileData, 'error:', profileError);
  
  if (profileError) {
    console.warn('Profile fetch error:', profileError);
  }

  // Use the profile data if available
  let userName = profileData?.full_name || `Profissional ${data.id.slice(0, 8)}`;
  let userPhone = profileData?.phone || '';

  // Parse bio if it's JSON to extract the real data saved in dashboard
  let bioText = data.bio;
  let whatsapp = '';
  let experienceYears = 0;
  
  if (data.bio) {
    try {
      const bioData = JSON.parse(data.bio);
      console.log('Parsed bio data:', bioData);
      bioText = bioData.description || data.bio;
      whatsapp = bioData.whatsapp || '';
      experienceYears = bioData.experienceYears || 0;
    } catch {
      // If not JSON, keep as simple text
      bioText = data.bio;
    }
  }
  
  const result = {
    id: data.id,
    user_id: data.user_id,
    name: userName || `Profissional ${data.id.slice(0, 8)}`,
    slug: data.slug || data.id,
    bio: bioText,
    phone: userPhone || '',
    whatsapp: whatsapp,
    experienceYears: experienceYears,
    specialties: data.specialties || [],
    avatar_path: data.avatar_url || data.avatar_path, // Priorizar avatar_url
    establishment_id: data.establishment_id
  };
  
  console.log('Final professional result:', result);
  return result;
}
