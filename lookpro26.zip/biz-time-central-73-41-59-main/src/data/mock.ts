// DEPRECATED: Legacy types for backward compatibility
// Use types from @/integrations/supabase/types.ts instead

export type Category = string;

export type Service = {
  id: string;
  name: string;
  durationMin: number;
  price: number;
};

export type Professional = {
  id: string;
  name: string;
};

export type Review = {
  id: string;
  author: string;
  rating: number;
  comment?: string;
};

export type Establishment = {
  id: string;
  name: string;
  city: string;
  category: Category;
  logoUrl?: string;
  coverUrl?: string;
  isActive: boolean;
  services: Service[];
  professionals: Professional[];
  workingHours: { start: string; end: string };
  workingHoursByDay?: {
    monFri: { start: string; end: string };
    saturday?: { start: string; end: string } | null;
    sunday?: { start: string; end: string } | null;
  };
  rating?: number;
  gallery?: string[];
  reviews?: Review[];
  whatsapp?: string;
  email?: string;
  phone?: string;
  address?: string;
  state?: string;
  description?: string;
};

// Constants
export const cities = [
  "São Paulo",
  "Rio de Janeiro", 
  "Belo Horizonte",
  "Curitiba",
  "Porto Alegre",
] as const;

export const categories: Category[] = [
  "Barbearia",
  "Salão de Beleza",
  "Clínica Estética", 
  "Tatuagem",
  "Spa",
];

// Data is now 100% from Supabase
export const establishments: Establishment[] = [];