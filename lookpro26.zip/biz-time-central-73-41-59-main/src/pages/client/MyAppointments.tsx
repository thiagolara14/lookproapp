import Seo from "@/components/Seo";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "@/hooks/use-toast";
import { useEffect, useState } from "react";
import { listAppointmentsByClient, cancelAppointmentAsClient } from "@/services/appointments";
import type { Appointment } from "@/types/appointments";
import { getClientKey, setClientKey, normalizePhone } from "@/lib/clientIdentity";
import { Link } from "react-router-dom";

const MyAppointments = () => {
  const [list, setList] = useState<Appointment[]>([]);
  const [clientKey, setKey] = useState<string | null>(getClientKey());
  const [phoneInput, setPhoneInput] = useState<string>("");

  async function refresh() {
    if (!clientKey) return;
    const data = await listAppointmentsByClient(clientKey);
    setList(data);
  }

  useEffect(() => {
    refresh();
  }, [clientKey]);

  return (
    <main className="container py-8">
      <Seo title="LookPro — Meus Agendamentos" description="Gerencie seus agendamentos" canonicalPath="/cliente/agendamentos" />
      <header className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-extrabold">Meus Agendamentos</h1>
        <Link to="/"><Button variant="soft">Voltar</Button></Link>
      </header>

      {!clientKey ? (
        <Card>
          <CardHeader>
            <CardTitle>Identifique-se pelo WhatsApp</CardTitle>
          </CardHeader>
          <CardContent className="grid gap-4 max-w-md">
            <div className="grid gap-2">
              <Label htmlFor="whats">Número do WhatsApp</Label>
              <Input id="whats" placeholder="(11) 90000-0000" value={phoneInput} onChange={(e) => setPhoneInput(e.target.value)} />
            </div>
            <div className="flex justify-end">
              <Button
                variant="hero"
                onClick={() => {
                  const normalized = normalizePhone(phoneInput);
                  if (!normalized) {
                    toast({ title: "Número inválido", description: "Informe seu WhatsApp." });
                    return;
                  }
                  setClientKey(normalized);
                  setKey(normalized);
                  toast({ title: "Bem-vindo", description: "Carregando seus agendamentos" });
                }}
              >Acessar</Button>
            </div>
            <p className="text-xs text-muted-foreground">Usamos seu WhatsApp como identificador. Com autenticação completa, você pode usar login/senha.</p>
          </CardContent>
        </Card>
      ) : (
        <Card>
          <CardHeader>
            <CardTitle>Próximos e passados</CardTitle>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Estabelecimento</TableHead>
                  <TableHead>Serviço</TableHead>
                  <TableHead>Data</TableHead>
                  <TableHead>Hora</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Ações</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {list.length === 0 && (
                  <TableRow>
                    <TableCell colSpan={6} className="text-muted-foreground">Você ainda não possui agendamentos.</TableCell>
                  </TableRow>
                )}
                {list.map((a) => (
                  <TableRow key={a.id}>
                    <TableCell className="font-medium">{a.establishmentId}</TableCell>
                    <TableCell>{a.serviceName}</TableCell>
                    <TableCell>{a.date}</TableCell>
                    <TableCell>{a.time}</TableCell>
                    <TableCell>{a.status}</TableCell>
                    <TableCell className="text-right space-x-2">
                      <Link to={`/cliente/agendamentos/${a.id}/editar`}><Button size="sm" variant="outline">Editar</Button></Link>
                      <Button size="sm" variant="destructive" onClick={async () => {
                        try {
                          await cancelAppointmentAsClient(a.id, clientKey!);
                          toast({ title: "Agendamento cancelado", description: `${a.serviceName} • ${a.time}` });
                          await refresh();
                        } catch (e: any) {
                          toast({ title: "Erro ao cancelar", description: e.message });
                        }
                      }}>Cancelar</Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      )}
    </main>
  );
};

export default MyAppointments;
