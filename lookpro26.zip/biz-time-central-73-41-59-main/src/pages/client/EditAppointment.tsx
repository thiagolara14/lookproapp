import Seo from "@/components/Seo";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "@/hooks/use-toast";
import { listAppointmentsByClient, editAppointmentAsClient } from "@/services/appointments";
import type { Appointment } from "@/types/appointments";
import { Link, useNavigate, useParams } from "react-router-dom";
import { useEffect, useState } from "react";
import { getClientKey } from "@/lib/clientIdentity";

const EditAppointment = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [appt, setAppt] = useState<Appointment | null>(null);
  const [date, setDate] = useState("");
  const [time, setTime] = useState("");
  const [loading, setLoading] = useState(false);
  const clientKey = getClientKey();

  useEffect(() => {
    async function load() {
      if (!clientKey) return;
      try {
        const list = await listAppointmentsByClient(clientKey);
        const found = list.find((a) => a.id === id) || null;
        setAppt(found);
        if (found) {
          setDate(found.date);
          setTime(found.time);
        }
      } catch (e: any) {
        toast({ title: "Erro ao carregar", description: e.message });
      }
    }
    load();
  }, [id, clientKey]);

  async function onSave() {
    if (!id || !clientKey) return;
    try {
      setLoading(true);
      await editAppointmentAsClient(id, { date, time }, clientKey);
      toast({ title: "Agendamento atualizado", description: `${date} • ${time}` });
      navigate("/cliente/agendamentos");
    } catch (e: any) {
      toast({ title: "Erro ao atualizar", description: e.message });
    } finally {
      setLoading(false);
    }
  }

  return (
    <main className="container py-8">
      <Seo title="LookPro — Editar Agendamento" description="Altere data e horário do seu agendamento" canonicalPath={`/cliente/agendamentos/${id}/editar`} />
      <header className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-extrabold">Editar Agendamento</h1>
        <Link to="/cliente/agendamentos"><Button variant="soft">Voltar</Button></Link>
      </header>

      {!clientKey ? (
        <Card>
          <CardHeader>
            <CardTitle>Identifique-se</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground">Volte para "Meus Agendamentos" e informe seu WhatsApp para continuar.</p>
            <div className="mt-4"><Link to="/cliente/agendamentos"><Button variant="outline">Acessar meus agendamentos</Button></Link></div>
          </CardContent>
        </Card>
      ) : (
        <Card>
          <CardHeader>
            <CardTitle>Reagendar</CardTitle>
          </CardHeader>
          <CardContent className="grid gap-4 max-w-md">
            {!appt && (
              <p className="text-sm text-muted-foreground">Carregando informações do agendamento...</p>
            )}

            <div className="grid gap-2">
              <Label htmlFor="date">Data</Label>
              <Input id="date" type="date" value={date} onChange={(e) => setDate(e.target.value)} />
            </div>

            <div className="grid gap-2">
              <Label htmlFor="time">Hora</Label>
              <Input id="time" type="time" value={time} onChange={(e) => setTime(e.target.value)} />
            </div>

            <div className="flex gap-2 justify-end">
              <Link to="/cliente/agendamentos"><Button variant="outline">Cancelar</Button></Link>
              <Button variant="hero" onClick={onSave} disabled={loading || !date || !time}>
                {loading ? "Salvando..." : "Salvar alterações"}
              </Button>
            </div>
          </CardContent>
        </Card>
      )}
    </main>
  );
};

export default EditAppointment;
