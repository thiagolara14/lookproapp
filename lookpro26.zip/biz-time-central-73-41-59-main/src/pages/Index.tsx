import { useState, useEffect } from "react";
import Seo from "@/components/Seo";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import GradientSpotlight from "@/components/GradientSpotlight";
import { Link, useNavigate } from "react-router-dom";
import { Mail, MessageCircle } from "lucide-react";
import { Carousel, CarouselContent, CarouselItem, CarouselNext, CarouselPrevious } from "@/components/ui/carousel";
import { getCitiesAdapter, getCategoriesAdapter } from "@/services/superAdminAdapters";
import { getGlobalSettings } from "@/services/globalSettings";
import { FeatureFlags } from "@/lib/featureFlags";
import { OnboardingCTA } from "@/features/onboarding/OnboardingCTA";
import { OnboardingForm } from "@/features/onboarding/OnboardingForm";
import { OnboardingSuccess } from "@/features/onboarding/success/OnboardingSuccess";
import type { City, Category } from "@/lib/superStore";

const Index = () => {
  const [city, setCity] = useState<string>("");
  const [category, setCategory] = useState<string>("");
  const [supCats, setSupCats] = useState<Category[]>([]);
  const [supCities, setSupCities] = useState<City[]>([]);
  const [supportSettings, setSupportSettings] = useState({ whatsapp: "", email: "" });
  const [loading, setLoading] = useState(true);
  const [onboardingOpen, setOnboardingOpen] = useState(false);
  const [onboardingStep, setOnboardingStep] = useState<'form' | 'success'>('form');
  const [leadId, setLeadId] = useState<string>('');
  const navigate = useNavigate();

  useEffect(() => {
    const loadData = async () => {
      try {
        const [categories, cities, settings] = await Promise.all([
          getCategoriesAdapter().listCategories(),
          getCitiesAdapter().listCities(),
          getGlobalSettings()
        ]);
        setSupCats(Array.isArray(categories) ? categories : await categories);
        setSupCities(Array.isArray(cities) ? cities : await cities);
        setSupportSettings({
          whatsapp: settings.support_whatsapp || "",
          email: settings.support_email || ""
        });
      } catch (error) {
        console.error('Error loading data:', error);
      } finally {
        setLoading(false);
      }
    };
    loadData();
  }, []);

  const handleOnboardingSuccess = (newLeadId: string) => {
    setLeadId(newLeadId);
    setOnboardingStep('success');
  };

  const handleOnboardingClose = () => {
    setOnboardingOpen(false);
    setOnboardingStep('form');
    setLeadId('');
  };

  // Prepare business types from categories for onboarding
  const businessTypes = supCats.map(cat => ({ id: cat.id, name: cat.name }));
  const cityOptions = supCities.map(city => ({ id: city.id, name: city.name }));

  return (
    <div className="min-h-screen relative">
      <Seo title="LookPro — Agendamentos e Gestão" description="Vitrine pública, agendamento sem conta e painéis para clientes e negócios." canonicalPath="/" />
      <GradientSpotlight />
      <header className="container pwa-header py-6 flex flex-wrap items-center justify-between gap-2">
        <a href="/" className="inline-flex items-center gap-2">
          <div className="size-8 rounded-md bg-[image:var(--gradient-primary)] grid place-items-center">
            <span aria-hidden="true" className="text-[10px] font-extrabold tracking-tight text-primary-foreground">LP</span>
          </div>
          <span className="text-lg font-extrabold">LookPro</span>
        </a>
        <nav className="flex flex-wrap items-center gap-3 pwa-nav">
          <Link to="/como-funciona" className="text-sm text-muted-foreground hover:text-foreground transition-colors">Como funciona</Link>
          <Link to="/planos" className="text-sm text-muted-foreground hover:text-foreground transition-colors">Planos</Link>
          <a href="/super/login"><Button variant="soft" size="sm">Sou gestor da plataforma</Button></a>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="hero" size="sm">Entrar</Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem asChild>
                <Link to="/login/admin">Entrar como Admin</Link>
              </DropdownMenuItem>
              <DropdownMenuItem asChild>
                <Link to="/login/pro">Entrar como Profissional</Link>
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </nav>
      </header>

        <main className="container pb-16">
          <section className="py-10 text-center">
          <h1 className="text-4xl md:text-5xl font-extrabold tracking-tight mb-4">
            Agende serviços e gerencie seu negócio com LookPro
          </h1>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
            Vitrine pública, agendamento sem conta e painéis para cliente, profissional, admin e super admin.
          </p>
          <div className="mt-8 grid grid-cols-1 md:grid-cols-3 gap-3 max-w-3xl mx-auto">
            <Select value={city} onValueChange={setCity}>
              <SelectTrigger className="h-12">
                <SelectValue placeholder="Cidade" />
              </SelectTrigger>
              <SelectContent>
                {supCities.map((c) => (
                  <SelectItem key={c.id} value={c.name}>{c.name}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={category} onValueChange={setCategory}>
              <SelectTrigger className="h-12">
                <SelectValue placeholder="Categoria" />
              </SelectTrigger>
              <SelectContent>
                {supCats.map((cat) => (
                  <SelectItem key={cat.id} value={cat.name}>{cat.name}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Button
              variant="hero"
              size="xl"
              onClick={() => {
                const params = new URLSearchParams();
                if (city) params.set("city", city);
                if (category) params.set("category", category);
                navigate(`/vitrine${params.toString() ? `?${params.toString()}` : ""}`);
              }}
            >
              Buscar
            </Button>
          </div>
          <div className="mt-4">
            <Link to="/vitrine">
              <Button variant="soft" size="lg">Ver todos os estabelecimentos</Button>
            </Link>
          </div>
        </section>

        <section className="py-12">
          <div className="text-center mb-8">
            <h2 className="text-3xl font-bold mb-2">Explore por categoria</h2>
            <p className="text-muted-foreground">Encontre o serviço perfeito para você</p>
          </div>
          <Carousel 
            opts={{ 
              align: "start", 
              loop: true,
              slidesToScroll: 1
            }}
            className="w-full max-w-5xl mx-auto"
          >
            <CarouselContent className="-ml-2 md:-ml-4">
              {supCats.map((cat) => {
                const img = cat.imageUrl || "";
                return (
                  <CarouselItem key={cat.id} className="pl-2 md:pl-4 basis-full sm:basis-1/2 lg:basis-1/3">
                    <div className="h-full">
                      <button
                        onClick={() => navigate(`/vitrine?category=${encodeURIComponent(cat.name)}`)}
                        className="group w-full text-left rounded-xl border bg-card/50 backdrop-blur-sm hover:bg-card hover:shadow-xl hover:shadow-primary/10 transition-all duration-300 overflow-hidden hover-scale"
                        aria-label={`Ver estabelecimentos da categoria ${cat.name}`}
                      >
                        <div className="aspect-[4/3] w-full overflow-hidden rounded-t-xl">
                          <img 
                            src={img} 
                            alt={`Categoria ${cat.name}`} 
                            className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105" 
                            loading="lazy" 
                          />
                        </div>
                        <div className="p-6">
                          <h3 className="font-semibold text-lg mb-1 group-hover:text-primary transition-colors">
                            {cat.name}
                          </h3>
                          <p className="text-sm text-muted-foreground">
                            Ver estabelecimentos disponíveis
                          </p>
                        </div>
                      </button>
                    </div>
                  </CarouselItem>
                );
              })}
            </CarouselContent>
            <div className="flex justify-center gap-4 mt-8">
              <CarouselPrevious className="static translate-y-0" />
              <CarouselNext className="static translate-y-0" />
            </div>
          </Carousel>
        </section>

        {/* Onboarding CTA - Only show if feature flag is enabled */}
        {FeatureFlags.ONBOARDING_SELF_SERVE && (
          <OnboardingCTA />
        )}
      </main>

      {/* Onboarding Dialog */}
      {FeatureFlags.ONBOARDING_SELF_SERVE && (
        <Dialog open={onboardingOpen} onOpenChange={setOnboardingOpen}>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            {onboardingStep === 'form' && (
              <OnboardingForm
                cities={cityOptions}
                businessTypes={businessTypes}
                onSuccess={handleOnboardingSuccess}
                onCancel={handleOnboardingClose}
              />
            )}
            {onboardingStep === 'success' && (
              <OnboardingSuccess
                leadId={leadId}
                onClose={handleOnboardingClose}
              />
            )}
          </DialogContent>
        </Dialog>
      )}

      <footer className="container py-10 text-center text-sm text-muted-foreground">
        <div className="flex flex-col items-center gap-4">
          {loading ? (
            <div className="flex gap-3">
              <div className="h-8 w-32 bg-muted animate-pulse rounded"></div>
              <div className="h-8 w-40 bg-muted animate-pulse rounded"></div>
            </div>
          ) : (supportSettings.whatsapp || supportSettings.email) ? (
            <div className="flex flex-wrap items-center justify-center gap-3">
              {supportSettings.whatsapp && (
                <a href={`https://wa.me/${supportSettings.whatsapp}`} target="_blank" rel="noopener noreferrer">
                  <Button variant="hero" size="sm" aria-label="Suporte via WhatsApp">
                    <MessageCircle className="size-4" /> WhatsApp Suporte
                  </Button>
                </a>
              )}
              {supportSettings.email && (
                <a href={`mailto:${supportSettings.email}`}>
                  <Button variant="soft" size="sm" aria-label="Suporte por e-mail">
                    <Mail className="size-4" /> {supportSettings.email}
                  </Button>
                </a>
              )}
            </div>
          ) : null}
          <div className="text-xs text-muted-foreground/90">
            © {new Date().getFullYear()} LookPro • Plataforma de agendamentos multi-tenant ·
            <Link to="/privacidade" className="ml-1 underline-offset-4 hover:underline">Política de Privacidade</Link>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Index;
