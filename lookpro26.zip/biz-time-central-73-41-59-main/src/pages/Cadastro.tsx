import { useState, useEffect } from "react";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { OnboardingForm } from "@/features/onboarding/OnboardingForm";
import { OnboardingSuccess } from "@/features/onboarding/success/OnboardingSuccess";
import Seo from "@/components/Seo";
import Logo from "@/components/Logo";
import { Button } from "@/components/ui/button";
import { ArrowLeft } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";

// Mock data for cities - in real app this would come from API
const MOCK_CITIES = [
  { id: "1", name: "São Paulo" },
  { id: "2", name: "Rio de Janeiro" },
  { id: "3", name: "Belo Horizonte" },
  { id: "4", name: "Brasília" },
  { id: "5", name: "Salvador" },
  { id: "6", name: "Fortaleza" },
  { id: "7", name: "Curitiba" },
  { id: "8", name: "Recife" },
  { id: "9", name: "Porto Alegre" },
  { id: "10", name: "Goiânia" },
];

export default function Cadastro() {
  const [leadId, setLeadId] = useState<string | null>(null);
  const [businessTypes, setBusinessTypes] = useState<{ id: string; name: string }[]>([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchBusinessTypes = async () => {
      try {
        const { data, error } = await supabase
          .from('categories')
          .select('id, name')
          .eq('active', true)
          .order('name');

        if (error) {
          console.error('Error fetching categories:', error);
          return;
        }

        setBusinessTypes(data || []);
      } catch (error) {
        console.error('Error fetching business types:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchBusinessTypes();
  }, []);

  const handleSuccess = (id: string) => {
    setLeadId(id);
  };

  const handleCancel = () => {
    navigate('/');
  };

  return (
    <>
      <Seo 
        title="Criar App de Agendamentos" 
        description="Crie seu app personalizado de agendamentos em minutos. 7 dias grátis, sem cartão de crédito." 
      />
      
      <div className="min-h-screen bg-gradient-to-br from-background via-background to-muted/20 safe-area-inset">
        {/* Header */}
        <header className="border-b bg-background/80 backdrop-blur-sm sticky top-0 z-40 safe-area-top">
          <div className="container py-3 px-4">
            <div className="flex items-center justify-between">
              <Logo />
              <Button
                variant="ghost"
                onClick={handleCancel}
                className="flex items-center gap-2 text-sm"
                size="sm"
              >
                <ArrowLeft className="h-4 w-4" />
                Voltar
              </Button>
            </div>
          </div>
        </header>

        {/* Main Content */}
        <main className="container py-4 px-4 pb-20 safe-area-bottom">
          <div className="max-w-4xl mx-auto">
            {leadId ? (
              <OnboardingSuccess 
                leadId={leadId} 
                onClose={() => navigate('/')}
              />
            ) : (
              <div className="bg-card/50 backdrop-blur-sm border rounded-xl p-4 md:p-8 shadow-lg">
                {loading ? (
                  <div className="flex items-center justify-center py-8">
                    <div className="text-center">
                      <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-4"></div>
                      <p className="text-muted-foreground">Carregando tipos de negócio...</p>
                    </div>
                  </div>
                ) : (
                  <OnboardingForm
                    cities={MOCK_CITIES}
                    businessTypes={businessTypes}
                    onSuccess={handleSuccess}
                    onCancel={handleCancel}
                  />
                )}
              </div>
            )}
          </div>
        </main>

        {/* Background decoration */}
        <div className="fixed inset-0 -z-10 overflow-hidden pointer-events-none">
          <div className="absolute -top-40 -right-40 w-80 h-80 bg-primary/5 rounded-full blur-3xl" />
          <div className="absolute -bottom-40 -left-40 w-80 h-80 bg-secondary/5 rounded-full blur-3xl" />
        </div>
      </div>
    </>
  );
}