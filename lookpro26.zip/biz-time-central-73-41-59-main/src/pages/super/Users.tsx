import { useState, useEffect } from "react";
import Seo from "@/components/Seo";
import SuperLayout from "@/components/super/SuperLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";
import { Copy, Check, Eye, EyeOff, RefreshCw } from "lucide-react";
import { getUsersAdapter, getEstablishmentsAdapter } from "@/services/superAdminAdapters";
import { supabase } from "@/integrations/supabase/client";
import type { UserRole, User, Establishment } from "@/lib/superStore";

const UsersPage = () => {
  const [open, setOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [form, setForm] = useState<{ name: string; email: string; password: string; role: UserRole; establishmentId: string }>({ name: "", email: "", password: "", role: "admin", establishmentId: "" });
  const [users, setUsers] = useState<User[]>([]);
  const [establishments, setEstablishments] = useState<Establishment[]>([]);
  const [loading, setLoading] = useState(false);
  const [showCredentials, setShowCredentials] = useState(false);
  const [newUserCredentials, setNewUserCredentials] = useState<{ email: string; password: string } | null>(null);
  const [showPassword, setShowPassword] = useState(false);
  const [copiedField, setCopiedField] = useState<string | null>(null);

  const usersAdapter = getUsersAdapter();
  const establishmentsAdapter = getEstablishmentsAdapter();

  const loadData = async () => {
    setLoading(true);
    try {
      const [usersResult, establishmentsResult] = await Promise.all([
        usersAdapter.listUsers(),
        establishmentsAdapter.listEstablishments(),
      ]);
      
      setUsers(Array.isArray(usersResult) ? usersResult : []);
      setEstablishments(Array.isArray(establishmentsResult) ? establishmentsResult : []);
    } catch (error) {
      toast.error("Erro ao carregar dados");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const onSave = async () => {
    if (!form.name || !form.email) return toast.error("Preencha nome e e-mail.");
    if (!form.establishmentId) return toast.error("Selecione um estabelecimento válido.");
    if (!editingId && !form.password) return toast.error("Preencha a senha.");
    
    // Verificar se o estabelecimento existe
    const selectedEstablishment = establishments.find(e => e.id === form.establishmentId);
    if (!selectedEstablishment) {
      return toast.error("Estabelecimento selecionado não é válido.");
    }
    
    setLoading(true);
    try {
      if (editingId) {
        // Update existing user
        await usersAdapter.upsertUser({ id: editingId, ...form });
        toast.success("Usuário atualizado.");
      } else {
        // Create new user with Supabase
        const { data: { session } } = await supabase.auth.getSession();
        if (!session) {
          toast.error("Sessão expirada. Faça login novamente.");
          return;
        }

        const { data, error } = await supabase.functions.invoke('create-user', {
          body: {
            email: form.email,
            password: form.password,
            full_name: form.name,
            role: form.role === "admin" ? "admin" : "professional",
            establishment_id: form.establishmentId
          },
          headers: {
            Authorization: `Bearer ${session.access_token}`
          }
        });

        if (error) {
          console.error("Erro ao criar usuário:", error);
          toast.error("Erro ao criar usuário: " + error.message);
          return;
        }

        if (data?.success) {
          // Armazenar credenciais para exibição
          setNewUserCredentials({ email: form.email, password: form.password });
          setShowCredentials(true);
          setOpen(false);
          toast.success("Usuário criado com sucesso!");
        } else {
          toast.error(data?.error || "Erro ao criar usuário");
          return;
        }
      }
      
      if (!editingId) {
        // Se foi criação de usuário, não fecha o modal ainda - será fechado após mostrar credenciais
        setEditingId(null);
        setForm({ name: "", email: "", password: "", role: "admin", establishmentId: "" });
        await loadData();
      } else {
        // Se foi edição, fecha normalmente
        setOpen(false);
        setEditingId(null);
        setForm({ name: "", email: "", password: "", role: "admin", establishmentId: "" });
        await loadData();
      }
    } catch (error) {
      toast.error("Erro ao salvar usuário");
    } finally {
      setLoading(false);
    }
  };

  const generateRandomPassword = () => {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789@#$%&*!';
    let password = '';
    // Garantir ao menos uma maiúscula, uma minúscula, um número e um símbolo
    password += 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'[Math.floor(Math.random() * 26)];
    password += 'abcdefghijklmnopqrstuvwxyz'[Math.floor(Math.random() * 26)];
    password += '0123456789'[Math.floor(Math.random() * 10)];
    password += '@#$%&*!'[Math.floor(Math.random() * 7)];
    
    // Completar com caracteres aleatórios
    for (let i = 4; i < 12; i++) {
      password += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    
    // Embaralhar a senha
    return password.split('').sort(() => Math.random() - 0.5).join('');
  };

  const copyToClipboard = async (text: string, field: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopiedField(field);
      toast.success(`${field} copiado para área de transferência!`);
      setTimeout(() => setCopiedField(null), 2000);
    } catch (error) {
      toast.error("Erro ao copiar");
    }
  };

  const copyAllCredentials = async () => {
    if (!newUserCredentials) return;
    const text = `Email: ${newUserCredentials.email}\nSenha: ${newUserCredentials.password}`;
    try {
      await navigator.clipboard.writeText(text);
      toast.success("Credenciais completas copiadas!");
    } catch (error) {
      toast.error("Erro ao copiar credenciais");
    }
  };

  const handleCloseCredentials = () => {
    setShowCredentials(false);
    setNewUserCredentials(null);
    setShowPassword(false);
    setCopiedField(null);
  };

  const handleToggleUser = async (id: string) => {
    setLoading(true);
    try {
      await usersAdapter.toggleUserBlock(id);
      toast.success("Status atualizado");
      await loadData();
    } catch (error) {
      toast.error("Erro ao atualizar status");
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteUser = async (id: string) => {
    if (!confirm("Tem certeza que deseja excluir este usuário? Esta ação não pode ser desfeita.")) return;
    
    setLoading(true);
    try {
      console.log('Tentando deletar usuário com ID:', id);
      await usersAdapter.deleteUser(id);
      
      // Forçar recarregamento imediato da lista
      await loadData();
      
      toast.success("Usuário excluído com sucesso");
    } catch (error: any) {
      console.error('Erro ao excluir usuário:', error);
      toast.error(`Erro ao excluir usuário: ${error.message || error}`);
    } finally {
      setLoading(false);
    }
  };

  return (
    <SuperLayout>
      <Seo title="LookPro — Gestão de Usuários" description="Gerencie contas de admins e profissionais." canonicalPath="/dashboard/super/usuarios" />
      <h1 className="text-2xl font-extrabold mb-4">Gestão de Usuários</h1>

      {/* Modal de Credenciais */}
      <Dialog open={showCredentials} onOpenChange={handleCloseCredentials}>
        <DialogContent className="w-[calc(100vw-1rem)] max-w-[95vw] sm:max-w-md max-h-[calc(100svh-env(safe-area-inset-top)-env(safe-area-inset-bottom)-2rem)] overflow-y-auto p-4 sm:p-6"
          onPointerDownOutside={(e) => e.preventDefault()}
          onInteractOutside={(e) => e.preventDefault()}
        >
          <DialogHeader>
            <DialogTitle className="text-center">🎉 Usuário Criado com Sucesso!</DialogTitle>
          </DialogHeader>
          <div className="space-y-6">
            <div className="bg-muted/50 p-4 rounded-lg border-2 border-dashed border-primary/20">
              <p className="text-sm text-muted-foreground mb-4 text-center">
                Copie estas credenciais e envie para o novo usuário:
              </p>
              
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label className="text-xs font-medium text-muted-foreground">EMAIL</Label>
                  <div className="flex items-center gap-2">
                    <Input 
                      value={newUserCredentials?.email || ""} 
                      readOnly 
                      className="font-mono text-sm bg-background"
                    />
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => copyToClipboard(newUserCredentials?.email || "", "Email")}
                    >
                      {copiedField === "Email" ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                    </Button>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label className="text-xs font-medium text-muted-foreground">SENHA</Label>
                  <div className="flex items-center gap-2">
                    <Input 
                      value={newUserCredentials?.password || ""} 
                      type={showPassword ? "text" : "password"}
                      readOnly 
                      className="font-mono text-sm bg-background"
                    />
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => setShowPassword(!showPassword)}
                    >
                      {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => copyToClipboard(newUserCredentials?.password || "", "Senha")}
                    >
                      {copiedField === "Senha" ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                    </Button>
                  </div>
                </div>
              </div>
            </div>

            <div className="flex flex-col gap-2">
              <Button onClick={copyAllCredentials} className="w-full">
                <Copy className="mr-2 h-4 w-4" />
                Copiar Credenciais Completas
              </Button>
              <Button variant="outline" onClick={handleCloseCredentials} className="w-full">
                Fechar
              </Button>
            </div>
            
            <p className="text-xs text-center text-muted-foreground">
              ⚠️ Estas credenciais não serão exibidas novamente
            </p>
          </div>
        </DialogContent>
      </Dialog>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle>Todos os usuários</CardTitle>
          <div className="flex gap-2">
            <Dialog open={open} onOpenChange={setOpen}>
              <DialogTrigger asChild>
                <Button>Novo usuário</Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader><DialogTitle>{editingId ? "Editar" : "Criar"} usuário</DialogTitle></DialogHeader>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2"><Label>Nome</Label><Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></div>
                  <div className="space-y-2"><Label>E-mail</Label><Input type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} /></div>
                  {!editingId && (
                    <div className="space-y-2 md:col-span-2">
                      <Label>Senha</Label>
                      <div className="flex gap-2">
                        <Input 
                          type={showPassword ? "text" : "password"} 
                          value={form.password} 
                          onChange={(e) => setForm({ ...form, password: e.target.value })}
                          placeholder="Digite a senha ou gere uma automaticamente"
                        />
                        <Button
                          type="button"
                          variant="outline"
                          onClick={() => setShowPassword(!showPassword)}
                        >
                          {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                        </Button>
                        <Button
                          type="button"
                          variant="outline"
                          onClick={() => setForm({ ...form, password: generateRandomPassword() })}
                        >
                          <RefreshCw className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  )}
                   <div className="space-y-2">
                     <Label>Empresa <span className="text-red-500">*</span></Label>
                     <Select value={form.establishmentId} onValueChange={(v) => setForm({ ...form, establishmentId: v })} required>
                       <SelectTrigger className={!form.establishmentId ? "border-red-200" : ""}>
                         <SelectValue placeholder="Selecione uma empresa (obrigatório)" />
                       </SelectTrigger>
                       <SelectContent>
                         {establishments.length === 0 && (
                           <SelectItem value="" disabled>Nenhuma empresa disponível</SelectItem>
                         )}
                         {establishments.map((e) => (<SelectItem key={e.id} value={e.id}>{e.name}</SelectItem>))}
                       </SelectContent>
                     </Select>
                     {!form.establishmentId && (
                       <p className="text-xs text-red-500">Selecione um estabelecimento válido</p>
                     )}
                   </div>
                  <div className="space-y-2">
                    <Label>Perfil</Label>
                    <Select value={form.role} onValueChange={(v) => setForm({ ...form, role: v as UserRole })}>
                      <SelectTrigger><SelectValue placeholder="Selecione" /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="admin">Admin</SelectItem>
                        <SelectItem value="pro">Profissional</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="flex justify-end gap-2">
                  <Button variant="outline" onClick={() => setOpen(false)}>Cancelar</Button>
                  <Button onClick={onSave}>{editingId ? "Salvar" : "Criar"}</Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Nome</TableHead>
                  <TableHead>E-mail</TableHead>
                  <TableHead>Empresa</TableHead>
                  <TableHead>Perfil</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Ações</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {users.map((u) => (
                  <TableRow key={u.id}>
                    <TableCell className="font-medium">{u.name}</TableCell>
                    <TableCell>{u.email}</TableCell>
                    <TableCell>{establishments.find((e) => e.id === u.establishmentId)?.name}</TableCell>
                    <TableCell>{u.role}</TableCell>
                    <TableCell>{u.status === "active" ? "Ativo" : "Bloqueado"}</TableCell>
                    <TableCell className="text-right space-x-2">
                      <Button size="sm" variant="outline" onClick={() => { 
                        console.log('Editando usuário:', u.id, u.name);
                        setEditingId(u.id); 
                        setForm({ name: u.name, email: u.email, password: "", role: u.role, establishmentId: u.establishmentId }); 
                        setOpen(true); 
                      }}>Editar</Button>
                      <Button size="sm" onClick={() => { toast.success("Senha resetada"); }}>Resetar senha</Button>
                      <Button size="sm" variant="secondary" onClick={() => handleToggleUser(u.id)} disabled={loading}>{u.status === "active" ? "Bloquear" : "Desbloquear"}</Button>
                      <Button 
                        size="sm" 
                        variant="destructive" 
                        onClick={() => {
                          console.log('Tentando excluir usuário:', u.id, u.email);
                          handleDeleteUser(u.id);
                        }} 
                        disabled={loading}
                      >
                        Excluir
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </SuperLayout>
  );
};

export default UsersPage;
