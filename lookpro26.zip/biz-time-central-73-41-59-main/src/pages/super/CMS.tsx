import { useEffect, useState } from "react";
import Seo from "@/components/Seo";
import SuperLayout from "@/components/super/SuperLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import { readCMS, updateCMS, uploadAsset, type CMSConfig, type CMSFaq } from "@/services/cms";

const CMSPage = () => {
  const [cfg, setCfg] = useState<CMSConfig | null>(null);
  const [assetKey, setAssetKey] = useState("");

  useEffect(() => {
    const loadConfig = async () => {
      try {
        const initial = await readCMS();
        setCfg(initial);
      } catch (e) {
        console.error(e);
      }
    };
    loadConfig();
  }, []);

  const save = async () => {
    if (!cfg) return;
    try {
      await updateCMS(cfg);
      toast.success("Configurações salvas no Supabase");
    } catch (error) {
      toast.error("Erro ao salvar configurações");
      console.error(error);
    }
  };

  const onLogoUpload = async (file?: File | null) => {
    if (!cfg || !file) return;
    try {
      const url = await uploadAsset(file, "logo");
      const next = { ...cfg, brand: { ...cfg.brand, logoUrl: url } };
      setCfg(next);
      toast.success("Logo enviado para o Storage");
    } catch (error) {
      toast.error("Erro ao enviar logo");
      console.error(error);
    }
  };

  const onHeroUpload = async (file?: File | null) => {
    if (!cfg || !file) return;
    try {
      const url = await uploadAsset(file, "hero-image");
      const next = { ...cfg, homepage: { ...cfg.homepage, heroImageUrl: url } };
      setCfg(next);
      toast.success("Imagem do herói enviada para o Storage");
    } catch (error) {
      toast.error("Erro ao enviar imagem");
      console.error(error);
    }
  };

  const onUploadAsset = async (file?: File | null) => {
    if (!cfg || !file || !assetKey.trim()) return toast.error("Informe um nome para o asset.");
    try {
      await uploadAsset(file, assetKey.trim());
      setAssetKey("");
      toast.success("Asset enviado para o Storage");
    } catch (error) {
      toast.error("Erro ao enviar asset");
      console.error(error);
    }
  };

  const addFaq = () => {
    if (!cfg) return;
    const id = crypto.randomUUID();
    const nextFaqs: CMSFaq[] = [...cfg.faqs, { id, q: "Nova pergunta", a: "Resposta" }];
    const next = { ...cfg, faqs: nextFaqs };
    setCfg(next);
  };

  const removeFaq = (id: string) => {
    if (!cfg) return;
    const next = { ...cfg, faqs: cfg.faqs.filter((f) => f.id !== id) };
    setCfg(next);
  };

  if (!cfg) return (
    <SuperLayout>
      <Seo title="LookPro — Conteúdo & Tema (CMS)" description="Gerencie textos, imagens, SEO e tema da PWA." canonicalPath="/dashboard/super/conteudo-tema" />
      <div className="text-muted-foreground">Carregando...</div>
    </SuperLayout>
  );

  return (
    <SuperLayout>
      <Seo title="LookPro — Conteúdo & Tema (CMS)" description="Gerencie textos, imagens, SEO e tema da PWA." canonicalPath="/dashboard/super/conteudo-tema" />
      <h1 className="text-2xl font-extrabold mb-4">Conteúdo & Tema (CMS Supabase)</h1>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <Card>
          <CardHeader><CardTitle>Branding</CardTitle></CardHeader>
          <CardContent className="space-y-3">
            <div className="space-y-1">
              <Label>Nome do app</Label>
              <Input value={cfg.brand.appName} onChange={(e) => setCfg({ ...cfg, brand: { ...cfg.brand, appName: e.target.value } })} />
            </div>
            <div className="space-y-1">
              <Label>Nome curto</Label>
              <Input value={cfg.brand.shortName} onChange={(e) => setCfg({ ...cfg, brand: { ...cfg.brand, shortName: e.target.value } })} />
            </div>
            <div className="space-y-2">
              <Label>Logo</Label>
              {cfg.brand.logoUrl ? (
                <img src={cfg.brand.logoUrl} alt={`${cfg.brand.appName} logo — CMS LookPro`} className="h-16 w-16 rounded border object-cover" loading="lazy" />
              ) : (
                <div className="h-16 w-16 rounded border bg-secondary/40 grid place-items-center text-xs text-muted-foreground">Sem logo</div>
              )}
              <Input type="file" accept="image/*" onChange={(e) => onLogoUpload(e.target.files?.[0])} />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader><CardTitle>Tema & PWA</CardTitle></CardHeader>
          <CardContent className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <div className="space-y-1 md:col-span-2">
              <Label>Cor primária (CSS: hsl(...) ou #hex)</Label>
              <Input value={cfg.theme.primaryColor} onChange={(e) => setCfg({ ...cfg, theme: { ...cfg.theme, primaryColor: e.target.value } })} placeholder="hsl(252 95% 60%)" />
            </div>
            <div className="space-y-1">
              <Label>Theme-color (PWA)</Label>
              <Input value={cfg.theme.themeColor} onChange={(e) => setCfg({ ...cfg, theme: { ...cfg.theme, themeColor: e.target.value } })} placeholder="#0f172a" />
            </div>
            <div className="space-y-1">
              <Label>Background-color (PWA)</Label>
              <Input value={cfg.theme.backgroundColor} onChange={(e) => setCfg({ ...cfg, theme: { ...cfg.theme, backgroundColor: e.target.value } })} placeholder="#0b1220" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader><CardTitle>Página Inicial</CardTitle></CardHeader>
          <CardContent className="space-y-3">
            <div className="space-y-1">
              <Label>Título do herói</Label>
              <Input value={cfg.homepage.heroTitle} onChange={(e) => setCfg({ ...cfg, homepage: { ...cfg.homepage, heroTitle: e.target.value } })} />
            </div>
            <div className="space-y-1">
              <Label>Subtítulo</Label>
              <Textarea value={cfg.homepage.heroSubtitle} onChange={(e) => setCfg({ ...cfg, homepage: { ...cfg.homepage, heroSubtitle: e.target.value } })} />
            </div>
            <div className="space-y-2">
              <Label>Imagem de destaque</Label>
              {cfg.homepage.heroImageUrl ? (
                <img src={cfg.homepage.heroImageUrl} alt="Imagem destaque da homepage — CMS LookPro" className="w-full h-32 object-cover rounded border" loading="lazy" />
              ) : (
                <div className="w-full h-32 rounded border bg-secondary/40 grid place-items-center text-xs text-muted-foreground">Sem imagem</div>
              )}
              <Input type="file" accept="image/*" onChange={(e) => onHeroUpload(e.target.files?.[0])} />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader><CardTitle>SEO Padrão</CardTitle></CardHeader>
          <CardContent className="space-y-3">
            <div className="space-y-1">
              <Label>Título padrão</Label>
              <Input value={cfg.seo.defaultTitle} onChange={(e) => setCfg({ ...cfg, seo: { ...cfg.seo, defaultTitle: e.target.value } })} />
            </div>
            <div className="space-y-1">
              <Label>Descrição padrão</Label>
              <Textarea value={cfg.seo.defaultDescription} onChange={(e) => setCfg({ ...cfg, seo: { ...cfg.seo, defaultDescription: e.target.value } })} />
            </div>
          </CardContent>
        </Card>

        <Card className="lg:col-span-2">
          <CardHeader><CardTitle>FAQs</CardTitle></CardHeader>
          <CardContent className="space-y-3">
            {cfg.faqs.map((f) => (
              <div key={f.id} className="grid grid-cols-1 md:grid-cols-12 gap-3 items-start">
                <div className="md:col-span-5 space-y-1">
                  <Label>Pergunta</Label>
                  <Input value={f.q} onChange={(e) => setCfg({ ...cfg, faqs: cfg.faqs.map((x) => x.id === f.id ? { ...x, q: e.target.value } : x) })} />
                </div>
                <div className="md:col-span-6 space-y-1">
                  <Label>Resposta</Label>
                  <Textarea value={f.a} onChange={(e) => setCfg({ ...cfg, faqs: cfg.faqs.map((x) => x.id === f.id ? { ...x, a: e.target.value } : x) })} />
                </div>
                <div className="md:col-span-1 pt-6 flex justify-end">
                  <Button variant="destructive" onClick={() => removeFaq(f.id)}>Remover</Button>
                </div>
              </div>
            ))}
            <Button variant="secondary" onClick={addFaq}>Adicionar FAQ</Button>
          </CardContent>
        </Card>

        <Card className="lg:col-span-2">
          <CardHeader><CardTitle>Uploads Centrais (Assets)</CardTitle></CardHeader>
          <CardContent className="space-y-3">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3 items-end">
              <div className="space-y-1 md:col-span-1">
                <Label>Nome/Chave do asset</Label>
                <Input placeholder="ex: homepageBanner" value={assetKey} onChange={(e) => setAssetKey(e.target.value)} />
              </div>
              <div className="md:col-span-2">
                <Input type="file" accept="image/*" onChange={(e) => onUploadAsset(e.target.files?.[0])} />
              </div>
            </div>
            <div className="text-sm text-muted-foreground">Assets são salvos no Storage do Supabase</div>
          </CardContent>
        </Card>
      </div>

      <div className="mt-4 flex justify-end">
        <Button onClick={save}>Salvar tudo</Button>
      </div>
    </SuperLayout>
  );
};

export default CMSPage;