import { FormEvent, useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import Seo from "@/components/Seo";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { toast } from "sonner";
import { ArrowLeft } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";

const SuperLogin = () => {
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    // Check if already authenticated
    (async () => {
      const { data } = await supabase.auth.getUser();
      if (data?.user) {
        const { data: profile } = await supabase
          .from('profiles')
          .select('role')
          .eq('user_id', data.user.id)
          .single();
          
        if (profile?.role === 'super_admin') {
          navigate("/dashboard/super", { replace: true });
        }
      }
    })();
  }, [navigate]);


  const onSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (loading) return;
    setLoading(true);
    
    try {
      const { data, error } = await supabase.auth.signInWithPassword({
        email,
        password
      });

      if (error) throw error;

      if (data.user) {
        // Verify super admin role
        const { data: profile } = await supabase
          .from('profiles')
          .select('role')
          .eq('user_id', data.user.id)
          .single();

        if (profile?.role !== 'super_admin') {
          await supabase.auth.signOut();
          throw new Error('Acesso negado. Apenas Super Admins podem acessar.');
        }

        toast.success("Login realizado com sucesso.");
        navigate("/dashboard/super", { replace: true });
      }
    } catch (err: any) {
      toast.error(err?.message ?? "Credenciais inválidas para Super Admin.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center py-10">
      <Seo
        title="LookPro — Login do Super Admin"
        description="Acesso exclusivo ao painel global do Super Admin da LookPro."
        canonicalPath="/super/login"
      />
      <main className="container max-w-md">
        <Card className="shadow-sm">
          <CardHeader className="flex items-center justify-between">
            <CardTitle className="text-2xl font-extrabold">Entrar como Super Admin</CardTitle>
            <Button asChild variant="ghost" size="sm">
              <Link to="/"><span className="inline-flex items-center gap-1"><ArrowLeft className="size-4" /> Voltar</span></Link>
            </Button>
          </CardHeader>
          <CardContent>
            <form onSubmit={onSubmit} className="space-y-5">
              <div className="space-y-2">
                <Label htmlFor="email">E-mail</Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="super@lookpro.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="password">Senha</Label>
                <Input
                  id="password"
                  type="password"
                  placeholder="••••••"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                />
              </div>
              <Button type="submit" className="w-full" disabled={loading}>
                {loading ? "Entrando..." : "Entrar"}
              </Button>
              
              <div className="text-center">
                <Link to="/" className="text-sm underline underline-offset-4">Voltar ao início</Link>
              </div>
            </form>
          </CardContent>
        </Card>
      </main>
    </div>
  );
};

export default SuperLogin;