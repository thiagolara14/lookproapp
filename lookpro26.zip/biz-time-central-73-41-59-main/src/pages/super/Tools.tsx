import Seo from "@/components/Seo";
import SuperLayout from "@/components/super/SuperLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { getGlobalSettings, updateGlobalSetting, createGlobalSetting } from "@/services/globalSettings";

const ToolsPage = () => {
  const [flags, setFlags] = useState<Record<string, boolean>>({ betaReports: true, newDashboard: false });
  const [phrases, setPhrases] = useState({ welcome: "Bem-vindo ao LookPro", maintenance: "Estamos em manutenção" });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadSettings();
  }, []);

  const loadSettings = async () => {
    try {
      const settings = await getGlobalSettings();
      setFlags({
        betaReports: settings.flag_betaReports === 'true',
        newDashboard: settings.flag_newDashboard === 'true'
      });
      setPhrases({
        welcome: settings.content_welcome || "Bem-vindo ao LookPro",
        maintenance: settings.content_maintenance || "Estamos em manutenção"
      });
    } catch (error) {
      console.error('Error loading settings:', error);
    } finally {
      setLoading(false);
    }
  };

  const saveFlags = async () => {
    try {
      await Promise.all([
        updateOrCreate('flag_betaReports', flags.betaReports.toString()),
        updateOrCreate('flag_newDashboard', flags.newDashboard.toString())
      ]);
      toast.success("Flags salvas");
    } catch (error) {
      toast.error("Erro ao salvar flags");
    }
  };

  const saveContent = async () => {
    try {
      await Promise.all([
        updateOrCreate('content_welcome', phrases.welcome),
        updateOrCreate('content_maintenance', phrases.maintenance)
      ]);
      toast.success("Conteúdo salvo");
    } catch (error) {
      toast.error("Erro ao salvar conteúdo");
    }
  };

  const updateOrCreate = async (key: string, value: string) => {
    try {
      await updateGlobalSetting(key, value);
    } catch (error) {
      // If update fails, try creating
      await createGlobalSetting(key, value);
    }
  };

  return (
    <SuperLayout>
      <Seo title="LookPro — Ferramentas" description="Experimentos, notificações e conteúdos institucionais." canonicalPath="/dashboard/super/ferramentas" />
      <h1 className="text-2xl font-extrabold mb-4">Ferramentas e Experimentos</h1>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <Card>
          <CardHeader><CardTitle>Recursos em beta</CardTitle></CardHeader>
          <CardContent className="space-y-3">
            {Object.entries(flags).map(([k, v]) => (
              <label key={k} className="flex items-center gap-3">
                <input type="checkbox" checked={v} onChange={(e) => setFlags({ ...flags, [k]: e.target.checked })} />
                <span>{k}</span>
              </label>
            ))}
            <Button onClick={saveFlags}>Salvar</Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader><CardTitle>Notificações</CardTitle></CardHeader>
          <CardContent className="space-y-3">
            <p className="text-sm text-muted-foreground">Sistema de notificações em desenvolvimento</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader><CardTitle>Frases padrão / Conteúdo institucional</CardTitle></CardHeader>
          <CardContent className="space-y-3">
            <div className="space-y-1"><Label>Boas-vindas</Label><Input value={phrases.welcome} onChange={(e) => setPhrases({ ...phrases, welcome: e.target.value })} /></div>
            <div className="space-y-1"><Label>Manutenção</Label><Input value={phrases.maintenance} onChange={(e) => setPhrases({ ...phrases, maintenance: e.target.value })} /></div>
            <Button onClick={saveContent}>Salvar</Button>
          </CardContent>
        </Card>
      </div>
    </SuperLayout>
  );
};

export default ToolsPage;
