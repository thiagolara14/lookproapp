import { useMemo, useState, useEffect } from "react";
import Seo from "@/components/Seo";
import SuperLayout from "@/components/super/SuperLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { getCitiesAdapter } from "@/services/superAdminAdapters";
import type { City } from "@/lib/superStore";

const CitiesPage = () => {
  const [open, setOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [name, setName] = useState("");
  const [cities, setCities] = useState<City[]>([]);
  const [loading, setLoading] = useState(false);

  const citiesAdapter = getCitiesAdapter();

  const loadCities = async () => {
    setLoading(true);
    try {
      const result = await citiesAdapter.listCities();
      setCities(Array.isArray(result) ? result : []);
    } catch (error) {
      toast.error("Erro ao carregar cidades");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadCities();
  }, []);

  const onSave = async () => {
    if (!name) return toast.error("Informe um nome.");
    setLoading(true);
    try {
      if (editingId) {
        await citiesAdapter.updateCity(editingId, name);
      } else {
        await citiesAdapter.addCity(name);
      }
      toast.success(editingId ? "Cidade atualizada." : "Cidade criada.");
      setOpen(false);
      setEditingId(null);
      setName("");
      await loadCities();
    } catch (error) {
      toast.error("Erro ao salvar cidade");
    } finally {
      setLoading(false);
    }
  };

  const handleToggleCity = async (id: string) => {
    setLoading(true);
    try {
      await citiesAdapter.toggleCity(id);
      toast.success("Visibilidade atualizada");
      await loadCities();
    } catch (error) {
      toast.error("Erro ao atualizar visibilidade");
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteCity = async (id: string) => {
    if (!confirm("Excluir cidade?")) return;
    setLoading(true);
    try {
      await citiesAdapter.deleteCity(id);
      toast.success("Cidade excluída");
      await loadCities();
    } catch (error) {
      toast.error("Erro ao excluir cidade");
    } finally {
      setLoading(false);
    }
  };

  return (
    <SuperLayout>
      <Seo title="LookPro — Cidades" description="Defina e gerencie cidades disponíveis." canonicalPath="/dashboard/super/cidades" />
      <h1 className="text-2xl font-extrabold mb-4">Gestão de Cidades</h1>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle>Lista de cidades</CardTitle>
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild><Button>Nova cidade</Button></DialogTrigger>
            <DialogContent>
              <DialogHeader><DialogTitle>{editingId ? "Editar" : "Criar"} cidade</DialogTitle></DialogHeader>
              <div className="space-y-2">
                <Label>Nome</Label>
                <Input value={name} onChange={(e) => setName(e.target.value)} />
              </div>
              <div className="flex justify-end gap-2 mt-4">
                <Button variant="outline" onClick={() => setOpen(false)}>Cancelar</Button>
                <Button onClick={onSave}>{editingId ? "Salvar" : "Criar"}</Button>
              </div>
            </DialogContent>
          </Dialog>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow><TableHead>Nome</TableHead><TableHead>Visível</TableHead><TableHead className="text-right">Ações</TableHead></TableRow>
            </TableHeader>
            <TableBody>
              {cities.map((c) => (
                <TableRow key={c.id}>
                  <TableCell>{c.name}</TableCell>
                  <TableCell>{c.visible ? "Sim" : "Não"}</TableCell>
                  <TableCell className="text-right space-x-2">
                    <Button size="sm" variant="outline" onClick={() => { setEditingId(c.id); setName(c.name); setOpen(true); }}>Editar</Button>
                    <Button size="sm" variant="secondary" onClick={() => handleToggleCity(c.id)} disabled={loading}>{c.visible ? "Ocultar" : "Reexibir"}</Button>
                    <Button size="sm" variant="destructive" onClick={() => handleDeleteCity(c.id)} disabled={loading}>Excluir</Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </SuperLayout>
  );
};

export default CitiesPage;
