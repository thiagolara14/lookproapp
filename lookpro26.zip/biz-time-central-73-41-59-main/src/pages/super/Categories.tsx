import { useState, useEffect } from "react";
import Seo from "@/components/Seo";
import SuperLayout from "@/components/super/SuperLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { getCategoriesAdapter } from "@/services/superAdminAdapters";
import type { Category } from "@/lib/superStore";
import { ensureImageFitsRules } from "@/lib/image";

const CategoriesPage = () => {
  const [open, setOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [name, setName] = useState("");
  const [imagePreview, setImagePreview] = useState<string>("");
  const [file, setFile] = useState<File | null>(null);
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(false);

  const categoriesAdapter = getCategoriesAdapter();

  const loadCategories = async () => {
    setLoading(true);
    try {
      const result = await categoriesAdapter.listCategories();
      setCategories(Array.isArray(result) ? result : []);
    } catch {
      toast.error("Erro ao carregar categorias");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { loadCategories(); }, []);

  const onFileChange: React.ChangeEventHandler<HTMLInputElement> = (e) => {
    const f = e.target.files?.[0] || null;
    setFile(f);
    setImagePreview(f ? URL.createObjectURL(f) : "");
  };

  const reset = () => {
    setOpen(false);
    setEditingId(null);
    setName("");
    setFile(null);
    setImagePreview("");
  };

  const onSave = async () => {
    if (!name.trim()) return toast.error("Informe um nome.");
    setLoading(true);
    try {
      if (editingId) {
        // UPDATE
        await categoriesAdapter.updateCategory(editingId, name.trim());
      } else {
        // CREATE
        await categoriesAdapter.addCategory(name.trim());
      }

      toast.success(editingId ? "Categoria atualizada." : "Categoria criada.");
      reset();
      await loadCategories();
    } catch (e: any) {
      console.error("handleSave error", e);
      toast.error(e?.message || "Erro ao salvar categoria");
    } finally { setLoading(false); }
  };

  const handleDeleteCategory = async (id: string) => {
    if (!confirm("Excluir categoria?")) return;
    setLoading(true);
    try {
      await categoriesAdapter.deleteCategory(id);
      toast.success("Categoria excluída");
      await loadCategories();
    } catch (error) {
      toast.error("Erro ao excluir categoria");
    } finally {
      setLoading(false);
    }
  };

  return (
    <SuperLayout>
      <Seo title="LookPro — Categorias" description="Gerencie os tipos de estabelecimentos." canonicalPath="/dashboard/super/categorias" />
      <h1 className="text-2xl font-extrabold mb-4">Categorias e Tipos de Negócio</h1>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle>Lista de categorias</CardTitle>
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild><Button>Novo tipo</Button></DialogTrigger>
            <DialogContent>
              <DialogHeader><DialogTitle>{editingId ? "Editar" : "Criar"} tipo</DialogTitle></DialogHeader>
              <div className="space-y-3">
                <div className="space-y-2">
                  <Label>Nome</Label>
                  <Input value={name} onChange={(e) => setName(e.target.value)} />
                </div>
                <div className="space-y-2">
                  <Label>Imagem (opcional)</Label>
                  {imagePreview && (
                    <img src={imagePreview} alt="Prévia da categoria" className="w-full h-32 object-cover rounded-md border" />
                  )}
                  <Input type="file" accept="image/*" onChange={onFileChange} />
                  <p className="text-xs text-muted-foreground">
                    Aceitamos qualquer imagem — convertida/comprimida automaticamente para ≤ 5MB.
                  </p>
                </div>
              </div>
              <div className="flex justify-end gap-2 mt-4">
                <Button variant="outline" onClick={reset}>Cancelar</Button>
                <Button onClick={onSave} disabled={loading}>{editingId ? "Salvar" : "Criar"}</Button>
              </div>
            </DialogContent>
          </Dialog>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow><TableHead>Imagem</TableHead><TableHead>Nome</TableHead><TableHead className="text-right">Ações</TableHead></TableRow>
            </TableHeader>
            <TableBody>
              {categories.map((c) => (
                <TableRow key={c.id}>
                  <TableCell className="w-[96px]">
                    {c.imageUrl ? (
                      <img src={c.imageUrl} alt={`Imagem da categoria ${c.name}`} className="w-16 h-12 object-cover rounded border" />
                    ) : (
                      <div className="w-16 h-12 rounded border bg-secondary/40 grid place-items-center text-xs text-muted-foreground">Sem imagem</div>
                    )}
                  </TableCell>
                  <TableCell>{c.name}</TableCell>
                  <TableCell className="text-right space-x-2">
                    <Button size="sm" variant="outline" onClick={() => { setEditingId(c.id); setName(c.name); setImagePreview(c.imageUrl ?? ""); setOpen(true); }}>Editar</Button>
                    <Button size="sm" variant="destructive" onClick={() => handleDeleteCategory(c.id)} disabled={loading}>Excluir</Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </SuperLayout>
  );
};

export default CategoriesPage;