import { useState, useEffect } from "react";
import Seo from "@/components/Seo";
import SuperLayout from "@/components/super/SuperLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { toast } from "sonner";
import { getCitiesAdapter, getCategoriesAdapter, getPlansAdapter, getEstablishmentsAdapter } from "@/services/superAdminAdapters";
import MultiCategorySelect from "@/components/super/MultiCategorySelect";
import type { EstablishmentStatus, Establishment, City, Category, Plan } from "@/lib/superStore";
import { readFileAsDataURL } from "@/lib/file";

const EstablishmentsPage = () => {
  const [open, setOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [form, setForm] = useState<{ name: string; cityId: string; categoryId: string; categoriesIds: string[]; status: EstablishmentStatus; logo: string; planId: string; hoursStart: string; hoursEnd: string }>(
    { name: "", cityId: "", categoryId: "", categoriesIds: [], status: "active", logo: "", planId: "", hoursStart: "", hoursEnd: "" }
  );
  const [establishments, setEstablishments] = useState<Establishment[]>([]);
  const [cities, setCities] = useState<City[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [plans, setPlans] = useState<Plan[]>([]);
  const [loading, setLoading] = useState(false);

  const establishmentsAdapter = getEstablishmentsAdapter();
  const citiesAdapter = getCitiesAdapter();
  const categoriesAdapter = getCategoriesAdapter();
  const plansAdapter = getPlansAdapter();

  const loadData = async () => {
    setLoading(true);
    try {
      const [estResult, citiesResult, categoriesResult, plansResult] = await Promise.all([
        establishmentsAdapter.listEstablishments(),
        citiesAdapter.listCities(),
        categoriesAdapter.listCategories(),
        plansAdapter.listPlans(),
      ]);
      
      setEstablishments(Array.isArray(estResult) ? estResult : []);
      setCities(Array.isArray(citiesResult) ? citiesResult : []);
      setCategories(Array.isArray(categoriesResult) ? categoriesResult : []);
      setPlans(Array.isArray(plansResult) ? plansResult : []);
    } catch (error) {
      toast.error("Erro ao carregar dados");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const resetForm = () =>
    setForm({
      name: "",
      cityId: cities[0]?.id ?? "",
      categoryId: categories[0]?.id ?? "",
      categoriesIds: [],
      status: "active",
      logo: "",
      planId: plans[0]?.id ?? "",
      hoursStart: "",
      hoursEnd: "",
    });

  const onSave = async () => {
    const categoriesToUse = form.categoriesIds.length > 0 ? form.categoriesIds : (form.categoryId ? [form.categoryId] : []);
    if (!form.name || !form.cityId || categoriesToUse.length === 0) {
      return toast.error("Preencha os campos obrigatórios (nome, cidade e pelo menos uma categoria).");
    }
    
    setLoading(true);
    try {
      await establishmentsAdapter.upsertEstablishment({
        id: editingId ?? undefined,
        name: form.name,
        cityId: form.cityId,
        categoryId: form.categoryId,
        categoriesIds: categoriesToUse,
        status: form.status,
        logo: form.logo,
        planId: form.planId || undefined,
        workingHours: { start: form.hoursStart, end: form.hoursEnd },
      });
      toast.success(editingId ? "Estabelecimento atualizado." : "Estabelecimento criado.");
      setOpen(false);
      setEditingId(null);
      resetForm();
      await loadData();
    } catch (error) {
      toast.error("Erro ao salvar estabelecimento");
    } finally {
      setLoading(false);
    }
  };

  const handleToggleEstablishment = async (id: string) => {
    setLoading(true);
    try {
      await establishmentsAdapter.toggleEstablishment(id);
      toast.success("Status atualizado.");
      await loadData();
    } catch (error) {
      toast.error("Erro ao atualizar status");
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteEstablishment = async (id: string) => {
    if (!confirm("Excluir permanentemente?")) return;
    setLoading(true);
    try {
      await establishmentsAdapter.deleteEstablishment(id);
      toast.success("Estabelecimento excluído.");
      await loadData();
    } catch (error) {
      toast.error("Erro ao excluir estabelecimento");
    } finally {
      setLoading(false);
    }
  };

  const handleImpersonate = (establishmentId: string) => {
    const establishment = establishments.find(e => e.id === establishmentId);
    if (!establishment) return;
    
    // Navigate directly to admin dashboard for the establishment
    toast.success("Entrando como admin do estabelecimento...");
    window.location.href = `/dashboard/admin?est=${establishment.id}`;
  };

  return (
    <SuperLayout>
      <Seo title="LookPro — Gestão de Estabelecimentos" description="Crie, edite, ative/desative, exclua e faça impersonate de empresas." canonicalPath="/dashboard/super/estabelecimentos" />
      <h1 className="text-2xl font-extrabold mb-4">Gestão de Estabelecimentos</h1>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle>Todos os estabelecimentos</CardTitle>
          <Dialog open={open} onOpenChange={(o) => { setOpen(o); if (!o) { setEditingId(null); resetForm(); } }}>
            <DialogTrigger asChild>
              <Button onClick={() => { resetForm(); setEditingId(null); }}>Novo estabelecimento</Button>
            </DialogTrigger>
            <DialogContent className="w-[calc(100vw-1rem)] max-w-[95vw] sm:max-w-xl max-h-[calc(100svh-env(safe-area-inset-top)-env(safe-area-inset-bottom)-2rem)] overflow-y-auto p-4 sm:p-6">
              <DialogHeader>
                <DialogTitle>{editingId ? "Editar" : "Criar"} estabelecimento</DialogTitle>
              </DialogHeader>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Nome</Label>
                  <Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
                </div>
                <div className="space-y-2">
                  <Label>Logo (URL)</Label>
                  <Input value={form.logo} onChange={(e) => setForm({ ...form, logo: e.target.value })} />
                  <Label>Enviar logo</Label>
                  <Input type="file" accept="image/*" capture="environment" onChange={async (e) => { const f = e.target.files?.[0]; if (!f) return; const url = await readFileAsDataURL(f); setForm({ ...form, logo: url }); }} />
                </div>
                <div className="space-y-2">
                  <Label>Cidade</Label>
                  <Select value={form.cityId} onValueChange={(v) => setForm({ ...form, cityId: v })}>
                    <SelectTrigger><SelectValue placeholder="Selecione" /></SelectTrigger>
                    <SelectContent>
                      {cities.map((c) => (<SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="md:col-span-2">
                  <MultiCategorySelect
                    categories={categories}
                    selectedCategoryIds={form.categoriesIds}
                    primaryCategoryId={form.categoryId}
                    onSelectionChange={(categoryIds, primaryId) => {
                      setForm({ ...form, categoriesIds: categoryIds, categoryId: primaryId });
                    }}
                    maxCategories={3}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Plano</Label>
                  <Select value={form.planId} onValueChange={(v) => setForm({ ...form, planId: v })}>
                    <SelectTrigger><SelectValue placeholder="Selecione" /></SelectTrigger>
                    <SelectContent>
                      {plans.map((p) => (<SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Abre</Label>
                  <Input type="time" value={form.hoursStart} onChange={(e) => setForm({ ...form, hoursStart: e.target.value })} />
                </div>
                <div className="space-y-2">
                  <Label>Fecha</Label>
                  <Input type="time" value={form.hoursEnd} onChange={(e) => setForm({ ...form, hoursEnd: e.target.value })} />
                </div>
                <div className="space-y-2 flex items-center gap-3">
                  <Label>Status</Label>
                  <Switch checked={form.status === "active"} onCheckedChange={(v) => setForm({ ...form, status: v ? "active" : "inactive" })} />
                </div>
              </div>
              <div className="flex justify-end gap-2">
                <Button variant="outline" onClick={() => setOpen(false)}>Cancelar</Button>
                <Button onClick={onSave}>{editingId ? "Salvar" : "Criar"}</Button>
              </div>
            </DialogContent>
          </Dialog>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Nome</TableHead>
                  <TableHead>Cidade</TableHead>
                  <TableHead>Tipo</TableHead>
                  <TableHead>Plano</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Último acesso</TableHead>
                  <TableHead className="text-right">Ações</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {establishments.map((e) => (
                  <TableRow key={e.id}>
                    <TableCell className="font-medium flex items-center gap-2">
                      {e.logo && <img src={e.logo} alt={`Logo ${e.name}`} className="h-6 w-6 rounded" loading="lazy" />}
                      {e.name}
                    </TableCell>
                    <TableCell>{cities.find((c) => c.id === e.cityId)?.name}</TableCell>
                    <TableCell>{categories.find((c) => c.id === e.categoryId)?.name}</TableCell>
                    <TableCell>{plans.find((p) => p.id === e.planId)?.name ?? "—"}</TableCell>
                    <TableCell>{e.status === "active" ? "Ativo" : "Inativo"}</TableCell>
                    <TableCell>{e.lastAccessAt ? new Date(e.lastAccessAt).toLocaleString() : "—"}</TableCell>
                    <TableCell className="text-right space-x-2">
                      <Button size="sm" variant="outline" onClick={() => { 
                        setEditingId(e.id); 
                        setForm({ 
                          name: e.name, 
                          cityId: e.cityId, 
                          categoryId: e.categoryId, 
                          categoriesIds: e.categoryId ? [e.categoryId] : [], 
                          status: e.status, 
                          logo: e.logo ?? "", 
                          planId: e.planId ?? "", 
                          hoursStart: e.workingHours?.start ?? "", 
                          hoursEnd: e.workingHours?.end ?? "" 
                        }); 
                        setOpen(true); 
                      }}>Editar</Button>
                      <Button size="sm" variant="secondary" onClick={() => handleToggleEstablishment(e.id)} disabled={loading}>{e.status === "active" ? "Desativar" : "Ativar"}</Button>
                      <Button size="sm" onClick={() => handleImpersonate(e.id)}>Impersonate</Button>
                      <Button size="sm" variant="destructive" onClick={() => handleDeleteEstablishment(e.id)} disabled={loading}>Excluir</Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </SuperLayout>
  );
};

export default EstablishmentsPage;
