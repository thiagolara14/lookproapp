import Seo from "@/components/Seo";
import SuperLayout from "@/components/super/SuperLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { exportToCsv } from "@/utils/csvExport";
import { getCitiesAdapter, getCategoriesAdapter, getPlansAdapter } from "@/services/superAdminAdapters";
import { getAppointmentPrice, listAllAppointments } from "@/services/appointments";
import { useMemo, useState, useEffect } from "react";

const ReportsPage = () => {
  const [period, setPeriod] = useState("30");
  const [cityId, setCityId] = useState<string | "all">("all");
  const [categoryId, setCategoryId] = useState<string | "all">("all");
  const [cities, setCities] = useState<any[]>([]);
  const [categories, setCategories] = useState<any[]>([]);
  const [establishments, setEstablishments] = useState<any[]>([]);
  const [plans, setPlans] = useState<any[]>([]);

  useEffect(() => {
    const loadData = async () => {
      try {
        const [citiesData, categoriesData, plansData] = await Promise.all([
          getCitiesAdapter().listCities(),
          getCategoriesAdapter().listCategories(),
          getPlansAdapter().listPlans()
        ]);
        
        setCities(Array.isArray(citiesData) ? citiesData : []);
        setCategories(Array.isArray(categoriesData) ? categoriesData : []);
        setEstablishments([]); // Empty array - to be loaded from Supabase
        setPlans(Array.isArray(plansData) ? plansData : []);
      } catch (error) {
        console.error('Error loading data for reports:', error);
        setCities([]);
        setCategories([]);
        setEstablishments([]);
        setPlans([]);
      }
    };
    
    loadData();
  }, []);

  const filterByPeriod = (iso: string) => {
    const days = Number(period);
    const d = new Date();
    const from = new Date();
    from.setDate(d.getDate() - days);
    const date = new Date(iso);
    return date >= from;
  };

  const exportBookings = async () => {
    const appts = await listAllAppointments();
    const cityById = new Map(cities.map(c => [c.id, c.name]));
    const categoryById = new Map(categories.map(c => [c.id, c.name]));
    
    const rows = appts
      .filter((a) => filterByPeriod(`${a.date}T${a.time}:00`))
      .filter((a) => {
        if (cityId === "all") return true;
        const est = establishments.find((e) => e.id === a.establishmentId);
        return est ? cityById.get(est.cityId) === cityId : false;
      })
      .filter((a) => {
        if (categoryId === "all") return true;
        const est = establishments.find((e) => e.id === a.establishmentId);
        return est ? categoryById.get(est.categoryId) === categoryId : false;
      })
      .map((a) => {
        const est = establishments.find((e) => e.id === a.establishmentId);
        return {
          date: `${a.date} ${a.time}`,
          establishment: est?.name || 'N/A',
          city: est ? cityById.get(est.cityId) || 'N/A' : 'N/A',
          type: est ? categoryById.get(est.categoryId) || 'N/A' : 'N/A',
          price: "0.00", // TODO: Fix async price calculation
          clientName: a.clientName,
          status: a.status,
        };
      });
    exportToCsv(rows as any, "relatorio-agendamentos.csv");
  };

  const exportEstablishments = () => {
    const cityById = new Map(cities.map(c => [c.id, c.name]));
    const categoryById = new Map(categories.map(c => [c.id, c.name]));
    const planById = new Map(plans.map(p => [p.id, p.name]));
    
    const rows = establishments.map((e) => ({
      name: e.name || 'N/A',
      city: cityById.get(e.cityId) || 'N/A',
      type: categoryById.get(e.categoryId) || 'N/A',
      status: e.status || 'inactive',
      plan: planById.get(e.planId) || 'Sem plano',
      lastAccessAt: e.lastAccessAt || "",
    }));
    exportToCsv(rows as any, "relatorio-empresas.csv");
  };

  const exportFinancial = async () => {
    const appts = await listAllAppointments();
    const cityById = new Map(cities.map(c => [c.id, c.name]));
    const categoryById = new Map(categories.map(c => [c.id, c.name]));
    
    const rows = appts
      .filter((a) => filterByPeriod(`${a.date}T${a.time}:00`))
      .filter((a) => a.status === "concluído")
      .filter((a) => {
        if (cityId === "all") return true;
        const est = establishments.find((e) => e.id === a.establishmentId);
        return est ? cityById.get(est.cityId) === cityId : false;
      })
      .filter((a) => {
        if (categoryId === "all") return true;
        const est = establishments.find((e) => e.id === a.establishmentId);
        return est ? categoryById.get(est.categoryId) === categoryId : false;
      })
      .map((a) => {
        const est = establishments.find((e) => e.id === a.establishmentId);
        return {
          date: `${a.date} ${a.time}`,
          establishment: est?.name || 'N/A',
          value: "0.00", // TODO: Fix async price calculation
        };
      });
    exportToCsv(rows as any, "relatorio-financeiro.csv");
  };

  const exportFinancialPlans = () => {
    const ests = establishments.filter((e) => e.status === "active");
    const planById = new Map(plans.map((p) => [p.id, p]));

    type Row = { plan: string; period: string; price: string; ativos: number; MRR: string; ARR: string };
    const agg = new Map<string, { name: string; period?: string; price: number; active: number; mrr: number }>();

    ests.forEach((e) => {
      const plan = e.planId ? planById.get(e.planId) : undefined;
      const key = plan ? plan.id : "none";
      const estMRR = plan ? (plan.period === "monthly" ? plan.price : plan.price / 12) : 0;
      if (!agg.has(key)) {
        agg.set(key, { name: plan ? plan.name : "Sem plano", period: plan ? (plan.period === "monthly" ? "Mensal" : "Anual") : undefined, price: plan?.price ?? 0, active: 0, mrr: 0 });
      }
      const a = agg.get(key)!;
      a.active += 1;
      a.mrr += estMRR;
    });

    const rows: Row[] = Array.from(agg.values()).map((v) => ({
      plan: v.name,
      period: v.period ?? "—",
      price: v.price.toFixed(2),
      ativos: v.active,
      MRR: v.mrr.toFixed(2),
      ARR: (v.mrr * 12).toFixed(2),
    }));

    exportToCsv(rows as any, "relatorio-financeiro-planos.csv");
  };
  return (
    <SuperLayout>
      <Seo title="LookPro — Relatórios" description="Gere e exporte relatórios." canonicalPath="/dashboard/super/relatorios" />
      <h1 className="text-2xl font-extrabold mb-4">Relatórios e Exportações</h1>

      <Card>
        <CardHeader><CardTitle>Filtros</CardTitle></CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="space-y-1"><Label>Período (dias)</Label><Input value={period} onChange={(e) => setPeriod(e.target.value)} type="number" min={1} /></div>
            <div className="space-y-1">
              <Label>Cidade</Label>
              <Select value={cityId} onValueChange={(v) => setCityId(v as any)}>
                <SelectTrigger><SelectValue placeholder="Todas" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todas</SelectItem>
                  {cities.map((city) => (<SelectItem key={city.id} value={city.name}>{city.name}</SelectItem>))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1">
              <Label>Categoria</Label>
              <Select value={categoryId} onValueChange={(v) => setCategoryId(v as any)}>
                <SelectTrigger><SelectValue placeholder="Todas" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todas</SelectItem>
                  {categories.map((category) => (<SelectItem key={category.id} value={category.name}>{category.name}</SelectItem>))}
                </SelectContent>
              </Select>
            </div>
          </div>
          <div className="flex flex-wrap gap-2">
            <Button onClick={exportBookings}>Exportar agendamentos (CSV)</Button>
            <Button variant="secondary" onClick={exportEstablishments}>Exportar empresas (CSV)</Button>
            <Button variant="outline" onClick={exportFinancial}>Relatório financeiro (CSV)</Button>
            <Button variant="outline" onClick={exportFinancialPlans}>Financeiro por planos (CSV)</Button>
          </div>
        </CardContent>
      </Card>
    </SuperLayout>
  );
};

export default ReportsPage;
