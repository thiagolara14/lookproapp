import { useState, useEffect } from "react";
import Seo from "@/components/Seo";
import SuperLayout from "@/components/super/SuperLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";
import { getPlansAdapter } from "@/services/superAdminAdapters";
import type { Plan, PlanPeriod } from "@/lib/superStore";

// Utility to parse Brazilian price format
function parseBRLToNumber(v: string | number): number {
  if (typeof v === "number") return v;
  // "1.234,56" -> 1234.56
  const s = String(v).replace(/\./g, "").replace(",", ".");
  const n = Number(s);
  if (Number.isNaN(n)) return 0;
  return n;
}

const PlansPage = () => {
  const [open, setOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [form, setForm] = useState<{ name: string; price: number; period: PlanPeriod; trialDays: number; bookingLimit: number; extras: string }>({ name: "", price: 0, period: "monthly", trialDays: 7, bookingLimit: 100, extras: "" });
  const [plans, setPlans] = useState<Plan[]>([]);
  const [loading, setLoading] = useState(false);

  const plansAdapter = getPlansAdapter();

  const loadPlans = async () => {
    setLoading(true);
    try {
      const result = await plansAdapter.listPlans();
      setPlans(Array.isArray(result) ? result : []);
    } catch (error) {
      toast.error("Erro ao carregar planos");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadPlans();
  }, []);

  const onSave = async () => {
    if (!form.name) return toast.error("Informe um nome.");
    setLoading(true);
    try {
      const extras = form.extras ? form.extras.split(",").map((s) => s.trim()).filter(Boolean) : [];
      await plansAdapter.upsertPlan({ 
        id: editingId ?? undefined, 
        name: form.name, 
        price: parseBRLToNumber(form.price), 
        period: form.period, 
        trialDays: Number(form.trialDays), 
        bookingLimit: Number(form.bookingLimit), 
        extras 
      });
      toast.success(editingId ? "Plano atualizado." : "Plano criado.");
      setOpen(false);
      setEditingId(null);
      setForm({ name: "", price: 0, period: "monthly", trialDays: 7, bookingLimit: 100, extras: "" });
      await loadPlans();
    } catch (error) {
      toast.error("Erro ao salvar plano");
    } finally {
      setLoading(false);
    }
  };

  const handleDeletePlan = async (id: string) => {
    if (!confirm("Excluir plano?")) return;
    setLoading(true);
    try {
      await plansAdapter.deletePlan(id);
      toast.success("Plano excluído");
      await loadPlans();
    } catch (error) {
      toast.error("Erro ao excluir plano");
    } finally {
      setLoading(false);
    }
  };

  return (
    <SuperLayout>
      <Seo title="LookPro — Planos" description="Controle de assinaturas e planos." canonicalPath="/dashboard/super/planos" />
      <h1 className="text-2xl font-extrabold mb-4">Controle de Assinaturas e Planos</h1>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle>Planos</CardTitle>
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild><Button>Novo plano</Button></DialogTrigger>
            <DialogContent>
              <DialogHeader><DialogTitle>{editingId ? "Editar" : "Criar"} plano</DialogTitle></DialogHeader>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2"><Label>Nome</Label><Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></div>
                <div className="space-y-2"><Label>Preço (R$)</Label><Input type="number" value={form.price} onChange={(e) => setForm({ ...form, price: Number(e.target.value) })} /></div>
                <div className="space-y-2">
                  <Label>Período</Label>
                  <Select value={form.period} onValueChange={(v) => setForm({ ...form, period: v as PlanPeriod })}>
                    <SelectTrigger><SelectValue placeholder="Selecione" /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="monthly">Mensal</SelectItem>
                      <SelectItem value="yearly">Anual</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2"><Label>Teste grátis (dias)</Label><Input type="number" value={form.trialDays} onChange={(e) => setForm({ ...form, trialDays: Number(e.target.value) })} /></div>
                <div className="space-y-2"><Label>Limite de agendamentos/mês</Label><Input type="number" value={form.bookingLimit} onChange={(e) => setForm({ ...form, bookingLimit: Number(e.target.value) })} /></div>
                <div className="space-y-2 md:col-span-2"><Label>Extras (separar por vírgula)</Label><Input value={form.extras} onChange={(e) => setForm({ ...form, extras: e.target.value })} /></div>
              </div>
              <div className="flex justify-end gap-2 mt-4">
                <Button variant="outline" onClick={() => setOpen(false)}>Cancelar</Button>
                <Button onClick={onSave}>{editingId ? "Salvar" : "Criar"}</Button>
              </div>
            </DialogContent>
          </Dialog>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Nome</TableHead>
                <TableHead>Preço</TableHead>
                <TableHead>Período</TableHead>
                <TableHead>Teste grátis</TableHead>
                <TableHead>Limite</TableHead>
                <TableHead>Extras</TableHead>
                <TableHead className="text-right">Ações</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {plans.map((p) => (
                <TableRow key={p.id}>
                  <TableCell className="font-medium">{p.name}</TableCell>
                  <TableCell>R$ {p.price.toFixed(2)}</TableCell>
                  <TableCell>{p.period === "monthly" ? "Mensal" : "Anual"}</TableCell>
                  <TableCell>{p.trialDays} dias</TableCell>
                  <TableCell>{p.bookingLimit}</TableCell>
                  <TableCell>{p.extras.join(", ") || "—"}</TableCell>
                  <TableCell className="text-right space-x-2">
                    <Button size="sm" variant="outline" onClick={() => { setEditingId(p.id); setForm({ name: p.name, price: p.price, period: p.period, trialDays: p.trialDays, bookingLimit: p.bookingLimit, extras: p.extras.join(", ") }); setOpen(true); }}>Editar</Button>
                    <Button size="sm" variant="destructive" onClick={() => handleDeletePlan(p.id)} disabled={loading}>Excluir</Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </SuperLayout>
  );
};

export default PlansPage;
