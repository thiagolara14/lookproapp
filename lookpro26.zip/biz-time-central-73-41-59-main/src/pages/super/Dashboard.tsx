import Seo from "@/components/Seo";
import SuperLayout from "@/components/super/SuperLayout";
import { useMemo, useEffect, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { getMetricsAdapter } from "@/services/superAdminAdapters";
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  PieChart,
  Pie,
  Cell,
  LineChart,
  Line,
} from "recharts";

const colors = ["#3b82f6", "#10b981", "#f59e0b", "#ef4444", "#8b5cf6", "#06b6d4"];

const DashboardContent = () => {
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  
  useEffect(() => {
    const loadMetrics = async () => {
      try {
        const metricsAdapter = getMetricsAdapter();
        const metricsData = await metricsAdapter.metrics();
        setData(metricsData);
      } catch (error) {
        console.error('Error loading metrics:', error);
        // Fallback to empty data structure
        setData({
          totalEst: 0,
          totalBookings: 0,
          uniqueUsers: 0,
          active: 0,
          inactive: 0,
          mrr: 0,
          arr: 0,
          byCity: [],
          byCategory: [],
          revenueByPlan: [],
          byPeriod: []
        });
      } finally {
        setLoading(false);
      }
    };
    
    loadMetrics();
  }, []);

  if (loading || !data) {
    return (
      <div className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {[...Array(3)].map((_, i) => (
            <Card key={i}>
              <CardHeader><CardTitle>Carregando...</CardTitle></CardHeader>
              <CardContent className="text-3xl font-extrabold">-</CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardHeader><CardTitle>Estabelecimentos</CardTitle></CardHeader>
          <CardContent className="text-3xl font-extrabold">{data.totalEst}</CardContent>
        </Card>
        <Card>
          <CardHeader><CardTitle>Agendamentos</CardTitle></CardHeader>
          <CardContent className="text-3xl font-extrabold">{data.totalBookings}</CardContent>
        </Card>
        <Card>
          <CardHeader><CardTitle>Clientes únicos</CardTitle></CardHeader>
          <CardContent className="text-3xl font-extrabold">{data.uniqueUsers}</CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <Card>
          <CardHeader><CardTitle>Estabelecimentos por cidade</CardTitle></CardHeader>
          <CardContent className="h-72">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={data.byCity}>
                <XAxis dataKey="city" />
                <YAxis allowDecimals={false} />
                <Tooltip />
                <Bar dataKey="count" fill="#3b82f6" radius={[4,4,0,0]} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
        <Card>
          <CardHeader><CardTitle>Tipos de negócio</CardTitle></CardHeader>
          <CardContent className="h-72">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie data={data.byCategory} dataKey="count" nameKey="type" outerRadius={90} label>
                  {data.byCategory.map((_, i) => (
                    <Cell key={i} fill={colors[i % colors.length]} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
        <Card>
          <CardHeader><CardTitle>Receita por plano (MRR)</CardTitle></CardHeader>
          <CardContent className="h-72">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={data.revenueByPlan}>
                <XAxis dataKey="name" interval={0} tick={{ fontSize: 12 }} />
                <YAxis />
                <Tooltip />
                <Bar dataKey="mrr" fill="#8b5cf6" radius={[4,4,0,0]} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 gap-4">
        <Card>
          <CardHeader><CardTitle>Agendamentos (últimos 14 dias)</CardTitle></CardHeader>
          <CardContent className="h-72">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={data.byPeriod}>
                <XAxis dataKey="date" tickFormatter={(v) => v.slice(5)} />
                <YAxis allowDecimals={false} />
                <Tooltip />
                <Line type="monotone" dataKey="count" stroke="#10b981" strokeWidth={2} dot={false} />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardHeader><CardTitle>Ativos</CardTitle></CardHeader>
          <CardContent className="text-3xl font-extrabold">{data.active}</CardContent>
        </Card>
        <Card>
          <CardHeader><CardTitle>Inativos</CardTitle></CardHeader>
          <CardContent className="text-3xl font-extrabold">{data.inactive}</CardContent>
        </Card>
        <Card>
          <CardHeader><CardTitle>MRR (R$)</CardTitle></CardHeader>
          <CardContent className="text-3xl font-extrabold">{data.mrr.toFixed(2)}</CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardHeader><CardTitle>ARR (R$)</CardTitle></CardHeader>
          <CardContent className="text-3xl font-extrabold">{data.arr.toFixed(2)}</CardContent>
        </Card>
        {/* Debug WhatsApp - Feature Flag */}
        {import.meta.env.VITE_FEATURE_ONBOARDING_SELF_SERVE === 'true' && (
          <Card>
            <CardHeader><CardTitle>Debug WhatsApp</CardTitle></CardHeader>
            <CardContent>
              <a 
                href="/debug/whatsapp" 
                className="text-primary hover:underline"
              >
                Acessar página de testes
              </a>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
};

const SuperDashboardPage = () => (
  <SuperLayout>
    <Seo title="LookPro — Painel do Super Admin" description="Estatísticas globais da plataforma LookPro." canonicalPath="/dashboard/super" />
    <h1 className="text-2xl font-extrabold mb-4">Dashboard Geral da Plataforma</h1>
    <DashboardContent />
  </SuperLayout>
);

export default SuperDashboardPage;
