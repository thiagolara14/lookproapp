import { useEffect, useMemo, useState } from "react";
import Seo from "@/components/Seo";
import SuperLayout from "@/components/super/SuperLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { getReviewsAdapter } from "@/services/superAdminAdapters";

const ReviewsPage = () => {
  const [q, setQ] = useState("");
  const [score, setScore] = useState<string>("all");
  const [reviews, setReviews] = useState<any[]>([]);

  const reviewsAdapter = getReviewsAdapter();

  useEffect(() => {
    const loadReviews = async () => {
      try {
        const data = await reviewsAdapter.listReviews();
        setReviews(Array.isArray(data) ? data : []);
      } catch (error) {
        console.error('Error loading reviews:', error);
        setReviews([]);
      }
    };
    loadReviews();
  }, []);

  const onDelete = async (id: string) => {
    try {
      await reviewsAdapter.deleteReview(id);
      setReviews(prev => prev.filter(r => r.id !== id));
      toast.success("Avaliação excluída");
    } catch (error) {
      console.error('Error deleting review:', error);
      toast.error("Erro ao excluir avaliação");
    }
  };

  const filteredReviews = useMemo(() => {
    return reviews.filter((r) => (score === "all" || String(r.rating) === score) && (q ? (r.comment?.toLowerCase().includes(q.toLowerCase()) || r.userName?.toLowerCase().includes(q.toLowerCase())) : true));
  }, [reviews, q, score]);

  return (
    <SuperLayout>
      <Seo title="LookPro — Avaliações" description="Modere avaliações e feedbacks." canonicalPath="/dashboard/super/avaliacoes" />
      <h1 className="text-2xl font-extrabold mb-4">Avaliações e Feedbacks</h1>

      <Card>
        <CardHeader>
          <CardTitle>Moderação</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col md:flex-row gap-3 mb-4">
            <div className="flex-1 space-y-1"><Label>Buscar por palavra</Label><Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Ex: atraso, excelente" /></div>
            <div className="w-48 space-y-1"><Label>Nota</Label>
              <select className="border rounded h-10 px-3" value={score} onChange={(e) => setScore(e.target.value)}>
                <option value="all">Todas</option>
                {[1,2,3,4,5].map((n) => (<option key={n} value={String(n)}>{n} estrela{n>1?"s":""}</option>))}
              </select>
            </div>
          </div>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Cliente</TableHead>
                <TableHead>Nota</TableHead>
                <TableHead>Comentário</TableHead>
                <TableHead>Data</TableHead>
                <TableHead className="text-right">Ações</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredReviews.map((r) => (
                <TableRow key={r.id}>
                  <TableCell className="font-medium">{r.userName ?? "Cliente"}</TableCell>
                  <TableCell>{r.rating}</TableCell>
                  <TableCell>{r.comment}</TableCell>
                  <TableCell>{new Date(r.date).toLocaleString()}</TableCell>
                  <TableCell className="text-right space-x-2">
                    <Button size="sm" variant="destructive" onClick={() => { const reason = prompt("Justificativa para apagar?") || ""; if (confirm("Apagar avaliação?")) { onDelete(r.id); toast.success("Apagada. "+(reason?`Motivo: ${reason}`:"")); } }}>Apagar</Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </SuperLayout>
  );
};

export default ReviewsPage;
