import { useState, useEffect } from "react";
import Seo from "@/components/Seo";
import SuperLayout from "@/components/super/SuperLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import { readSupabaseCMSSettings, updateSupabaseCMSSettings } from "@/services/cms";

const CMSEditorPage = () => {
  const [settings, setSettings] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    const loadSettings = async () => {
      try {
        const data = await readSupabaseCMSSettings();
        setSettings(data);
      } catch (error) {
        console.error('Error loading CMS settings:', error);
        toast.error("Erro ao carregar configurações");
      } finally {
        setLoading(false);
      }
    };

    loadSettings();
  }, []);

  const handleSave = async () => {
    setSaving(true);
    try {
      await updateSupabaseCMSSettings(settings);
      toast.success("Configurações salvas com sucesso!");
    } catch (error) {
      console.error('Error saving CMS settings:', error);
      toast.error("Erro ao salvar configurações");
    } finally {
      setSaving(false);
    }
  };

  const updateSetting = (key: string, value: string) => {
    setSettings(prev => ({ ...prev, [key]: value }));
  };

  if (loading) {
    return (
      <SuperLayout>
        <Seo title="LookPro — Editor de Conteúdo" description="Edite os textos da tela inicial." canonicalPath="/dashboard/super/cms" />
        <h1 className="text-2xl font-extrabold mb-4">Editor de Conteúdo</h1>
        <div className="text-muted-foreground">Carregando...</div>
      </SuperLayout>
    );
  }

  return (
    <SuperLayout>
      <Seo title="LookPro — Editor de Conteúdo" description="Edite os textos da tela inicial." canonicalPath="/dashboard/super/cms" />
      <h1 className="text-2xl font-extrabold mb-4">Editor de Conteúdo</h1>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <Card>
          <CardHeader>
            <CardTitle>Textos da Página Inicial</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label>Título Principal</Label>
              <Input
                value={settings.hero_title || ''}
                onChange={(e) => updateSetting('hero_title', e.target.value)}
                placeholder="Título principal da homepage"
              />
            </div>
            <div className="space-y-2">
              <Label>Subtítulo</Label>
              <Textarea
                value={settings.hero_subtitle || ''}
                onChange={(e) => updateSetting('hero_subtitle', e.target.value)}
                placeholder="Subtítulo da homepage"
                rows={3}
              />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Informações do App</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label>Nome da Aplicação</Label>
              <Input
                value={settings.app_name || ''}
                onChange={(e) => updateSetting('app_name', e.target.value)}
                placeholder="Nome da aplicação"
              />
            </div>
            <div className="space-y-2">
              <Label>Descrição da Aplicação</Label>
              <Textarea
                value={settings.app_description || ''}
                onChange={(e) => updateSetting('app_description', e.target.value)}
                placeholder="Descrição da aplicação"
                rows={3}
              />
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="mt-6 flex justify-end">
        <Button onClick={handleSave} disabled={saving}>
          {saving ? "Salvando..." : "Salvar Alterações"}
        </Button>
      </div>
    </SuperLayout>
  );
};

export default CMSEditorPage;