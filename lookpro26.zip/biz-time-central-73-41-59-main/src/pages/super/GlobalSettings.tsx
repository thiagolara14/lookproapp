import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { toast } from "@/hooks/use-toast";
import { Save, MessageCircle, Mail, ArrowLeft } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { getGlobalSettings, updateGlobalSetting } from "@/services/globalSettings";

const GlobalSettings = () => {
  const navigate = useNavigate();
  const [whatsapp, setWhatsapp] = useState("");
  const [email, setEmail] = useState("");
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    loadSettings();
  }, []);

  const loadSettings = async () => {
    try {
      const settings = await getGlobalSettings();
      setWhatsapp(settings.support_whatsapp || "");
      setEmail(settings.support_email || "");
    } catch (error) {
      console.error('Error loading settings:', error);
      toast({
        title: "Erro ao carregar configurações",
        description: "Tente novamente mais tarde.",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const handleSave = async () => {
    if (!whatsapp.trim() || !email.trim()) {
      toast({
        title: "Campos obrigatórios",
        description: "Preencha todos os campos.",
        variant: "destructive"
      });
      return;
    }

    setSaving(true);
    try {
      await Promise.all([
        updateGlobalSetting('support_whatsapp', whatsapp.trim()),
        updateGlobalSetting('support_email', email.trim())
      ]);

      toast({
        title: "Configurações salvas",
        description: "As informações de suporte foram atualizadas com sucesso."
      });
    } catch (error) {
      console.error('Error saving settings:', error);
      toast({
        title: "Erro ao salvar configurações",
        description: "Tente novamente mais tarde.",
        variant: "destructive"
      });
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="container py-6">
        <div className="mb-6">
          <h1 className="text-3xl font-bold">Configurações Globais</h1>
          <p className="text-muted-foreground">Gerencie as configurações da plataforma</p>
        </div>
        <div className="grid gap-6">
          <Card>
            <CardHeader>
              <CardTitle>Carregando...</CardTitle>
            </CardHeader>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="container py-6">
      <div className="mb-6">
        <div className="flex items-center gap-4 mb-4">
          <Button variant="outline" size="sm" onClick={() => navigate('/dashboard/super')}>
            <ArrowLeft className="size-4 mr-2" />
            Voltar
          </Button>
        </div>
        <h1 className="text-3xl font-bold">Configurações Globais</h1>
        <p className="text-muted-foreground">Gerencie as configurações da plataforma</p>
      </div>

      <div className="grid gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <MessageCircle className="size-5" />
              Informações de Suporte
            </CardTitle>
            <CardDescription>
              Configure os canais de suporte exibidos na página inicial
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid gap-2">
              <Label htmlFor="whatsapp">WhatsApp Suporte</Label>
              <Input
                id="whatsapp"
                placeholder="5511999999999"
                value={whatsapp}
                onChange={(e) => setWhatsapp(e.target.value)}
                className="font-mono"
              />
              <p className="text-xs text-muted-foreground">
                Apenas números, sem + ou espaços (ex: 5511999999999)
              </p>
            </div>

            <div className="grid gap-2">
              <Label htmlFor="email">Email Suporte</Label>
              <Input
                id="email"
                type="email"
                placeholder="suporte@lookpro.app"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
            </div>

            <div className="flex gap-4 pt-4">
              <Button onClick={handleSave} disabled={saving}>
                <Save className="size-4 mr-2" />
                {saving ? "Salvando..." : "Salvar Configurações"}
              </Button>
            </div>
          </CardContent>
        </Card>

        <Card className="border-muted">
          <CardHeader>
            <CardTitle className="text-sm">Prévia</CardTitle>
            <CardDescription>Como os botões aparecerão na página inicial</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-3">
              <a 
                href={`https://wa.me/${whatsapp}`} 
                target="_blank" 
                rel="noopener noreferrer"
                className="pointer-events-none"
              >
                <Button variant="hero" size="sm">
                  <MessageCircle className="size-4" /> WhatsApp Suporte
                </Button>
              </a>
              <a href={`mailto:${email}`} className="pointer-events-none">
                <Button variant="soft" size="sm">
                  <Mail className="size-4" /> {email}
                </Button>
              </a>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default GlobalSettings;