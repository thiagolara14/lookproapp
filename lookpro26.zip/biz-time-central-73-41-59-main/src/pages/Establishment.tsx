import { useEffect, useMemo, useState } from "react";
import { useNavigate, useParams, Link } from "react-router-dom";

import { supabase } from "@/integrations/supabase/client";

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { downloadICS, buildICS } from "@/lib/calendar";
import { toast } from "sonner";
import { professionalsAdapter, servicesAdapter, establishmentsAdapter, reviewsAdapter } from "@/services/adapters";
import { createAppointment } from "@/services/appointments";
import { useEstablishmentSchedule } from "@/hooks/useEstablishmentSchedule";
import { ArrowLeft, Phone } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import BookingDialog from "@/components/BookingDialog";
import Seo from "@/components/Seo";
import { MapPin, Clock, Star } from "lucide-react";
import { Textarea } from "@/components/ui/textarea";
import ProfessionalsSection from "@/components/ProfessionalsSection";
import { fetchPublicProfessionalsByEstablishment, PublicProfessional } from "@/data/professionals";
import Logo from "@/components/Logo";
import EstablishmentWorkingHours from "@/components/EstablishmentWorkingHours";
type Category = string;

type WorkingHours = { start: string; end: string };
type SupabaseEstablishment = {
  id: string;
  name: string;
  category: Category;
  city: string;
  address?: string; // Add address field
  state?: string; // Add state field
  whatsapp?: string;
  logoUrl?: string;
  coverUrl?: string;
  workingHours: WorkingHours;
  rating?: number;
  createdAt?: unknown;
  updatedAt?: unknown;
  services: any[];
  professionals: any[];
  reviews: any[];
  isActive: boolean;
  description?: string;
  workingHoursByDay?: {
    monFri: { start: string; end: string };
    saturday?: { start: string; end: string } | null;
    sunday?: { start: string; end: string } | null;
  };
};

type EstablishmentInput = {
  name: string;
  category: string;
  city: string;
  description?: string;
  address?: string;
  state?: string;
  phone?: string;
  email?: string;
  whatsapp?: string;
  logoUrl?: string;
  coverUrl?: string;
  workingHours?: WorkingHours;
};

async function createEstablishment(input: EstablishmentInput) {
  const { data, error } = await supabase
    .from('establishments')
    .insert({
      name: input.name,
      description: input.description || '',
      address: input.address,
      city: input.city,
      state: input.state || '',
      phone: input.phone || '',
      email: input.email || '',
    })
    .select()
    .single();

  if (error) throw error;
  return data.id;
}

const currency = new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" });

function EstablishmentPage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { workingHours: establishmentHours } = useEstablishmentSchedule(id || "");

  const isCreateMode = id === "new";

  // form (create)
  const [name, setName] = useState("");
  const [category, setCategory] = useState("Barbearia");
  const [city, setCity] = useState("");
  const [whatsapp, setWhatsapp] = useState("");
  const [start, setStart] = useState("09:00");
  const [end, setEnd] = useState("18:00");
  const [saving, setSaving] = useState(false);

  // detail
  const [loading, setLoading] = useState(true);
  const [supabaseEst, setSupabaseEst] = useState<SupabaseEstablishment | null>(null);
  const [error, setError] = useState<string | null>(null);

  // Supabase professionals and reviews
  const [pros, setPros] = useState<any[]>([]);
  const [publicPros, setPublicPros] = useState<PublicProfessional[]>([]);

  // Review form states
  const [author, setAuthor] = useState("");
  const [rating, setRating] = useState<string>("5");
  const [comment, setComment] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [avgRating, setAvgRating] = useState<number | null>(null);
  
  // Gallery state for establishment photos
  const [gallery, setGallery] = useState<string[]>([]);

  async function onCreate(e: React.FormEvent) {
    e.preventDefault();
    if (!name.trim() || !city.trim() || !category) {
      toast.error("Preencha Nome, Categoria e Cidade.");
      return;
    }
    setSaving(true);
    try {
      const newId = await createEstablishment({
        name: name.trim(),
        category,
        city: city.trim(),
        whatsapp: whatsapp.trim() || undefined,
        workingHours: { start, end },
      });
      toast.success("Estabelecimento criado!");
      navigate(`/e/${newId}`);
    } catch (err: any) {
      toast.error(err?.message ?? "Falha ao salvar no Supabase");
    } finally {
      setSaving(false);
    }
  }

  const handleReviewSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!id || id === "new") return;
    
    // Basic validation
    if (!rating) {
      toast.error("Por favor, selecione uma nota.");
      return;
    }

    setSubmitting(true);
    try {
      // Save review directly to Supabase with proper data
        const { data: inserted, error } = await supabase
          .from('reviews')
          .insert({
            establishment_id: id,
            professional_id: null, // evitar erro de FK: só preencher quando houver seleção explícita de profissional (profiles.id)
            client_id: null, // permitir anônimo
            client_name: author.trim() || null, // armazenar nome quando cliente se identifica
            professional_rating: Number(rating),
            establishment_rating: Number(rating),
            comment: comment.trim() || null,
            appointment_id: null // permitir anônimo
          })
          .select('*')
          .single();

      if (error) {
        console.error('Supabase error:', error);
        throw error;
      }
      
      toast.success("Avaliação enviada com sucesso!");
      setAuthor("");
      setRating("5");
      setComment("");
      
      // Atualiza a lista local sem recarregar
      if (inserted) {
        setSupabaseEst((prev) => {
          if (!prev) return prev;
          const newReviews = [inserted, ...(prev.reviews || [])];
          
          // Recalcular média com nova avaliação
          const sum = newReviews.reduce((acc: number, review: any) => 
            acc + (review.establishment_rating || review.professional_rating || 0), 0
          );
          const newAvg = Math.round((sum / newReviews.length) * 10) / 10;
          setAvgRating(newAvg);
          
          return { 
            ...prev, 
            reviews: newReviews,
            rating: newAvg 
          };
        });
      }
    } catch (error: any) {
      console.error('Review submission error:', error);
      toast.error("Falha ao enviar avaliação. Tente novamente.");
    } finally {
      setSubmitting(false);
    }
  };

  if (isCreateMode) {
    return (
      <main className="container py-8">
        <Seo title="Novo Estabelecimento — LookPro" description="Cadastre um novo estabelecimento" canonicalPath="/e/new"/>
        <div className="flex items-center justify-between mb-4">
          <h1 className="text-2xl font-bold">Novo Estabelecimento</h1>
          <Link to="/"><Button variant="secondary" className="gap-2"><ArrowLeft className="size-4" />Voltar</Button></Link>
        </div>

        <Card className="max-w-2xl">
          <CardHeader><CardTitle className="text-base">Dados básicos</CardTitle></CardHeader>
          <CardContent>
            <form className="grid grid-cols-1 sm:grid-cols-2 gap-4" onSubmit={onCreate}>
              <div className="sm:col-span-2">
                <Label>Nome</Label>
                <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="Ex.: Barber King" />
              </div>
              <div>
                <Label>Categoria</Label>
                <Select value={category} onValueChange={setCategory}>
                  <SelectTrigger><SelectValue placeholder="Selecione" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Barbearia">Barbearia</SelectItem>
                    <SelectItem value="Salão">Salão</SelectItem>
                    <SelectItem value="Clínica">Clínica</SelectItem>
                    <SelectItem value="Estúdio">Estúdio</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Cidade</Label>
                <Input value={city} onChange={(e) => setCity(e.target.value)} placeholder="Ex.: São Paulo" />
              </div>
              <div className="sm:col-span-2">
                <Label>WhatsApp (opcional)</Label>
                <Input value={whatsapp} onChange={(e) => setWhatsapp(e.target.value)} placeholder="+55 11 99999-9999" />
              </div>
              <div>
                <Label>Abre</Label>
                <Input type="time" value={start} onChange={(e) => setStart(e.target.value)} />
              </div>
              <div>
                <Label>Fecha</Label>
                <Input type="time" value={end} onChange={(e) => setEnd(e.target.value)} />
              </div>
              <div className="sm:col-span-2">
                <Button type="submit" disabled={saving}>{saving ? "Salvando..." : "Salvar no Supabase"}</Button>
              </div>
            </form>
          </CardContent>
        </Card>
      </main>
    );
  }

  // Use Supabase directly
  useEffect(() => {
    // Setup realtime listener for professionals and profiles changes
    const professionalsChannel = supabase
      .channel('team-changes')
      .on('postgres_changes', {
        event: 'UPDATE',
        schema: 'public',
        table: 'professionals'
      }, () => {
        console.log('Professionals table updated, reloading professionals...');
        loadPublicProfessionals();
      })
      .on('postgres_changes', {
        event: 'UPDATE',
        schema: 'public',
        table: 'profiles'
      }, (payload) => {
        // Se um profile foi deletado (soft delete), recarregar profissionais
        if (payload.new.deleted_at !== payload.old.deleted_at) {
          console.log('Profile deleted_at changed, reloading professionals...');
          loadPublicProfessionals();
        }
      })
      .subscribe();

    async function loadPublicProfessionals() {
      if (!id || id === "new") return;
      try {
        const publicProfessionals = await fetchPublicProfessionalsByEstablishment(id);
        setPublicPros(publicProfessionals || []);
      } catch (error) {
        console.error('Error reloading public professionals:', error);
      }
    }

    async function loadGallery() {
      if (!id || id === "new") return;
      try {
        const { data: photos } = await supabase
          .from('establishment_photos')
          .select('url')
          .eq('establishment_id', id)
          .order('sort_order');
        setGallery(photos?.map(p => p.url) || []);
      } catch (error) {
        console.error('Error loading gallery:', error);
      }
    }
    loadGallery();

    return () => {
      supabase.removeChannel(professionalsChannel);
    };
  }, [id]);

  useEffect(() => {
    let active = true;
    async function load() {
      if (!id) return;
      setLoading(true); setError(null);
      try {
        // Fetch establishment with category name
        const { data: estData, error: estError } = await supabase
          .from('establishments')
          .select(`*, categories(name)`)
          .eq('id', id)
          .maybeSingle();
        
        if (estError) throw estError;
        if (!estData) {
          setError("Estabelecimento não encontrado.");
          return;
        }

        const [professionals, services, reviews, publicProfessionals] = await Promise.all([
          professionalsAdapter.listByEstablishment(id),
          servicesAdapter.listByEstablishment(id),
          // Fetch reviews directly from Supabase
          supabase.from('reviews').select('*').eq('establishment_id', id).order('created_at', { ascending: false }),
          // Fetch public professionals with force refresh
          fetchPublicProfessionalsByEstablishment(id).catch(() => [])
        ]);
        
        if (estData && active) {
          const reviewsData = reviews.data || [];
          
          // Calcular média real das avaliações
          let calculatedAvg = null;
          if (reviewsData.length > 0) {
            const sum = reviewsData.reduce((acc: number, review: any) => 
              acc + (review.establishment_rating || review.professional_rating || 0), 0
            );
            calculatedAvg = Math.round((sum / reviewsData.length) * 10) / 10;
          }
          setAvgRating(calculatedAvg);
          
          console.log('=== ESTABLISHMENT DATA DEBUG ===');
          console.log('Raw establishment data:', estData);
          console.log('Cover image URL:', estData.cover_image_url);
          console.log('Logo URL:', estData.logo_url);
          console.log('Available fields:', Object.keys(estData));
          
          setSupabaseEst({
            id: estData.id,
            name: estData.name,
            category: (estData.categories as any)?.name || "Categoria não definida" as Category,
            city: estData.city || "N/A",
            address: estData.address,
            state: estData.state,
            whatsapp: estData.phone,
            logoUrl: estData.logo_url || null,
            coverUrl: estData.cover_image_url || null,
            workingHours: { start: "09:00", end: "18:00" },
            rating: calculatedAvg,
            createdAt: estData.created_at,
            updatedAt: estData.updated_at,
            services: services,
            professionals: professionals,
            reviews: reviewsData,
            isActive: estData.status === 'active',
            description: estData.description,
            workingHoursByDay: undefined,
          });
          setPros(professionals);
          setPublicPros(publicProfessionals || []);
        }
      } catch (err: any) {
        if (active) setError(err?.message ?? "Falha ao carregar estabelecimento");
      } finally {
        if (active) setLoading(false);
      }
    }
    load();
    return () => { active = false; };
  }, [id]);

  if (loading) {
    return (<main className="container py-8"><div className="animate-pulse text-sm text-muted-foreground">Carregando...</div></main>);
  }

  if (error || !supabaseEst) {
    return (
      <main className="container py-8">
        <Seo title="Estabelecimento não encontrado — LookPro" description="Página não encontrada" canonicalPath={`/e/${id ?? ""}`}/>
        <div className="flex items-center gap-3 mb-6">
          <Link to="/" className="inline-flex items-center gap-2 text-sm hover:underline">
            <ArrowLeft className="size-4" /> Voltar
          </Link>
        </div>
        <Card className="max-w-2xl">
          <CardHeader><CardTitle className="text-base">Estabelecimento</CardTitle></CardHeader>
          <CardContent><p className="text-sm text-red-600">{error ?? "Estabelecimento não encontrado."}</p></CardContent>
        </Card>
      </main>
    );
  }

  // Show Supabase establishment
  if (!supabaseEst) {
    return (
      <main className="container py-10">
        <Seo title="Estabelecimento não encontrado — LookPro" description="Página não encontrada" canonicalPath={`/e/${id ?? ""}`}/>
        <div className="flex items-center gap-3 mb-6">
          <Link to="/" className="inline-flex items-center gap-2 text-sm hover:underline">
            <ArrowLeft className="size-4" /> Voltar
          </Link>
        </div>
        <p className="text-muted-foreground">Este estabelecimento não existe ou está inativo.</p>
      </main>
    );
  }

  const est = supabaseEst;
  
  
  // Use establishment data from Supabase - Get full address parsing JSON when available
  const getFormattedAddress = () => {
    console.log('=== DEBUGGING ADDRESS ===');
    console.log('est.description:', est.description);
    console.log('est.address:', est.address);
    console.log('est.city:', est.city);
    console.log('est.state:', est.state);
    
    try {
      const metaInfo = JSON.parse(est.description || '{}');
      console.log('Parsed metaInfo:', metaInfo);
      const address = metaInfo.address;
      if (address && (address.street || address.city)) {
        const parts = [
          address.street && address.number ? `${address.street}, ${address.number}` : address.street,
          address.neighborhood,
          address.city || est.city,
          address.state || est.state
        ].filter(Boolean);
        const fullAddress = parts.join(', ');
        console.log('Full address from JSON:', fullAddress);
        return fullAddress;
      }
    } catch (e) {
      console.log('Error parsing description JSON:', e);
    }
    
    // Fallback to database fields if no JSON address
    const hasValidAddress = est.address && 
      est.address !== "Endereço não informado" && 
      est.address.trim() !== "";
      
    const parts = [
      hasValidAddress ? est.address : null,
      est.city,
      est.state
    ].filter(Boolean);
    
    const fallbackAddress = parts.join(', ');
    console.log('Fallback address:', fallbackAddress);
    return fallbackAddress;
  };
  const formattedAddress = getFormattedAddress();
  const mapUrl = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(formattedAddress)}`;
  
  console.log('Final formatted address:', formattedAddress);
  console.log('Map URL:', mapUrl);
  console.log('Button should open:', mapUrl);
  
  // Get social media and WhatsApp from description JSON
  const getSocialMedia = () => {
    try {
      const metaInfo = JSON.parse(est.description || '{}');
      const isValidUrl = (url: string) => url && url.trim() !== '' && url !== 'N/A' && url !== 'null';
      
      return {
        instagram: isValidUrl(metaInfo.social?.instagram) ? metaInfo.social.instagram : '',
        facebook: isValidUrl(metaInfo.social?.facebook) ? metaInfo.social.facebook : '',
        tiktok: isValidUrl(metaInfo.social?.tiktok) ? metaInfo.social.tiktok : '',
        website: isValidUrl(metaInfo.social?.website) ? metaInfo.social.website : '',
        whatsapp: est.whatsapp && est.whatsapp.trim() !== '' && est.whatsapp !== 'N/A' ? est.whatsapp : ''
      };
    } catch {
      return {
        instagram: '',
        facebook: '',
        tiktok: '',
        website: '',
        whatsapp: est.whatsapp && est.whatsapp.trim() !== '' && est.whatsapp !== 'N/A' ? est.whatsapp : ''
      };
    }
  };
  
  const socialMedia = getSocialMedia();
  const estWhatsapp = socialMedia.whatsapp;
  
  // Clean the WhatsApp number (remove non-digits)
  const cleanWhatsapp = estWhatsapp?.replace(/\D/g, "");

  // Debug logging
  console.log("Establishment data:", est);
  console.log("Raw WhatsApp:", estWhatsapp);
  console.log("Clean WhatsApp:", cleanWhatsapp);

  return (
    <div className="min-h-screen">
      <Seo
        title={`Agendar em ${est.name} — LookPro`}
        description={`Confira serviços, avaliações e faça seu agendamento em ${est.name} em ${est.city}.`}
        canonicalPath={`/e/${est.id}`}
      />
      <header className="container pwa-header py-6 flex items-center justify-between">
        <Link to="/" className="inline-flex items-center gap-2 text-sm hover:underline">
          <ArrowLeft className="size-4" /> Voltar
        </Link>
        <Logo />
      </header>

      <main className="container pb-16">
        <section className="rounded-xl overflow-hidden border bg-card/70 backdrop-blur">
          {/* Try cover from establishment data or fallback to gallery first image */}
          {(est.coverUrl && est.coverUrl.trim() !== '') ? (
            <img 
              src={est.coverUrl} 
              alt={`Capa de ${est.name}`} 
              className="w-full h-36 sm:h-48 object-cover"
              onError={(e) => {
                console.error('Error loading cover image:', est.coverUrl);
                e.currentTarget.style.display = 'none';
                const fallbackDiv = e.currentTarget.nextElementSibling as HTMLElement;
                if (fallbackDiv) fallbackDiv.style.display = 'block';
              }}
            />
          ) : gallery.length > 0 ? (
            <img 
              src={gallery[0]} 
              alt={`Capa de ${est.name}`} 
              className="w-full h-36 sm:h-48 object-cover"
              onError={(e) => {
                console.error('Error loading gallery cover image:', gallery[0]);
                e.currentTarget.style.display = 'none';
                const fallbackDiv = e.currentTarget.nextElementSibling as HTMLElement;
                if (fallbackDiv) fallbackDiv.style.display = 'block';
              }}
            />
          ) : (
            <div className="h-36 sm:h-48 bg-[image:var(--gradient-primary)]" aria-hidden style={{ display: est.coverUrl || gallery.length > 0 ? 'none' : 'block' }} />
          )}
          <div className="p-6 -mt-10 relative">
            <div className="flex items-center gap-4">
              <div className="size-16 rounded-md bg-secondary/30 flex items-center justify-center border border-border overflow-hidden">
                {est.logoUrl ? (
                  <img src={est.logoUrl} alt={`Logo de ${est.name}`} className="w-full h-full object-cover" />
                ) : (
                  <span className="text-xl font-bold">{est.name.charAt(0)}</span>
                )}
              </div>
              <div className="flex-1">
                <h1 className="text-2xl font-extrabold tracking-tight">{est.name}</h1>
                <div className="flex flex-wrap items-center gap-2 text-sm text-muted-foreground mt-1">
                  <span className="inline-flex items-center gap-1"><MapPin className="size-4" /> {formattedAddress}</span>
                  <Badge variant="secondary">{est.category}</Badge>
                  {avgRating !== null && (
                    <span className="inline-flex items-center gap-1"><Star className="size-4 text-primary fill-primary" /> {avgRating}</span>
                  )}
                </div>
              </div>
            </div>
          </div>
        </section>

        <section className="mt-8 grid grid-cols-1 lg:grid-cols-3 gap-8">
          <article className="lg:col-span-2 space-y-8">
            <div>
              <h2 className="text-xl font-bold mb-3">Serviços</h2>
              <div className="space-y-3">
                {est.services && est.services.length > 0 ? est.services.map((s: any) => (
                  <Card key={s.id} className="bg-card/70 backdrop-blur border-border/60">
                    <CardHeader className="py-3">
                      <div className="flex items-center justify-between gap-4">
                        <div>
                          <CardTitle className="text-base">{s.name}</CardTitle>
                          <div className="text-sm text-muted-foreground inline-flex items-center gap-3">
                            <span className="inline-flex items-center gap-1"><Clock className="size-4" /> {s.duration} min</span>
                            <span>{currency.format(s.price)}</span>
                          </div>
                        </div>
                        <BookingDialog establishment={est} preselectedServiceId={s.id} />
                      </div>
                    </CardHeader>
                  </Card>
                )) : (
                  <p className="text-muted-foreground">Serviços serão exibidos aqui quando cadastrados.</p>
                )}
              </div>
            </div>
            
            {/* Professional Profiles Section */}
            <ProfessionalsSection pros={publicPros} />

            {gallery.length > 0 && (
              <div>
                <h2 className="text-xl font-bold mb-3">Galeria</h2>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                  {gallery.map((src, i) => (
                    <img key={i} src={src} alt={`Galeria ${est.name} imagem ${i + 1}`} className="rounded-lg border object-cover w-full h-32 sm:h-40" loading="lazy" />
                  ))}
                </div>
              </div>
            )}

            <div>
              <h2 className="text-xl font-bold mb-3">Deixe sua avaliação</h2>
              <Card className="bg-card/70 backdrop-blur border-border/60 mb-6">
                <CardContent className="py-4">
                  <form onSubmit={handleReviewSubmit} className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div className="space-y-1">
                      <Label htmlFor="author">Seu nome</Label>
                      <Input id="author" value={author} onChange={(e) => setAuthor(e.target.value)} placeholder="Opcional" />
                    </div>
                    <div className="space-y-1">
                      <Label htmlFor="rating">Nota</Label>
                      <Select value={rating} onValueChange={setRating}>
                        <SelectTrigger id="rating"><SelectValue placeholder="Selecione uma nota" /></SelectTrigger>
                        <SelectContent>
                          <SelectItem value="5">5 — Excelente</SelectItem>
                          <SelectItem value="4">4 — Muito bom</SelectItem>
                          <SelectItem value="3">3 — Bom</SelectItem>
                          <SelectItem value="2">2 — Regular</SelectItem>
                          <SelectItem value="1">1 — Ruim</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="sm:col-span-2 space-y-1">
                      <Label htmlFor="comment">Comentário</Label>
                      <Textarea id="comment" rows={3} value={comment} onChange={(e) => setComment(e.target.value)} placeholder="Conte como foi sua experiência" />
                    </div>
                    <div className="sm:col-span-2">
                      <Button type="submit" disabled={submitting}>{submitting ? "Enviando..." : "Enviar avaliação"}</Button>
                    </div>
                  </form>
                </CardContent>
              </Card>
              <h2 className="text-xl font-bold mb-3">Avaliações</h2>
              {est.reviews && est.reviews.length > 0 ? (
                <div className="space-y-3">
                  {est.reviews.map((r: any) => (
                    <Card key={r.id} className="bg-card/70 backdrop-blur border-border/60">
                      <CardContent className="py-4">
                        <div className="flex items-start gap-3">
                          <div className="size-10 rounded-md bg-secondary/30 flex items-center justify-center border border-border text-sm font-bold">
                            {(r.client_name || "A").charAt(0)}
                          </div>
                          <div className="flex-1">
                            <div className="flex items-center justify-between">
                              <div className="font-medium">{r.client_name || "Cliente Anônimo"}</div>
                              <div className="inline-flex items-center gap-1 text-sm">
                                <Star className="size-4 text-primary" /> 
                                {r.establishment_rating || r.professional_rating}
                              </div>
                            </div>
                            {r.comment && <p className="text-sm text-muted-foreground mt-1">{r.comment}</p>}
                            <p className="text-xs text-muted-foreground mt-1">
                              {new Date(r.created_at).toLocaleDateString('pt-BR')}
                            </p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              ) : (
                <p className="text-muted-foreground">Ainda não há avaliações públicas.</p>
              )}
            </div>
          </article>

          <aside className="lg:col-span-1">
            <div className="sticky top-4">
              <Card className="bg-card/70 backdrop-blur border-border/60">
                <CardHeader>
                  <CardTitle className="text-base">Agende agora</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <p className="text-sm text-muted-foreground">Escolha um serviço na lista e clique em Agendar.</p>
                  <div className="text-xs text-muted-foreground">Agendamentos via Supabase estão ativos</div>
                </CardContent>
              </Card>
              <Card className="bg-card/70 backdrop-blur border-border/60 mt-4">
                <CardHeader>
                  <CardTitle className="text-base">Horário de atendimento</CardTitle>
                </CardHeader>
                <CardContent>
                  <EstablishmentWorkingHours establishmentId={est.id} />
                </CardContent>
              </Card>
              <Card className="bg-card/70 backdrop-blur border-border/60 mt-4">
                <CardHeader>
                  <CardTitle className="text-base">Endereço & Contato</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3 text-sm">
                  {formattedAddress ? (
                    <div className="space-y-2">
                      <div className="inline-flex items-center gap-2">
                        <MapPin className="size-4" />
                        <span>{formattedAddress}</span>
                      </div>
                      <Button 
                        size="sm" 
                        variant="secondary" 
                        className="w-full"
                        onClick={(e) => {
                          e.preventDefault();
                          e.stopPropagation();
                          try {
                            const url = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(formattedAddress)}`;
                            window.open(url, '_blank', 'noopener,noreferrer');
                          } catch (error) {
                            console.error('Error opening maps:', error);
                            toast.error('Erro ao abrir o mapa');
                          }
                        }}
                      >
                        Ver no mapa
                      </Button>
                    </div>
                  ) : (
                    <p className="text-muted-foreground">Endereço não informado.</p>
                  )}

                  {cleanWhatsapp && (
                    <div className="space-y-3 pt-2 border-t border-border/60">
                      <div className="inline-flex items-center gap-2">
                        <Phone className="size-4 text-green-600" />
                        <span className="font-medium">WhatsApp: {cleanWhatsapp}</span>
                      </div>
                      <Button 
                        size="sm" 
                        variant="default" 
                        className="w-full gap-2 bg-green-600 hover:bg-green-700 text-white"
                        onClick={(e) => {
                          e.preventDefault();
                          e.stopPropagation();
                          try {
                            const message = encodeURIComponent('Olá! Gostaria de agendar um horário.');
                            const url = `https://wa.me/${cleanWhatsapp}?text=${message}`;
                            window.open(url, '_blank', 'noopener,noreferrer');
                          } catch (error) {
                            console.error('Error opening WhatsApp:', error);
                            toast.error('Erro ao abrir o WhatsApp');
                          }
                        }}
                      >
                        <Phone className="size-4" />
                        Chamar no WhatsApp
                      </Button>
                    </div>
                  )}
                </CardContent>
              </Card>
              
              {/* Social Media Links */}
              {(socialMedia.instagram || socialMedia.facebook || socialMedia.tiktok || socialMedia.website) && (
                <Card className="bg-card/70 backdrop-blur border-border/60 mt-4">
                  <CardHeader>
                    <CardTitle className="text-base">Redes Sociais</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-2">
                    {socialMedia.instagram && (
                      <Button 
                        size="sm" 
                        variant="outline" 
                        className="w-full justify-start gap-2"
                        onClick={() => window.open(socialMedia.instagram, '_blank')}
                      >
                        <svg className="size-4" viewBox="0 0 24 24" fill="currentColor">
                          <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/>
                        </svg>
                        Instagram
                      </Button>
                    )}
                    {socialMedia.facebook && (
                      <Button 
                        size="sm" 
                        variant="outline" 
                        className="w-full justify-start gap-2"
                        onClick={() => window.open(socialMedia.facebook, '_blank')}
                      >
                        <svg className="size-4" viewBox="0 0 24 24" fill="currentColor">
                          <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/>
                        </svg>
                        Facebook
                      </Button>
                    )}
                    {socialMedia.tiktok && (
                      <Button 
                        size="sm" 
                        variant="outline" 
                        className="w-full justify-start gap-2"
                        onClick={() => window.open(socialMedia.tiktok, '_blank')}
                      >
                        <svg className="size-4" viewBox="0 0 24 24" fill="currentColor">
                          <path d="M19.59 6.69a4.83 4.83 0 0 1-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 0 1-5.2 1.74 2.89 2.89 0 0 1 2.31-4.64 2.93 2.93 0 0 1 .88.13V9.4a6.84 6.84 0 0 0-1-.05A6.33 6.33 0 0 0 5 20.1a6.34 6.34 0 0 0 10.86-4.43v-7a8.16 8.16 0 0 0 4.77 1.52v-3.4a4.85 4.85 0 0 1-1-.1z"/>
                        </svg>
                        TikTok
                      </Button>
                    )}
                    {socialMedia.website && (
                      <Button 
                        size="sm" 
                        variant="outline" 
                        className="w-full justify-start gap-2"
                        onClick={() => window.open(socialMedia.website.startsWith('http') ? socialMedia.website : `https://${socialMedia.website}`, '_blank')}
                      >
                        <svg className="size-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                          <circle cx="12" cy="12" r="10"/>
                          <line x1="2" y1="12" x2="22" y2="12"/>
                          <path d="m12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/>
                        </svg>
                        Website
                      </Button>
                    )}
                  </CardContent>
                </Card>
              )}
            </div>
          </aside>
        </section>
      </main>

      <footer className="container py-10 text-center text-sm text-muted-foreground">
        © {new Date().getFullYear()} LookPro
      </footer>
    </div>
  );
}

export default EstablishmentPage;