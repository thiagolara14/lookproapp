import Seo from "@/components/Seo";

const Privacidade = () => {
  return (
    <main className="container py-10">
      <Seo
        title="LookPro — Política de Privacidade"
        description="Entenda como tratamos seus dados pessoais na plataforma LookPro."
        canonicalPath="/privacidade"
      />
      <header className="mb-8">
        <h1 className="text-3xl md:text-4xl font-extrabold tracking-tight">Política de Privacidade</h1>
        <p className="text-muted-foreground mt-2 max-w-2xl">
          Sua privacidade é importante para nós. Esta política descreve como coletamos, usamos e protegemos seus dados.
        </p>
      </header>

      <section className="space-y-6">
        <article>
          <h2 className="text-xl font-bold">1. Dados coletados</h2>
          <p className="text-sm text-muted-foreground mt-2">
            Podemos coletar informações como nome, e-mail, telefone e dados de agendamentos para fornecer nossos serviços.
          </p>
        </article>
        <article>
          <h2 className="text-xl font-bold">2. Como utilizamos os dados</h2>
          <p className="text-sm text-muted-foreground mt-2">
            Utilizamos os dados para viabilizar agendamentos, comunicação e melhorias da plataforma, sempre respeitando a legislação aplicável.
          </p>
        </article>
        <article>
          <h2 className="text-xl font-bold">3. Seus direitos</h2>
          <p className="text-sm text-muted-foreground mt-2">
            Você pode solicitar acesso, correção ou exclusão de seus dados. Entre em contato pelo e-mail de suporte.
          </p>
        </article>
        <article>
          <h2 className="text-xl font-bold">4. Contato</h2>
          <p className="text-sm text-muted-foreground mt-2">
            Para dúvidas sobre privacidade, envie um e-mail para <a className="underline" href="mailto:suporte@lookpro.app">suporte@lookpro.app</a>.
          </p>
        </article>
      </section>
    </main>
  );
};

export default Privacidade;
