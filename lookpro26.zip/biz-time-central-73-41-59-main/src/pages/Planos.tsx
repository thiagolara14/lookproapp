import Seo from "@/components/Seo";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

const Planos = () => {
  return (
    <main className="container py-10">
      <Seo
        title="LookPro — Planos e preços"
        description="Compare os planos da LookPro e escolha o ideal para seu negócio."
        canonicalPath="/planos"
      />
      <header className="text-center mb-10">
        <h1 className="text-3xl md:text-4xl font-extrabold tracking-tight">Planos e preços</h1>
        <p className="text-muted-foreground mt-2 max-w-2xl mx-auto">
          Comece grátis e evolua conforme seu negócio cresce. Todos os planos incluem vitrine pública e agendamentos online.
        </p>
      </header>

      <section className="grid gap-6 md:grid-cols-3">
        <Card className="border-border">
          <CardHeader>
            <CardTitle>Basic</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3 text-sm text-muted-foreground">
            <ul className="list-disc list-inside space-y-1">
              <li>1 profissional</li>
              <li>Serviços ilimitados</li>
              <li>Vitrine pública</li>
            </ul>
            <a href="https://wa.me/5511943623908" target="_blank" rel="noopener noreferrer">
              <Button variant="soft" className="w-full">Assinar agora</Button>
            </a>
          </CardContent>
        </Card>

        <Card className="border-border">
          <CardHeader>
            <CardTitle>Pro</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3 text-sm text-muted-foreground">
            <ul className="list-disc list-inside space-y-1">
              <li>Até 5 profissionais</li>
              <li>Agenda avançada</li>
              <li>Relatórios básicos</li>
            </ul>
            <a href="https://wa.me/5511943623908" target="_blank" rel="noopener noreferrer">
              <Button variant="hero" className="w-full">Assinar agora</Button>
            </a>
          </CardContent>
        </Card>

        <Card className="border-border">
          <CardHeader>
            <CardTitle>Empresarial</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3 text-sm text-muted-foreground">
            <ul className="list-disc list-inside space-y-1">
              <li>Profissionais ilimitados</li>
              <li>Relatórios avançados</li>
              <li>Suporte prioritário</li>
            </ul>
            <a href="https://wa.me/5511943623908" target="_blank" rel="noopener noreferrer">
              <Button variant="soft" className="w-full">Assinar agora</Button>
            </a>
          </CardContent>
        </Card>
      </section>
    </main>
  );
};

export default Planos;
