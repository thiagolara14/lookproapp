import { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import Seo from '@/components/Seo';
import { ArrowLeft, Edit } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/context/AuthContext';

export default function ProfessionalPublicPage() {
  const { idOrSlug } = useParams<{ idOrSlug: string }>();
  const { user } = useAuth();
  const [pro, setPro] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let channel: any = null;

    const setupProfessional = async () => {
      if (!idOrSlug) return;
      
      try {
        setLoading(true);
        setError(null);
        console.log('Loading professional data');
        
        // Detectar se é UUID ou slug
        const isUuid = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(idOrSlug);
        console.log('Is UUID:', isUuid, 'Parameter:', idOrSlug);
        
        // Buscar no Supabase
        const { data, error: fetchError } = await supabase
          .from('professionals')
          .select(`
            id, 
            bio, 
            slug, 
            avatar_path, 
            avatar_url, 
            establishment_id, 
            user_id, 
            specialties,
            updated_at
          `)
          .eq(isUuid ? 'id' : 'slug', idOrSlug)
          .eq('is_public', true)
          .eq('active', true)
          .maybeSingle();

        if (fetchError || !data) {
          console.error('Professional fetch error:', fetchError);
          setError('Profissional não encontrado');
          setLoading(false);
          return;
        }

        console.log('Professional data from DB:', data);

      // Buscar dados do perfil usando a função que funciona
      const { data: professionalData } = await supabase.rpc('get_establishment_professionals', {
        establishment_uuid: data.establishment_id
      });
      
      const profileData = professionalData?.find((p: any) => p.id === data.id);
      console.log('Professional data from function:', profileData);

        // Normalizar bio (JSON ou texto plano)
        let bioText = "";
        let whatsapp = "";
        let experienceYears = 0;
        
        if (data.bio) {
          try {
            const bioData = JSON.parse(data.bio);
            console.log('Parsed bio data:', bioData);
            bioText = bioData.description || data.bio || "";
            whatsapp = bioData.whatsapp || "";
            experienceYears = bioData.experienceYears || 0;
          } catch {
            // Se não for JSON, manter como texto simples
            bioText = data.bio;
          }
        }

        // Normalizar avatar (priorizar avatar_url)
        const avatar = data.avatar_url || data.avatar_path || null;

        const finalProfessionalData = {
          id: data.id,
          user_id: data.user_id,
          name: profileData?.name || `Profissional ${data.id.slice(0, 8)}`,
          slug: data.slug || data.id,
          bio: bioText,
          phone: "",
          whatsapp: whatsapp,
          experienceYears: experienceYears,
          specialties: data.specialties || [],
          avatar_path: avatar,
          establishment_id: data.establishment_id
        };

        console.log('Final professional result:', finalProfessionalData);
        setPro(finalProfessionalData);

        // Configurar realtime updates para mudanças no dashboard
        channel = supabase
          .channel(`professional-${data.id}`)
          .on('postgres_changes', {
            event: 'UPDATE',
            schema: 'public',
            table: 'professionals',
            filter: `id=eq.${data.id}`
          }, (payload) => {
            console.log('Professional updated via realtime:', payload);
            const newData = payload.new as any;
            
            // Normalizar novos dados
            let newBioText = "";
            let newWhatsapp = "";
            let newExperienceYears = 0;
            
            if (newData.bio) {
              try {
                const bioData = JSON.parse(newData.bio);
                newBioText = bioData.description || newData.bio || "";
                newWhatsapp = bioData.whatsapp || "";
                newExperienceYears = bioData.experienceYears || 0;
              } catch {
                newBioText = newData.bio || "";
              }
            }
            
            setPro((prev: any) => prev && ({
              ...prev,
              ...newData,
              bio: newBioText,
              whatsapp: newWhatsapp,
              experienceYears: newExperienceYears,
              avatar_path: newData.avatar_url || newData.avatar_path || prev.avatar_path
            }));
          })
          .subscribe();

      } catch (err) {
        console.error('Error fetching professional:', err);
        setError('Profissional não encontrado');
      } finally {
        setLoading(false);
      }
    };

    setupProfessional();

    // Cleanup function
    return () => {
      if (channel) {
        supabase.removeChannel(channel);
      }
    };
  }, [idOrSlug]);

  const loadProfessional = async (force = false) => {
    if (!idOrSlug) return;
    
    try {
      setLoading(true);
      setError(null);
      console.log('Loading professional data, force refresh:', force);
      
      // Detectar se é UUID ou slug
      const isUuid = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(idOrSlug);
      console.log('Is UUID:', isUuid, 'Parameter:', idOrSlug);
      
      // Buscar no Supabase
      const { data, error: fetchError } = await supabase
        .from('professionals')
        .select(`
          id, 
          bio, 
          slug, 
          avatar_path, 
          avatar_url, 
          establishment_id, 
          user_id, 
          specialties,
          updated_at
        `)
        .eq(isUuid ? 'id' : 'slug', idOrSlug)
        .eq('is_public', true)
        .eq('active', true)
        .maybeSingle();

      if (fetchError || !data) {
        console.error('Professional fetch error:', fetchError);
        setError('Profissional não encontrado');
        setLoading(false);
        return;
      }

      console.log('Professional data from DB:', data);

        // Buscar dados do perfil usando a função que funciona
        const { data: professionalData } = await supabase.rpc('get_establishment_professionals', {
          establishment_uuid: data.establishment_id
        });
        
        const profileData = professionalData?.find((p: any) => p.id === data.id);
        console.log('Professional data from function:', profileData);

      // Normalizar bio (JSON ou texto plano)
      let bioText = "";
      let whatsapp = "";
      let experienceYears = 0;
      
      if (data.bio) {
        try {
          const bioData = JSON.parse(data.bio);
          console.log('Parsed bio data:', bioData);
          bioText = bioData.description || data.bio || "";
          whatsapp = bioData.whatsapp || "";
          experienceYears = bioData.experienceYears || 0;
        } catch {
          // Se não for JSON, manter como texto simples
          bioText = data.bio;
        }
      }

      // Normalizar avatar (priorizar avatar_url)
      const avatar = data.avatar_url || data.avatar_path || null;

        const finalProfessionalData = {
          id: data.id,
          user_id: data.user_id,
          name: profileData?.name || `Profissional ${data.id.slice(0, 8)}`,
          slug: data.slug || data.id,
          bio: bioText,
          phone: "",
          whatsapp: whatsapp,
          experienceYears: experienceYears,
          specialties: data.specialties || [],
          avatar_path: avatar,
          establishment_id: data.establishment_id
        };

        console.log('Final professional result:', finalProfessionalData);
        setPro(finalProfessionalData);

    } catch (err) {
      console.error('Error fetching professional:', err);
      setError('Profissional não encontrado');
    } finally {
      setLoading(false);
    }
  };

  // Listener para mudanças de foco (ainda útil como fallback)
  useEffect(() => {
    const handleVisibilityChange = () => {
      if (!document.hidden) {
        console.log('Tab became visible, reloading professional data');
        loadProfessional();
      }
    };

    document.addEventListener('visibilitychange', handleVisibilityChange);
    
    return () => {
      document.removeEventListener('visibilitychange', handleVisibilityChange);
    };
  }, [idOrSlug]);

  if (loading) {
    return (
      <main className="container py-8">
        <div className="animate-pulse text-sm text-muted-foreground">Carregando...</div>
      </main>
    );
  }

  if (error || !pro) {
    return (
      <main className="container py-8">
        <Seo 
          title="Profissional não encontrado — LookPro" 
          description="Página não encontrada" 
          canonicalPath={`/profissional/${idOrSlug}`}
        />
        <div className="flex items-center gap-3 mb-6">
          <Link to="/" className="inline-flex items-center gap-2 text-sm hover:underline">
            <ArrowLeft className="size-4" /> Voltar
          </Link>
        </div>
        <Card className="max-w-2xl">
          <CardHeader>
            <CardTitle className="text-base">Profissional</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-red-600">{error || "Profissional não encontrado."}</p>
          </CardContent>
        </Card>
      </main>
    );
  }

  const avatar = pro.avatar_path || '/placeholder.svg';
  
  // Check if current user is this professional
  const isOwnerProfessional = user?.role === 'professional' && user?.id && pro.user_id === user.id;

  return (
    <main className="container py-8">
      <Seo 
        title={`${pro.name} — LookPro`}
        description={pro.bio || `Perfil público de ${pro.name}`}
        canonicalPath={`/profissional/${pro.slug}`}
      />
      
      <div className="flex items-center justify-between mb-6">
        <Link to={`/e/${pro.establishment_id}`} className="inline-flex items-center gap-2 text-sm hover:underline">
          <ArrowLeft className="size-4" /> Voltar ao estabelecimento
        </Link>
        
        {isOwnerProfessional && (
          <div className="flex gap-2">
            <Button 
              variant="ghost" 
              size="sm"
              onClick={() => loadProfessional(true)}
            >
              Recarregar Dados
            </Button>
            <Button asChild variant="outline" size="sm">
              <Link to="/dashboard/pro/perfil">
                <Edit className="size-4 mr-2" />
                Editar Perfil
              </Link>
            </Button>
          </div>
        )}
      </div>

      <Card className="max-w-2xl">
        <CardHeader>
          <div className="flex items-start gap-4">
            <img
              src={avatar || '/placeholder.svg'}
              alt={`Foto de perfil de ${pro.name}`}
              className="h-20 w-20 rounded-full object-cover bg-muted"
              onError={(e) => { 
                (e.currentTarget as HTMLImageElement).src = '/placeholder.svg';
              }}
            />
            <div className="flex-1">
              <CardTitle id="pro-name" className="text-xl">
                {pro.name}
              </CardTitle>
              <p className="text-sm text-muted-foreground mt-1">
                Profissional
              </p>
              {pro.experienceYears > 0 && (
                <p className="text-xs text-muted-foreground mt-1">
                  {pro.experienceYears} {pro.experienceYears === 1 ? 'ano' : 'anos'} de experiência
                </p>
              )}
            </div>
          </div>
        </CardHeader>
        
        <CardContent className="space-y-4">
          {pro.bio && (
            <section aria-label="Sobre">
              <h2 className="font-medium mb-2">Sobre</h2>
              <p className="text-muted-foreground whitespace-pre-wrap">
                {pro.bio}
              </p>
            </section>
          )}
          
          {pro.specialties && pro.specialties.length > 0 && (
            <section aria-label="Especialidades">
              <h2 className="font-medium mb-2">Especialidades</h2>
              <div className="flex flex-wrap gap-2">
                {pro.specialties.map((specialty: string, index: number) => (
                  <span 
                    key={index}
                    className="px-2 py-1 bg-secondary text-secondary-foreground rounded-md text-sm"
                  >
                    {specialty}
                  </span>
                ))}
              </div>
            </section>
          )}
          
          {(pro.phone || pro.whatsapp) && (
            <section aria-label="Contato">
              <h2 className="font-medium mb-2">Contato</h2>
              <div className="space-y-1">
                {pro.phone && (
                  <p className="text-sm text-muted-foreground">
                    <strong>Telefone:</strong> {pro.phone}
                  </p>
                )}
                {pro.whatsapp && (
                  <p className="text-sm text-muted-foreground">
                    <strong>WhatsApp:</strong> {pro.whatsapp}
                  </p>
                )}
              </div>
            </section>
          )}
          
          {!pro.bio && (!pro.specialties || pro.specialties.length === 0) && (
            <section aria-label="Informações">
              <h2 className="font-medium mb-2">Informações</h2>
              <p className="text-muted-foreground">
                Este profissional ainda não adicionou informações detalhadas sobre seus serviços.
              </p>
            </section>
          )}
        </CardContent>
      </Card>
    </main>
  );
}