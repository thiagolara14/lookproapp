import Seo from "@/components/Seo";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";

const ComoFunciona = () => {
  return (
    <main className="container py-10">
      <Seo
        title="LookPro — Como funciona"
        description="Entenda como agendar serviços e gerenciar seu negócio com a LookPro."
        canonicalPath="/como-funciona"
      />
      <header className="mb-8">
        <h1 className="text-3xl md:text-4xl font-extrabold tracking-tight">Como funciona</h1>
        <p className="text-muted-foreground mt-2 max-w-2xl">
          Veja o passo a passo para clientes, profissionais e administradores usarem a plataforma.
        </p>
      </header>

      <section className="grid gap-6 md:grid-cols-3">
        <Card>
          <CardHeader>
            <CardTitle>Para clientes</CardTitle>
          </CardHeader>
          <CardContent className="text-sm text-muted-foreground space-y-2">
            <ol className="list-decimal list-inside space-y-1">
              <li>Encontre o estabelecimento na vitrine pública.</li>
              <li>Escolha o serviço e o horário disponível.</li>
              <li>Confirme seu agendamento sem necessidade de conta.</li>
            </ol>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Para profissionais</CardTitle>
          </CardHeader>
          <CardContent className="text-sm text-muted-foreground space-y-2">
            <ol className="list-decimal list-inside space-y-1">
              <li>Gerencie agenda e serviços no painel do profissional.</li>
              <li>Receba notificações e acompanhe avaliações.</li>
              <li>Otimize horários e reduza faltas.</li>
            </ol>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Para administradores</CardTitle>
          </CardHeader>
          <CardContent className="text-sm text-muted-foreground space-y-2">
            <ol className="list-decimal list-inside space-y-1">
              <li>Cadastre serviços e profissionais.</li>
              <li>Acompanhe relatórios e métricas.</li>
              <li>Personalize horários e bloqueios.</li>
            </ol>
          </CardContent>
        </Card>
      </section>

      <aside className="mt-10 flex items-center gap-3">
        <Link to="/planos">
          <Button variant="hero">Ver planos e preços</Button>
        </Link>
        <Link to="/vitrine" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
          Explorar estabelecimentos
        </Link>
      </aside>
    </main>
  );
};

export default ComoFunciona;
