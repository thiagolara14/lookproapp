import { useState, useEffect } from "react";
import { useSearchParams, useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { MessageCircle, CheckCircle, Clock, AlertCircle, ExternalLink, Share } from "lucide-react";
import { getLeadStatus, LeadStatusResponse } from "@/services/onboardingClient";
import { OnboardingConfig } from "@/lib/featureFlags";
import Seo from "@/components/Seo";
import Logo from "@/components/Logo";
import { toast } from "@/hooks/use-toast";

export default function CadastroSucesso() {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const leadId = searchParams.get('lead');
  
  const [leadStatus, setLeadStatus] = useState<LeadStatusResponse | null>(null);
  const [isPolling, setIsPolling] = useState(true);

  useEffect(() => {
    if (!leadId) {
      navigate('/cadastro');
      return;
    }

    const pollStatus = async () => {
      try {
        const response = await getLeadStatus(leadId);
        setLeadStatus(response);
        
        if (response.status === 'entregue' || response.status === 'erro') {
          setIsPolling(false);
        }
      } catch (error) {
        console.error('Error polling status:', error);
        setIsPolling(false);
      }
    };

    // Poll immediately
    pollStatus();

    // Continue polling if not finished
    if (isPolling) {
      const interval = setInterval(pollStatus, 5000); // Poll every 5 seconds
      return () => clearInterval(interval);
    }
  }, [leadId, navigate, isPolling]);

  const getStatusIcon = () => {
    switch (leadStatus?.status) {
      case 'entregue':
        return <CheckCircle className="h-8 w-8 text-green-500" />;
      case 'erro':
        return <AlertCircle className="h-8 w-8 text-red-500" />;
      default:
        return <Clock className="h-8 w-8 text-blue-500 animate-pulse" />;
    }
  };

  const getStatusTitle = () => {
    switch (leadStatus?.status) {
      case 'entregue':
        return 'Pronto! 🚀';
      case 'erro':
        return 'Oops! Algo deu errado 😔';
      default:
        return 'Quase lá! 🚀';
    }
  };

  const getStatusMessage = () => {
    switch (leadStatus?.status) {
      case 'entregue':
        return 'Seu app LookPro está pronto! Você pode acessá-lo através dos links abaixo ou pelo WhatsApp.';
      case 'erro':
        return 'Houve um problema ao criar seu app. Nossa equipe foi notificada e entrará em contato em breve.';
      case 'em_provisionamento':
        return 'Estamos criando seu app personalizado. Isso leva alguns minutos...';
      default:
        return 'Seu pedido foi recebido e será processado em instantes. Você receberá os dados de acesso por WhatsApp em poucos minutos.';
    }
  };

  const handleWhatsAppSupport = () => {
    const supportNumber = OnboardingConfig.SUPPORT_WHATSAPP;
    const message = encodeURIComponent(`Olá! Preciso de ajuda com meu app LookPro. Lead ID: ${leadId}`);
    window.open(`https://wa.me/${supportNumber}?text=${message}`, '_blank');
  };

  const handleShareWhatsApp = () => {
    if (leadStatus?.tenant_data?.url_publica) {
      const message = encodeURIComponent(`Confira meu novo app de agendamentos! ${leadStatus.tenant_data.url_publica}`);
      window.open(`https://wa.me/?text=${message}`, '_blank');
    }
  };

  const handleOpenApp = (url: string) => {
    window.open(url, '_blank');
  };

  if (!leadId) {
    return null;
  }

  return (
    <>
      <Seo 
        title="Status do seu App" 
        description="Acompanhe o status da criação do seu app de agendamentos" 
      />
      
      <div className="min-h-screen bg-gradient-to-br from-background via-background to-muted/20">
        {/* Header */}
        <header className="border-b bg-background/80 backdrop-blur-sm sticky top-0 z-50">
          <div className="container py-4">
            <div className="flex items-center justify-between">
              <Logo />
              <Button
                variant="ghost"
                onClick={() => navigate('/')}
                className="flex items-center gap-2"
              >
                Início
              </Button>
            </div>
          </div>
        </header>

        {/* Main Content */}
        <main className="container py-8">
          <div className="max-w-2xl mx-auto">
            <div className="bg-card/50 backdrop-blur-sm border rounded-xl p-8 shadow-lg">
              <div className="text-center mb-8">
                <div className="flex justify-center mb-4">
                  <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center">
                    {getStatusIcon()}
                  </div>
                </div>
                <h1 className="text-3xl font-bold tracking-tight mb-4">
                  {getStatusTitle()}
                </h1>
                <p className="text-lg text-muted-foreground">
                  {getStatusMessage()}
                </p>
              </div>

              <div className="space-y-6">
                {/* Status Card */}
                <Card>
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <span className="font-medium">Status:</span>
                      <span className={`px-2 py-1 rounded-full text-sm font-medium ${
                        leadStatus?.status === 'entregue' ? 'bg-green-100 text-green-800' :
                        leadStatus?.status === 'erro' ? 'bg-red-100 text-red-800' :
                        'bg-blue-100 text-blue-800'
                      }`}>
                        {leadStatus?.status === 'entregue' ? 'Pronto' :
                         leadStatus?.status === 'erro' ? 'Erro' :
                         leadStatus?.status === 'em_provisionamento' ? 'Criando...' :
                         'Aguardando'}
                      </span>
                    </div>
                    <div className="flex items-center justify-between mt-2">
                      <span className="font-medium">ID do pedido:</span>
                      <span className="text-sm font-mono">{leadId}</span>
                    </div>
                  </CardContent>
                </Card>

                {/* Links (only when ready) */}
                {leadStatus?.status === 'entregue' && leadStatus.tenant_data && (
                  <div className="space-y-4">
                    <Card>
                      <CardContent className="p-4">
                        <h3 className="font-semibold mb-3">Seus links estão prontos!</h3>
                        <div className="space-y-3">
                          <div className="flex items-center justify-between p-3 bg-muted rounded-lg">
                            <div>
                              <p className="font-medium">Link para clientes</p>
                              <p className="text-sm text-muted-foreground">
                                {leadStatus.tenant_data.url_publica}
                              </p>
                            </div>
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => handleOpenApp(leadStatus.tenant_data.url_publica)}
                            >
                              <ExternalLink className="h-4 w-4" />
                            </Button>
                          </div>
                          
                          <div className="flex items-center justify-between p-3 bg-muted rounded-lg">
                            <div>
                              <p className="font-medium">Painel Administrativo</p>
                              <p className="text-sm text-muted-foreground">
                                {leadStatus.tenant_data.url_admin}
                              </p>
                              {leadStatus.tenant_data.login && (
                                <p className="text-xs text-muted-foreground mt-1">
                                  Login: {leadStatus.tenant_data.login}
                                </p>
                              )}
                            </div>
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => handleOpenApp(leadStatus.tenant_data.url_admin)}
                            >
                              <ExternalLink className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>

                    {/* Action buttons */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <Button
                        variant="outline"
                        onClick={handleShareWhatsApp}
                        className="flex items-center gap-2"
                      >
                        <Share className="h-4 w-4" />
                        Compartilhar no WhatsApp
                      </Button>
                      <Button
                        onClick={() => handleOpenApp(leadStatus.tenant_data.url_admin)}
                        className="flex items-center gap-2"
                      >
                        <ExternalLink className="h-4 w-4" />
                        Abrir meu app
                      </Button>
                    </div>
                  </div>
                )}

                {/* Support button */}
                <div className="text-center">
                  <Button
                    variant="ghost"
                    onClick={handleWhatsAppSupport}
                    className="flex items-center gap-2"
                  >
                    <MessageCircle className="h-4 w-4" />
                    Falar no WhatsApp com suporte
                  </Button>
                </div>

                {/* Additional info */}
                <div className="bg-muted/50 border rounded-lg p-4 text-center">
                  <p className="text-sm text-muted-foreground">
                    {leadStatus?.status === 'entregue' 
                      ? 'Os dados de acesso foram enviados por WhatsApp. Comece a usar agora!'
                      : 'Mantenha esta página aberta. O status é atualizado automaticamente.'
                    }
                  </p>
                </div>
              </div>
            </div>
          </div>
        </main>

        {/* Background decoration */}
        <div className="fixed inset-0 -z-10 overflow-hidden pointer-events-none">
          <div className="absolute -top-40 -right-40 w-80 h-80 bg-primary/5 rounded-full blur-3xl" />
          <div className="absolute -bottom-40 -left-40 w-80 h-80 bg-secondary/5 rounded-full blur-3xl" />
        </div>
      </div>
    </>
  );
}