import { useLocation } from "react-router-dom";
import { useEffect } from "react";
import Seo from "@/components/Seo";

const NotFound = () => {
  const location = useLocation();

  useEffect(() => {
    console.error(
      "404 Error: User attempted to access non-existent route:",
      location.pathname
    );
  }, [location.pathname]);

  return (
    <div className="min-h-screen flex items-center justify-center bg-background">
      <Seo title="Página não encontrada — LookPro" description="A página solicitada não existe ou foi movida." canonicalPath={location.pathname} />
      <div className="text-center">
        <h1 className="text-4xl font-bold mb-4">404</h1>
        <p className="text-xl text-muted-foreground mb-4">Ops! Página não encontrada.</p>
        <a href="/" className="text-primary hover:opacity-80 underline">
          Voltar para a página inicial
        </a>
      </div>
    </div>
  );
};

export default NotFound;
