import { useEffect, useMemo, useState } from "react";
import Seo from "@/components/Seo";
import GradientSpotlight from "@/components/GradientSpotlight";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import EstablishmentCard from "@/components/EstablishmentCard";
import { getCategoriesAdapter, getCitiesAdapter } from "@/services/superAdminAdapters";
import { listEstablishments } from "@/services/supabase/establishments";
import { Link, useNavigate } from "react-router-dom";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle, DialogTrigger, DialogDescription } from "@/components/ui/dialog";
import { toast } from "@/hooks/use-toast";
import { normalizePhone, setClientKey, setClientName, getClientKey, getClientName, clearClientKey } from "@/lib/clientIdentity";
import { listAppointmentsByClient, cancelAppointmentAsClient } from "@/services/appointments";
import type { Appointment } from "@/types/appointments";
const Vitrine = () => {
  const [search, setSearch] = useState(() => {
    const params = new URLSearchParams(window.location.search);
    return params.get("q") ?? "";
  });
  const [city, setCity] = useState<string>(() => {
    const params = new URLSearchParams(window.location.search);
    return params.get("city") ?? "";
  });
  const [type, setType] = useState<string>(() => {
    const params = new URLSearchParams(window.location.search);
    return (params.get("category") ?? params.get("type") ?? "") as string;
  });
  const [loading, setLoading] = useState(true);
  const [showAccess, setShowAccess] = useState(false);
  const [name, setName] = useState("");
  const [whats, setWhats] = useState("");
  const [clientKeyState, setClientKeyState] = useState<string | null>(getClientKey());
  const [clientNameState, setClientNameState] = useState<string>(getClientName() ?? "");
  const [appts, setAppts] = useState<Appointment[]>([]);
  const [loadingAppts, setLoadingAppts] = useState(false);
  const [editId, setEditId] = useState("");
  const [supCities, setSupCities] = useState<any[]>([]);
  const [supCats, setSupCats] = useState<any[]>([]);
  const navigate = useNavigate();
  useEffect(() => {
    async function loadData() {
      try {
        const [cats, cities] = await Promise.all([
          getCategoriesAdapter().listCategories(),
          getCitiesAdapter().listCities()
        ]);
        setSupCats(cats);
        setSupCities(cities);
      } catch (error) {
        console.error('Error loading data:', error);
      } finally {
        const t = setTimeout(() => setLoading(false), 400);
        clearTimeout(t);
        setLoading(false);
      }
    }
    loadData();
  }, []);

  useEffect(() => {
    if (showAccess) {
      setClientKeyState(getClientKey());
      setClientNameState(getClientName() ?? "");
    }
  }, [showAccess]);

  useEffect(() => {
    async function fetchAppts() {
      if (!showAccess || !clientKeyState) return;
      setLoadingAppts(true);
      try {
        const data = await listAppointmentsByClient(clientKeyState);
        setAppts(data);
      } finally {
        setLoadingAppts(false);
      }
    }
    fetchAppts();
  }, [showAccess, clientKeyState]);

  const [establishments, setEstablishments] = useState<any[]>([]);

  useEffect(() => {
    async function loadEstablishments() {
      try {
        const filters: any = {};
        if (city && city !== "all") {
          const selectedCity = supCities.find(c => c.name === city);
          if (selectedCity) filters.cityId = selectedCity.id;
        }
        if (type && type !== "all") {
          const selectedCat = supCats.find(c => c.name === type);
          if (selectedCat) filters.categoryId = selectedCat.id;
        }
        
        console.log('Loading establishments with filters:', filters);
        const ests = await listEstablishments(Object.keys(filters).length > 0 ? filters : undefined);
        console.log('Loaded establishments:', ests);
        console.log('Establishments with Kabra in name:', ests.filter(e => e.name.toLowerCase().includes('kabra')));
        setEstablishments(ests);
      } catch (error) {
        console.error('Error loading establishments:', error);
        setEstablishments([]);
      }
    }
    if (supCities.length > 0 && supCats.length > 0) {
      loadEstablishments();
    }
  }, [city, type, supCities, supCats]);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    return establishments.filter(
      (e) =>
        e.isActive &&
        (q ? e.name.toLowerCase().includes(q) : true)
    );
  }, [search, establishments]);

  function handleAccess() {
    const normalized = normalizePhone(whats);
    if (!name.trim() || !normalized) {
      toast({ title: "Dados obrigatórios", description: "Informe seu nome e WhatsApp." });
      return;
    }
    setClientKey(normalized);
    setClientName(name.trim());
    setClientKeyState(normalized);
    setClientNameState(name.trim());
    toast({ title: "Bem-vindo", description: "Selecione uma opção abaixo" });
  }

  return (
    <div className="min-h-screen relative">
      <Seo
        title="Vitrine de Estabelecimentos | LookPro"
        description="Explore todos os estabelecimentos ativos e encontre serviços perto de você."
        canonicalPath="/vitrine"
      />
      <GradientSpotlight />

      <header className="container pwa-header py-6 flex flex-wrap items-center justify-between gap-2">
        <Link to="/" className="inline-flex items-center gap-2">
          <div className="size-8 rounded-md bg-[image:var(--gradient-primary)] grid place-items-center">
            <span aria-hidden="true" className="text-[10px] font-extrabold tracking-tight text-primary-foreground">LP</span>
          </div>
          <span className="text-lg font-extrabold">LookPro</span>
        </Link>
        <div className="flex flex-wrap items-center gap-2">
          <Dialog open={showAccess} onOpenChange={setShowAccess}>
            <DialogTrigger asChild>
              <Button variant="hero" size="sm">Meus Agendamentos</Button>
            </DialogTrigger>
            <DialogContent aria-describedby={undefined}>
              <DialogHeader>
                <DialogTitle>Área do Cliente</DialogTitle>
                <DialogDescription>Acesse seus agendamentos e ações.</DialogDescription>
              </DialogHeader>
              {clientKeyState ? (
                <div className="grid gap-4 py-2">
                  <p className="text-sm text-muted-foreground">Olá{clientNameState ? `, ${clientNameState}` : ""}! O que você deseja fazer?</p>
                  <div className="grid gap-2">
                     <Button variant="hero" onClick={() => { setShowAccess(false); navigate("/cliente/agendamentos"); }}>Ver meus agendamentos</Button>
                  </div>
                  <div className="grid gap-3">
                    <h3 className="text-sm font-semibold">Meus agendamentos</h3>
                    {loadingAppts ? (
                      <div className="grid gap-2">
                        {[...Array(3)].map((_, i) => (
                          <div key={i} className="flex items-center justify-between rounded-md border p-3 bg-card">
                            <div className="flex-1 mr-4">
                              <Skeleton className="h-4 w-40 mb-2" />
                              <Skeleton className="h-3 w-24" />
                            </div>
                            <Skeleton className="h-8 w-32 rounded-md" />
                          </div>
                        ))}
                      </div>
                    ) : appts.length === 0 ? (
                      <p className="text-sm text-muted-foreground">Você ainda não possui agendamentos.</p>
                    ) : (
                      <div className="grid gap-2">
                        {appts.map((a) => (
                          <div key={a.id} className="flex items-center justify-between rounded-md border p-3 bg-card">
                            <div className="min-w-0 mr-4">
                              <p className="font-medium truncate">{a.serviceName}</p>
                              <p className="text-xs text-muted-foreground">{a.date} • {a.time} • {a.status}</p>
                            </div>
                            <div className="flex gap-2 shrink-0">
                              <Button size="sm" variant="outline" onClick={() => { setShowAccess(false); navigate(`/cliente/agendamentos/${a.id}/editar`); }}>Editar</Button>
                              <Button size="sm" variant="destructive" onClick={async () => {
                                try {
                                  await cancelAppointmentAsClient(a.id, clientKeyState!);
                                  toast({ title: "Agendamento cancelado", description: `${a.serviceName} • ${a.time}` });
                                  const data = await listAppointmentsByClient(clientKeyState!);
                                  setAppts(data);
                                } catch (e: any) {
                                  toast({ title: "Erro ao cancelar", description: e.message });
                                }
                              }}>Cancelar</Button>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                  <div className="flex justify-between pt-2">
                    <Button variant="outline" onClick={() => setShowAccess(false)}>Fechar</Button>
                    <Button variant="destructive" onClick={() => { clearClientKey(); setClientName(""); setWhats(""); setName(""); setClientKeyState(null); setClientNameState(""); toast({ title: "Sessão encerrada" }); }}>Sair</Button>
                  </div>
                </div>
              ) : (
                <div className="grid gap-4 py-2">
                  <div className="grid gap-2">
                    <Label htmlFor="client-name">Seu nome</Label>
                    <Input id="client-name" placeholder="Nome completo" value={name} onChange={(e) => setName(e.target.value)} />
                  </div>
                  <div className="grid gap-2">
                    <Label htmlFor="client-whats">WhatsApp</Label>
                    <Input id="client-whats" placeholder="(11) 90000-0000" value={whats} onChange={(e) => setWhats(e.target.value)} />
                  </div>
                  <div className="flex justify-end gap-2">
                    <Button variant="outline" onClick={() => setShowAccess(false)}>Cancelar</Button>
                    <Button variant="hero" onClick={handleAccess}>Acessar</Button>
                  </div>
                </div>
              )}
            </DialogContent>
          </Dialog>
          <Link to="/">
            <Button variant="soft" size="sm">Voltar</Button>
          </Link>
        </div>
      </header>

      <main className="container pb-16">
        <section className="py-6">
          <h1 className="text-3xl md:text-4xl font-extrabold tracking-tight">Explore todos os estabelecimentos</h1>
          <div className="mt-6 grid grid-cols-1 md:grid-cols-4 gap-3">
            <Input
              placeholder="Buscar por nome"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="md:col-span-2 h-12"
            />
            <Select value={city} onValueChange={setCity}>
              <SelectTrigger className="h-12">
                <SelectValue placeholder="Cidade" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todas as cidades</SelectItem>
                {supCities.map((c) => (
                  <SelectItem key={c.id} value={c.name}>
                    {c.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={type} onValueChange={setType}>
              <SelectTrigger className="h-12">
                <SelectValue placeholder="Tipo" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos os tipos</SelectItem>
                {supCats.map((cat) => (
                  <SelectItem key={cat.id} value={cat.name}>
                    {cat.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </section>

        <section aria-labelledby="grid-vitrine" className="py-4">
          <h2 id="grid-vitrine" className="sr-only">Lista de estabelecimentos ativos</h2>
          {loading ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {[...Array(8)].map((_, i) => (
                <div key={i} className="rounded-lg border bg-card p-6">
                  <div className="flex items-center gap-3 mb-4">
                    <Skeleton className="size-12 rounded-md" />
                    <div className="flex-1">
                      <Skeleton className="h-4 w-40 mb-2" />
                      <Skeleton className="h-3 w-28" />
                    </div>
                  </div>
                  <div className="flex items-center justify-between">
                    <Skeleton className="h-4 w-32" />
                    <Skeleton className="h-9 w-24 rounded-md" />
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                {filtered.map((e) => (
                  <EstablishmentCard key={e.id} est={e} />
                ))}
              </div>
              {filtered.length === 0 && (
                <p className="text-center text-muted-foreground mt-8">
                  Nenhum estabelecimento encontrado com esses critérios.
                </p>
              )}
            </>
          )}
        </section>
      </main>

      <footer className="container py-10 text-center text-sm text-muted-foreground">
        © {new Date().getFullYear()} LookPro • Plataforma de agendamentos multi-tenant
      </footer>
    </div>
  );
};

export default Vitrine;
