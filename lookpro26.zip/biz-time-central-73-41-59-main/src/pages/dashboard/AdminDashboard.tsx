import { useEffect, useMemo, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import Seo from "@/components/Seo";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart";
import { Line, LineChart, XAxis, YAxis, CartesianGrid } from "recharts";
import { Plus, Users } from "lucide-react";
import { toast } from "@/hooks/use-toast";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/context/AuthContext";
import { listAppointmentsByEstablishment } from "@/services/appointments";
import { establishmentsAdapter } from "@/services/adapters";
import { adminAdapter } from "@/services/adminAdapters";
import { fetchEstablishmentTotalCents, FinancePeriodUtils } from "@/services/finance";
import { formatBRL } from "@/utils/currency";
import type { Appointment, AppointmentStatus } from "@/types/appointments";

// Local types for dashboard display
interface DashboardAppointment {
  id: string;
  client: string;
  service: string;
  date: string; // 2025-08-10
  time: string; // 14:30
  professional: string;
  status: AppointmentStatus;
}

const AdminDashboard = () => {
  const navigate = useNavigate();
  const { user, loading: authLoading } = useAuth();

  // Get establishment ID from authenticated user context
  const estId = user?.establishmentId;
  
  const [establishment, setEstablishment] = useState<any>(null);
  const [professionals, setProfessionals] = useState<any[]>([]);
  const [services, setServices] = useState<any[]>([]);
  const [revenueCents, setRevenueCents] = useState(0);
  const [appointments, setAppointments] = useState<DashboardAppointment[]>([]);
  const [search, setSearch] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function loadData() {
      // Wait for auth to load and check if user has establishment_id
      if (authLoading || !user || !estId) {
        setLoading(false);
        return;
      }

      try {
        // Load establishment data
        const est = await establishmentsAdapter.getById(estId);
        if (!est) {
          console.error('Establishment not found');
          setLoading(false);
          return;
        }
        setEstablishment(est);

        // Load professionals and services
        const [professionalsData, servicesData] = await Promise.all([
        adminAdapter.listProfessionals(estId),
        adminAdapter.listServices(estId)
        ]);
        
        setProfessionals(Array.isArray(professionalsData) ? professionalsData : []);
        setServices(Array.isArray(servicesData) ? servicesData : []);

        // Load appointments for today
        const today = new Date().toISOString().split('T')[0]; // YYYY-MM-DD format
        const appointmentsData = await listAppointmentsByEstablishment(estId, { date: today });
        
        // Transform appointments to dashboard format
        const dashboardAppointments: DashboardAppointment[] = (Array.isArray(appointmentsData) ? appointmentsData : []).map(appt => ({
          id: appt.id,
          client: appt.clientName || 'N/A',
          service: appt.serviceName || 'N/A',
          date: appt.date,
          time: appt.time,
          professional: appt.professionalName || 'N/A',
          status: appt.status
        }));
        
        setAppointments(dashboardAppointments);

        // Load monthly revenue using new financial system
        const { start, end } = FinancePeriodUtils.getCurrentMonth();
        const totalCents = await fetchEstablishmentTotalCents(estId, start, end);
        setRevenueCents(totalCents);

      } catch (error) {
        console.error('Error loading dashboard data:', error);
      } finally {
        setLoading(false);
      }
    }
    
    loadData();
  }, [estId, authLoading, user]);

  const filteredAppts = useMemo(() => {
    const q = search.toLowerCase();
    return appointments.filter((a) =>
      [a.client, a.service, a.professional, a.time].some((t) => t.toLowerCase().includes(q))
    );
  }, [appointments, search]);

  const metrics = useMemo(() => {
    const todayTotal = appointments.length;
    const pend = appointments.filter((a) => a.status === "pendente").length;
    const conf = appointments.filter((a) => a.status === "confirmado").length;
    const concl = appointments.filter((a) => a.status === "concluído").length;
    return { todayTotal, pend, conf, concl };
  }, [appointments]);

  const chartData = useMemo(
    () => [
      { day: "Seg", value: 8 },
      { day: "Ter", value: 10 },
      { day: "Qua", value: 7 },
      { day: "Qui", value: 12 },
      { day: "Sex", value: 14 },
      { day: "Sáb", value: 9 },
      { day: "Dom", value: 5 },
    ],
    []
  );

  async function concluir(id: string) {
    setAppointments((prev) => prev.map((a) => (a.id === id ? { ...a, status: "concluído" } : a)));
    const appt = appointments.find((a) => a.id === id);
    toast({ title: "Atendimento concluído", description: `${appt?.client} • ${appt?.time}` });
    
    try {
      const { updateAppointment } = await import("@/services/supabase/appointments");
      await updateAppointment(id, { status: "completed" as any });
    } catch (error) {
      console.error('Error updating appointment status:', error);
    }
  }

  async function cancelar(id: string) {
    setAppointments((prev) => prev.map((a) => (a.id === id ? { ...a, status: "cancelado" } : a)));
    const appt = appointments.find((a) => a.id === id);
    toast({ title: "Agendamento cancelado", description: `${appt?.client} • ${appt?.time}` });
    
    try {
      const { updateAppointment } = await import("@/services/supabase/appointments");
      await updateAppointment(id, { status: "cancelled" as any });
    } catch (error) {
      console.error('Error updating appointment status:', error);
    }
  }

  function novoServico() {
    navigate("/dashboard/admin/servicos/novo");
  }
  
  function convidarProfissional() {
    navigate("/dashboard/admin/profissionais/novo");
  }

  if (authLoading || loading) {
    return (
      <main className="container py-8">
        <Seo title="LookPro — Painel do Estabelecimento" description="Visão geral do seu estabelecimento e métricas." canonicalPath="/dashboard/admin" />
        <div className="text-center py-8">Carregando dados do estabelecimento...</div>
      </main>
    );
  }

  if (!user?.establishmentId) {
    return (
      <main className="container py-8">
        <Seo title="LookPro — Painel do Estabelecimento" description="Visão geral do seu estabelecimento e métricas." canonicalPath="/dashboard/admin" />
        <div className="text-center py-8">
          <h2 className="text-xl font-semibold mb-2">Configuração Pendente</h2>
          <p className="text-muted-foreground">Seu usuário ainda não foi associado a um estabelecimento. Entre em contato com o suporte.</p>
        </div>
      </main>
    );
  }

  if (!establishment) {
    return (
      <main className="container py-8">
        <Seo title="LookPro — Painel do Estabelecimento" description="Visão geral do seu estabelecimento e métricas." canonicalPath="/dashboard/admin" />
        <div className="text-center py-8">
          <h2 className="text-xl font-semibold mb-2">Estabelecimento não encontrado</h2>
          <p className="text-muted-foreground">O estabelecimento associado à sua conta não foi encontrado.</p>
        </div>
      </main>
    );
  }

  return (
    <main className="container py-8">
      <Seo title="LookPro — Painel do Estabelecimento" description="Visão geral do seu estabelecimento e métricas." canonicalPath="/dashboard/admin" />
      <header className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between mb-6">
        <div className="flex items-center gap-3">
          <div className="size-10 rounded-md bg-[image:var(--gradient-primary)]" />
          <div>
            <h1 className="text-2xl font-extrabold">{establishment.name || 'Estabelecimento'}</h1>
            <p className="text-sm text-muted-foreground">{establishment.address || 'Endereço não informado'}</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="soft" onClick={convidarProfissional}><Users className="size-4" /> Convidar profissional</Button>
          <Button variant="hero" onClick={novoServico}><Plus className="size-4" /> Novo serviço</Button>
        </div>
      </header>

      <section className="grid grid-cols-1 md:grid-cols-5 gap-4 mb-6">
        <Card className="shadow-[var(--shadow-elev)]">
          <CardHeader><CardTitle>Agendamentos de Hoje</CardTitle></CardHeader>
          <CardContent className="text-3xl font-extrabold">{metrics.todayTotal}</CardContent>
        </Card>
        <Card>
          <CardHeader><CardTitle>Pendentes</CardTitle></CardHeader>
          <CardContent className="text-3xl font-extrabold">{metrics.pend}</CardContent>
        </Card>
        <Card>
          <CardHeader><CardTitle>Confirmados</CardTitle></CardHeader>
          <CardContent className="text-3xl font-extrabold">{metrics.conf}</CardContent>
        </Card>
        <Card>
          <CardHeader><CardTitle>Concluídos</CardTitle></CardHeader>
          <CardContent className="text-3xl font-extrabold">{metrics.concl}</CardContent>
        </Card>
        <Card>
          <CardHeader><CardTitle>Faturamento (mês)</CardTitle></CardHeader>
          <CardContent className="text-3xl font-extrabold">{formatBRL(revenueCents)}</CardContent>
        </Card>
      </section>

      <section className="mb-6">
        <Card>
          <CardHeader><CardTitle>Evolução semanal de agendamentos</CardTitle></CardHeader>
          <CardContent>
            <ChartContainer
              config={{ series: { label: "Agendamentos", color: "hsl(var(--primary))" } }}
              className="h-[220px]"
            >
              <LineChart data={chartData} margin={{ left: 12, right: 12 }}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="day" tickLine={false} axisLine={false} />
                <YAxis width={28} tickLine={false} axisLine={false} />
                <ChartTooltip content={<ChartTooltipContent />} />
                <Line type="monotone" dataKey="value" stroke="var(--color-series)" strokeWidth={2} dot={false} />
              </LineChart>
            </ChartContainer>
          </CardContent>
        </Card>
      </section>

      <Tabs defaultValue="agendamentos" className="space-y-4">
        <TabsList>
          <TabsTrigger value="agendamentos">Agendamentos</TabsTrigger>
          <TabsTrigger value="servicos">Serviços</TabsTrigger>
          <TabsTrigger value="profissionais">Profissionais</TabsTrigger>
          <TabsTrigger value="avaliacoes">Avaliações</TabsTrigger>
          <TabsTrigger value="horarios">Horários</TabsTrigger>
          <TabsTrigger value="config">Configuração</TabsTrigger>
        </TabsList>

        <TabsContent value="agendamentos">
          <Card>
            <CardHeader className="flex flex-col gap-2 md:flex-row md:items-center md:justify-between">
              <CardTitle>Próximos atendimentos</CardTitle>
              <div className="w-full md:w-64">
                <Input placeholder="Buscar por cliente, serviço..." value={search} onChange={(e) => setSearch(e.target.value)} />
              </div>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Cliente</TableHead>
                    <TableHead>Serviço</TableHead>
                    <TableHead>Data</TableHead>
                    <TableHead>Hora</TableHead>
                    <TableHead>Profissional</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Ações</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredAppts.map((a) => (
                    <TableRow key={a.id}>
                      <TableCell className="font-medium">{a.client}</TableCell>
                      <TableCell>{a.service}</TableCell>
                      <TableCell>{a.date}</TableCell>
                      <TableCell>{a.time}</TableCell>
                      <TableCell>{a.professional}</TableCell>
                      <TableCell>
                        {a.status === "confirmado" && <Badge variant="default">Confirmado</Badge>}
                        {a.status === "pendente" && <Badge variant="secondary">Pendente</Badge>}
                        {a.status === "concluído" && <Badge variant="outline">Concluído</Badge>}
                        {a.status === "cancelado" && <Badge variant="destructive">Cancelado</Badge>}
                      </TableCell>
                      <TableCell className="text-right space-x-2">
                        {a.status !== "concluído" && a.status !== "cancelado" && (
                          <Button size="sm" variant="soft" onClick={() => concluir(a.id)}>Concluir</Button>
                        )}
                        {a.status !== "cancelado" && (
                          <Button size="sm" variant="outline" onClick={() => cancelar(a.id)}>Cancelar</Button>
                        )}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
              {filteredAppts.length === 0 && (
                <p className="text-sm text-muted-foreground">Nenhum agendamento encontrado.</p>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="servicos">
          <Card>
            <CardHeader className="flex flex-col md:flex-row md:items-center md:justify-between">
              <CardTitle>Serviços</CardTitle>
              <Button variant="hero" onClick={novoServico}><Plus className="size-4" /> Novo serviço</Button>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Nome</TableHead>
                    <TableHead>Duração</TableHead>
                    <TableHead>Preço</TableHead>
                    <TableHead className="text-right">Ações</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {services.map((s) => (
                    <TableRow key={s.id}>
                      <TableCell className="font-medium">{s.name || 'N/A'}</TableCell>
                      <TableCell>{s.duration || 0} min</TableCell>
                      <TableCell>{Number(s.price || 0).toLocaleString("pt-BR", { style: "currency", currency: "BRL" })}</TableCell>
                      <TableCell className="text-right space-x-2">
                        <Button size="sm" variant="outline" onClick={() => navigate(`/dashboard/admin/servicos/${s.id}/editar`)}>Editar</Button>
                        <Button size="sm" variant="destructive" onClick={() => toast({ title: "Serviço removido", description: s.name })}>Remover</Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="profissionais">
          <Card>
            <CardHeader className="flex flex-col md:flex-row md:items-center md:justify-between">
              <CardTitle>Equipe</CardTitle>
              <Button variant="soft" onClick={convidarProfissional}><Users className="size-4" /> Convidar</Button>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Nome</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Total Hoje</TableHead>
                    <TableHead className="text-right">Ações</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {professionals.map((p) => (
                    <TableRow key={p.id}>
                      <TableCell className="font-medium">{p.name || 'N/A'}</TableCell>
                      <TableCell><Badge variant="secondary">{p.active ? 'Ativo' : 'Inativo'}</Badge></TableCell>
                      <TableCell>{appointments.filter(a => a.professional === p.name).length}</TableCell>
                      <TableCell className="text-right space-x-2">
                        <Button size="sm" variant="outline" onClick={() => navigate(`/dashboard/admin/profissionais/${p.id}/editar`)}>Editar</Button>
                        <Button size="sm" variant="destructive" onClick={() => toast({ title: "Profissional desativado", description: p.name })}>Desativar</Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="avaliacoes">
          <Card>
            <CardHeader><CardTitle>Avaliações Recentes</CardTitle></CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">Sem avaliações novas.</p>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="horarios">
          <Card>
            <CardHeader className="flex flex-col md:flex-row md:items-center md:justify-between">
              <CardTitle>Horário de funcionamento</CardTitle>
              <Button variant="outline" onClick={() => navigate("/dashboard/admin/horarios")}>Editar horários</Button>
            </CardHeader>
            <CardContent>
              {(() => {
                const today = new Date().getDay().toString();
                const h = establishment?.workingHoursByDay?.[today];
                return h && !h.closed
                  ? <p className="text-sm">Hoje: {h.start} – {h.end}</p>
                  : <p className="text-sm text-muted-foreground">Horário não configurado</p>;
              })()}
              <p className="text-sm text-muted-foreground mt-1">Feriados e pausas podem ser configurados em breve.</p>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="config">
          <Card>
            <CardHeader><CardTitle>Perfil da empresa</CardTitle></CardHeader>
            <CardContent className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <div className="text-xs text-muted-foreground">Nome</div>
                <div className="font-medium">{establishment.name || 'N/A'}</div>
              </div>
              <div>
                <div className="text-xs text-muted-foreground">Endereço</div>
                <div className="font-medium">{establishment.address || 'N/A'}</div>
              </div>
              <div>
                <div className="text-xs text-muted-foreground">Telefone</div>
                <div className="font-medium">{establishment.phone || 'N/A'}</div>
              </div>
              <div>
                <div className="text-xs text-muted-foreground">Status</div>
                <div className="font-medium">{establishment.status === 'active' ? "Ativo" : "Inativo"}</div>
              </div>
              <div className="md:col-span-2 flex justify-end">
                <Button variant="hero" onClick={() => navigate("/dashboard/admin/configuracoes")}>Editar perfil</Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </main>
  );
};

export default AdminDashboard;
