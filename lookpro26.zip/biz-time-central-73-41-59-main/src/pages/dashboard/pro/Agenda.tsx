import { useEffect, useMemo, useState } from "react";
import Seo from "@/components/Seo";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";
import { listAppointmentsByProfessional, updateAppointmentStatus, createAppointment, deleteAppointment } from "@/services/appointments";
import { blockedPeriodsAdapter, servicesAdapter, professionalsAdapter } from "@/services/adapters";
import { useAuthContext } from "@/context/AuthContext";
import { fetchProfessionalTotalCents, FinancePeriodUtils } from "@/services/finance";
import { formatBRL } from "@/utils/currency";
import type { Appointment } from "@/types/appointments";
import { normalizePhone } from "@/lib/clientIdentity";
import { getProfessionalSchedule, isTimeSlotAvailable, getEstablishmentWorkingHours } from "@/services/supabase/schedule";
import { useProfessionalSchedule } from "@/hooks/useProfessionalSchedule";
import { useEstablishmentSchedule } from "@/hooks/useEstablishmentSchedule";
import { supabase } from "@/integrations/supabase/client";
import { Clock, User, Calendar } from "lucide-react";

const formatDateTime = (date: string, time: string) => {
  // Ensure time is in HH:mm format (remove seconds if present)
  const timeFormatted = time.split(':').slice(0, 2).join(':');
  const datetime = `${date}T${timeFormatted}:00`;
  const d = new Date(datetime);
  
  // Check if date is valid
  if (isNaN(d.getTime())) {
    return `${date} ${timeFormatted}`;
  }
  
  return d.toLocaleString("pt-BR", { dateStyle: "short", timeStyle: "short" });
};

const withinRange = (iso: string, range: "day" | "week" | "month") => {
  try {
    const d = new Date(iso);
    if (isNaN(d.getTime())) {
      console.error('Invalid date:', iso);
      return false;
    }
    const now = new Date();
    
    if (range === "day") {
      // Compare only the date part, ignoring time
      const appointmentDate = d.toISOString().split('T')[0];
      const todayDate = now.toISOString().split('T')[0];
      return appointmentDate === todayDate;
    }
  
  if (range === "week") {
    const start = new Date(now);
    const day = start.getDay();
    const diffToMon = (day === 0 ? 6 : day - 1);
    start.setDate(now.getDate() - diffToMon);
    const end = new Date(start);
    end.setDate(start.getDate() + 6);
    return d >= start && d <= end;
  }
  
  const start = new Date(now.getFullYear(), now.getMonth(), 1);
  const end = new Date(now.getFullYear(), now.getMonth() + 1, 0, 23, 59, 59);
  return d >= start && d <= end;
  } catch (error) {
    console.error('Error in withinRange:', error);
    return false;
  }
};

const statusBadge = (st: Appointment["status"]) => {
  const map: Record<Appointment["status"], string> = {
    pendente: "default",
    confirmado: "default", 
    concluído: "secondary",
    cancelado: "destructive",
  };
  return <Badge variant={map[st] as any}>{
    st === "pendente" ? "Pendente" : st === "confirmado" ? "Confirmado" : st === "concluído" ? "Concluído" : "Cancelado"
  }</Badge>;
};

const AgendaPage = () => {
  const { user } = useAuthContext();
  const { workingHours: establishmentHours } = useEstablishmentSchedule(user?.establishmentId || "");
  const [range, setRange] = useState<"day" | "week" | "month">("day");
  const [refresh, setRefresh] = useState(0);
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState<{ clientName: string; clientPhone: string; serviceId: string; date: string; time: string }>({
    clientName: "",
    clientPhone: "",
    serviceId: "",
    date: new Date().toISOString().slice(0, 10),
    time: "",
  });

  const [services, setServices] = useState<{ id: string; name: string; price: number; duration: number }[]>([]);
  const [availableSlots, setAvailableSlots] = useState<string[]>([]);
  const [establishmentId, setEstablishmentId] = useState<string>("");
  const [isBlocked, setIsBlocked] = useState(false);
  const [data, setData] = useState<any[]>([]);
  const [currentDate, setCurrentDate] = useState(() => new Date().toISOString().slice(0, 10));
  const [selectedDateObj, setSelectedDateObj] = useState(() => new Date());
  const [financialSummary, setFinancialSummary] = useState({ completed: 0, revenueCents: 0 });
  
  // Get professional ID from user ID
  const [professionalId, setProfessionalId] = useState<string>('');

  useEffect(() => {
    (async () => {
      if (!user) return;
      const pro = await professionalsAdapter.getById(user.uid);
      if (pro?.establishmentId) {
        setEstablishmentId(pro.establishmentId);
        const list = await servicesAdapter.listByEstablishment(pro.establishmentId);
        setServices(list);
      }
    })();
  }, [user]);

  // Atualizar slots de tempo baseados no horário de funcionamento do estabelecimento
  useEffect(() => {
    (async () => {
      if (!establishmentId || !form.date) return;
      
      try {
        const workingHours = await getEstablishmentWorkingHours(establishmentId);
        const dayOfWeek = new Date(form.date + 'T00:00:00').getDay();
        const dayHours = workingHours[dayOfWeek.toString()];
        
        if (dayHours && !dayHours.closed) {
          const slots: string[] = [];
          const [startHour, startMin] = dayHours.start.split(':').map(Number);
          const [endHour, endMin] = dayHours.end.split(':').map(Number);
          
          const startMinutes = startHour * 60 + startMin;
          const endMinutes = endHour * 60 + endMin;
          
          for (let minutes = startMinutes; minutes < endMinutes; minutes += 30) {
            const hours = Math.floor(minutes / 60);
            const mins = minutes % 60;
            const timeString = `${hours.toString().padStart(2, '0')}:${mins.toString().padStart(2, '0')}`;
            slots.push(timeString);
          }
          
          setAvailableSlots(slots);
        } else {
          setAvailableSlots([]);
        }
      } catch (error) {
        console.error('Error loading working hours:', error);
        setAvailableSlots([]);
      }
    })();
  }, [establishmentId, form.date]);

  useEffect(() => {
    (async () => {
      if (!user) return;
      console.log('Current user email:', user.email, 'user UID:', user.uid);
      const pro = await professionalsAdapter.getByEmail(user.email);
      console.log('Professional found by email:', pro);
      if (pro?.id) {
        setProfessionalId(pro.id);
        console.log('Professional ID set to:', pro.id);
      } else {
        console.log('No professional found for email:', user.email);
        console.log('Trying alternative lookup by user_id:', user.uid);
        // Fallback: try to find professional by user_id directly
        const { data: fallbackPro } = await supabase
          .from('professionals')
          .select('id')
          .eq('user_id', user.uid)
          .single();
        if (fallbackPro) {
          setProfessionalId(fallbackPro.id);
          console.log('Professional ID found via fallback:', fallbackPro.id);
        }
      }
    })();
  }, [user]);

  useEffect(() => {
    if (!professionalId || !form.date || !form.time) {
      setIsBlocked(false);
      return;
    }
    
    const checkBlocked = async () => {
      const blocked = await blockedPeriodsAdapter.listOverlaps(professionalId, form.date);
      const apptDate = new Date(`${form.date}T${form.time}:00`).toISOString();
      const isSlotBlocked = blocked.some(b => apptDate >= b.start && apptDate <= b.end);
      setIsBlocked(isSlotBlocked);
    };
    
    checkBlocked();
  }, [professionalId, form.date, form.time, refresh]);

  // Use the professional schedule hook
  const { getScheduleForDate, refreshSchedule, loading: scheduleLoading } = useProfessionalSchedule(professionalId);

  // Add real-time synchronization
  useEffect(() => {
    if (!professionalId) return;

    console.log('Setting up realtime listeners for agenda page, professional:', professionalId);

    // Listen to appointments changes
    const appointmentsChannel = supabase
      .channel('agenda-appointments-changes')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'appointments',
          filter: `professional_id=eq.${professionalId}`
        },
        (payload) => {
          console.log('Agenda: Appointment realtime update:', payload);
          setRefresh((x) => x + 1);
          refreshSchedule();
        }
      )
      .subscribe();

    // Listen to blocked periods changes
    const blockedChannel = supabase
      .channel('agenda-blocked-periods-changes')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'blocked_periods',
          filter: `professional_id=eq.${professionalId}`
        },
        (payload) => {
          console.log('Agenda: Blocked period realtime update:', payload);
          setRefresh((x) => x + 1);
          refreshSchedule();
        }
      )
      .subscribe();

    // Listen to custom blocking events from other pages
    const handleBlockingUpdated = (event: any) => {
      if (event.detail?.professionalId === professionalId) {
        console.log('Agenda: Blocking updated via custom event:', event.detail);
        setRefresh((x) => x + 1);
        refreshSchedule();
      }
    };

    window.addEventListener('blockingUpdated', handleBlockingUpdated);

    return () => {
      supabase.removeChannel(appointmentsChannel);
      supabase.removeChannel(blockedChannel);
      window.removeEventListener('blockingUpdated', handleBlockingUpdated);
    };
  }, [professionalId, refreshSchedule]);

  useEffect(() => {
    if (!professionalId) {
      console.log('No professional ID available yet');
      return;
    }
    const loadData = async () => {
      console.log('Loading appointments for professional:', professionalId, 'date:', currentDate);
      const appointments = await listAppointmentsByProfessional(professionalId, { date: currentDate });
      console.log('Appointments loaded via service:', appointments);
      const filtered = appointments.filter((a) => {
        try {
          // Time already includes seconds (HH:MM:SS), so just append to date
          const appointmentDate = `${a.date}T${a.time}`;
          const inRange = withinRange(appointmentDate, range);
          console.log(`Appointment ${a.id} (${a.clientName}) date: ${appointmentDate}, range: ${range}, in range: ${inRange}`);
          return inRange;
        } catch (error) {
          console.error('Error filtering appointment:', a, error);
          return false;
        }
      });
      console.log('Final filtered appointments for display:', filtered);
      setData(filtered);
    };
    loadData();
  }, [professionalId, range, refresh, currentDate]);

  // Get schedule for selected date and merge with appointments
  const daySchedule = useMemo(() => {
    const schedule = getScheduleForDate(selectedDateObj);
    const selectedDateStr = selectedDateObj.toISOString().split('T')[0];
    
    // Get appointments for the selected date
    const dayAppointments = data.filter(appointment => {
      return appointment.date === selectedDateStr;
    });
    
    // Update slots with appointment information
    const updatedSlots = schedule.slots.map(slot => {
      const appointment = dayAppointments.find(apt => {
        // Remove seconds from appointment time and compare
        const aptTime = apt.time.split(':').slice(0, 2).join(':');
        return aptTime === slot.time;
      });
      
      return {
        ...slot,
        appointment: appointment || slot.appointment
      };
    });
    
    return {
      ...schedule,
      slots: updatedSlots
    };
  }, [getScheduleForDate, selectedDateObj, data]);

  // Load financial data when professional or range changes
  useEffect(() => {
    const loadFinancialData = async () => {
      if (!professionalId) return;
      
      try {
        let startDate: Date | undefined;
        let endDate: Date | undefined;
        
        if (range === "day") {
          startDate = new Date(currentDate + 'T00:00:00');
          endDate = new Date(currentDate + 'T23:59:59');
        } else if (range === "week") {
          const now = new Date(currentDate + 'T00:00:00');
          const dayOfWeek = now.getDay();
          const diffToMon = (dayOfWeek === 0 ? 6 : dayOfWeek - 1);
          startDate = new Date(now.getTime() - diffToMon * 24 * 60 * 60 * 1000);
          endDate = new Date(startDate.getTime() + 6 * 24 * 60 * 60 * 1000 + 23 * 60 * 60 * 1000 + 59 * 60 * 1000 + 59 * 1000);
        } else {
          const { start, end } = FinancePeriodUtils.getCurrentMonth();
          startDate = start;
          endDate = end;
        }
        
        const totalCents = await fetchProfessionalTotalCents(professionalId, startDate, endDate);
        const completed = data.filter((a) => a.status === "concluído").length;
        
        setFinancialSummary({ completed, revenueCents: totalCents });
      } catch (error) {
        console.error('Error loading financial data:', error);
        setFinancialSummary({ completed: 0, revenueCents: 0 });
      }
    };
    
    loadFinancialData();
  }, [professionalId, range, currentDate, data]);

  const summary = useMemo(() => {
    return financialSummary;
  }, [financialSummary]);

  const onUpdate = async (id: string, status: "concluído" | "cancelado") => {
    await updateAppointmentStatus(id, status);
    toast.success("Status atualizado");
    setRefresh((x) => x + 1);
  };

  const onDelete = async (id: string) => {
    try {
      await deleteAppointment(id);
      toast.success("Agendamento excluído com sucesso");
      setRefresh((x) => x + 1);
      refreshSchedule();
    } catch (error: any) {
      toast.error(error.message || "Erro ao excluir agendamento");
    }
  };
  const onToggleBlock = async () => {
    if (!professionalId || !form.date || !form.time) return;
    
    try {
      if (isBlocked) {
        // Find and remove the blocking period
        const blocked = await blockedPeriodsAdapter.listOverlaps(professionalId, form.date);
        const apptDate = new Date(`${form.date}T${form.time}:00`).toISOString();
        const blockToRemove = blocked.find(b => apptDate >= b.start && apptDate <= b.end);
        
        if (blockToRemove) {
          await blockedPeriodsAdapter.remove(blockToRemove.id);
          toast.success("Horário desbloqueado");
        }
      } else {
        // Create new blocking period for this specific time slot
        const start = new Date(`${form.date}T${form.time}:00`).toISOString();
        const end = new Date(new Date(start).getTime() + 30 * 60 * 1000).toISOString(); // 30 min block
        
        await blockedPeriodsAdapter.create({
          professionalId: professionalId,
          start,
          end,
          reason: "Bloqueado pela agenda"
        });
        
        toast.success("Horário bloqueado");
      }
      
      setRefresh((x) => x + 1);
    } catch (error: any) {
      toast.error(error.message || "Erro ao alterar bloqueio");
    }
  };

  const onCreate = async () => {
    if (!user || !professionalId) return;
    const { clientName, clientPhone, serviceId, date, time } = form;
    if (!clientName || !clientPhone || !serviceId || !date || !time) {
      toast.error("Preencha todos os campos");
      return;
    }
    
    // Verificar se o horário não está bloqueado
    const blocked = await blockedPeriodsAdapter.listOverlaps(professionalId, date);
    const apptDateTime = new Date(`${date}T${time}:00`).toISOString();
    const isSlotBlocked = blocked.some(b => apptDateTime >= b.start && apptDateTime <= b.end);
    
    if (isSlotBlocked) {
      toast.error("Não é possível agendar neste horário pois está bloqueado");
      return;
    }
    
    // Validar se o horário está disponível baseado no horário de funcionamento
    const availability = await isTimeSlotAvailable(professionalId, date, time);
    if (!availability.available) {
      toast.error(availability.reason || "Horário não disponível");
      return;
    }
    
    try {
      const svc = services.find(s => s.id === serviceId)!;
      const dateStr = form.date;              // "YYYY-MM-DD"
      const timeStr = form.time;              // "HH:mm"
      const pro = await professionalsAdapter.getById(professionalId);
      
      await createAppointment({
        establishmentId: pro!.establishmentId,
        professionalId: professionalId,
        professionalName: user.email || "Profissional",
        clientId: normalizePhone(clientPhone),// se já usa esse helper na Vitrine
        clientName,
        serviceId,
        serviceName: svc.name,
        date: dateStr,
        time: timeStr,
        status: "confirmado",
      });
      
      toast.success("Agendamento criado com sucesso");
      setOpen(false);
      setForm({ clientName: "", clientPhone: "", serviceId: "", date, time: "" });
      setRefresh((x) => x + 1);
      refreshSchedule(); // Refresh the schedule hook as well
    } catch (e: any) {
      console.error('Error creating appointment:', e);
      toast.error(e.message ?? "Erro ao criar agendamento");
    }
  };

  return (
    <div className="max-w-full overflow-x-visible overflow-y-visible space-y-4">
        <Seo title="LookPro — Minha Agenda" description="Agenda do profissional: visualize e atualize seus atendimentos." canonicalPath="/dashboard/pro/agenda" />
        <h1 className="text-2xl font-extrabold mb-4">Minha Agenda</h1>

        <div className="flex items-center justify-between mb-4 gap-3 flex-wrap">
          <p className="text-muted-foreground">Horários do {range === "day" ? "dia" : range === "week" ? "período semanal" : "mês"}.</p>
          <div className="flex items-center gap-2">
            <Select value={range} onValueChange={(v) => setRange(v as any)}>
              <SelectTrigger className="w-40"><SelectValue placeholder="Período" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="day">Dia</SelectItem>
                <SelectItem value="week">Semana</SelectItem>
                <SelectItem value="month">Mês</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Resumo do período */}
          <Card>
            <CardHeader><CardTitle>Resumo do período</CardTitle></CardHeader>
            <CardContent className="grid grid-cols-1 gap-4">
              <div>
                <div className="text-xs text-muted-foreground">Concluídos</div>
                <div className="text-2xl font-extrabold">{summary.completed}</div>
              </div>
              <div>
                <div className="text-xs text-muted-foreground">Faturamento</div>
                <div className="text-2xl font-extrabold">{formatBRL(summary.revenueCents)}</div>
              </div>
            </CardContent>
          </Card>

          {/* Controle de data */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Calendar className="h-5 w-5" />
                Agenda Individual
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <Input 
                  type="date" 
                  value={selectedDateObj.toISOString().split('T')[0]}
                  onChange={(e) => setSelectedDateObj(new Date(e.target.value + 'T00:00:00'))}
                />
                <div className="text-sm text-muted-foreground">
                  {selectedDateObj.toLocaleDateString('pt-BR', { 
                    weekday: 'long', 
                    year: 'numeric', 
                    month: 'long', 
                    day: 'numeric' 
                  })}
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Agenda visual do dia */}
          <Card>
            <CardHeader>
              <CardTitle>Horários do Dia</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2 max-h-96 overflow-y-auto">
                {scheduleLoading ? (
                  <div className="text-center py-4 text-muted-foreground">Carregando...</div>
                ) : daySchedule.slots.length === 0 ? (
                  <div className="text-center py-4 text-muted-foreground">
                    Estabelecimento fechado
                  </div>
                ) : (
                  daySchedule.slots.map((slot) => (
                    <div 
                      key={slot.time} 
                      className={`flex items-center justify-between p-3 rounded-lg border text-sm ${
                        slot.appointment 
                          ? 'bg-primary/10 border-primary/30' 
                          : slot.blocked 
                            ? 'bg-destructive/10 border-destructive/30'
                            : 'bg-muted/50 border-border'
                      }`}
                    >
                      <div className="flex items-center gap-2">
                        <Clock className="h-4 w-4 text-muted-foreground" />
                        <span className="font-medium">{slot.time}</span>
                      </div>
                      
                      {slot.appointment ? (
                        <div className="flex items-center gap-2 text-xs">
                          <User className="h-3 w-3" />
                          <span className="truncate max-w-20">{slot.appointment.clientName}</span>
                          {statusBadge(slot.appointment.status)}
                        </div>
                      ) : slot.blocked ? (
                        <span className="text-xs text-destructive">Bloqueado</span>
                      ) : (
                        <span className="text-xs text-muted-foreground">Livre</span>
                      )}
                    </div>
                  ))
                )}
              </div>
            </CardContent>
          </Card>
        </div>
        <div className="grid grid-cols-1 gap-4 max-w-full">
          {data.length === 0 && (
            <Card>
              <CardHeader><CardTitle>Nenhum agendamento</CardTitle></CardHeader>
              <CardContent className="text-muted-foreground">Sem horários para o período selecionado.</CardContent>
            </Card>
          )}
          {data.map((a) => (
            <Card key={a.id}>
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle className="text-base">{a.serviceName} • {formatDateTime(a.date, a.time)}</CardTitle>
                {statusBadge(a.status)}
              </CardHeader>
              <CardContent>
                <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-3 min-w-0">
                  <div className="min-w-0 break-words">
                    <p><strong>Cliente:</strong> {a.clientName}</p>
                    <p className="text-muted-foreground text-sm">Cliente • Duração: 60 min</p>
                  </div>
                  <div className="flex gap-2 justify-end">
                    <Button variant="secondary" onClick={() => onUpdate(a.id, "concluído")} disabled={a.status !== "confirmado" && a.status !== "pendente"}>Concluir</Button>
                    <Button variant="destructive" onClick={() => onUpdate(a.id, "cancelado")} disabled={a.status !== "confirmado" && a.status !== "pendente"}>Não compareceu</Button>
                    <Button variant="outline" onClick={() => onDelete(a.id)} className="text-destructive hover:text-destructive">Excluir</Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
  );
};

export default AgendaPage;
