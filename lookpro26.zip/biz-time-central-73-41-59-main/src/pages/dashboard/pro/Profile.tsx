import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useForm } from "react-hook-form";
import Seo from "@/components/Seo";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Camera, MapPin, Star, ArrowLeft, Plus, X, Upload, Eye, EyeOff, ExternalLink } from "lucide-react";
import { useAuth } from "@/context/AuthContext";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { triggerProfessionalProfileUpdate } from "@/utils/professionalSync";
import { uploadProfessionalAvatar } from "@/services/imageUpload";

interface ProfessionalProfile {
  id: string;
  name: string;
  email: string;
  phone: string;
  whatsapp: string;
  bio: string;
  specialties: string[];
  experienceYears: number;
  avatarUrl: string;
  establishmentName: string;
  rating: number;
  slug: string;
  isPublic: boolean;
}

function Profile() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [profile, setProfile] = useState<ProfessionalProfile | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [newSpecialty, setNewSpecialty] = useState("");

  // Função para gerar slug automaticamente a partir do nome
  const generateSlug = (name: string) => {
    return name
      .toLowerCase()
      .normalize('NFD') // Remove acentos
      .replace(/[\u0300-\u036f]/g, '')
      .replace(/[^a-z0-9\s-]/g, '') // Remove caracteres especiais
      .replace(/\s+/g, '-') // Substitui espaços por hífens
      .replace(/-+/g, '-') // Remove hífens duplicados
      .replace(/^-|-$/g, ''); // Remove hífens do início/fim
  };

  useEffect(() => {
    loadProfile();
  }, [user]);

  const loadProfile = async () => {
    if (!user) return;
    
    try {
      setLoading(true);
      console.log('Loading profile for user:', user.id);
      
      // Implementação conforme especificação
      const { data: { user: authUser } } = await supabase.auth.getUser();
      if (!authUser) {
        toast.error("Usuário não autenticado");
        return;
      }

      // Buscar dados do profissional primeiro
      const { data: professionalData, error: profError } = await supabase
        .from('professionals')
        .select('id, user_id, bio, avatar_url, specialties, slug, is_public, establishment_id')
        .eq('user_id', authUser.id)
        .maybeSingle();

      console.log('Professional data:', professionalData, 'error:', profError);

      if (profError) {
        console.error('Error loading professional:', profError);
        toast.error("Erro ao carregar dados do profissional");
        return;
      }

      if (!professionalData) {
        console.log("Nenhum profissional encontrado para user_id:", user.id);
        return;
      }

      // Buscar dados do perfil do usuário
      const { data: profileData, error: profileError } = await supabase
        .from('profiles')
        .select('full_name, email, phone')
        .eq('user_id', user.id)
        .maybeSingle();

      console.log('Profile data:', profileData, 'error:', profileError);

      if (profileError) {
        console.error('Error loading profile:', profileError);
      }

      // Buscar dados do estabelecimento
      const { data: establishmentData, error: estError } = await supabase
        .from('establishments')
        .select('name')
        .eq('id', professionalData.establishment_id)
        .maybeSingle();

      if (estError) {
        console.error('Error loading establishment:', estError);
      }

      // Calcular avaliação média
      const { data: reviews } = await supabase
        .from('reviews')
        .select('professional_rating')
        .eq('professional_id', professionalData.id);

      let rating = 0;
      if (reviews?.length) {
        rating = reviews.reduce((sum, r) => sum + (r.professional_rating || 0), 0) / reviews.length;
        rating = Math.round(rating * 10) / 10;
      }

      // Extrair bio conforme especificação: se bio vier JSON, extrair description
      let bioText = "";
      let whatsapp = "";
      let experienceYears = 1;
      
      try { 
        bioText = professionalData?.bio ? (JSON.parse(professionalData.bio).description ?? professionalData.bio) : ""; 
        if (professionalData?.bio) {
          const bioData = JSON.parse(professionalData.bio);
          whatsapp = bioData.whatsapp || "";
          experienceYears = bioData.experienceYears || 1;
        }
      } catch { 
        bioText = professionalData?.bio ?? ""; 
      }

      const newProfile: ProfessionalProfile = {
        id: professionalData.id,
        name: profileData?.full_name || user.full_name || "",
        email: profileData?.email || user.email || "",
        phone: profileData?.phone || "",
        whatsapp: whatsapp,
        bio: bioText,
        specialties: professionalData.specialties || [],
        experienceYears: experienceYears,
        avatarUrl: professionalData.avatar_url || "",
        establishmentName: establishmentData?.name || "",
        rating: rating,
        slug: professionalData.slug || "",
        isPublic: professionalData.is_public ?? true
      };

      console.log('New profile state:', newProfile);
      setProfile(newProfile);
    } catch (error) {
      console.error("Erro ao carregar perfil:", error);
      toast.error("Erro ao carregar perfil");
    } finally {
      setLoading(false);
    }
  };

  const handleSave = async () => {
    if (!profile || !user) return;

    try {
      setSaving(true);
      toast.loading("Salvando perfil...", { id: "save-profile" });
      
      console.log('Saving profile:', profile);

      // Gerar slug automático se não foi fornecido
      let finalSlug = profile.slug;
      if (!finalSlug && profile.name) {
        finalSlug = generateSlug(profile.name);
        
        // Verificar se o slug gerado já existe
        let slugAttempt = finalSlug;
        let counter = 1;
        
        while (true) {
          const { data: existingPro, error: slugError } = await supabase
            .from('professionals')
            .select('id')
            .eq('slug', slugAttempt)
            .neq('id', profile.id)
            .maybeSingle();

          if (slugError) throw slugError;
          
          if (!existingPro) {
            finalSlug = slugAttempt;
            break;
          }
          
          counter++;
          slugAttempt = `${finalSlug}-${counter}`;
        }
      } else if (finalSlug) {
        // Validar slug personalizado se foi preenchido
        const { data: existingPro, error: slugError } = await supabase
          .from('professionals')
          .select('id')
          .eq('slug', finalSlug)
          .neq('id', profile.id)
          .maybeSingle();

        if (slugError) throw slugError;
        
        if (existingPro) {
          toast.error("Este URL já está sendo usado por outro profissional. Escolha um diferente.", { id: "save-profile" });
          return;
        }
      }

      // Atualizar dados do perfil
      const { error: profileError } = await supabase
        .from('profiles')
        .update({
          full_name: profile.name,
          phone: profile.phone
        })
        .eq('user_id', user.id);

      if (profileError) {
        console.error('Profile update error:', profileError);
        throw profileError;
      }

      // Implementação conforme especificação
      const payload = {
        avatar_url: profile.avatarUrl || null,
        bio: JSON.stringify({
          description: profile.bio || "",
          whatsapp: profile.whatsapp || "",
          experienceYears: Number(profile.experienceYears) || 0,
        }),
        specialties: profile.specialties,
        slug: finalSlug || null,
        is_public: profile.isPublic,
        updated_at: new Date().toISOString(),
      };

      console.log('Saving payload:', payload);

      // Update ou upsert conforme especificação
      const professionalExists = await supabase
        .from('professionals')
        .select('id, establishment_id')
        .eq('user_id', user.id)
        .maybeSingle();

      if (professionalExists.data?.id) {
        const { error: updateError } = await supabase
          .from('professionals')
          .update(payload)
          .eq('id', professionalExists.data.id);
        
        if (updateError) throw updateError;
      } else {
        // Para insert, precisamos do establishment_id - buscar do perfil do usuário
        const { data: userProfile } = await supabase
          .from('profiles')
          .select('establishment_id')
          .eq('user_id', user.id)
          .single();
          
        if (!userProfile?.establishment_id) {
          throw new Error('Estabelecimento não encontrado para o usuário');
        }
        
        const { error: insertError } = await supabase
          .from('professionals')
          .insert({ 
            user_id: user.id, 
            establishment_id: userProfile.establishment_id,
            ...payload 
          });
        
        if (insertError) throw insertError;
      }

      console.log('Profile saved successfully');

      // Disparar evento de sincronização usando utility
      triggerProfessionalProfileUpdate(profile.id, finalSlug);

      // Atualizar o slug no estado local se foi gerado automaticamente
      if (finalSlug && finalSlug !== profile.slug) {
        setProfile(prev => prev ? { ...prev, slug: finalSlug } : null);
      }

      toast.success("Perfil atualizado com sucesso! Sua página pública foi atualizada automaticamente.", { id: "save-profile" });
    } catch (error) {
      console.error("Erro ao salvar perfil:", error);
      toast.error("Erro ao salvar perfil. Tente novamente.", { id: "save-profile" });
    } finally {
      setSaving(false);
    }
  };

  const handlePhotoUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    
    if (!file || !profile || !user) {
      return;
    }

    if (!file.type.startsWith('image/')) {
      toast.error("Por favor, selecione apenas arquivos de imagem");
      return;
    }

    // Verificar tamanho do arquivo (máximo 5MB)
    if (file.size > 5 * 1024 * 1024) {
      toast.error("A imagem deve ter no máximo 5MB");
      return;
    }

    try {
      setUploading(true);
      toast.loading("Fazendo upload da foto...", { id: "photo-upload" });
      
      // Usar o helper do uploadProfessionalAvatar que já está importado
      const publicUrl = await uploadProfessionalAvatar(profile.id, file);
      
      // Atualizar no estado local
      setProfile(prev => prev ? { ...prev, avatarUrl: publicUrl } : null);
      
      // Salvar no banco de dados (atualizar ambos avatar_url e avatar_path)
      const { error } = await supabase
        .from('professionals')
        .update({ 
          avatar_url: publicUrl,
          avatar_path: publicUrl 
        })
        .eq('user_id', user.id);

      if (error) {
        throw error;
      }

      toast.success("Foto atualizada com sucesso!", { id: "photo-upload" });
    } catch (error) {
      console.error("Erro no upload:", error);
      toast.error("Erro ao fazer upload da foto", { id: "photo-upload" });
    } finally {
      setUploading(false);
      // Limpar o input para permitir selecionar o mesmo arquivo novamente
      event.target.value = '';
    }
  };

  const addSpecialty = () => {
    if (!newSpecialty.trim() || !profile) return;
    
    setProfile(prev => prev ? {
      ...prev,
      specialties: [...prev.specialties, newSpecialty.trim()]
    } : null);
    setNewSpecialty("");
  };

  const removeSpecialty = (index: number) => {
    setProfile(prev => prev ? {
      ...prev,
      specialties: prev.specialties.filter((_, i) => i !== index)
    } : null);
  };

  if (loading) {
    return (
      <div className="text-center py-8">
        <p className="text-muted-foreground">Carregando perfil...</p>
      </div>
    );
  }

  if (!profile) {
    return (
      <div className="text-center py-8">
        <p className="text-muted-foreground">Perfil não encontrado</p>
        <Button 
          variant="outline" 
          onClick={() => navigate(-1)}
          className="mt-4"
        >
          <ArrowLeft className="h-4 w-4 mr-2" />
          Voltar
        </Button>
      </div>
    );
  }

  return (
    <>
      <Seo title="LookPro — Meu Perfil" description="Gerencie suas informações profissionais" canonicalPath="/dashboard/pro/perfil" />
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Meu Perfil</h1>
            <p className="text-muted-foreground">
              Gerencie suas informações profissionais
            </p>
          </div>
          <Button 
            variant="outline" 
            onClick={() => navigate(-1)}
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Voltar
          </Button>
        </div>

        <div className="grid gap-6 lg:grid-cols-2 overflow-x-hidden">
          <Card>
            <CardHeader>
              <CardTitle>Informações Pessoais</CardTitle>
              <CardDescription>
                Suas informações básicas e de contato
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center space-x-4">
                <Avatar className="h-20 w-20">
                  <AvatarImage 
                    src={profile.avatarUrl} 
                    alt={`Foto de ${profile.name}`}
                    className="object-cover"
                  />
                  <AvatarFallback className="text-lg font-medium bg-primary/10 text-primary">
                    {profile.name.charAt(0).toUpperCase()}
                  </AvatarFallback>
                </Avatar>
                <div className="space-y-2">
                  <Button 
                    variant="outline" 
                    size="sm" 
                    disabled={uploading}
                    onClick={() => document.getElementById('photo-input')?.click()}
                  >
                    <Upload className="h-4 w-4 mr-2" />
                    {uploading ? "Enviando..." : "Alterar Foto"}
                  </Button>
                  <input
                    id="photo-input"
                    type="file"
                    accept="image/*"
                    onChange={handlePhotoUpload}
                    style={{ display: 'none' }}
                  />
                  {profile.avatarUrl && (
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      onClick={() => setProfile(prev => prev ? { ...prev, avatarUrl: "" } : null)}
                      className="text-destructive hover:text-destructive"
                    >
                      <X className="h-4 w-4 mr-2" />
                      Remover Foto
                    </Button>
                  )}
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="name">Nome</Label>
                <Input
                  id="name"
                  value={profile.name || ""}
                  onChange={(e) => setProfile(prev => prev ? { ...prev, name: e.target.value } : null)}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="email">E-mail</Label>
                <Input
                  id="email"
                  type="email"
                  value={profile.email || ""}
                  disabled
                  className="bg-muted"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="phone">Telefone</Label>
                <Input
                  id="phone"
                  value={profile.phone || ""}
                  onChange={(e) => setProfile(prev => prev ? { ...prev, phone: e.target.value } : null)}
                  placeholder="(11) 99999-9999"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="whatsapp">WhatsApp</Label>
                <Input
                  id="whatsapp"
                  value={profile.whatsapp || ""}
                  onChange={(e) => setProfile(prev => prev ? { ...prev, whatsapp: e.target.value } : null)}
                  placeholder="(11) 99999-9999"
                />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Perfil Público</CardTitle>
              <CardDescription>
                Configure a visibilidade e URL do seu perfil público
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="isPublic" className="text-base">
                    Perfil público
                  </Label>
                  <div className="text-sm text-muted-foreground">
                    Permitir que clientes vejam seu perfil público
                  </div>
                </div>
                <Switch
                  id="isPublic"
                  checked={profile.isPublic}
                  onCheckedChange={(checked) => setProfile(prev => prev ? { ...prev, isPublic: checked } : null)}
                />
              </div>

              {profile.isPublic && (
                <>
                  <div className="space-y-2">
                    <Label htmlFor="slug">URL personalizada (opcional)</Label>
                    <div className="flex items-center space-x-2">
                      <span className="text-sm text-muted-foreground">lookpro.com/profissional/</span>
                      <Input
                        id="slug"
                        value={profile.slug || ""}
                        onChange={(e) => {
                          // Apenas letras, números e hífens, em minúsculas
                          const value = e.target.value.toLowerCase().replace(/[^a-z0-9-]/g, '');
                          setProfile(prev => prev ? { ...prev, slug: value } : null);
                        }}
                        placeholder="seu-nome"
                        className="flex-1"
                      />
                    </div>
                    <p className="text-xs text-muted-foreground">
                      Deixe em branco para usar URL automática. Use apenas letras, números e hífens.
                    </p>
                  </div>

                  {profile.slug && (
                    <div className="p-3 bg-muted rounded-lg">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="text-sm font-medium">Seu perfil público estará em:</p>
                          <p className="text-sm text-primary">
                            lookpro.com/profissional/{profile.slug}
                          </p>
                        </div>
                        <Button
                          variant="outline"
                          size="sm"
                          asChild
                          className="ml-2"
                        >
                          <a 
                            href={`/profissional/${profile.slug}`} 
                            target="_blank" 
                            rel="noopener noreferrer"
                          >
                            <ExternalLink className="h-4 w-4" />
                          </a>
                        </Button>
                      </div>
                    </div>
                  )}
                </>
              )}

              <div className="flex items-center space-x-2">
                <MapPin className="h-4 w-4 text-muted-foreground" />
                <span className="text-sm">{profile.establishmentName}</span>
              </div>

              <div className="flex items-center space-x-2">
                <Star className="h-4 w-4 text-yellow-400 fill-current" />
                <span className="text-sm font-medium">{profile.rating}</span>
                <span className="text-sm text-muted-foreground">avaliação média</span>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Informações Profissionais</CardTitle>
              <CardDescription>
                Dados sobre sua atuação profissional
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="experienceYears">Anos de Experiência</Label>
                <Input
                  id="experienceYears"
                  type="number"
                  min="0"
                  max="50"
                  value={profile.experienceYears || 0}
                  onChange={(e) => setProfile(prev => prev ? { ...prev, experienceYears: parseInt(e.target.value) || 0 } : null)}
                />
              </div>

              <div className="space-y-2">
                <Label>Especialidades</Label>
                <div className="flex gap-2">
                  <Input
                    value={newSpecialty || ""}
                    onChange={(e) => setNewSpecialty(e.target.value)}
                    placeholder="Adicionar especialidade"
                    onKeyPress={(e) => e.key === 'Enter' && addSpecialty()}
                  />
                  <Button onClick={addSpecialty} size="sm">
                    <Plus className="h-4 w-4" />
                  </Button>
                </div>
                <div className="flex flex-wrap gap-2 mt-2">
                  {(profile.specialties || []).map((specialty, index) => (
                    <Badge key={index} variant="secondary" className="flex items-center gap-1">
                      {specialty}
                      <button
                        onClick={() => removeSpecialty(index)}
                        className="ml-1 hover:text-destructive"
                      >
                        <X className="h-3 w-3" />
                      </button>
                    </Badge>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Sobre Mim</CardTitle>
            <CardDescription>
              Descreva sua experiência e abordagem profissional
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Textarea
              rows={4}
              value={profile.bio || ""}
              onChange={(e) => setProfile(prev => prev ? { ...prev, bio: e.target.value } : null)}
              placeholder="Conte um pouco sobre sua experiência, especialidades e abordagem profissional..."
            />
          </CardContent>
        </Card>

        <div className="flex justify-end">
          <Button onClick={handleSave} disabled={saving}>
            {saving ? "Salvando..." : "Salvar Alterações"}
          </Button>
        </div>
      </div>
    </>
  );
}

export default Profile;