import { useState, useEffect, useCallback } from "react";
import Seo from "@/components/Seo";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { useAuth } from "@/context/AuthContext";
import { professionalsAdapter } from "@/services/adapters";
import { professionalServicesAdapter, type ProfessionalService, type AvailableService } from "@/services/professionalServicesAdapter";
import ServiceForm, { type ServiceFormData } from "@/components/pro/ServiceForm";
import { toast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { Plus, MoreHorizontal, Edit, Power, PowerOff, Link } from "lucide-react";

const formatPrice = (price?: number) => (price !== undefined ? price.toLocaleString("pt-BR", { style: "currency", currency: "BRL" }) : "—");

const ServicesPage = () => {
  const { user } = useAuth();
  const [services, setServices] = useState<ProfessionalService[]>([]);
  const [availableServices, setAvailableServices] = useState<AvailableService[]>([]);
  const [loading, setLoading] = useState(true);
  const [formLoading, setFormLoading] = useState(false);
  const [showForm, setShowForm] = useState(false);
  const [formMode, setFormMode] = useState<'create' | 'edit' | 'link'>('link');
  const [selectedService, setSelectedService] = useState<ProfessionalService | null>(null);
  const [professionalId, setProfessionalId] = useState<string>('');
  const [establishmentId, setEstablishmentId] = useState<string>('');

  // Carrega dados do profissional e serviços
  const loadData = useCallback(async () => {
    if (!user) return;
    
    try {
      setLoading(true);
      const pro = await professionalsAdapter.getByUserId(user.uid);
      
      if (!pro) {
        console.error('Professional not found for user:', user.uid);
        return;
      }

      setProfessionalId(pro.id);
      setEstablishmentId(pro.establishmentId);

      // Carrega serviços do profissional e disponíveis para vínculo
      const [professionalServices, availableForLink] = await Promise.all([
        professionalServicesAdapter.listByProfessional(pro.id),
        professionalServicesAdapter.listAvailableServices(pro.id, pro.establishmentId)
      ]);

      setServices(professionalServices);
      setAvailableServices(availableForLink);
    } catch (error) {
      console.error('Error loading services:', error);
      toast({
        title: "Erro",
        description: "Erro ao carregar serviços. Tente novamente.",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  }, [user]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  // Real-time updates
  useEffect(() => {
    if (!professionalId || !establishmentId) return;

    console.log('Setting up realtime listeners for professional services');

    const servicesChannel = supabase
      .channel('services-changes')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'services',
          filter: `establishment_id=eq.${establishmentId}`
        },
        () => {
          console.log('Services table changed, reloading data');
          loadData();
        }
      )
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'professional_services',
          filter: `professional_id=eq.${professionalId}`
        },
        () => {
          console.log('Professional services table changed, reloading data');
          loadData();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(servicesChannel);
    };
  }, [professionalId, establishmentId, loadData]);

  const handleLinkService = () => {
    setFormMode('link');
    setSelectedService(null);
    setShowForm(true);
  };

  const handleEditService = (service: ProfessionalService) => {
    setFormMode('edit');
    setSelectedService(service);
    setShowForm(true);
  };

  const handleToggleStatus = async (service: ProfessionalService) => {
    try {
      if (service.isActive) {
        await professionalServicesAdapter.unlinkService(service.id);
        toast({
          title: "Serviço desativado",
          description: `${service.name} foi desativado com sucesso.`
        });
      } else {
        await professionalServicesAdapter.reactivateService(service.id);
        toast({
          title: "Serviço reativado", 
          description: `${service.name} foi reativado com sucesso.`
        });
      }
      loadData();
    } catch (error) {
      console.error('Error toggling service status:', error);
      toast({
        title: "Erro",
        description: "Erro ao alterar status do serviço.",
        variant: "destructive"
      });
    }
  };

  const handleFormSubmit = async (formData: ServiceFormData) => {
    setFormLoading(true);
    try {
      if (formMode === 'link' && formData.serviceId) {
        await professionalServicesAdapter.linkService(
          professionalId,
          establishmentId,
          formData.serviceId,
          {
            customDurationMinutes: formData.customDurationMinutes,
            customPrice: formData.customPrice
          }
        );
      } else if (formMode === 'edit' && selectedService) {
        await professionalServicesAdapter.updateCustomizations(selectedService.id, {
          customDurationMinutes: formData.customDurationMinutes,
          customPrice: formData.customPrice,
          isActive: formData.isActive
        });
      }
      
      loadData();
      
      // Trigger custom events for other components
      window.dispatchEvent(new CustomEvent('professionalServicesUpdated', { 
        detail: { professionalId } 
      }));
      window.dispatchEvent(new CustomEvent('servicesUpdated', { 
        detail: { establishmentId } 
      }));
    } finally {
      setFormLoading(false);
    }
  };

  if (loading) {
    return (
      <>
        <Seo title="LookPro — Meus Serviços" description="Gerencie seus serviços e personalizações." canonicalPath="/dashboard/pro/servicos" />
        <div className="flex items-center justify-center h-64">
          <div className="text-center">
            <div className="animate-spin h-8 w-8 border-b-2 border-primary mx-auto mb-4"></div>
            <p>Carregando serviços...</p>
          </div>
        </div>
      </>
    );
  }

  return (
    <>
      <Seo title="LookPro — Meus Serviços" description="Gerencie seus serviços e personalizações." canonicalPath="/dashboard/pro/servicos" />
      
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-extrabold">Meus Serviços</h1>
        <Button onClick={handleLinkService} className="gap-2">
          <Link className="h-4 w-4" />
          Vincular Serviço
        </Button>
      </div>

      {services.length === 0 ? (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-12">
            <div className="text-center">
              <h3 className="text-lg font-medium mb-2">Nenhum serviço vinculado</h3>
              <p className="text-muted-foreground mb-4">
                Vincule serviços do seu estabelecimento para personalizar preços e durações.
              </p>
              <Button onClick={handleLinkService} className="gap-2">
                <Link className="h-4 w-4" />
                Vincular Primeiro Serviço
              </Button>
            </div>
          </CardContent>
        </Card>
      ) : (
        <Card>
          <CardHeader>
            <CardTitle>Serviços Ativos ({services.filter(s => s.isActive).length})</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Serviço</TableHead>
                    <TableHead>Duração</TableHead>
                    <TableHead>Preço</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Personalizado</TableHead>
                    <TableHead className="text-right">Ações</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {services.map((service) => (
                    <TableRow key={service.id}>
                      <TableCell>
                        <div>
                          <div className="font-medium">{service.name}</div>
                          {service.description && (
                            <div className="text-sm text-muted-foreground line-clamp-1">
                              {service.description}
                            </div>
                          )}
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex flex-col">
                          <span>{service.durationMinutes} min</span>
                          {service.customDurationMinutes && (
                            <span className="text-xs text-muted-foreground">
                              (base: {service.durationMinutes - (service.customDurationMinutes - service.durationMinutes)} min)
                            </span>
                          )}
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex flex-col">
                          <span>{formatPrice(service.price)}</span>
                          {service.customPrice && (
                            <span className="text-xs text-muted-foreground">
                              personalizado
                            </span>
                          )}
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge variant={service.isActive ? "default" : "secondary"}>
                          {service.isActive ? "Ativo" : "Inativo"}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        {(service.customPrice || service.customDurationMinutes) ? (
                          <Badge variant="outline">Sim</Badge>
                        ) : (
                          <span className="text-muted-foreground">Não</span>
                        )}
                      </TableCell>
                      <TableCell className="text-right">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="sm">
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem onClick={() => handleEditService(service)}>
                              <Edit className="h-4 w-4 mr-2" />
                              Editar
                            </DropdownMenuItem>
                            <DropdownMenuItem 
                              onClick={() => handleToggleStatus(service)}
                              className={service.isActive ? "text-destructive" : "text-green-600"}
                            >
                              {service.isActive ? (
                                <>
                                  <PowerOff className="h-4 w-4 mr-2" />
                                  Desativar
                                </>
                              ) : (
                                <>
                                  <Power className="h-4 w-4 mr-2" />
                                  Reativar
                                </>
                              )}
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      )}

      {availableServices.length > 0 && (
        <Card className="mt-6">
          <CardHeader>
            <CardTitle>Serviços Disponíveis para Vínculo ({availableServices.length})</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {availableServices.map((service) => (
                <div key={service.serviceId} className="border rounded-lg p-4">
                  <h4 className="font-medium mb-2">{service.name}</h4>
                  {service.description && (
                    <p className="text-sm text-muted-foreground mb-3 line-clamp-2">
                      {service.description}
                    </p>
                  )}
                  <div className="flex justify-between items-center text-sm mb-3">
                    <span>{service.durationMinutes} min</span>
                    <span className="font-medium">{formatPrice(service.price)}</span>
                  </div>
                  <Button 
                    size="sm" 
                    variant="outline" 
                    onClick={() => {
                      setFormMode('link');
                      setSelectedService(null);
                      setShowForm(true);
                    }} 
                    className="w-full"
                  >
                    <Link className="h-4 w-4 mr-2" />
                    Vincular
                  </Button>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      <ServiceForm
        isOpen={showForm}
        onClose={() => setShowForm(false)}
        onSubmit={handleFormSubmit}
        initialData={selectedService || undefined}
        availableServices={availableServices}
        mode={formMode}
        loading={formLoading}
      />
    </>
  );
};

export default ServicesPage;
