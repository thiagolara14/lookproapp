import { useEffect, useState, useCallback } from "react";
import Seo from "@/components/Seo";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Calendar } from "lucide-react";
import { toast } from "@/hooks/use-toast";
import { useAuth } from "@/context/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { professionalsAdapter, servicesAdapter, establishmentsAdapter } from "@/services/adapters";
import { ymdLocal, isoForLocal, computeAvailableStarts, generateTimeSlots } from "@/utils/scheduleUtils";
import type { Service, Professional, BlockedPeriod } from "@/services/adapters";
import type { Appointment } from "@/types/appointments";

interface AppointmentForm {
  serviceId: string;
  date: string;
  time: string;
  clientName: string;
  clientPhone: string;
  notes: string;
}

const NovoAgendamento = () => {
  const { user } = useAuth();
  
  // Core state
  const [professionalId, setProfessionalId] = useState<string>('');
  const [establishmentId, setEstablishmentId] = useState<string>('');
  const [services, setServices] = useState<Service[]>([]);
  const [workingHours, setWorkingHours] = useState<any>(null);
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [blockedPeriods, setBlockedPeriods] = useState<BlockedPeriod[]>([]);
  const [availableSlots, setAvailableSlots] = useState<string[]>([]);
  const [loading, setLoading] = useState(true);
  const [version, setVersion] = useState(0); // For triggering re-calculations
  
  // Form state
  const [form, setForm] = useState<AppointmentForm>({
    serviceId: '',
    date: new Date().toISOString().split('T')[0],
    time: '',
    clientName: '',
    clientPhone: '',
    notes: ''
  });

  // 1. Load professional from logged user
  useEffect(() => {
    if (!user?.uid) return;
    
    const loadProfessional = async () => {
      try {
        const professional = await professionalsAdapter.getByUserId(user.uid);
        if (professional) {
          setProfessionalId(professional.id);
          setEstablishmentId(professional.establishmentId);
        }
      } catch (error) {
        console.error('Error loading professional:', error);
        toast({ variant: "destructive", title: "Erro", description: "Erro ao carregar dados do profissional" });
      }
    };
    
    loadProfessional();
  }, [user]);

  // 2. Load services for establishment
  useEffect(() => {
    if (!establishmentId) return;
    
    const loadServices = async () => {
      try {
        const servicesList = await servicesAdapter.listByEstablishment(establishmentId, { active: true });
        setServices(servicesList);
      } catch (error) {
        console.error('Error loading services:', error);
        toast({ variant: "destructive", title: "Erro", description: "Erro ao carregar serviços" });
      }
    };
    
    loadServices();
  }, [establishmentId]);

  // 3. Load working hours for establishment
  useEffect(() => {
    if (!establishmentId) return;
    
    const loadWorkingHours = async () => {
      try {
        const hours = await establishmentsAdapter.getWorkingHours(establishmentId);
        setWorkingHours(hours);
      } catch (error) {
        console.error('Error loading working hours:', error);
        toast({ variant: "destructive", title: "Erro", description: "Erro ao carregar horários" });
      }
    };
    
    loadWorkingHours();
  }, [establishmentId]);

  // 4. Load appointments and blocks when date/professional changes
  const loadScheduleData = useCallback(async () => {
    if (!professionalId || !form.date) return;
    
    try {
      const dateStr = form.date;
      
      // Load appointments for the day
      const { data: appointmentsData, error: apptError } = await supabase
        .from('appointments')
        .select('*')
        .eq('professional_id', professionalId)
        .eq('appointment_date', dateStr)
        .neq('status', 'cancelled');
      
      if (apptError) throw apptError;
      
      // Map to our format and filter cancelled ones
      const mappedAppointments = (appointmentsData || [])
        .filter(a => a.status !== 'cancelled')
        .map(a => ({
          id: a.id,
          establishmentId: a.establishment_id,
          professionalId: a.professional_id,
          professionalName: '',
          clientId: a.client_id || a.client_phone || '',
          clientName: a.client_name || '',
          serviceId: a.service_id,
          serviceName: '',
          date: a.appointment_date,
          time: a.start_time,
          duration: 60, // Will be updated from service data
          status: 'pendente' as const,
          notes: a.notes,
          createdAt: a.created_at,
          updatedAt: a.updated_at,
        }));
      
      setAppointments(mappedAppointments);
      
      // Load blocked periods
      const { data: blocksData, error: blockError } = await supabase
        .from('blocked_periods')
        .select('*')
        .eq('professional_id', professionalId)
        .lte('start_date', dateStr)
        .gte('end_date', dateStr);
      
      if (blockError) throw blockError;
      
      // Map blocked periods to our format
      const mappedBlocks = (blocksData || []).map(b => ({
        id: b.id,
        professionalId: b.professional_id,
        start: b.start_at || `${b.start_date}T${b.start_time || '00:00'}:00.000Z`,
        end: b.end_at || `${b.end_date}T${b.end_time || '23:59'}:59.000Z`,
        reason: b.reason
      }));
      
      setBlockedPeriods(mappedBlocks);
      
    } catch (error) {
      console.error('Error loading schedule data:', error);
      toast({ variant: "destructive", title: "Erro", description: "Erro ao carregar agenda" });
    }
  }, [professionalId, form.date]);

  useEffect(() => {
    loadScheduleData();
  }, [loadScheduleData, version]);

  // 5. Calculate available slots when service, date, or schedule data changes
  useEffect(() => {
    if (!workingHours || !form.date || !form.serviceId) {
      setAvailableSlots([]);
      return;
    }
    
    try {
      const date = new Date(form.date + 'T12:00:00'); // Ensure valid date
      const dayOfWeek = date.getDay();
      const dayHours = workingHours[dayOfWeek.toString()];
      
      if (!dayHours || dayHours.closed) {
        setAvailableSlots([]);
        return;
      }
      
      // Generate base time slots (30min intervals)
      const slots = generateTimeSlots(dayHours, 30);
      
      // Get selected service duration
      const selectedService = services.find(s => s.id === form.serviceId);
      if (!selectedService) {
        setAvailableSlots([]);
        return;
      }
      
      // Calculate available start times considering service duration
      const available = computeAvailableStarts({
        date,
        slots,
        appointments: appointments.map(a => ({ 
          time: a.time, 
          duration: a.duration || 60,
          status: a.status 
        })),
        blocks: blockedPeriods,
        serviceMinutes: selectedService.duration
      });
      
      setAvailableSlots(available);
      
    } catch (error) {
      console.error('Error calculating available slots:', error);
      setAvailableSlots([]);
    }
  }, [workingHours, form.date, form.serviceId, services, appointments, blockedPeriods]);

  // 6. Real-time subscription setup
  useEffect(() => {
    if (!professionalId) return;
    
    console.log('Setting up realtime for professional:', professionalId);
    
    const appointmentsChannel = supabase
      .channel(`appointments-${professionalId}`)
      .on('postgres_changes', {
        event: '*',
        schema: 'public',
        table: 'appointments',
        filter: `professional_id=eq.${professionalId}`
      }, () => {
        console.log('Appointment change detected, refreshing...');
        setVersion(v => v + 1);
      })
      .subscribe();
    
    const blockedChannel = supabase
      .channel(`blocked-periods-${professionalId}`)
      .on('postgres_changes', {
        event: '*',
        schema: 'public', 
        table: 'blocked_periods',
        filter: `professional_id=eq.${professionalId}`
      }, () => {
        console.log('Blocked period change detected, refreshing...');
        setVersion(v => v + 1);
      })
      .subscribe();
    
    return () => {
      supabase.removeChannel(appointmentsChannel);
      supabase.removeChannel(blockedChannel);
    };
  }, [professionalId]);

  // 7. Create appointment function
  const handleCreateAppointment = async () => {
    if (!professionalId || !establishmentId || !form.serviceId || !form.date || !form.time || !form.clientName) {
      toast({ variant: "destructive", title: "Erro", description: "Preencha todos os campos obrigatórios" });
      return;
    }
    
    // Validate that selected time is available
    if (!availableSlots.includes(form.time)) {
      toast({ variant: "destructive", title: "Horário indisponível", description: "Selecione um horário disponível" });
      return;
    }
    
    try {
      const selectedService = services.find(s => s.id === form.serviceId);
      if (!selectedService) throw new Error('Serviço não encontrado');
      
      const startAt = isoForLocal(new Date(form.date + 'T12:00:00'), form.time);
      
      // Use RPC for atomic creation with conflict checking
      const { data, error } = await supabase.rpc('create_appointment_rpc', {
        p_establishment_id: establishmentId,
        p_professional_id: professionalId,
        p_service_id: form.serviceId,
        p_appointment_date: form.date,
        p_start_time: form.time,
        p_duration_minutes: selectedService.duration,
        p_client_id: null,
        p_client_name: form.clientName,
        p_client_phone: form.clientPhone || null,
        p_status: 'scheduled'
      });
      
      if (error) throw error;
      
      toast({ title: "Sucesso", description: "Agendamento criado com sucesso!" });
      
      // Clear form
      setForm({
        serviceId: '',
        date: form.date, // Keep the same date
        time: '',
        clientName: '',
        clientPhone: '',
        notes: ''
      });
      
      // Dispatch custom event to propagate to other pages/components
      window.dispatchEvent(new CustomEvent('newAppointmentCreated', {
        detail: { 
          professionalId: professionalId,
          appointmentId: data,
          action: 'created' 
        }
      }));
      
      // Trigger refresh (realtime will also trigger, but this is immediate)
      setVersion(v => v + 1);
      
    } catch (error: any) {
      console.error('Error creating appointment:', error);
      let errorMessage = 'Erro ao criar agendamento';
      
      if (error.code === 'P0001') {
        errorMessage = 'Horário indisponível (conflito com outro agendamento)';
      } else if (error.code === 'P0002') {
        errorMessage = 'Horário não disponível (bloqueado ou inválido)';
      } else if (error.message) {
        errorMessage = error.message;
      }
      
      toast({ variant: "destructive", title: "Erro", description: errorMessage });
    }
  };

  // Set loading to false once core data is loaded
  useEffect(() => {
    if (professionalId && services.length > 0 && workingHours) {
      setLoading(false);
    }
  }, [professionalId, services, workingHours]);

  const selectedService = services.find(s => s.id === form.serviceId);

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-96">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-4"></div>
          <p>Carregando dados...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto p-6 space-y-6">
      <Seo 
        title="LookPro — Novo Agendamento" 
        description="Crie novos agendamentos para seus clientes com disponibilidade em tempo real" 
        canonicalPath="/dashboard/pro/novo-agendamento" 
      />
      
      <div className="flex items-center gap-3">
        <Calendar className="w-6 h-6" />
        <h1 className="text-2xl font-bold">Novo Agendamento</h1>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Dados do Agendamento</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Service Selection */}
          <div className="space-y-2">
            <Label htmlFor="service">Serviço *</Label>
            <Select value={form.serviceId} onValueChange={(value) => setForm(prev => ({ ...prev, serviceId: value, time: '' }))}>
              <SelectTrigger>
                <SelectValue placeholder="Selecione um serviço" />
              </SelectTrigger>
              <SelectContent>
                {services.map(service => (
                  <SelectItem key={service.id} value={service.id}>
                    {service.name} - R$ {service.price.toFixed(2)} ({service.duration}min)
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Date Selection */}
          <div className="space-y-2">
            <Label htmlFor="date">Data *</Label>
            <Input
              id="date"
              type="date"
              value={form.date}
              onChange={(e) => setForm(prev => ({ ...prev, date: e.target.value, time: '' }))}
              min={new Date().toISOString().split('T')[0]}
            />
          </div>

          {/* Time Selection */}
          {form.serviceId && form.date && (
            <div className="space-y-2">
              <Label>Horário *</Label>
              <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-6 gap-2">
                {availableSlots.map(slot => (
                  <Button
                    key={slot}
                    variant={form.time === slot ? "default" : "outline"}
                    size="sm"
                    onClick={() => setForm(prev => ({ ...prev, time: slot }))}
                  >
                    {slot}
                  </Button>
                ))}
              </div>
              {availableSlots.length === 0 && (
                <p className="text-sm text-muted-foreground">
                  Nenhum horário disponível para este serviço nesta data
                </p>
              )}
            </div>
          )}

          {/* Client Information */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="clientName">Nome do Cliente *</Label>
              <Input
                id="clientName"
                placeholder="Ex: Maria Silva"
                value={form.clientName}
                onChange={(e) => setForm(prev => ({ ...prev, clientName: e.target.value }))}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="clientPhone">Telefone</Label>
              <Input
                id="clientPhone"
                placeholder="(11) 99999-0000"
                value={form.clientPhone}
                onChange={(e) => setForm(prev => ({ ...prev, clientPhone: e.target.value }))}
              />
            </div>
          </div>

          {/* Notes */}
          <div className="space-y-2">
            <Label htmlFor="notes">Observações</Label>
            <Input
              id="notes"
              placeholder="Observações sobre o agendamento"
              value={form.notes}
              onChange={(e) => setForm(prev => ({ ...prev, notes: e.target.value }))}
            />
          </div>

          {/* Summary */}
          {selectedService && form.time && (
            <div className="bg-muted/50 p-4 rounded-lg space-y-2">
              <h3 className="font-medium">Resumo do Agendamento</h3>
              <div className="text-sm text-muted-foreground space-y-1">
                <p><strong>Serviço:</strong> {selectedService.name}</p>
                <p><strong>Data:</strong> {new Date(form.date + 'T12:00:00').toLocaleDateString('pt-BR')}</p>
                <p><strong>Horário:</strong> {form.time}</p>
                <p><strong>Duração:</strong> {selectedService.duration} minutos</p>
                <p><strong>Valor:</strong> R$ {selectedService.price.toFixed(2)}</p>
                {form.clientName && <p><strong>Cliente:</strong> {form.clientName}</p>}
              </div>
            </div>
          )}

          {/* Actions */}
          <div className="flex gap-3 pt-4">
            <Button
              variant="outline"
              onClick={() => setForm({
                serviceId: '',
                date: new Date().toISOString().split('T')[0],
                time: '',
                clientName: '',
                clientPhone: '',
                notes: ''
              })}
            >
              Limpar
            </Button>
            <Button
              onClick={handleCreateAppointment}
              disabled={!form.serviceId || !form.date || !form.time || !form.clientName}
            >
              Criar Agendamento
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default NovoAgendamento;