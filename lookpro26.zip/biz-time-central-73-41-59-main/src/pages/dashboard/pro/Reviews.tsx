import Seo from "@/components/Seo";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Star } from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import { reviewsAdapter, professionalsAdapter } from "@/services/adapters";
import { useAuth } from "@/context/AuthContext";

const formatDate = (iso: string) => new Date(iso).toLocaleDateString("pt-BR");

export default function ReviewsPage() {
  const { user } = useAuth();
  const [proId, setProId] = useState<string>("");
  const [reviews, setReviews] = useState<Awaited<ReturnType<typeof reviewsAdapter.listByProfessional>>>([]);

  useEffect(() => {
    (async () => {
      if (!user) return;
      const pro = await professionalsAdapter.getByEmail(user.email);
      if (!pro) return;
      setProId(pro.id);
      setReviews(await reviewsAdapter.listByProfessional(pro.id));
    })();
  }, [user?.uid]);

  const avg = useMemo(() => {
    if (!reviews.length) return 0;
    return Math.round((reviews.reduce((s, r) => s + r.professional_rating, 0) / reviews.length) * 10) / 10;
  }, [reviews]);

  return (
    <>
      <Seo title="LookPro — Avaliações Recebidas" description="Opiniões dos clientes atendidos." canonicalPath="/dashboard/pro/avaliacoes" />
      <h1 className="text-2xl font-extrabold mb-4">Avaliações Recebidas</h1>

      <Card className="mb-4">
        <CardHeader><CardTitle>Média: {avg} / 5 ({reviews.length})</CardTitle></CardHeader>
        <CardContent className="text-muted-foreground">Atualizado automaticamente</CardContent>
      </Card>

      {reviews.length === 0 && (
        <Card>
          <CardHeader><CardTitle>Nenhuma avaliação</CardTitle></CardHeader>
          <CardContent className="text-muted-foreground">Você ainda não recebeu avaliações.</CardContent>
        </Card>
      )}

      <div className="grid gap-3">
        {reviews.map((r) => (
          <Card key={r.id}>
            <CardHeader className="flex items-center justify-between">
              <CardTitle className="text-base">{r.client_id ?? "Cliente"}</CardTitle>
              <div className="flex items-center gap-1">
                {Array.from({ length: 5 }, (_, i) => (
                  <Star key={i} size={16} className={i < r.professional_rating ? "" : "opacity-30"} />
                ))}
              </div>
            </CardHeader>
            <CardContent className="space-y-2">
              {r.comment && <p className="text-sm">{r.comment}</p>}
              <div className="text-xs text-muted-foreground">{formatDate(r.created_at)}</div>
            </CardContent>
          </Card>
        ))}
      </div>
    </>
  );
}