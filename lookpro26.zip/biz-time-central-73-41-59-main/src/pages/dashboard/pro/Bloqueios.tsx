import { useState, useEffect, useMemo } from "react";
import type { DateRange } from "react-day-picker";
import Seo from "@/components/Seo";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Calendar } from "@/components/ui/calendar";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { toast } from "@/hooks/use-toast";
import { blockedPeriodsAdapter, professionalsAdapter, establishmentsAdapter } from "@/services/adapters";
import { listAppointmentsByProfessional } from "@/services/appointments";
import { useAuthContext } from "@/context/AuthContext";
import BlockedPeriodsList from "@/components/pro/BlockedPeriodsList";
import { generateTimeSlots } from "@/lib/timeSlots";

// Utilitários de data/hora (mantém data local correta - evita deslocamento por UTC)
const ymdLocal = (d: Date) =>
  `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;

const isoForLocal = (day: Date, time: string) => {
  const [H, M] = time.split(":").map(Number);
  const local = new Date(day.getFullYear(), day.getMonth(), day.getDate(), H, M, 0);
  return local.toISOString(); // persistimos em UTC, baseando na hora local
};

const BloqueiosPage = () => {
  const { user } = useAuthContext();
  const [date, setDate] = useState<Date | undefined>(new Date());
  const [range, setRange] = useState<DateRange | undefined>();
  const [version, setVersion] = useState(0);
  const [professionalId, setProfessionalId] = useState<string>("");
  const [establishmentId, setEstablishmentId] = useState<string>("");
  const [modalOpen, setModalOpen] = useState(false);
  const [selectedDate, setSelectedDate] = useState<Date | undefined>();
  const [loading, setLoading] = useState(true);
  const [slots, setSlots] = useState<any[]>([]);

  // Load professional data
  useEffect(() => {
    (async () => {
      if (!user) {
        setLoading(false);
        return;
      }
      
      try {
        setLoading(true);
        const authUserId = (user as any).id ?? (user as any).uid;
        const pro = await professionalsAdapter.getByUserId(authUserId);
        if (pro) {
          setProfessionalId(pro.id);
          setEstablishmentId(pro.establishmentId);
        }
      } catch (error) {
        console.error('Error loading professional data:', error);
        toast({ variant: "destructive", title: "Erro ao carregar dados do profissional" });
      } finally {
        setLoading(false);  
      }
    })();
  }, [user]);

  // Carregamento de slots/agenda/bloqueios por dia local
  useEffect(() => {
    (async () => {
      if (!professionalId || !establishmentId || !date) {
        setSlots([]);
        return;
      }

      try {
        const establishment = await establishmentsAdapter.getById(establishmentId);
        if (!establishment?.workingHours) {
          setSlots([]);
          return;
        }

        const dayOfWeek = date.getDay();
        const dayHours = establishment.workingHours[dayOfWeek];
        
        if (!dayHours || dayHours.closed) {
          setSlots([]);
          return;
        }

        // Gerar slots com generateTimeSlots
        const timeSlots = generateTimeSlots(dayHours, 30);
        
        // Carregar agendamentos ativos do dia
        const dateStr = ymdLocal(date);
        const appointments = await listAppointmentsByProfessional(professionalId, { date: dateStr });
        const activeAppointments = appointments.filter(apt => apt.status !== "cancelado");
        
        // Carregar bloqueios
        const blocked = await blockedPeriodsAdapter.listByProfessional(professionalId);
        
        // Processar cada slot
        const processedSlots = timeSlots.map(({ time, available: defaultAvailable }) => {
          const slotISO = isoForLocal(date, time);
          
          // Verificar agendamentos (intervalo [start, end))
          const hasAppointment = activeAppointments.some(apt => {
            const aptStart = new Date(`2000-01-01T${apt.time}`);
            const aptDuration = 60; // assumindo 60min se não especificado
            const aptEnd = new Date(aptStart.getTime() + aptDuration * 60 * 1000);
            const slotTime = new Date(`2000-01-01T${time}:00`);
            return slotTime >= aptStart && slotTime < aptEnd;
          });
          
          // Verificar bloqueios (intervalo [start, end))
          const isBlocked = blocked.some(b => slotISO >= b.start && slotISO < b.end);
          
          return {
            time,
            available: defaultAvailable && !hasAppointment && !isBlocked,
            blocked: isBlocked,
            appointment: hasAppointment ? activeAppointments.find(apt => {
              const aptStart = new Date(`2000-01-01T${apt.time}`);
              const slotTime = new Date(`2000-01-01T${time}:00`);
              return Math.abs(aptStart.getTime() - slotTime.getTime()) < 30 * 60 * 1000; // 30min tolerance
            }) : null
          };
        });
        
        setSlots(processedSlots);
      } catch (error) {
        console.error('Error loading schedule data:', error);
        toast({ variant: "destructive", title: "Erro ao carregar agenda" });
        setSlots([]);
      }
    })();
  }, [professionalId, establishmentId, date, version]);

  // Calculate blocked periods count in range
  const blockedInRangeCount = useMemo(() => {
    if (!professionalId || !range?.from || !establishmentId) return 0;
    
    // Este é um cálculo simplificado - seria ideal recalcular baseado na lógica completa
    return 0; // TODO: implementar contagem precisa se necessário
  }, [professionalId, establishmentId, range, version]);

  const blockAllForDay = async () => {
    if (!professionalId || !date) return;
    
    try {
      // Filtrar slots livres (sem agendamento e sem bloqueio)
      const freeSlots = slots.filter(slot => 
        slot.available && !slot.appointment && !slot.blocked
      );
      
      if (freeSlots.length === 0) {
        toast({ title: "Não há horários livres para bloquear nesta data" });
        return;
      }
      
      const promises = freeSlots.map((slot) => {
        const start = isoForLocal(date, slot.time);
        const end = new Date(new Date(start).getTime() + 30 * 60 * 1000).toISOString();
        
        return blockedPeriodsAdapter.create({
          professionalId: professionalId,
          establishmentId: establishmentId,
          start,
          end,
          reason: "Bloqueio de horários livres"
        });
      });
      
      await Promise.all(promises);
      toast({ title: `${freeSlots.length} horários livres bloqueados` });
      setVersion((v) => v + 1);
    } catch (error: any) {
      console.error('[blockedPeriods/blockAllForDay] error:', error);
      toast({ variant: "destructive", title: "Erro ao bloquear horários", description: error.message });
    }
  };

  const unblockAllForDay = async () => {
    if (!professionalId || !date) return;
    
    try {
      const blockedSlots = slots.filter(slot => slot.blocked);
      
      if (blockedSlots.length === 0) {
        toast({ title: "Não há horários bloqueados para desbloquear nesta data" });
        return;
      }
      
      const dayKey = ymdLocal(date);
      const blocked = await blockedPeriodsAdapter.listByProfessional(professionalId);
      const dayBlocked = blocked.filter(b => {
        const dayStartISO = new Date(`${dayKey}T00:00:00`).toISOString();
        const dayEndISO = new Date(`${dayKey}T23:59:59`).toISOString();
        return !(dayEndISO <= b.start || dayStartISO >= b.end);
      });
      
      const promises = dayBlocked.map(b => blockedPeriodsAdapter.remove(b.id));
      await Promise.all(promises);
      
      toast({ title: "Todos os horários do dia desbloqueados" });
      setVersion((v) => v + 1);
    } catch (error: any) {
      console.error('[blockedPeriods/unblockAllForDay] error:', error);
      toast({ variant: "destructive", title: "Erro ao desbloquear horários", description: error.message });
    }
  };

  const blockRange = async () => {
    if (!professionalId || !establishmentId || !range?.from) return;
    
    try {
      const start = range.from;
      const end = range.to ?? range.from;
      const current = new Date(start);
      
      const establishment = await establishmentsAdapter.getById(establishmentId);
      if (!establishment?.workingHours) return;
      
      const promises: Promise<any>[] = [];
      let totalFreeSlots = 0;
      
      while (current <= end) {
        const dayOfWeek = current.getDay();
        const dayHours = establishment.workingHours[dayOfWeek];
        
        if (!dayHours || dayHours.closed) {
          current.setDate(current.getDate() + 1);
          continue;
        }
        
        // Gerar slots do dia
        const dailySlots = generateTimeSlots(dayHours, 30);
        
        // Carregar agendamentos ativos do dia
        const dateStr = ymdLocal(current);
        const appointments = await listAppointmentsByProfessional(professionalId, { date: dateStr });
        const activeAppointments = appointments.filter(apt => apt.status !== "cancelado");
        
        // Carregar bloqueios do dia
        const blocked = await blockedPeriodsAdapter.listByProfessional(professionalId);
        const dayStartISO = new Date(`${dateStr}T00:00:00`).toISOString();
        const dayEndISO = new Date(`${dateStr}T23:59:59`).toISOString();
        const todaysBlocks = blocked.filter(
          bk => !(dayEndISO <= bk.start || dayStartISO >= bk.end)
        );
        
        // Para cada slot do dia
        for (const { time } of dailySlots) {
          const startISO = isoForLocal(current, time);
          const endISO = new Date(new Date(startISO).getTime() + 30 * 60 * 1000).toISOString();
          
          // Verificar conflito com agendamento
          const hasAppointment = activeAppointments.some(apt => {
            const aptStart = new Date(`2000-01-01T${apt.time}`);
            const aptDuration = 60;
            const aptEnd = new Date(aptStart.getTime() + aptDuration * 60 * 1000);
            const slotTime = new Date(`2000-01-01T${time}:00`);
            return slotTime >= aptStart && slotTime < aptEnd;
          });
          
          if (hasAppointment) continue;
          
          // Verificar sobreposição com bloqueio existente
          const hasBlockOverlap = todaysBlocks.some(bk => 
            !(endISO <= bk.start || startISO >= bk.end)
          );
          
          if (hasBlockOverlap) continue;
          
          // Slot livre: criar bloqueio
          promises.push(blockedPeriodsAdapter.create({
            professionalId: professionalId,
            establishmentId: establishmentId,
            start: startISO,
            end: endISO,
            reason: "Bloqueio por período"
          }));
          totalFreeSlots++;
        }
        
        current.setDate(current.getDate() + 1);
      }
      
      if (totalFreeSlots === 0) {
        toast({ title: "Não há horários livres para bloquear no período selecionado" });
        return;
      }
      
      await Promise.all(promises);
      toast({ title: `${totalFreeSlots} horários livres bloqueados no período` });
      setVersion((v) => v + 1);
      setRange(undefined);
    } catch (error: any) {
      console.error('[blockedPeriods/blockRange] error:', error);
      toast({ variant: "destructive", title: "Erro ao bloquear período", description: error.message });
    }
  };

  const unblockRange = async () => {
    if (!professionalId || !range?.from) return;
    
    try {
      const start = range.from;
      const end = range.to ?? range.from;
      const current = new Date(start);
      
      const blocked = await blockedPeriodsAdapter.listByProfessional(professionalId);
      const promises: Promise<void>[] = [];
      
      while (current <= end) {
        const dayKey = ymdLocal(current);
        const dayStartISO = new Date(`${dayKey}T00:00:00`).toISOString();
        const dayEndISO = new Date(`${dayKey}T23:59:59`).toISOString();
        
        const dayBlocked = blocked.filter(bk => 
          !(dayEndISO <= bk.start || dayStartISO >= bk.end)
        );
        
        dayBlocked.forEach(b => {
          promises.push(blockedPeriodsAdapter.remove(b.id));
        });
        
        current.setDate(current.getDate() + 1);
      }
      
      await Promise.all(promises);
      toast({ title: "Período desbloqueado com sucesso" });
      setVersion((v) => v + 1);
      setRange(undefined);
    } catch (error: any) {
      console.error('[blockedPeriods/unblockRange] error:', error);
      toast({ variant: "destructive", title: "Erro ao desbloquear período", description: error.message });
    }
  };

  const handleSlotToggle = async (time: string, targetDate: Date) => {
    if (!user || !professionalId) return;
    
    try {
      // Usar slots do state local ao invés de getScheduleForDate
      const slot = slots.find(s => s.time === time);
      
      if (!slot) {
        toast({ variant: "destructive", title: "Horário não encontrado" });
        return;
      }
      
      // Calcular ISO (início) e endISO (+30min)
      const iso = isoForLocal(targetDate, time);
      const endISO = new Date(new Date(iso).getTime() + 30 * 60 * 1000).toISOString();
      
      // Checar conflito com agendamento usando intervalo
      if (slot.appointment) {
        const appointmentInfo = slot.appointment.clientName ? 
          ` (Cliente: ${slot.appointment.clientName})` : '';
        toast({ 
          variant: "destructive", 
          title: "Não é possível bloquear um horário com agendamento", 
          description: `${appointmentInfo}. Cancele o agendamento primeiro.` 
        });
        return;
      }
      
      // Detectar bloqueio existente usando intervalo meia-aberto
      const blocked = await blockedPeriodsAdapter.listByProfessional(professionalId);
      const existing = blocked.find(b => iso >= b.start && iso < b.end);
      
      if (existing) {
        // Desbloquear o slot
        await blockedPeriodsAdapter.remove(existing.id);
        toast({ title: "Horário desbloqueado com sucesso" });
      } else if (slot.available) {
        // Bloquear o slot (apenas se disponível)
        await blockedPeriodsAdapter.create({
          professionalId: professionalId,
          establishmentId: establishmentId,
          start: iso,
          end: endISO,
          reason: "Bloqueio manual"
        });
        
        toast({ title: "Horário bloqueado com sucesso" });
      } else {
        toast({ variant: "destructive", title: "Este horário não está disponível para bloqueio" });
      }
      
      setVersion((v) => v + 1);
    } catch (error: any) {
      console.error('[blockedPeriods/onToggle] error:', error);
      toast({ variant: "destructive", title: "Erro ao alterar bloqueio", description: error.message });
    }
  };

  const handleDateClick = (clickedDate: Date) => {
    setSelectedDate(clickedDate);
    setModalOpen(true);
  };

  const renderSlotButton = (slot: any, targetDate: Date) => {
    let variant: "default" | "secondary" | "destructive" | "outline" = "secondary";
    let disabled = false;
    let label = slot.time;
    let className = "text-xs h-8";
    
    if (slot.appointment) {
      // Slots with appointments are completely disabled and visually distinct
      variant = "outline";
      disabled = true;
      label = `${slot.time} (Agendado)`;
      className += " cursor-not-allowed opacity-60";
    } else if (slot.blocked) {
      variant = "destructive";
      label = `${slot.time} (Bloqueado)`;
    } else if (slot.available) {
      variant = "secondary";
      label = `${slot.time} (Livre)`;
    }
    
    return (
      <Button
        key={slot.time}
        variant={variant}
        size="sm"
        disabled={disabled}
        onClick={() => !disabled && handleSlotToggle(slot.time, targetDate)}
        className={className}
      >
        {label}
      </Button>
    );
  };

  if (loading) {
    return (
      <div className="space-y-4">
        <Seo title="LookPro — Bloqueios de Agenda" description="Bloqueie ou desbloqueie horários específicos do seu calendário." canonicalPath="/dashboard/pro/bloqueios" />
        <h1 className="text-2xl font-extrabold">Bloqueios</h1>
        <div className="flex items-center justify-center py-8">
          <p className="text-muted-foreground">Carregando...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="space-y-4">
        <Seo title="LookPro — Bloqueios de Agenda" description="Bloqueie ou desbloqueie horários específicos do seu calendário." canonicalPath="/dashboard/pro/bloqueios" />
        <h1 className="text-2xl font-extrabold">Bloqueios</h1>
        <div className="flex items-center justify-center py-8">
          <p className="text-muted-foreground">Você precisa estar logado para acessar esta página.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-4 max-w-full overflow-x-hidden">
      <Seo title="LookPro — Bloqueios de Agenda" description="Bloqueie ou desbloqueie horários específicos do seu calendário." canonicalPath="/dashboard/pro/bloqueios" />
      <div className="space-y-2">
        <h1 className="text-xl sm:text-2xl font-extrabold">Bloqueios</h1>
        <p className="text-sm sm:text-base text-muted-foreground">
          Selecione uma data para ver horários disponíveis para bloqueio.
          <strong className="text-foreground"> Horários com agendamentos não podem ser bloqueados.</strong>
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 overflow-x-hidden">
        <Card>
          <CardHeader><CardTitle>Escolha a data</CardTitle></CardHeader>
          <CardContent>
            <Calendar
              mode="single"
              selected={date}
              onSelect={(selectedDate) => {
                setDate(selectedDate);
                if (selectedDate) {
                  handleDateClick(selectedDate);
                }
              }}
              initialFocus
              className="p-3 pointer-events-auto"
            />
          </CardContent>
        </Card>

        <Card>
          <CardHeader><CardTitle>Horários do dia</CardTitle></CardHeader>
          <CardContent>
            {!date ? (
              <p className="text-muted-foreground">Selecione uma data para ver os horários.</p>
            ) : (() => {
              // Usar slots do state local
              const availableSlots = slots.filter(slot => slot.available);
              const appointmentSlots = slots.filter(slot => slot.appointment);
              const blockedSlots = slots.filter(slot => slot.blocked);
              
              return (
                <>
                   <div className="flex flex-col sm:flex-row flex-wrap items-start sm:items-center gap-2 mb-3">
                     <Button 
                       onClick={blockAllForDay}
                       disabled={availableSlots.length === 0}
                       size="sm"
                       className="w-full sm:w-auto text-xs"
                     >
                       Bloquear livres ({availableSlots.length})
                     </Button>
                     {blockedSlots.length > 0 && (
                       <Button 
                         variant="outline" 
                         onClick={unblockAllForDay}
                         size="sm"
                         className="w-full sm:w-auto text-xs"
                       >
                         Desbloquear ({blockedSlots.length})
                       </Button>
                     )}
                   </div>
                  
                  <div className="mb-3 text-sm text-muted-foreground">
                    <div className="flex flex-wrap gap-4">
                      <span className="flex items-center gap-1">
                        <div className="w-3 h-3 rounded bg-secondary"></div>
                        Livre ({availableSlots.length})
                      </span>
                      <span className="flex items-center gap-1">
                        <div className="w-3 h-3 rounded border-2 border-border bg-background"></div>
                        Agendado ({appointmentSlots.length})
                      </span>
                      <span className="flex items-center gap-1">
                        <div className="w-3 h-3 rounded bg-destructive"></div>
                        Bloqueado ({blockedSlots.length})
                      </span>
                    </div>
                  </div>
                  
                  {slots.length === 0 ? (
                    <p className="text-muted-foreground">Estabelecimento fechado nesta data.</p>
                  ) : (
                    <div className="grid grid-cols-3 sm:grid-cols-4 gap-2">
                      {slots.map((slot) => renderSlotButton(slot, date))}
                    </div>
                  )}
                </>
              );
            })()}
          </CardContent>
        </Card>
      </div>

      <Card className="mt-4">
        <CardHeader><CardTitle>Bloqueio por período</CardTitle></CardHeader>
        <CardContent>
          <div className="grid gap-4 lg:grid-cols-2 overflow-x-hidden">
            <div>
              <Calendar
                mode="range"
                selected={range}
                onSelect={setRange}
                initialFocus
                className="p-3 pointer-events-auto"
              />
            </div>
            <div className="flex flex-col gap-2">
              <p className="text-sm text-muted-foreground">
                Selecione um intervalo de datas para bloquear apenas os horários livres de cada dia.
                <strong className="block mt-1 text-foreground">
                  Horários com agendamentos não serão afetados.
                </strong>
              </p>
               <div className="flex flex-col sm:flex-row gap-2">
                 <Button 
                   onClick={blockRange} 
                   disabled={!range?.from}
                   size="sm"
                   className="w-full sm:w-auto text-xs"
                 >
                   Bloquear período
                 </Button>
                 {blockedInRangeCount > 0 && (
                   <Button 
                     variant="outline" 
                     onClick={unblockRange}
                     size="sm"
                     className="w-full sm:w-auto text-xs"
                   >
                     Desbloquear período ({blockedInRangeCount})
                   </Button>
                 )}
               </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card className="mt-4">
        <CardHeader><CardTitle>Períodos bloqueados</CardTitle></CardHeader>
        <CardContent>
          {professionalId ? (
            <BlockedPeriodsList 
              proId={professionalId}
              slots={[]}
              version={version} 
              onChanged={() => setVersion((v) => v + 1)} 
            />
          ) : (
            <p className="text-muted-foreground text-sm">Carregando...</p>
          )}
        </CardContent>
      </Card>

      {/* Modal for available slots */}
      <Dialog open={modalOpen} onOpenChange={setModalOpen}>
        <DialogContent className="w-[calc(100vw-1rem)] max-w-[95vw] sm:max-w-[500px] max-h-[calc(100svh-env(safe-area-inset-top)-env(safe-area-inset-bottom)-2rem)] overflow-y-auto p-4 sm:p-6">
          <DialogHeader>
            <DialogTitle>Horários para {selectedDate?.toLocaleDateString()}</DialogTitle>
          </DialogHeader>
          
          <div className="space-y-3">
            <div className="text-sm text-muted-foreground">
              <div className="flex flex-wrap gap-4">
                <span className="flex items-center gap-1">
                  <div className="w-3 h-3 rounded bg-secondary"></div>
                  Livre
                </span>
                <span className="flex items-center gap-1">
                  <div className="w-3 h-3 rounded border-2 border-border bg-background"></div>
                  Agendado (não bloqueável)
                </span>
                <span className="flex items-center gap-1">
                  <div className="w-3 h-3 rounded bg-destructive"></div>
                  Bloqueado
                </span>
              </div>
            </div>

            {selectedDate && (() => {
              // Para o modal, recalcular slots da data selecionada se for diferente de `date`
              const modalSlots = selectedDate.toDateString() === date?.toDateString() 
                ? slots 
                : []; // Simplificado - pode ser implementado se necessário
              
              return modalSlots.length === 0 ? (
                <p className="text-muted-foreground">Estabelecimento fechado nesta data.</p>
              ) : (
                <div className="grid grid-cols-3 sm:grid-cols-4 gap-2 max-h-96 overflow-y-auto">
                  {modalSlots.map((slot) => renderSlotButton(slot, selectedDate))}
                </div>
              );
            })()}
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default BloqueiosPage;