import { useEffect, useState } from "react";
import Seo from "@/components/Seo";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Link } from "react-router-dom";
import { adminAdapter } from "@/services/adminAdapters";
import { toast } from "@/hooks/use-toast";
import { useAuth } from "@/context/AuthContext";
const AdminProfessionals = () => {
  const { user } = useAuth();
  const [pros, setPros] = useState<any[]>([]);
  const estId = user?.establishmentId;
  
  const refresh = async () => {
    if (!estId) {
      console.log('No establishment ID available, skipping professionals fetch');
      setPros([]);
      return;
    }
    
    try {
      console.log('Fetching professionals for establishment:', estId);
      const professionals = await adminAdapter.listProfessionals(estId);
      console.log('Professionals loaded:', professionals);
      setPros(professionals || []);
    } catch (error) {
      console.error('Error loading professionals:', error);
      setPros([]);
    }
  };

  useEffect(() => { 
    if (estId) refresh(); 
  }, [estId]);

  const onDelete = async (id: string) => {
    if (!confirm("Remover profissional?")) return;
    try {
      await adminAdapter.deleteProfessional(id);
      toast({ title: "Profissional removido" });
      refresh();
    } catch (error: any) {
      toast({ title: "Erro ao remover", description: error.message });
    }
  };

  return (
    <main className="container py-8">
      <Seo title="LookPro — Admin | Profissionais" description="Gestão da equipe do estabelecimento" canonicalPath="/dashboard/admin/profissionais" />
      <header className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-extrabold">Profissionais</h1>
        <div className="flex gap-2">
          <Link to="/dashboard/admin/profissionais/novo"><Button variant="hero">Convidar/Adicionar</Button></Link>
          <Link to="/dashboard/admin"><Button variant="soft">Voltar ao painel</Button></Link>
        </div>
      </header>
      <Card>
        <CardHeader>
          <CardTitle>Equipe</CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Profissional</TableHead>
                <TableHead>WhatsApp</TableHead>
                <TableHead className="text-right">Ações</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {pros.length === 0 && (
                <TableRow>
                  <TableCell colSpan={3} className="text-muted-foreground">Nenhum profissional cadastrado. Total: {pros.length}</TableCell>
                </TableRow>
              )}
              {pros.map((p) => (
                <TableRow key={p.id}>
                  <TableCell className="font-medium">
                    <div className="flex items-center gap-3">
                      <div className="h-8 w-8 rounded-full bg-secondary/50" />
                      {p.name}
                    </div>
                  </TableCell>
                  <TableCell>—</TableCell>
                  <TableCell className="text-right space-x-2">
                    <Link to={`/dashboard/admin/profissionais/${p.id}/editar`}><Button size="sm" variant="outline">Editar</Button></Link>
                    <Button size="sm" variant="destructive" onClick={() => onDelete(p.id)}>Remover</Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </main>
  );
};

export default AdminProfessionals;

