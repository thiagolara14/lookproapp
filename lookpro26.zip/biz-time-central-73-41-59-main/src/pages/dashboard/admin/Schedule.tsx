import { useEffect, useState } from "react";
import Seo from "@/components/Seo";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { toast } from "@/hooks/use-toast";
import { useAuth } from "@/context/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { Clock, Save } from "lucide-react";

interface DaySchedule {
  day_of_week: number;
  open_time: string;
  close_time: string;
  is_closed: boolean;
}

const DAYS = [
  { value: 1, label: "Segunda-feira" },
  { value: 2, label: "Terça-feira" },
  { value: 3, label: "Quarta-feira" },
  { value: 4, label: "Quinta-feira" },
  { value: 5, label: "Sexta-feira" },
  { value: 6, label: "Sábado" },
  { value: 0, label: "Domingo" },
];

const AdminSchedule = () => {
  const { user } = useAuth();
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [schedule, setSchedule] = useState<DaySchedule[]>([]);

  useEffect(() => {
    if (user?.establishmentId) {
      loadSchedule();
    }
  }, [user?.establishmentId]);

  const loadSchedule = async () => {
    if (!user?.establishmentId) return;

    try {
      // First, try to get data using the RPC to ensure consistency
      const { data: rpcData, error: rpcError } = await supabase.rpc('get_establishment_working_hours', {
        establishment_uuid: user.establishmentId
      });

      if (!rpcError && rpcData && Object.keys(rpcData).length > 0) {
        // Convert RPC data to schedule format
        const scheduleFromRPC = DAYS.map(day => {
          const dayData = rpcData[day.value.toString()];
          return {
            day_of_week: day.value,
            open_time: dayData && !dayData.closed ? dayData.start : "09:00",
            close_time: dayData && !dayData.closed ? dayData.end : "18:00",
            is_closed: !dayData || dayData.closed,
          };
        });
        setSchedule(scheduleFromRPC);
        return;
      }

      // Fallback: read directly from establishment_hours table
      const { data, error } = await supabase
        .from('establishment_hours')
        .select('*')
        .eq('establishment_id', user.establishmentId)
        .order('day_of_week');

      if (error) throw error;

      // Initialize with default hours if no data exists
      const defaultSchedule = DAYS.map(day => ({
        day_of_week: day.value,
        open_time: "09:00",
        close_time: "18:00",
        is_closed: day.value === 0, // Sunday closed by default
      }));

      if (data && data.length > 0) {
        // Merge existing data with defaults
        const existingSchedule = defaultSchedule.map(defaultDay => {
          const existing = data.find(d => d.day_of_week === defaultDay.day_of_week);
          return existing ? {
            day_of_week: existing.day_of_week,
            open_time: existing.open_time || defaultDay.open_time,
            close_time: existing.close_time || defaultDay.close_time,
            is_closed: existing.is_closed ?? defaultDay.is_closed,
          } : defaultDay;
        });
        setSchedule(existingSchedule);
      } else {
        setSchedule(defaultSchedule);
      }
    } catch (error) {
      console.error('Error loading schedule:', error);
      toast({
        title: "Erro",
        description: "Não foi possível carregar os horários.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const updateDaySchedule = (dayOfWeek: number, field: keyof DaySchedule, value: any) => {
    setSchedule(prev => prev.map(day => 
      day.day_of_week === dayOfWeek 
        ? { ...day, [field]: value }
        : day
    ));
  };

  const saveSchedule = async () => {
    if (!user?.establishmentId) return;

    setSaving(true);
    try {
      // Delete existing records
      await supabase
        .from('establishment_hours')
        .delete()
        .eq('establishment_id', user.establishmentId);

      // Insert new records
      const schedulesToInsert = schedule.map(day => ({
        establishment_id: user.establishmentId,
        day_of_week: day.day_of_week,
        open_time: day.is_closed ? null : day.open_time,
        close_time: day.is_closed ? null : day.close_time,
        is_closed: day.is_closed,
      }));

      const { error } = await supabase
        .from('establishment_hours')
        .insert(schedulesToInsert);

      if (error) throw error;

      toast({
        title: "Horários salvos",
        description: "Suas alterações foram aplicadas com sucesso.",
      });
    } catch (error) {
      console.error('Error saving schedule:', error);
      toast({
        title: "Erro",
        description: "Não foi possível salvar os horários.",
        variant: "destructive",
      });
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <main className="container py-8">
        <Seo title="LookPro — Admin | Horários" description="Configuração de horário de funcionamento" canonicalPath="/dashboard/admin/horarios" />
        <div className="text-center py-8">Carregando horários...</div>
      </main>
    );
  }

  return (
    <main className="container py-8">
      <Seo title="LookPro — Admin | Horários" description="Configuração de horário de funcionamento" canonicalPath="/dashboard/admin/horarios" />
      
      <header className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <div className="size-10 rounded-md bg-[image:var(--gradient-primary)] flex items-center justify-center">
            <Clock className="size-5 text-white" />
          </div>
          <div>
            <h1 className="text-2xl font-extrabold">Horário de funcionamento</h1>
            <p className="text-sm text-muted-foreground">Configure os horários de atendimento do seu estabelecimento</p>
          </div>
        </div>
        <Button 
          variant="hero" 
          onClick={saveSchedule} 
          disabled={saving}
          className="gap-2"
        >
          <Save className="size-4" />
          {saving ? "Salvando..." : "Salvar alterações"}
        </Button>
      </header>

      <Card>
        <CardHeader>
          <CardTitle>Horários por dia da semana</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          {DAYS.map((day) => {
            const daySchedule = schedule.find(s => s.day_of_week === day.value);
            if (!daySchedule) return null;

            return (
              <div key={day.value} className="flex flex-col md:flex-row md:items-center gap-4 p-4 border rounded-lg">
                <div className="flex-1">
                  <Label className="text-base font-semibold">{day.label}</Label>
                </div>
                
                <div className="flex items-center gap-4">
                  <div className="flex items-center gap-2">
                    <Switch
                      checked={!daySchedule.is_closed}
                      onCheckedChange={(checked) => updateDaySchedule(day.value, 'is_closed', !checked)}
                    />
                    <Label className="text-sm">
                      {daySchedule.is_closed ? "Fechado" : "Aberto"}
                    </Label>
                  </div>

                  {!daySchedule.is_closed && (
                    <>
                      <div className="flex items-center gap-2">
                        <Label htmlFor={`open-${day.value}`} className="text-sm">Abertura:</Label>
                        <Input
                          id={`open-${day.value}`}
                          type="time"
                          value={daySchedule.open_time}
                          onChange={(e) => updateDaySchedule(day.value, 'open_time', e.target.value)}
                          className="w-24"
                        />
                      </div>

                      <div className="flex items-center gap-2">
                        <Label htmlFor={`close-${day.value}`} className="text-sm">Fechamento:</Label>
                        <Input
                          id={`close-${day.value}`}
                          type="time"
                          value={daySchedule.close_time}
                          onChange={(e) => updateDaySchedule(day.value, 'close_time', e.target.value)}
                          className="w-24"
                        />
                      </div>
                    </>
                  )}
                </div>
              </div>
            );
          })}

          <div className="bg-muted/50 p-4 rounded-lg">
            <h3 className="font-semibold mb-2">Informações importantes:</h3>
            <ul className="text-sm text-muted-foreground space-y-1">
              <li>• Os horários definidos aqui afetam a disponibilidade de agendamentos</li>
              <li>• Clientes só poderão agendar dentro dos horários de funcionamento</li>
              <li>• Você pode definir horários diferentes para cada dia da semana</li>
              <li>• Marque como "Fechado" os dias que não há atendimento</li>
            </ul>
          </div>
        </CardContent>
      </Card>
    </main>
  );
};

export default AdminSchedule;
