import { useEffect, useState } from "react";
import Seo from "@/components/Seo";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Star, Clock } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useCurrentEstablishmentId } from "@/hooks/useCurrentEstablishmentId";
import { toast } from "sonner";

const AdminReviews = () => {
  const [reviews, setReviews] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const { establishmentId, loading: hookLoading } = useCurrentEstablishmentId();

  useEffect(() => {
    async function loadReviews() {
      if (hookLoading || !establishmentId) return;
      
      try {
        const { data, error } = await supabase
          .from('reviews')
          .select('*')
          .eq('establishment_id', establishmentId)
          .order('created_at', { ascending: false });

        if (error) throw error;
        setReviews(data || []);
      } catch (error: any) {
        console.error('Erro ao carregar avaliações:', error);
        toast.error('Falha ao carregar avaliações');
      } finally {
        setLoading(false);
      }
    }

    loadReviews();
  }, [establishmentId, hookLoading]);

  if (loading) {
    return (
      <main className="container py-8">
        <div className="animate-pulse text-sm text-muted-foreground">Carregando avaliações...</div>
      </main>
    );
  }

  return (
    <main className="container py-8">
      <Seo title="LookPro — Admin | Avaliações" description="Avaliações recebidas pelos serviços e profissionais" canonicalPath="/dashboard/admin/avaliacoes" />
      <h1 className="text-2xl font-extrabold mb-6">Avaliações</h1>
      
      {reviews.length === 0 ? (
        <Card>
          <CardHeader>
            <CardTitle>Nenhuma avaliação encontrada</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-muted-foreground">Quando clientes avaliarem seus serviços, as avaliações aparecerão aqui.</p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-4">
          {reviews.map((review) => (
            <Card key={review.id} className="bg-card/70 backdrop-blur border-border/60">
              <CardContent className="py-4">
                <div className="flex items-start justify-between gap-4">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <div className="size-10 rounded-md bg-secondary/30 flex items-center justify-center border border-border text-sm font-bold">
                        {review.profiles?.full_name?.charAt(0) || 'C'}
                      </div>
                      <div>
                        <div className="font-medium">{review.profiles?.full_name || 'Cliente Anônimo'}</div>
                        <div className="flex items-center gap-2 text-sm text-muted-foreground">
                          <Clock className="size-4" />
                          {new Date(review.created_at).toLocaleDateString('pt-BR', {
                            day: '2-digit',
                            month: '2-digit',
                            year: 'numeric',
                            hour: '2-digit',
                            minute: '2-digit'
                          })}
                        </div>
                      </div>
                    </div>
                    
                    <div className="flex items-center gap-3 mb-3">
                      <div className="flex items-center gap-1">
                        <Star className="size-4 text-primary fill-primary" />
                        <span className="font-medium">{review.establishment_rating}</span>
                        <span className="text-sm text-muted-foreground">Estabelecimento</span>
                      </div>
                      
                      {review.professional_rating && (
                        <div className="flex items-center gap-1">
                          <Star className="size-4 text-primary fill-primary" />
                          <span className="font-medium">{review.professional_rating}</span>
                          <span className="text-sm text-muted-foreground">Profissional</span>
                        </div>
                      )}
                    </div>

                    {review.comment && (
                      <p className="text-sm text-muted-foreground bg-secondary/20 p-3 rounded-md">
                        "{review.comment}"
                      </p>
                    )}
                  </div>
                  
                  <div className="flex flex-col items-end gap-2">
                    <Badge variant="secondary" className="text-xs">
                      ID: {review.id.slice(0, 8)}
                    </Badge>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </main>
  );
};

export default AdminReviews;
