import { useEffect, useState } from "react";
import Seo from "@/components/Seo";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { establishmentsAdapter } from "@/services/adapters";
import { toast } from "@/hooks/use-toast";
import { Switch } from "@/components/ui/switch";
import { useCurrentEstablishmentId } from "@/hooks/useCurrentEstablishmentId";
import { supabase } from "@/integrations/supabase/client";
import { updateEstablishment } from "@/services/supabaseDataSync";
import { useEstablishmentSchedule } from "@/hooks/useEstablishmentSchedule";
import { Clock } from "lucide-react";


const AdminSettings = () => {
  const { establishmentId: estId } = useCurrentEstablishmentId();
  const { workingHours } = useEstablishmentSchedule(estId || "");
  
  const [est, setEst] = useState<any>(null);
  const [instagram, setInstagram] = useState("");
  const [facebook, setFacebook] = useState("");
  const [tiktok, setTiktok] = useState("");
  const [website, setWebsite] = useState("");
  const [whatsapp, setWhatsapp] = useState("");
  const [gallery, setGallery] = useState<string[]>([]);
  const [coverUrl, setCoverUrl] = useState<string>("");
  const [logoUrl, setLogoUrl] = useState<string>("");
  const [addrStreet, setAddrStreet] = useState("");
  const [addrNumber, setAddrNumber] = useState("");
  const [addrNeighborhood, setAddrNeighborhood] = useState("");
  const [addrCity, setAddrCity] = useState("");
  const [addrState, setAddrState] = useState("");
  const [addrZip, setAddrZip] = useState("");
  
  useEffect(() => {
    async function loadEstablishment() {
      if (!estId) return;
      try {
        const establishment = await establishmentsAdapter.getById(estId);
        if (establishment) {
          setEst(establishment);
          // Note: Using any type to avoid strict typing issues during migration
          const est = establishment as any;
          
          // Load social media data from Supabase description field (temporary)
          let socialData: any = {};
          let addressData: any = {};
          if (est.description) {
            try {
              const metaInfo = JSON.parse(est.description);
              socialData = metaInfo.social || {};
              addressData = metaInfo.address || {};
            } catch {
              // If not JSON, ignore
            }
          }
          
          setInstagram(socialData.instagram ?? "");
          setFacebook(socialData.facebook ?? "");
          setTiktok(socialData.tiktok ?? "");
          setWebsite(est.website ?? "");
          setWhatsapp(est.phone ?? "");
          setCoverUrl(est.coverUrl ?? "");
          setLogoUrl(est.logoUrl ?? "");
          setAddrStreet(addressData.street ?? "");
          setAddrNumber(addressData.number ?? "");
          setAddrNeighborhood(addressData.neighborhood ?? "");
          setAddrCity(addressData.city ?? est.city ?? "");
          setAddrState(addressData.state ?? est.state ?? "");
          setAddrZip(addressData.zip ?? "");

          // Load gallery from establishment_photos
          const { data: photos } = await supabase
            .from('establishment_photos')
            .select('url')
            .eq('establishment_id', estId)
            .order('sort_order');
          setGallery(photos?.map(p => p.url) || []);

        }
      } catch (error) {
        console.error('Error loading establishment:', error);
      }
    }
    loadEstablishment();
  }, [estId]);

  const onFilesChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files ?? []);
    if (!files.length || !estId) return;
    try {
      const { uploadEstablishmentPhoto } = await import("@/services/imageUpload");
      const uploadPromises = files.map(file => uploadEstablishmentPhoto(estId, file));
      const photoUrls = await Promise.all(uploadPromises);
      setGallery([...gallery, ...photoUrls]);
      toast({ title: "Fotos adicionadas", description: `${files.length} foto(s) enviada(s) com sucesso!` });
    } catch (error) {
      console.error('Error uploading gallery:', error);
      toast({ title: "Erro no upload", description: "Falha ao enviar fotos da galeria" });
    }
  };

  const onCoverChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !estId) return;
    try {
      const { uploadEstablishmentCover } = await import("@/services/imageUpload");
      const coverUrl = await uploadEstablishmentCover(estId, file);
      setCoverUrl(coverUrl);
      toast({ title: "Capa atualizada", description: "Foto de capa enviada com sucesso!" });
    } catch (error) {
      console.error('Error uploading cover:', error);
      toast({ title: "Erro no upload", description: "Falha ao enviar foto de capa" });
    }
  };

  const onLogoChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !estId) return;
    try {
      const { uploadEstablishmentLogo } = await import("@/services/imageUpload");
      const logoUrl = await uploadEstablishmentLogo(estId, file);
      setLogoUrl(logoUrl);
      toast({ title: "Logo atualizado", description: "Logo enviado com sucesso!" });
    } catch (error) {
      console.error('Error uploading logo:', error);
      toast({ title: "Erro no upload", description: "Falha ao enviar logo" });
    }
  };

  const removeImage = (idx: number) => setGallery((g) => g.filter((_, i) => i !== idx));

  const onSaveBasic = async () => {
    if (!estId || !est) return;
    try {
      await updateEstablishment(estId, {
        website: website || null,
        phone: whatsapp || null,
        logo_url: logoUrl || null,
        cover_image_url: coverUrl || null,
        // Store social media and address in establishment fields
        // Note: Using phone field for whatsapp as it's available in schema
      } as any);

      // Store social media in a separate JSON field if available, or use description
      const socialData = { instagram, facebook, tiktok };
      const addressData = { 
        street: addrStreet, 
        number: addrNumber, 
        neighborhood: addrNeighborhood, 
        city: addrCity, 
        state: addrState, 
        zip: addrZip 
      };
      
      // Update description to include social and address info for now
      const metaInfo = JSON.stringify({ social: socialData, address: addressData });
      await supabase
        .from('establishments')
        .update({ description: metaInfo })
        .eq('id', estId);

      // Reset photos and insert current ones with sort_order
      await supabase.from("establishment_photos").delete().eq("establishment_id", estId);
      const rows = gallery.map((url, i) => ({ establishment_id: estId, url, sort_order: i }));
      if (rows.length) await supabase.from("establishment_photos").insert(rows);

      toast({ title: "Configurações salvas", description: "Perfil, redes sociais e imagens atualizados." });
    } catch (error: any) {
      toast({ title: "Erro ao salvar", description: error.message });
    }
  };


  if (!est) return <div className="container py-8">Carregando...</div>;

  return (
    <main className="container py-8">
      <Seo title="LookPro — Admin | Configurações" description="Configurações do perfil do estabelecimento" canonicalPath="/dashboard/admin/configuracoes" />
      <h1 className="text-2xl font-extrabold mb-6">Configurações do Estabelecimento</h1>

      <Card className="mb-6">
        <CardHeader>
          <CardTitle>Mídia & Redes sociais</CardTitle>
        </CardHeader>
        <CardContent className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-3">
            <Label>Instagram</Label>
            <Input placeholder="https://instagram.com/sua-pagina" value={instagram} onChange={(e) => setInstagram(e.target.value)} />
            <Label>Facebook</Label>
            <Input placeholder="https://facebook.com/sua-pagina" value={facebook} onChange={(e) => setFacebook(e.target.value)} />
            <Label>TikTok</Label>
            <Input placeholder="https://tiktok.com/@sua-pagina" value={tiktok} onChange={(e) => setTiktok(e.target.value)} />
            <Label>Website</Label>
            <Input placeholder="https://www.seusite.com" value={website} onChange={(e) => setWebsite(e.target.value)} />
            <Label>WhatsApp (principal do estabelecimento)</Label>
            <Input placeholder="5511999999999" value={whatsapp} onChange={(e) => setWhatsapp(e.target.value)} />
          </div>
          <div className="space-y-3">
            <Label>Logo</Label>
            <div className="flex items-center gap-3">
              <div className="size-16 rounded-md border overflow-hidden bg-secondary/30 flex items-center justify-center">
                {logoUrl ? (
                  <img src={logoUrl} alt="Logo do estabelecimento" className="w-full h-full object-cover" />
                ) : (
                  <span className="text-sm text-muted-foreground">Prévia</span>
                )}
              </div>
              <Input type="file" accept="image/*" capture="environment" onChange={onLogoChange} />
            </div>

            <Label>Foto de capa</Label>
            <div className="space-y-2">
              {coverUrl && (
                <img src={coverUrl} alt="Capa do estabelecimento" className="w-full h-28 object-cover rounded-md border" />
              )}
              <Input type="file" accept="image/*" capture="environment" onChange={onCoverChange} />
            </div>

            <Label>Galeria de fotos</Label>
            <Input type="file" accept="image/*" capture="environment" multiple onChange={onFilesChange} />
            {gallery.length > 0 && (
              <div className="grid grid-cols-3 gap-3">
                {gallery.map((src, i) => (
                  <div key={i} className="relative group">
                    <img src={src} alt={`Foto ${i + 1}`} className="rounded-md border object-cover w-full h-24" />
                    <button type="button" onClick={() => removeImage(i)} className="absolute top-1 right-1 text-xs px-2 py-1 rounded bg-destructive text-destructive-foreground opacity-0 group-hover:opacity-100 transition-opacity">Remover</button>
                  </div>
                ))}
              </div>
            )}
          </div>
          <div className="md:col-span-2 flex justify-end gap-2">
            <Button variant="soft" onClick={() => window.history.back()}>Cancelar</Button>
            <Button variant="hero" onClick={onSaveBasic}>Salvar</Button>
          </div>
        </CardContent>
      </Card>

      <Card className="mb-6">
        <CardHeader>
          <div className="flex items-center gap-3">
            <Clock className="size-5 text-primary" />
            <CardTitle>Horários de funcionamento</CardTitle>
          </div>
        </CardHeader>
        <CardContent>
          {workingHours && Object.keys(workingHours).length > 0 ? (
            <div className="space-y-3">
              {Object.entries(workingHours).map(([dayOfWeek, hours]) => {
                const dayNames = {
                  '0': 'Domingo',
                  '1': 'Segunda-feira', 
                  '2': 'Terça-feira',
                  '3': 'Quarta-feira',
                  '4': 'Quinta-feira',
                  '5': 'Sexta-feira',
                  '6': 'Sábado'
                };
                
                return (
                  <div key={dayOfWeek} className="flex items-center justify-between p-3 border rounded-lg">
                    <span className="font-medium">{dayNames[dayOfWeek as keyof typeof dayNames]}</span>
                    <span className="text-sm text-muted-foreground">
                      {(hours as any).closed ? 'Fechado' : `${(hours as any).start} - ${(hours as any).end}`}
                    </span>
                  </div>
                );
              })}
              <div className="flex justify-end">
                <Button variant="outline" onClick={() => window.open('/dashboard/admin/horarios', '_blank')}>
                  Editar horários
                </Button>
              </div>
            </div>
          ) : (
            <div className="text-center py-6">
              <p className="text-muted-foreground mb-4">Nenhum horário configurado</p>
              <Button variant="hero" onClick={() => window.open('/dashboard/admin/horarios', '_blank')}>
                Configurar horários
              </Button>
            </div>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Perfil (básico)</CardTitle>
        </CardHeader>
        <CardContent className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label>Nome</Label>
            <Input placeholder="Nome da empresa" defaultValue={est.name} disabled />
          </div>
          <div className="space-y-2">
            <Label>Cidade</Label>
            <Input placeholder="Cidade" defaultValue={est.cityName} disabled />
          </div>
          <div className="md:col-span-2 grid grid-cols-1 md:grid-cols-3 gap-4 mt-2">
            <div className="space-y-2">
              <Label>Rua</Label>
              <Input placeholder="Ex.: Av. Paulista" value={addrStreet} onChange={(e) => setAddrStreet(e.target.value)} />
            </div>
            <div className="space-y-2">
              <Label>Número</Label>
              <Input placeholder="Ex.: 1000" value={addrNumber} onChange={(e) => setAddrNumber(e.target.value)} />
            </div>
            <div className="space-y-2">
              <Label>Bairro</Label>
              <Input placeholder="Ex.: Bela Vista" value={addrNeighborhood} onChange={(e) => setAddrNeighborhood(e.target.value)} />
            </div>
            <div className="space-y-2">
              <Label>Cidade</Label>
              <Input placeholder="Cidade" value={addrCity} onChange={(e) => setAddrCity(e.target.value)} />
            </div>
            <div className="space-y-2">
              <Label>Estado</Label>
              <Input placeholder="UF" value={addrState} onChange={(e) => setAddrState(e.target.value)} />
            </div>
            <div className="space-y-2">
              <Label>CEP</Label>
              <Input placeholder="00000-000" value={addrZip} onChange={(e) => setAddrZip(e.target.value)} />
            </div>
          </div>
          <div className="md:col-span-2 flex justify-end gap-2 mt-4">
            <Button variant="secondary" onClick={onSaveBasic}>Salvar endereço</Button>
          </div>
        </CardContent>
      </Card>
    </main>
  );
};

export default AdminSettings;