import Seo from "@/components/Seo";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { toast } from "@/hooks/use-toast";
import { useEffect, useMemo, useState } from "react";
import { generateTimeSlots } from "@/lib/timeSlots";
import { createAppointment, listAppointmentsByEstablishment, cancelAppointment, editAppointment, updateAppointmentStatus, getEstablishmentMeta } from "@/services/appointments";
import type { Appointment } from "@/types/appointments";
import EditAppointmentDialog from "@/components/admin/EditAppointmentDialog";
import CreateAppointmentDialog from "@/components/admin/CreateAppointmentDialog";
import { professionalsAdapter, type Professional } from "@/services/adapters";
import { useCurrentEstablishmentId } from "@/hooks/useCurrentEstablishmentId";
import { adminAdapter } from "@/services/adminAdapters";
import { useEstablishmentSchedule } from "@/hooks/useEstablishmentSchedule";
import { useProfessionalSchedule } from "@/hooks/useProfessionalSchedule";
import { Calendar, Clock, User, Phone, Edit, Trash2, Plus } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/context/AuthContext";

const AdminAppointments = () => {
  const { user } = useAuth();
  const { establishmentId: estId } = useCurrentEstablishmentId();
  const { workingHours } = useEstablishmentSchedule(estId!);
  
  // Main state
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [loading, setLoading] = useState(true);
  const [editingAppointment, setEditingAppointment] = useState<Appointment | null>(null);
  const [editDialogOpen, setEditDialogOpen] = useState(false);
  const [createDialogOpen, setCreateDialogOpen] = useState(false);
  
  // Form state
  const [professionalId, setProfessionalId] = useState<string>("");
  const [serviceId, setServiceId] = useState<string>("");
  const [date, setDate] = useState<string>(() => new Date().toISOString().slice(0, 10));
  const [time, setTime] = useState<string>("");
  const [clientName, setClientName] = useState<string>("");
  const [clientPhone, setClientPhone] = useState<string>("");
  const [notes, setNotes] = useState<string>("");

  // Legacy state (keeping for compatibility)
  const [est, setEst] = useState<any>(null);
  const [professionals, setProfessionals] = useState<Professional[]>([]);
  const [services, setServices] = useState<any[]>([]);
  const [stats, setStats] = useState({ total: 0, hoje: 0, pendentes: 0, confirmados: 0 });
  const [dialogOpen, setDialogOpen] = useState<boolean>(false);

  // Professional schedule for selected professional
  const { getScheduleForDate } = useProfessionalSchedule(professionalId);

  // Carregar dados do estabelecimento
  useEffect(() => {
    if (estId) {
      setLoading(true);
      Promise.all([
        getEstablishmentMeta(estId).then(establishment => setEst(establishment)),
        professionalsAdapter.listByEstablishment(estId).then(setProfessionals),
        adminAdapter.listServices(estId).then(setServices)
      ]).finally(() => setLoading(false));
    }
  }, [estId]);

  // Calcular estatísticas
  useEffect(() => {
    if (appointments.length > 0) {
      const hoje = new Date().toISOString().slice(0, 10);
      const hojeCounts = appointments.filter(a => a.date === hoje);
      
      setStats({
        total: appointments.length,
        hoje: hojeCounts.length,
        pendentes: appointments.filter(a => a.status === 'pendente').length,
        confirmados: appointments.filter(a => a.status === 'confirmado').length
      });
    }
  }, [appointments]);

  async function refresh() {
    if (estId) {
      console.log('Refreshing appointments for establishment:', estId, 'date:', date);
      const data = await listAppointmentsByEstablishment(estId, { date });
      console.log('Received appointments data:', data);
      setAppointments(data);
    }
  }

  useEffect(() => {
    refresh();
  }, [date, estId]);

  const service = useMemo(() => {
    return services.find(s => s.id === serviceId);
  }, [services, serviceId]);

  const professional = useMemo(() => {
    return professionals.find(p => p.id === professionalId);
  }, [professionals, professionalId]);

  const busy = useMemo(() => appointments.filter((a) => a.professionalId === professionalId).map((a) => a.time), [appointments, professionalId]);
  const slots = useMemo(() => {
    if (!service || !date || !professionalId) return [];
    
    try {
      const dateObj = new Date(date + 'T12:00:00'); // Ensure valid date with noon time
      const schedule = getScheduleForDate(dateObj);
      
      // Filter slots by service duration (assuming 30min slots, filter by service duration)
      const serviceDuration = service.duration || 30;
      const availableSlots = schedule.slots.filter(slot => slot.available);
      
      // Group slots by service duration
      const groupedSlots = [];
      for (let i = 0; i < availableSlots.length; i += Math.ceil(serviceDuration / 30)) {
        const slot = availableSlots[i];
        if (slot) {
          groupedSlots.push({
            time: slot.time,
            available: slot.available
          });
        }
      }
      
      return groupedSlots;
    } catch (error) {
      console.error('Error generating slots:', error);
      return [];
    }
  }, [service, date, professionalId, getScheduleForDate]);

  async function handleCreate() {
    try {
      if (!time || !clientName || !service || !professionalId) {
        return toast({ title: "Preencha todos os campos obrigatórios" });
      }
      
      // Validate slot availability before creating appointment
      if (!slots.find(s => s.time === time && s.available)) {
        return toast({ 
          title: "Horário não disponível", 
          description: "Este horário já está ocupado ou bloqueado. Selecione outro horário." 
        });
      }
      
      await createAppointment({
        establishmentId: estId,
        professionalId,
        professionalName: professional?.name || "",
        clientId: clientPhone || `client_${Date.now()}`,
        clientName,
        serviceId: service.id,
        serviceName: service.name,
        date,
        time,
        status: "confirmado",
        notes,
        price: service.price,
        duration: service.duration,
        reschedules: 0,
        createdAt: "",
        updatedAt: "",
      } as any);
      
      toast({ 
        title: "Agendamento criado", 
        description: `${clientName} • ${service.name} • ${time}` 
      });
      
      // Clear form
      setClientName("");
      setClientPhone("");
      setProfessionalId("");
      setServiceId("");
      setTime("");
      setNotes("");
      
      await refresh();
    } catch (e: any) {
      toast({ 
        title: "Erro ao criar agendamento", 
        description: e.message || "Tente novamente" 
      });
    }
  }

  return (
    <main className="w-full min-w-0 px-2 sm:px-4 py-4 sm:py-8 overflow-x-hidden">
      <Seo title="LookPro — Admin | Agendamentos" description="Agenda completa do estabelecimento" canonicalPath="/dashboard/admin/agendamentos" />
      <header className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-extrabold">Agendamentos</h1>
        <a href="/dashboard/admin"><Button variant="soft">Voltar ao painel</Button></a>
      </header>

      {/* Estatísticas e Info do Estabelecimento */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-2 sm:gap-4 mb-4 sm:mb-6">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Total de Agendamentos</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.total}</div>
            <p className="text-xs text-muted-foreground">No período selecionado</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Hoje</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.hoje}</div>
            <p className="text-xs text-muted-foreground">Agendamentos de hoje</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Pendentes</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-yellow-600">{stats.pendentes}</div>
            <p className="text-xs text-muted-foreground">Aguardando confirmação</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Confirmados</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{stats.confirmados}</div>
            <p className="text-xs text-muted-foreground">Prontos para atendimento</p>
          </CardContent>
        </Card>
      </div>

      {/* Info do Estabelecimento */}
      {est && (
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="flex items-center gap-3">
              {est.logoUrl && (
                <img src={est.logoUrl} alt={est.name} className="w-8 h-8 rounded-full" />
              )}
              {est.name || 'Estabelecimento'}
            </CardTitle>
          </CardHeader>
          <CardContent className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <div className="text-sm font-medium text-muted-foreground">Endereço</div>
              <div className="text-sm">{est.address || 'Não informado'}</div>
            </div>
            <div>
              <div className="text-sm font-medium text-muted-foreground">Profissionais</div>
              <div className="text-sm">{professionals.length} cadastrados</div>
            </div>
            <div>
              <div className="text-sm font-medium text-muted-foreground">Serviços</div>
              <div className="text-sm">{services.length} disponíveis</div>
            </div>
          </CardContent>
        </Card>
      )}

        {/* Botão para novo agendamento */}
        <div className="mb-6 flex justify-between items-center">
          <h2 className="text-lg font-semibold">Gerenciar Agendamentos</h2>
          <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
            <DialogTrigger asChild>
              <Button variant="hero">Novo agendamento</Button>
            </DialogTrigger>
            <DialogContent className="w-[calc(100vw-1rem)] max-w-[95vw] sm:max-w-[560px] max-h-[calc(100svh-env(safe-area-inset-top)-env(safe-area-inset-bottom)-2rem)] overflow-y-auto p-4 sm:p-6" aria-describedby={undefined}>
              <DialogHeader>
                <DialogTitle>Novo agendamento</DialogTitle>
              </DialogHeader>
              <div className="grid gap-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <label className="text-sm">Profissional</label>
                      <Select value={professionalId} onValueChange={setProfessionalId}>
                        <SelectTrigger><SelectValue placeholder="Selecione um profissional" /></SelectTrigger>
                        <SelectContent>
                          {professionals.map((prof) => (
                            <SelectItem key={prof.id} value={prof.id}>{prof.name}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <label className="text-sm">Serviço</label>
                      <Select value={serviceId} onValueChange={setServiceId}>
                        <SelectTrigger><SelectValue placeholder="Selecione um serviço" /></SelectTrigger>
                        <SelectContent>
                          {services.map((service) => (
                            <SelectItem key={service.id} value={service.id}>
                              {service.name} - R$ {service.price?.toFixed(2)} ({service.duration}min)
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <label className="text-sm">Data</label>
                      <Input type="date" value={date} onChange={(e) => setDate(e.target.value)} />
                    </div>
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-sm">Horário</label>
                  <div className="grid grid-cols-3 sm:grid-cols-4 gap-2">
                    {slots.map((s) => (
                      <button
                        key={s.time}
                        onClick={() => s.available && setTime(s.time)}
                        className={
                          `h-10 rounded-md border text-sm transition-colors ${
                            s.available 
                              ? (time === s.time 
                                  ? 'bg-primary text-primary-foreground border-transparent' 
                                  : 'bg-background hover:bg-accent hover:text-accent-foreground')
                              : 'opacity-50 cursor-not-allowed bg-muted text-muted-foreground'
                          }`
                        }
                      >
                        {s.time}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="text-sm">Nome do cliente</label>
                    <Input placeholder="Ex: Ana Silva" value={clientName} onChange={(e) => setClientName(e.target.value)} />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm">Telefone (WhatsApp)</label>
                    <Input placeholder="(11) 99999-0000" value={clientPhone} onChange={(e) => setClientPhone(e.target.value)} />
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-sm">Observações</label>
                  <Input placeholder="Observações sobre o agendamento" value={notes} onChange={(e) => setNotes(e.target.value)} />
                </div>

                {service && (
                  <div className="bg-muted/50 p-3 rounded-md text-sm">
                    Total: R$ {service.price?.toFixed(2)} • Duração: {service.duration}min
                  </div>
                )}

                <div className="flex justify-end gap-3 pt-2">
                  <Button variant="soft" onClick={() => {
                    setClientName("");
                    setClientPhone("");
                    setProfessionalId("");
                    setServiceId("");
                    setTime("");
                    setNotes("");
                  }}>Limpar</Button>
                  <Button variant="hero" onClick={async () => {
                    await handleCreate();
                    setDialogOpen(false);
                  }} disabled={!time || !clientName || !service || !professionalId}>
                    Criar agendamento
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        </div>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle>Agendamentos {date ? `do dia ${new Date(date + 'T12:00:00').toLocaleDateString('pt-BR')}` : ''}</CardTitle>
          <div className="flex gap-2">
            <Button 
              variant="outline" 
              size="sm"
              onClick={() => setDate(new Date().toISOString().slice(0, 10))}
            >
              Hoje
            </Button>
            <Button 
              variant="outline" 
              size="sm"
              onClick={async () => {
                if (estId) {
                  const allData = await listAppointmentsByEstablishment(estId);
                  setAppointments(allData);
                  setDate(''); // Clear date filter
                }
              }}
            >
              Ver todos
            </Button>
            <Button 
              variant="outline" 
              size="sm"
              onClick={() => refresh()}
            >
              Atualizar
            </Button>
          </div>
        </CardHeader>
        <CardContent className="overflow-x-auto">
          <div className="min-w-[800px]">
            <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Cliente</TableHead>
                <TableHead>Contato</TableHead>
                <TableHead>Serviço</TableHead>
                <TableHead>Valor</TableHead>
                <TableHead>Data/Hora</TableHead>
                <TableHead>Profissional</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-right">Ações</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {appointments.length === 0 && (
                <TableRow>
                  <TableCell colSpan={8} className="text-center py-8 text-muted-foreground">
                    {date ? `Sem agendamentos para ${new Date(date + 'T12:00:00').toLocaleDateString('pt-BR')}` : 'Nenhum agendamento encontrado'}
                  </TableCell>
                </TableRow>
              )}
              {appointments.map((a) => (
                <TableRow key={a.id}>
                  <TableCell className="font-medium">
                    <div>{a.clientName}</div>
                    {a.notes && <div className="text-xs text-muted-foreground">{a.notes}</div>}
                  </TableCell>
                  <TableCell>
                    <div className="text-sm">
                      {a.clientId?.startsWith('phone') ? a.clientId.replace('phone_', '') : 
                       a.clientId?.startsWith('client') ? 'Tel. não informado' : 
                       a.clientId || 'N/A'}
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="font-medium">{a.serviceName}</div>
                    <div className="text-xs text-muted-foreground">{a.duration}min</div>
                  </TableCell>
                  <TableCell className="font-medium">
                    R$ {a.price ? a.price.toFixed(2).replace('.', ',') : '0,00'}
                  </TableCell>
                  <TableCell>
                    <div>{new Date(a.date + 'T12:00:00').toLocaleDateString('pt-BR')}</div>
                    <div className="text-sm font-medium">{a.time}</div>
                  </TableCell>
                  <TableCell>{a.professionalName}</TableCell>
                  <TableCell>
                    <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                      a.status === 'confirmado' ? 'bg-green-100 text-green-800' :
                      a.status === 'pendente' ? 'bg-yellow-100 text-yellow-800' :
                      a.status === 'concluído' ? 'bg-blue-100 text-blue-800' :
                      'bg-red-100 text-red-800'
                    }`}>
                      {a.status}
                    </span>
                  </TableCell>
                  <TableCell className="text-right">
                    <div className="flex gap-1 justify-end">
                      {a.status === 'pendente' && (
                        <Button 
                          size="sm" 
                          variant="outline"
                          onClick={async () => {
                            try {
                              await updateAppointmentStatus(a.id, 'confirmado');
                              toast({ title: "Agendamento confirmado" });
                              await refresh();
                            } catch (e: any) {
                              toast({ title: "Erro", description: e.message });
                            }
                          }}
                        >
                          Confirmar
                        </Button>
                      )}
                      {(a.status === 'confirmado' || a.status === 'pendente') && (
                        <Button 
                          size="sm" 
                          variant="outline"
                          onClick={async () => {
                            try {
                              await updateAppointmentStatus(a.id, 'concluído');
                              toast({ title: "Agendamento concluído" });
                              await refresh();
                            } catch (e: any) {
                              toast({ title: "Erro", description: e.message });
                            }
                          }}
                        >
                          Concluir
                        </Button>
                      )}
                      <Button size="sm" variant="outline" onClick={() => setEditingAppointment(a)}>
                        Editar
                      </Button>
                      {a.status !== 'cancelado' && a.status !== 'concluído' && (
                        <Button 
                          size="sm" 
                          variant="destructive" 
                          onClick={async () => {
                            if (confirm(`Cancelar agendamento de ${a.clientName}?`)) {
                              try {
                                await cancelAppointment(a.id);
                                toast({ 
                                  title: "Agendamento cancelado", 
                                  description: `${a.clientName} • ${a.time}` 
                                });
                                await refresh();
                              } catch (e: any) {
                                toast({ title: "Erro ao cancelar", description: e.message });
                              }
                            }
                          }}
                        >
                          Cancelar
                        </Button>
                      )}
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {editingAppointment && (
        <EditAppointmentDialog
          appointment={editingAppointment}
          open={!!editingAppointment}
          onOpenChange={(v) => !v && setEditingAppointment(null)}
          onSave={async (changes) => {
            try {
              await editAppointment(editingAppointment.id, changes);
              toast({ title: "Agendamento atualizado", description: `${editingAppointment.clientName}` });
              await refresh();
            } catch (e: any) {
              toast({ title: "Erro ao atualizar", description: e.message });
            }
          }}
        />
      )}
    </main>
  );
};

export default AdminAppointments;
