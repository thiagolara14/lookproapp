import { useEffect, useState } from "react";
import Seo from "@/components/Seo";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Link, useNavigate, useParams } from "react-router-dom";
import { toast } from "@/hooks/use-toast";
import { Textarea } from "@/components/ui/textarea";
import { useCurrentEstablishmentId } from "@/hooks/useCurrentEstablishmentId";
import { adminAdapter } from "@/services/adminAdapters";

const AdminServiceForm = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const isEdit = Boolean(id);
  const { establishmentId: estId } = useCurrentEstablishmentId();

  const [name, setName] = useState<string>("");
  const [durationMin, setDurationMin] = useState<number>(30);
  const [priceBRL, setPriceBRL] = useState<string>("");
  const [description, setDescription] = useState<string>("");
  const [imageUrl, setImageUrl] = useState<string>("");

  useEffect(() => {
    const loadService = async () => {
      if (isEdit && id) {
        try {
          // Get service from admin services list for this establishment
          const services = await adminAdapter.listServices(estId);
          const svc = services.find(s => s.id === id);
          if (svc) {
            setName(svc.name);
            setDurationMin(svc.duration);
            setPriceBRL(String(Number(svc.price) || 0));
            setDescription(svc.description || "");
            setImageUrl(svc.imageUrl || "");
          }
        } catch (error) {
          console.error('Error loading service:', error);
        }
      }
    };
    loadService();
  }, [id, isEdit, estId]);

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const { uploadServicePhoto } = await import("@/services/imageUpload");
      const serviceId = id || crypto.randomUUID();
      const imageUrl = await uploadServicePhoto(serviceId, file);
      setImageUrl(imageUrl);
      toast({ title: "Imagem atualizada!", description: "Imagem do serviço enviada com sucesso!" });
    } catch (error) {
      toast({ title: "Erro no upload", description: "Falha ao enviar imagem", variant: "destructive" });
    }
  };

  const onSave = async () => {
    if (!name || !durationMin) return toast({ title: "Preencha os campos obrigatórios" });
    
    try {
      const serviceData = {
        name,
        duration: Number(durationMin),
        price: Number(priceBRL || 0),
        establishmentId: estId,
        description,
        image: imageUrl,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };

      if (isEdit && id) {
        await adminAdapter.updateService(id, serviceData);
      } else {
        await adminAdapter.createService(serviceData);
      }
      
      toast({ title: isEdit ? "Serviço atualizado" : "Serviço criado" });
      navigate("/dashboard/admin/servicos");
    } catch (error) {
      toast({ title: "Erro ao salvar serviço", variant: "destructive" });
    }
  };

  return (
    <main className="container py-8">
      <Seo title={`LookPro — Admin | ${isEdit ? "Editar serviço" : "Novo serviço"}`} description="Cadastro e edição de serviços" canonicalPath={isEdit ? `/dashboard/admin/servicos/${id}/editar` : "/dashboard/admin/servicos/novo"} />
      <header className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-extrabold">{isEdit ? "Editar serviço" : "Novo serviço"}</h1>
        <div className="flex gap-2">
          <Link to="/dashboard/admin/servicos"><Button variant="soft">Voltar</Button></Link>
        </div>
      </header>
      <Card>
        <CardHeader>
          <CardTitle>Dados do serviço</CardTitle>
        </CardHeader>
        <CardContent className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label>Nome</Label>
            <Input placeholder="Ex.: Corte clássico" value={name} onChange={(e) => setName(e.target.value)} />
          </div>
          <div className="space-y-2">
            <Label>Duração (min)</Label>
            <Input type="number" value={durationMin} onChange={(e) => setDurationMin(Number(e.target.value))} />
          </div>
          <div className="space-y-2">
            <Label>Preço (R$)</Label>
            <Input type="number" step="0.01" value={priceBRL} onChange={(e) => setPriceBRL(e.target.value)} />
          </div>
          <div className="space-y-2">
            <Label>Imagem</Label>
            <Input type="file" accept="image/*" onChange={handleImageUpload} />
            {imageUrl && (
              <img src={imageUrl} alt="Preview" className="w-32 h-24 object-cover rounded border" />
            )}
          </div>
          <div className="space-y-2 md:col-span-2">
            <Label>Descrição</Label>
            <Textarea 
              placeholder="Descreva o serviço..." 
              value={description} 
              onChange={(e) => setDescription(e.target.value)} 
            />
          </div>
          <div className="md:col-span-2 flex justify-end gap-2">
            <Button variant="soft" onClick={() => navigate("/dashboard/admin/servicos")}>Cancelar</Button>
            <Button variant="hero" onClick={onSave}>Salvar</Button>
          </div>
        </CardContent>
      </Card>
    </main>
  );
};

export default AdminServiceForm;

