import Seo from "@/components/Seo";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { useCurrentEstablishmentId } from "@/hooks/useCurrentEstablishmentId";
import { listAppointmentsByEstablishment } from "@/services/appointments";
import { useEffect, useState } from "react";
import type { Appointment } from "@/types/appointments";
import { supabase } from "@/integrations/supabase/client";

type ClientData = {
  name: string;
  phone: string;
  totalAppointments: number;
  totalSpent: number;
  lastVisit: string;
  status: 'Ativo' | 'Inativo';
  appointments: Appointment[];
};

const AdminClients = () => {
  const { establishmentId } = useCurrentEstablishmentId();
  const [clients, setClients] = useState<ClientData[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function loadClients() {
      if (!establishmentId) return;
      
      try {
        console.log('Loading clients for establishment:', establishmentId);
        
        // Buscar todos os agendamentos do estabelecimento especificamente
        const appointments = await listAppointmentsByEstablishment(establishmentId);
        console.log('Appointments loaded:', appointments);
        
        if (appointments.length === 0) {
          setClients([]);
          setLoading(false);
          return;
        }
        
        // Buscar preços reais dos serviços do Supabase
        const serviceIds = [...new Set(appointments.map(a => a.serviceId))];
        const { data: servicesData } = await supabase
          .from('services')
          .select('id, price')
          .in('id', serviceIds);
        
        console.log('Services data:', servicesData);
        
        const servicesMap = new Map(servicesData?.map(s => [s.id, Number(s.price)]) || []);
        
        // Agrupar por cliente (usando telefone como chave única)
        const clientsMap = new Map<string, ClientData>();
        
        appointments.forEach((appointment) => {
          // Usar clientId (que contém o telefone) como identificador único
          const clientKey = appointment.clientId || 'sem-telefone';
          
          if (!clientsMap.has(clientKey)) {
            clientsMap.set(clientKey, {
              name: appointment.clientName || 'Cliente não informado',
              phone: appointment.clientId || 'Não informado',
              totalAppointments: 0,
              totalSpent: 0,
              lastVisit: appointment.date,
              status: 'Ativo',
              appointments: []
            });
          }
          
          const client = clientsMap.get(clientKey)!;
          client.totalAppointments++;
          
          // Calcular valor real baseado no preço do serviço do Supabase
          const servicePrice = Number(servicesMap.get(appointment.serviceId)) || 0;
          client.totalSpent += servicePrice;
          
          client.appointments.push(appointment);
          
          // Atualizar última visita (mais recente)
          if (appointment.date > client.lastVisit) {
            client.lastVisit = appointment.date;
          }
        });
        
        console.log('Clients map after processing:', clientsMap);
        
        // Determinar status baseado na data da última visita
        const clientsArray = Array.from(clientsMap.values()).map(client => {
          const lastVisitDate = new Date(client.lastVisit);
          const daysSinceLastVisit = Math.floor((Date.now() - lastVisitDate.getTime()) / (1000 * 60 * 60 * 24));
          
          const status: 'Ativo' | 'Inativo' = daysSinceLastVisit > 90 ? 'Inativo' : 'Ativo';
          
          return {
            ...client,
            status
          };
        });
        
        // Ordenar por última visita (mais recente primeiro)
        clientsArray.sort((a, b) => new Date(b.lastVisit).getTime() - new Date(a.lastVisit).getTime());
        
        console.log('Final clients array:', clientsArray);
        setClients(clientsArray);
      } catch (error) {
        console.error('Erro ao carregar clientes:', error);
      } finally {
        setLoading(false);
      }
    }

    loadClients();
  }, [establishmentId]);

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(value);
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString + 'T12:00:00').toLocaleDateString('pt-BR');
  };

  return (
    <main className="container py-8">
      <Seo title="LookPro — Admin | Clientes" description="Clientes que já agendaram" canonicalPath="/dashboard/admin/clientes" />
      <h1 className="text-2xl font-extrabold mb-6">Clientes</h1>
      
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
        <Card>
          <CardContent className="p-4">
            <div className="text-2xl font-bold">{clients.length}</div>
            <div className="text-sm text-muted-foreground">Total de clientes</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="text-2xl font-bold">{clients.filter(c => c.status === 'Ativo').length}</div>
            <div className="text-sm text-muted-foreground">Clientes ativos</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="text-2xl font-bold">
              {formatCurrency(clients.reduce((sum, c) => sum + c.totalSpent, 0))}
            </div>
            <div className="text-sm text-muted-foreground">Receita total</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="text-2xl font-bold">
              {clients.length > 0 ? Math.round(clients.reduce((sum, c) => sum + c.totalSpent, 0) / clients.length) : 0}
            </div>
            <div className="text-sm text-muted-foreground">Ticket médio (R$)</div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Lista de clientes</CardTitle>
        </CardHeader>
        <CardContent>
          {loading ? (
            <p className="text-muted-foreground">Carregando clientes...</p>
          ) : clients.length === 0 ? (
            <p className="text-muted-foreground">Nenhum cliente encontrado. Os clientes aparecerão aqui após realizarem agendamentos.</p>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Nome</TableHead>
                  <TableHead>Telefone</TableHead>
                  <TableHead>Agendamentos</TableHead>
                  <TableHead>Total gasto</TableHead>
                  <TableHead>Última visita</TableHead>
                  <TableHead>Status</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {clients.map((client, index) => (
                  <TableRow key={index}>
                    <TableCell className="font-medium">{client.name}</TableCell>
                    <TableCell>{client.phone}</TableCell>
                    <TableCell>{client.totalAppointments}</TableCell>
                    <TableCell>{formatCurrency(client.totalSpent)}</TableCell>
                    <TableCell>{formatDate(client.lastVisit)}</TableCell>
                    <TableCell>
                      <Badge variant={client.status === 'Ativo' ? 'default' : 'secondary'}>
                        {client.status}
                      </Badge>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </main>
  );
};

export default AdminClients;
