import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import { useAuth } from "@/context/AuthContext";
import { sendBroadcastNotification, ensurePushSubscription } from "@/lib/push";
import Seo from "@/components/Seo";
import { Bell, Send, Users } from "lucide-react";

export default function AdminNotifications() {
  const { user } = useAuth();
  const [form, setForm] = useState({
    title: "",
    body: "",
    url: ""
  });
  const [loading, setLoading] = useState(false);

  // Registrar push para admin quando componente carrega
  useState(() => {
    if (user && user.role === "admin" && user.establishmentId) {
      ensurePushSubscription({
        user: { id: user.uid },
        professionalId: null,
        customerId: null, // Admin não é cliente, mas pode receber notificações
        establishmentId: user.establishmentId
      }).catch(console.error);
    }
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!form.title || !form.body) {
      toast.error("Título e mensagem são obrigatórios");
      return;
    }

    if (!user?.establishmentId) {
      toast.error("Estabelecimento não identificado");
      return;
    }

    setLoading(true);
    
    try {
      const result = await sendBroadcastNotification({
        establishmentId: user.establishmentId,
        title: form.title,
        body: form.body,
        url: form.url || undefined
      });

      if (result.success) {
        toast.success("Notificação enviada para todos os clientes!");
        setForm({ title: "", body: "", url: "" });
      } else {
        toast.error(result.error || "Erro ao enviar notificação");
      }
    } catch (error) {
      console.error("Erro ao enviar broadcast:", error);
      toast.error("Erro ao enviar notificação");
    } finally {
      setLoading(false);
    }
  };

  return (
    <main className="container py-8">
      <Seo 
        title="LookPro — Admin | Notificações" 
        description="Envie notificações para todos os clientes do estabelecimento" 
        canonicalPath="/dashboard/admin/notificacoes" 
      />
      
      <header className="flex items-center gap-3 mb-6">
        <Bell className="h-8 w-8 text-primary" />
        <h1 className="text-2xl font-extrabold">Notificações</h1>
      </header>

      <div className="max-w-2xl">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Users className="h-5 w-5" />
              Enviar para todos os clientes
            </CardTitle>
            <p className="text-sm text-muted-foreground">
              Envie uma notificação push para todos os clientes que têm o app instalado e permitiram notificações.
            </p>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <label htmlFor="title" className="text-sm font-medium">
                  Título da notificação *
                </label>
                <Input
                  id="title"
                  value={form.title}
                  onChange={(e) => setForm({ ...form, title: e.target.value })}
                  placeholder="Ex: Promoção especial!"
                  maxLength={50}
                  disabled={loading}
                />
                <p className="text-xs text-muted-foreground">
                  {form.title.length}/50 caracteres
                </p>
              </div>

              <div className="space-y-2">
                <label htmlFor="body" className="text-sm font-medium">
                  Mensagem *
                </label>
                <Textarea
                  id="body"
                  value={form.body}
                  onChange={(e) => setForm({ ...form, body: e.target.value })}
                  placeholder="Ex: Desconto de 20% em todos os serviços até sexta-feira!"
                  rows={3}
                  maxLength={120}
                  disabled={loading}
                />
                <p className="text-xs text-muted-foreground">
                  {form.body.length}/120 caracteres
                </p>
              </div>

              <div className="space-y-2">
                <label htmlFor="url" className="text-sm font-medium">
                  Link (opcional)
                </label>
                <Input
                  id="url"
                  type="url"
                  value={form.url}
                  onChange={(e) => setForm({ ...form, url: e.target.value })}
                  placeholder="Ex: /promocoes ou https://..."
                  disabled={loading}
                />
                <p className="text-xs text-muted-foreground">
                  Link que será aberto quando o cliente tocar na notificação
                </p>
              </div>

              <div className="pt-4">
                <Button
                  type="submit"
                  disabled={loading || !form.title || !form.body}
                  className="w-full sm:w-auto"
                >
                  <Send className="h-4 w-4 mr-2" />
                  {loading ? "Enviando..." : "Enviar notificação"}
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>

        <Card className="mt-6">
          <CardHeader>
            <CardTitle>Dicas importantes</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3 text-sm text-muted-foreground">
            <div className="flex gap-2">
              <span className="text-primary">•</span>
              <span>
                Apenas clientes que instalaram o app como PWA e permitiram notificações receberão a mensagem
              </span>
            </div>
            <div className="flex gap-2">
              <span className="text-primary">•</span>
              <span>
                Use títulos curtos e chamativos para aumentar a taxa de abertura
              </span>
            </div>
            <div className="flex gap-2">
              <span className="text-primary">•</span>
              <span>
                Evite enviar muitas notificações para não incomodar os clientes
              </span>
            </div>
            <div className="flex gap-2">
              <span className="text-primary">•</span>
              <span>
                O link pode direcionar para páginas internas do app ou sites externos
              </span>
            </div>
          </CardContent>
        </Card>
      </div>
    </main>
  );
}