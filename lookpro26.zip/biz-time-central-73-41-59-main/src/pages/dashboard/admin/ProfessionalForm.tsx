import { useEffect, useState, ChangeEvent } from "react";
import Seo from "@/components/Seo";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Link, useNavigate, useParams } from "react-router-dom";
import { readFileAsDataURL } from "@/lib/file";
import { adminAdapter } from "@/services/adminAdapters";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "@/hooks/use-toast";
import { useCurrentEstablishmentId } from "@/hooks/useCurrentEstablishmentId";

const AdminProfessionalForm = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const isEdit = Boolean(id);
  const { establishmentId: estId } = useCurrentEstablishmentId();

  const [name, setName] = useState<string>("");
  const [avatarUrl, setAvatarUrl] = useState<string>("");
  const [email, setEmail] = useState<string>("");

  useEffect(() => {
    const loadProfessional = async () => {
      if (isEdit && id) {
        const professionals = await adminAdapter.listProfessionals(estId);
        const pro = professionals.find(p => p.id === id);
        if (pro) {
          setName(pro.name);
          setAvatarUrl("");
          setEmail(pro.email);
        }
      }
    };
    loadProfessional();
  }, [id, isEdit]);

  const onAvatarFile = async (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    
    try {
      const { uploadProfessionalAvatar } = await import("@/services/imageUpload");
      const professionalId = id || crypto.randomUUID();
      const avatarUrl = await uploadProfessionalAvatar(professionalId, file);
      setAvatarUrl(avatarUrl);
      toast({ title: "Avatar atualizado!", description: "Avatar enviado com sucesso!" });
    } catch (error) {
      console.error('Error uploading avatar:', error);
      toast({ title: "Erro no upload", description: "Falha ao enviar avatar", variant: "destructive" });
    }
  };

  const onSave = async () => {
    if (!name) return toast({ title: "Informe o nome" });
    if (!email) return toast({ title: "Informe o email" });
    
    try {
      if (isEdit && id) {
        await adminAdapter.updateProfessional(id, {
          bio: "",
          specialties: [],
          active: true
        });
      } else {
        // Create user through edge function
        const { data, error } = await supabase.functions.invoke('create-user', {
          body: {
            email,
            password: 'temp123', // Temporary password that should be changed
            full_name: name,
            role: 'professional',
            establishment_id: estId
          }
        });

        if (error) {
          console.error('Error creating user:', error);
          throw new Error('Falha ao criar usuário');
        }

        if (!data.success) {
          throw new Error(data.message || 'Falha ao criar usuário');
        }

        // Create professional record
        await adminAdapter.createProfessional({
          establishmentId: estId,
          userId: data.user_id,
          bio: "",
          specialties: []
        });
      }
      toast({ title: isEdit ? "Profissional atualizado" : "Profissional criado" });
      navigate("/dashboard/admin/profissionais");
    } catch (error: any) {
      console.error('Error saving professional:', error);
      toast({ title: "Erro ao salvar profissional", description: error.message, variant: "destructive" });
    }
  };

  return (
    <main className="container py-8">
      <Seo title={`LookPro — Admin | ${isEdit ? "Editar profissional" : "Novo profissional"}`} description="Cadastro e edição de profissionais" canonicalPath={isEdit ? `/dashboard/admin/profissionais/${id}/editar` : "/dashboard/admin/profissionais/novo"} />
      <header className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-extrabold">{isEdit ? "Editar profissional" : "Novo profissional"}</h1>
        <div className="flex gap-2">
          <Link to="/dashboard/admin/profissionais"><Button variant="soft">Voltar</Button></Link>
        </div>
      </header>
      <Card>
        <CardHeader>
          <CardTitle>Dados do profissional</CardTitle>
        </CardHeader>
        <CardContent className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label>Nome</Label>
            <Input placeholder="Ex.: Rafa" value={name} onChange={(e) => setName(e.target.value)} />
          </div>
          <div className="space-y-2">
            <Label>Email</Label>
            <Input placeholder="professional@example.com" value={email} onChange={(e) => setEmail(e.target.value)} />
          </div>
          <div className="space-y-2">
            <Label>Avatar (URL)</Label>
            <Input placeholder="https://..." value={avatarUrl} onChange={(e) => setAvatarUrl(e.target.value)} />
            <Label>Enviar avatar</Label>
            <Input type="file" accept="image/*" capture="environment" onChange={onAvatarFile} />
          </div>
          <div className="md:col-span-2 flex justify-end gap-2">
            <Button variant="soft" onClick={() => navigate("/dashboard/admin/profissionais")}>Cancelar</Button>
            <Button variant="hero" onClick={onSave}>Salvar</Button>
          </div>
        </CardContent>
      </Card>
    </main>
  );
};


export default AdminProfessionalForm;

