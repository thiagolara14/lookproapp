import { useEffect, useState } from "react";
import { format, subDays, startOfMonth, endOfMonth, eachDayOfInterval } from "date-fns";
import { ptBR } from "date-fns/locale";
import Seo from "@/components/Seo";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart";
import { Bar, BarChart, Line, LineChart, XAxis, YAxis, CartesianGrid, Pie, PieChart, Cell } from "recharts";
import { Calendar, TrendingUp, Users, Clock, DollarSign, Download, BarChart3 } from "lucide-react";
import { useAuth } from "@/context/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "@/hooks/use-toast";
import { 
  getEstablishmentRevenueMetrics, 
  getServiceStatistics, 
  getProfessionalStatistics, 
  getDailyRevenueData, 
  getHourlyDistribution 
} from "@/services/realTimeReports";

interface RevenueData {
  date: string;
  revenue: number;
  appointments: number;
}

interface ServiceData {
  name: string;
  count: number;
  revenue: number;
}

interface ProfessionalData {
  name: string;
  appointments: number;
  revenue: number;
}

interface HourData {
  hour: string;
  count: number;
}

const AdminReports = () => {
  const { user } = useAuth();
  const [loading, setLoading] = useState(true);
  const [monthlyRevenue, setMonthlyRevenue] = useState(0);
  const [totalAppointments, setTotalAppointments] = useState(0);
  const [uniqueClients, setUniqueClients] = useState(0);
  const [avgTicket, setAvgTicket] = useState(0);
  const [revenueChart, setRevenueChart] = useState<RevenueData[]>([]);
  const [servicesChart, setServicesChart] = useState<ServiceData[]>([]);
  const [professionalsChart, setProfessionalsChart] = useState<ProfessionalData[]>([]);
  const [hoursChart, setHoursChart] = useState<HourData[]>([]);

  useEffect(() => {
    if (user?.establishmentId) {
      loadReportsData();
    }
  }, [user?.establishmentId]);

  const loadReportsData = async () => {
    if (!user?.establishmentId) return;

    try {
      setLoading(true);
      const currentMonth = new Date();
      const monthStart = startOfMonth(currentMonth);
      const monthEnd = endOfMonth(currentMonth);
      const last30Days = subDays(new Date(), 30);

      // Use real-time reports service for accurate data
      const [
        monthMetrics,
        serviceStats,
        professionalStats,
        dailyRevenue,
        hourlyStats
      ] = await Promise.all([
        getEstablishmentRevenueMetrics(user.establishmentId, monthStart, monthEnd),
        getServiceStatistics(user.establishmentId, last30Days),
        getProfessionalStatistics(user.establishmentId, last30Days),
        getDailyRevenueData(user.establishmentId, last30Days),
        getHourlyDistribution(user.establishmentId, last30Days)
      ]);

      // Set main metrics
      setMonthlyRevenue(monthMetrics.totalRevenue);
      setTotalAppointments(monthMetrics.totalAppointments);
      setUniqueClients(monthMetrics.uniqueClients);
      setAvgTicket(monthMetrics.averageTicket);

      // Set chart data
      setRevenueChart(dailyRevenue);
      
      setServicesChart(serviceStats.slice(0, 5).map(stat => ({
        name: stat.serviceName,
        count: stat.appointmentCount,
        revenue: stat.revenue
      })));

      setProfessionalsChart(professionalStats.map(stat => ({
        name: stat.professionalName,
        appointments: stat.appointmentCount,
        revenue: stat.revenue
      })));

      setHoursChart(hourlyStats.map(stat => ({
        hour: stat.hour,
        count: stat.appointmentCount
      })));

    } catch (error) {
      console.error('Error loading reports data:', error);
      toast({
        title: "Erro",
        description: "Não foi possível carregar os dados dos relatórios.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const exportData = () => {
    toast({
      title: "Exportação iniciada",
      description: "Seus dados serão exportados em breve.",
    });
  };

  if (loading) {
    return (
      <main className="container py-8">
        <Seo title="LookPro — Admin | Relatórios" description="Relatórios e exportação de dados" canonicalPath="/dashboard/admin/relatorios" />
        <div className="text-center py-8">Carregando relatórios...</div>
      </main>
    );
  }

  const COLORS = ['#8B5CF6', '#06B6D4', '#10B981', '#F59E0B', '#EF4444'];

  return (
    <main className="container py-8">
      <Seo title="LookPro — Admin | Relatórios" description="Relatórios e exportação de dados" canonicalPath="/dashboard/admin/relatorios" />
      
      <header className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between mb-6">
        <div className="flex items-center gap-3">
          <div className="size-10 rounded-md bg-[image:var(--gradient-primary)] flex items-center justify-center">
            <BarChart3 className="size-5 text-white" />
          </div>
          <div>
            <h1 className="text-2xl font-extrabold">Relatórios e Estatísticas</h1>
            <p className="text-sm text-muted-foreground">Análise detalhada do desempenho do seu estabelecimento</p>
          </div>
        </div>
        <Button variant="soft" onClick={exportData} className="gap-2">
          <Download className="size-4" />
          Exportar dados
        </Button>
      </header>

      {/* Métricas principais */}
      <section className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Faturamento (mês)</CardTitle>
            <DollarSign className="size-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-extrabold">
              {monthlyRevenue.toLocaleString("pt-BR", { style: "currency", currency: "BRL" })}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Agendamentos (mês)</CardTitle>
            <Calendar className="size-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-extrabold">{totalAppointments}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Clientes únicos</CardTitle>
            <Users className="size-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-extrabold">{uniqueClients}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Ticket médio</CardTitle>
            <TrendingUp className="size-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-extrabold">
              {avgTicket.toLocaleString("pt-BR", { style: "currency", currency: "BRL" })}
            </div>
          </CardContent>
        </Card>
      </section>

      <Tabs defaultValue="revenue" className="space-y-4">
        <TabsList>
          <TabsTrigger value="revenue">Faturamento</TabsTrigger>
          <TabsTrigger value="services">Serviços</TabsTrigger>
          <TabsTrigger value="professionals">Profissionais</TabsTrigger>
          <TabsTrigger value="hours">Horários</TabsTrigger>
        </TabsList>

        <TabsContent value="revenue">
          <Card>
            <CardHeader>
              <CardTitle>Evolução do faturamento (últimos 30 dias)</CardTitle>
            </CardHeader>
            <CardContent>
              <ChartContainer
                config={{
                  revenue: { label: "Faturamento", color: "hsl(var(--primary))" },
                  appointments: { label: "Agendamentos", color: "hsl(var(--muted-foreground))" }
                }}
                className="h-[300px]"
              >
                <LineChart data={revenueChart} margin={{ left: 12, right: 12 }}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="date" tickLine={false} axisLine={false} />
                  <YAxis width={60} tickLine={false} axisLine={false} />
                  <ChartTooltip content={<ChartTooltipContent />} />
                  <Line 
                    type="monotone" 
                    dataKey="revenue" 
                    stroke="var(--color-revenue)" 
                    strokeWidth={2} 
                    dot={false} 
                  />
                </LineChart>
              </ChartContainer>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="services">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Serviços mais agendados</CardTitle>
              </CardHeader>
              <CardContent>
                <ChartContainer
                  config={{
                    count: { label: "Agendamentos", color: "hsl(var(--primary))" }
                  }}
                  className="h-[300px]"
                >
                  <BarChart data={servicesChart} margin={{ left: 12, right: 12 }}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" tickLine={false} axisLine={false} />
                    <YAxis width={40} tickLine={false} axisLine={false} />
                    <ChartTooltip content={<ChartTooltipContent />} />
                    <Bar dataKey="count" fill="var(--color-count)" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ChartContainer>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Faturamento por serviço</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {servicesChart.map((service, index) => (
                    <div key={service.name} className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <div 
                          className="size-3 rounded-full" 
                          style={{ backgroundColor: COLORS[index % COLORS.length] }}
                        />
                        <span className="font-medium">{service.name}</span>
                      </div>
                      <div className="text-right">
                        <div className="font-semibold">
                          {service.revenue.toLocaleString("pt-BR", { style: "currency", currency: "BRL" })}
                        </div>
                        <div className="text-sm text-muted-foreground">{service.count} agendamentos</div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="professionals">
          <Card>
            <CardHeader>
              <CardTitle>Performance dos profissionais (últimos 30 dias)</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {professionalsChart.map((prof, index) => (
                  <div key={prof.name} className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex items-center gap-3">
                      <div className="size-10 rounded-full bg-muted flex items-center justify-center font-semibold">
                        {prof.name.charAt(0)}
                      </div>
                      <div>
                        <div className="font-medium">{prof.name}</div>
                        <div className="text-sm text-muted-foreground">{prof.appointments} agendamentos</div>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="font-semibold">
                        {prof.revenue.toLocaleString("pt-BR", { style: "currency", currency: "BRL" })}
                      </div>
                      <Badge variant="secondary">
                        {prof.appointments > 0 ? (prof.revenue / prof.appointments).toLocaleString("pt-BR", { 
                          style: "currency", 
                          currency: "BRL" 
                        }) : "R$ 0,00"} / serviço
                      </Badge>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="hours">
          <Card>
            <CardHeader>
              <CardTitle>Horários de pico (últimos 30 dias)</CardTitle>
            </CardHeader>
            <CardContent>
              <ChartContainer
                config={{
                  count: { label: "Agendamentos", color: "hsl(var(--primary))" }
                }}
                className="h-[300px]"
              >
                <BarChart data={hoursChart} margin={{ left: 12, right: 12 }}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="hour" tickLine={false} axisLine={false} />
                  <YAxis width={40} tickLine={false} axisLine={false} />
                  <ChartTooltip content={<ChartTooltipContent />} />
                  <Bar dataKey="count" fill="var(--color-count)" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ChartContainer>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </main>
  );
};

export default AdminReports;
