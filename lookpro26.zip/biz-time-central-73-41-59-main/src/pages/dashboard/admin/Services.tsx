import { useEffect, useState } from "react";
import Seo from "@/components/Seo";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Link } from "react-router-dom";
import { toast } from "@/hooks/use-toast";
import { useCurrentEstablishmentId } from "@/hooks/useCurrentEstablishmentId";
import { adminAdapter } from "@/services/adminAdapters";

const currency = new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" });

const AdminServices = () => {
  const { establishmentId: estId } = useCurrentEstablishmentId();
  const [services, setServices] = useState<any[]>([]);

  const refresh = async () => {
    try {
      const servicesList = await adminAdapter.listServices(estId);
      setServices(servicesList);
    } catch (error) {
      console.error('Error loading services:', error);
      setServices([]);
    }
  };

  useEffect(() => { 
    if (estId) refresh(); 
  }, [estId]);

  const onDelete = async (id: string) => {
    if (!confirm("Excluir serviço?")) return;
    try {
      await adminAdapter.deleteService(id);
      toast({ title: "Serviço excluído" });
      refresh();
    } catch (error: any) {
      toast({ title: "Erro ao excluir", description: error.message });
    }
  };

  return (
    <main className="container py-8">
      <Seo title="LookPro — Admin | Serviços" description="Gestão de serviços do estabelecimento" canonicalPath="/dashboard/admin/servicos" />
      <header className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-extrabold">Serviços</h1>
        <div className="flex gap-2">
          <Link to="/dashboard/admin/servicos/novo"><Button variant="hero">Novo serviço</Button></Link>
          <Link to="/dashboard/admin"><Button variant="soft">Voltar ao painel</Button></Link>
        </div>
      </header>
      <Card>
        <CardHeader>
          <CardTitle>Lista de serviços</CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Nome</TableHead>
                <TableHead>Duração</TableHead>
                <TableHead>Preço</TableHead>
                <TableHead className="text-right">Ações</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {services.length === 0 && (
                <TableRow>
                  <TableCell colSpan={4} className="text-muted-foreground">Nenhum serviço cadastrado.</TableCell>
                </TableRow>
              )}
              {services.map((s) => (
                <TableRow key={s.id}>
                  <TableCell className="font-medium">{s.name}</TableCell>
                  <TableCell>{s.duration || 0} min</TableCell>
                  <TableCell>{currency.format(Number(s.price) || 0)}</TableCell>
                  <TableCell className="text-right space-x-2">
                    <Link to={`/dashboard/admin/servicos/${s.id}/editar`}><Button size="sm" variant="outline">Editar</Button></Link>
                    <Button size="sm" variant="destructive" onClick={() => onDelete(s.id)}>Excluir</Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </main>
  );
};

export default AdminServices;

