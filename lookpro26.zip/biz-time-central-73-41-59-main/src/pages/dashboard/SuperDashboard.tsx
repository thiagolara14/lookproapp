import Dashboard from "@/pages/super/Dashboard";

const SuperDashboard = () => {
  return <Dashboard />;
};

export default SuperDashboard;
