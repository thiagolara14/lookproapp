import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { MessageCircle, CheckCircle, Clock, AlertCircle } from "lucide-react";
import { getLeadStatus } from "@/services/onboardingClient";

interface OnboardingSuccessProps {
  leadId: string;
  onClose: () => void;
}

export function OnboardingSuccess({ leadId, onClose }: OnboardingSuccessProps) {
  const [leadStatus, setLeadStatus] = useState<'novo' | 'em_provisionamento' | 'entregue' | 'erro'>('novo');
  const [tenantData, setTenantData] = useState<{url_publica: string; url_admin: string; login: string} | null>(null);

  useEffect(() => {
    let interval: NodeJS.Timeout;
    
    const checkStatus = async () => {
      try {
        const result = await getLeadStatus(leadId);
        if (result.success) {
          setLeadStatus(result.status);
          if (result.tenant_data) {
            setTenantData(result.tenant_data);
          }
          
          // Stop polling when delivered or error
          if (result.status === 'entregue' || result.status === 'erro') {
            clearInterval(interval);
          }
        }
      } catch (error) {
        console.error('Error checking lead status:', error);
      }
    };

    // Check immediately
    checkStatus();
    
    // Then check every 10 seconds if not delivered or error
    interval = setInterval(checkStatus, 10000);
    
    return () => clearInterval(interval);
  }, [leadId]);

  const handleWhatsAppContact = () => {
    const message = encodeURIComponent(`Olá! Acabei de enviar meu cadastro para criar meu app LookPro. ID: ${leadId}`);
    const whatsappUrl = `https://wa.me/5511999999999?text=${message}`;
    window.open(whatsappUrl, '_blank');
    onClose();
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'entregue':
        return <CheckCircle className="w-8 h-8 text-green-500" />;
      case 'erro':
        return <AlertCircle className="w-8 h-8 text-destructive" />;
      default:
        return <Clock className="w-8 h-8 text-primary animate-pulse" />;
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'novo':
        return 'Dados recebidos';
      case 'em_provisionamento':
        return 'Gerando app...';
      case 'entregue':
        return 'App pronto!';
      case 'erro':
        return 'Erro no processamento';
      default:
        return 'Processando...';
    }
  };

  return (
    <>
      <div className="text-center mb-8">
        <div className="flex justify-center mb-4">
          <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center">
            {getStatusIcon(leadStatus)}
          </div>
        </div>
        <h1 className="text-3xl font-bold tracking-tight mb-4">
          {leadStatus === 'entregue' ? 'Pronto! 🚀' : 'Quase lá! 🚀'}
        </h1>
        <div className="text-lg text-muted-foreground">
          {leadStatus === 'entregue' ? (
            <>
              Seu app LookPro está pronto! Você pode acessá-lo através dos links enviados para seu WhatsApp.
              {tenantData && (
                <div className="mt-4 p-4 bg-muted rounded-lg">
                  <p className="font-semibold mb-2">Seus links de acesso:</p>
                  <div className="space-y-2 text-sm">
                    <div>
                      <span className="font-medium">Link público:</span>
                      <br />
                      <a href={tenantData.url_publica} target="_blank" rel="noopener noreferrer" 
                         className="text-primary hover:underline break-all">
                        {tenantData.url_publica}
                      </a>
                    </div>
                    <div>
                      <span className="font-medium">Painel admin:</span>
                      <br />
                      <a href={tenantData.url_admin} target="_blank" rel="noopener noreferrer"
                         className="text-primary hover:underline break-all">
                        {tenantData.url_admin}
                      </a>
                    </div>
                    <div>
                      <span className="font-medium">Login:</span> {tenantData.login}
                    </div>
                  </div>
                </div>
              )}
            </>
          ) : leadStatus === 'erro' ? (
            "Ocorreu um erro no processamento. Entre em contato conosco pelo WhatsApp para resolvermos rapidamente."
          ) : (
            <>
              Recebemos seus dados e estamos gerando seu app. Você receberá{" "}
              <span className="font-semibold text-foreground">
                seu link público e acesso do painel
              </span>{" "}
              por WhatsApp em poucos minutos (geralmente sai em 10 min).
            </>
          )}
        </div>
      </div>

      <div className="space-y-6">
        <div className="bg-muted/50 border rounded-lg p-4">
          <div className="text-center">
            <p className="text-sm text-muted-foreground mb-2">
              ID do seu pedido para acompanhamento:
            </p>
            <code className="text-sm font-mono bg-background px-2 py-1 rounded border">
              {leadId}
            </code>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-sm">
          <div className="text-center p-3 rounded-lg bg-card/50 border">
            <div className="font-semibold mb-1">
              {leadStatus === 'novo' || leadStatus === 'em_provisionamento' || leadStatus === 'entregue' ? '✅' : '❌'} Dados recebidos
            </div>
            <div className="text-muted-foreground">Cadastro confirmado</div>
          </div>
          <div className="text-center p-3 rounded-lg bg-card/50 border">
            <div className="font-semibold mb-1">
              {leadStatus === 'entregue' ? '✅' : leadStatus === 'em_provisionamento' ? '⚙️' : leadStatus === 'erro' ? '❌' : '⏳'} Gerando app
            </div>
            <div className="text-muted-foreground">{getStatusText(leadStatus)}</div>
          </div>
          <div className="text-center p-3 rounded-lg bg-card/50 border">
            <div className="font-semibold mb-1">
              {leadStatus === 'entregue' ? '✅' : '📱'} Notificação
            </div>
            <div className="text-muted-foreground">Via WhatsApp</div>
          </div>
        </div>

        <div className="text-center">
          <p className="text-sm text-muted-foreground mb-4">
            {leadStatus === 'entregue' ? 'Tudo pronto! Ainda tem dúvidas?' : 'Alguma dúvida? Fale comigo agora:'}
          </p>
          
          <Button
            variant="hero"
            size="lg"
            onClick={handleWhatsAppContact}
            className="w-full"
          >
            <MessageCircle className="w-5 h-5" />
            Falar comigo no WhatsApp
          </Button>
        </div>

        <div className="text-center pt-4 border-t">
          <Button
            variant="soft"
            size="sm"
            onClick={onClose}
          >
            Fechar
          </Button>
        </div>
      </div>
    </>
  );
}