import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Copy, Edit, Eye, CheckCircle, AlertCircle, UserCheck, Image } from "lucide-react";
import { toast } from "@/hooks/use-toast";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import { 
  getLeadsForInbox, 
  generateWhatsAppMessage, 
  logCopiedMessage,
  getCities,
  toggleLeadStatus,
  type LeadInboxItem 
} from "@/services/onboardingManual";
import { formatPhoneForDisplay } from "@/utils/phoneValidation";

interface EditLeadSheetProps {
  lead: LeadInboxItem | null;
  isOpen: boolean;
  onOpenChange: (open: boolean) => void;
  onSave: () => void;
}

function EditLeadSheet({ lead, isOpen, onOpenChange, onSave }: EditLeadSheetProps) {
  const [selectedCity, setSelectedCity] = useState<string>("");
  const [cities, setCities] = useState<{ id: string; name: string }[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (isOpen) {
      loadCities();
    }
  }, [isOpen]);

  const loadCities = async () => {
    setLoading(true);
    try {
      const citiesData = await getCities();
      setCities(citiesData);
    } catch (error) {
      console.error('Error loading cities:', error);
    } finally {
      setLoading(false);
    }
  };

  if (!lead) return null;

  const handleSave = () => {
    // TODO: Implement city linking logic
    toast({
      title: "Funcionalidade em desenvolvimento",
      description: "Vinculação de cidade será implementada em breve.",
    });
    onSave();
    onOpenChange(false);
  };

  return (
    <Sheet open={isOpen} onOpenChange={onOpenChange}>
      <SheetContent className="w-[400px] sm:w-[540px]">
        <SheetHeader>
          <SheetTitle>Editar Cadastro</SheetTitle>
          <SheetDescription>
            Vincule a cidade oficial e ajuste os dados se necessário
          </SheetDescription>
        </SheetHeader>
        
        <div className="space-y-6 mt-6">
          {/* Lead Info */}
          <div className="space-y-4">
            <div>
              <Label className="text-sm font-medium">Estabelecimento</Label>
              <p className="text-sm text-muted-foreground">{lead.estabelecimento}</p>
            </div>
            <div>
              <Label className="text-sm font-medium">Responsável</Label>
              <p className="text-sm text-muted-foreground">{lead.responsavel}</p>
            </div>
            <div>
              <Label className="text-sm font-medium">WhatsApp</Label>
              <p className="text-sm text-muted-foreground">{formatPhoneForDisplay(lead.whatsapp)}</p>
            </div>
          </div>

          {/* City Linking */}
          <div className="space-y-4 border-t pt-4">
            <div>
              <Label className="text-sm font-medium">Cidade informada pelo cliente</Label>
              <p className="text-sm text-muted-foreground bg-muted p-2 rounded">{lead.raw_city}</p>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="city-select">Selecionar cidade oficial</Label>
              <Select value={selectedCity} onValueChange={setSelectedCity}>
                <SelectTrigger>
                  <SelectValue placeholder="Escolha uma cidade existente..." />
                </SelectTrigger>
                <SelectContent>
                  {loading ? (
                    <SelectItem value="" disabled>Carregando cidades...</SelectItem>
                  ) : cities.length === 0 ? (
                    <SelectItem value="" disabled>Nenhuma cidade encontrada</SelectItem>
                  ) : (
                    cities.map((city) => (
                      <SelectItem key={city.id} value={city.id}>
                        {city.name}
                      </SelectItem>
                    ))
                  )}
                </SelectContent>
              </Select>
              <p className="text-xs text-muted-foreground">
                Se a cidade não existir, cadastre em Admin → Cidades primeiro
              </p>
            </div>
          </div>

          {/* Actions */}
          <div className="flex justify-end gap-2 pt-4">
            <Button variant="outline" onClick={() => onOpenChange(false)}>
              Cancelar
            </Button>
            <Button onClick={handleSave}>
              Salvar Vinculação
            </Button>
          </div>
        </div>
      </SheetContent>
    </Sheet>
  );
}

export function AdminInbox() {
  const [leads, setLeads] = useState<LeadInboxItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedLead, setSelectedLead] = useState<LeadInboxItem | null>(null);
  const [editSheetOpen, setEditSheetOpen] = useState(false);
  const [photoModalOpen, setPhotoModalOpen] = useState(false);
  const [selectedPhoto, setSelectedPhoto] = useState<string | null>(null);
  const [convertingLeads, setConvertingLeads] = useState<Set<string>>(new Set());

  useEffect(() => {
    loadLeads();
  }, []);

  const loadLeads = async () => {
    setLoading(true);
    try {
      const data = await getLeadsForInbox();
      setLeads(data);
    } catch (error) {
      toast({
        title: "Erro",
        description: "Falha ao carregar cadastros.",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const handleCopyWhatsAppMessage = async (lead: LeadInboxItem) => {
    const message = generateWhatsAppMessage({
      responsavel: lead.responsavel,
      url_publica: '[URL_PUBLICA]',
      url_admin: '[URL_ADMIN]',
      login: '[LOGIN]',
      senha: '[SENHA]'
    });

    try {
      await navigator.clipboard.writeText(message);
      await logCopiedMessage(lead.id, message);
      
      toast({
        title: "Mensagem copiada!",
        description: "Cole no WhatsApp e envie manualmente."
      });
    } catch (error) {
      toast({
        title: "Erro",
        description: "Falha ao copiar mensagem. Tente novamente.",
        variant: "destructive"
      });
    }
  };

  const handleEdit = (lead: LeadInboxItem) => {
    setSelectedLead(lead);
    setEditSheetOpen(true);
  };

  const handleView = (lead: LeadInboxItem) => {
    // TODO: Implement view modal with all lead details
    toast({
      title: "Visualizar Cadastro",
      description: `Estabelecimento: ${lead.estabelecimento}\nStatus: ${lead.status}`,
    });
  };

  const handleViewPhoto = (photoUrl: string) => {
    setSelectedPhoto(photoUrl);
    setPhotoModalOpen(true);
  };

  const handleConvertToClient = async (lead: LeadInboxItem) => {
    setConvertingLeads(prev => new Set(prev).add(lead.id));
    
    try {
      const success = await toggleLeadStatus(lead.id, lead.status);
      
      if (success) {
        const newStatus = lead.status === 'entregue' ? 'pendente' : 'ativado';
        toast({
          title: newStatus === 'ativado' ? "Cliente ativado!" : "Status alterado",
          description: newStatus === 'ativado' 
            ? "Lead foi convertido para cliente ativo." 
            : "Cliente voltou para status pendente.",
        });
        loadLeads(); // Reload the list to update status
      } else {
        throw new Error('Toggle failed');
      }
    } catch (error) {
      toast({
        title: "Erro",
        description: "Falha ao alterar status. Tente novamente.",
        variant: "destructive"
      });
    } finally {
      setConvertingLeads(prev => {
        const newSet = new Set(prev);
        newSet.delete(lead.id);
        return newSet;
      });
    }
  };

  const getStatusBadge = (status: string, cityLinked: boolean) => {
    if (status === 'entregue') {
      return <Badge variant="default" className="bg-green-600"><CheckCircle className="w-3 h-3 mr-1" />Ativado</Badge>;
    }
    if (status === 'erro') {
      return <Badge variant="destructive"><AlertCircle className="w-3 h-3 mr-1" />Erro</Badge>;
    }
    if (cityLinked) {
      return <Badge variant="secondary">✅ Vinculada</Badge>;
    }
    return <Badge variant="outline">🟡 Pendente</Badge>;
  };

  const formatDate = (dateString: string) => {
    return format(new Date(dateString), "dd/MM/yyyy HH:mm", { locale: ptBR });
  };

  if (loading) {
    return (
      <div className="container mx-auto py-8">
        <div className="flex items-center justify-center h-64">
          <div className="text-center">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div>
            <p className="mt-4 text-muted-foreground">Carregando cadastros...</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto py-8 space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Novos Cadastros</h1>
          <p className="text-muted-foreground">
            Gerencie os cadastros dos últimos 30 dias e copie mensagens para WhatsApp
          </p>
        </div>
        <Button onClick={loadLeads} variant="outline">
          Atualizar
        </Button>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Lista de Cadastros ({leads.length})</CardTitle>
        </CardHeader>
        <CardContent>
          {leads.length === 0 ? (
            <div className="text-center py-8">
              <p className="text-muted-foreground">Nenhum cadastro encontrado nos últimos 30 dias.</p>
            </div>
          ) : (
            <div className="rounded-md border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Estabelecimento</TableHead>
                    <TableHead>Responsável</TableHead>
                    <TableHead>WhatsApp</TableHead>
                    <TableHead>Cidade</TableHead>
                    <TableHead>Serviços</TableHead>
                    <TableHead>Foto</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Criado em</TableHead>
                    <TableHead className="text-right">Ações</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {leads.map((lead) => (
                    <TableRow key={lead.id}>
                      <TableCell className="font-medium">
                        {lead.estabelecimento}
                      </TableCell>
                      <TableCell>{lead.responsavel}</TableCell>
                      <TableCell>{formatPhoneForDisplay(lead.whatsapp)}</TableCell>
                      <TableCell>
                        <span className="text-sm">
                          {lead.raw_city}
                          {!lead.city_linked && (
                            <span className="text-xs text-muted-foreground block">
                              (pendente vinculação)
                            </span>
                          )}
                        </span>
                      </TableCell>
                      <TableCell>
                        <div className="text-sm">
                          {lead.servicos_principais.length > 0 ? (
                            <div className="space-y-1">
                              {lead.servicos_principais.slice(0, 3).map((servico, index) => (
                                <Badge key={index} variant="outline" className="text-xs mr-1">
                                  {servico}
                                </Badge>
                              ))}
                              {lead.servicos_principais.length > 3 && (
                                <span className="text-xs text-muted-foreground">
                                  +{lead.servicos_principais.length - 3} mais
                                </span>
                              )}
                            </div>
                          ) : (
                            <span className="text-muted-foreground">Nenhum</span>
                          )}
                        </div>
                      </TableCell>
                      <TableCell>
                        {lead.foto_url ? (
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleViewPhoto(lead.foto_url!)}
                            title="Ver foto"
                          >
                            <Image className="w-4 h-4" />
                          </Button>
                        ) : (
                          <span className="text-muted-foreground text-sm">Sem foto</span>
                        )}
                      </TableCell>
                      <TableCell>
                        {getStatusBadge(lead.status, lead.city_linked)}
                      </TableCell>
                      <TableCell className="text-sm text-muted-foreground">
                        {formatDate(lead.created_at)}
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-1">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleCopyWhatsAppMessage(lead)}
                            title="Copiar mensagem WhatsApp"
                          >
                            <Copy className="w-4 h-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleEdit(lead)}
                            title="Editar/Vincular cidade"
                          >
                            <Edit className="w-4 h-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleView(lead)}
                            title="Ver detalhes"
                          >
                            <Eye className="w-4 h-4" />
                          </Button>
                          {lead.status !== 'entregue' && (
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleConvertToClient(lead)}
                              disabled={convertingLeads.has(lead.id)}
                              title="Converter em cliente"
                            >
                              <UserCheck className="w-4 h-4" />
                            </Button>
                          )}
                          {lead.status === 'entregue' && (
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleConvertToClient(lead)}
                              disabled={convertingLeads.has(lead.id)}
                              title="Voltar para pendente"
                              className="text-green-600"
                            >
                              <UserCheck className="w-4 h-4" />
                            </Button>
                          )}
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      <EditLeadSheet
        lead={selectedLead}
        isOpen={editSheetOpen}
        onOpenChange={setEditSheetOpen}
        onSave={() => loadLeads()}
      />

      {/* Photo Modal */}
      <Sheet open={photoModalOpen} onOpenChange={setPhotoModalOpen}>
        <SheetContent className="w-[400px] sm:w-[600px]">
          <SheetHeader>
            <SheetTitle>Foto do Estabelecimento</SheetTitle>
            <SheetDescription>
              Foto enviada pelo cliente durante o cadastro
            </SheetDescription>
          </SheetHeader>
          
          <div className="mt-6">
            {selectedPhoto && (
              <div className="relative">
                <img 
                  src={selectedPhoto} 
                  alt="Foto do estabelecimento" 
                  className="w-full h-auto rounded-lg border"
                  onError={(e) => {
                    console.error('Error loading image:', selectedPhoto);
                    (e.target as HTMLImageElement).src = '/placeholder.svg';
                  }}
                />
              </div>
            )}
          </div>
        </SheetContent>
      </Sheet>
    </div>
  );
}