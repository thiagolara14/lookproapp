import { Button } from "@/components/ui/button";
import { useNavigate } from "react-router-dom";

interface OnboardingCTAProps {}

export function OnboardingCTA({}: OnboardingCTAProps) {
  const navigate = useNavigate();
  
  return (
    <section className="py-12 border-t border-border">
      <div className="text-center max-w-3xl mx-auto">
        <h2 className="text-3xl md:text-4xl font-bold tracking-tight mb-4">
          Crie seu app de agendamentos agora (7 dias grátis)
        </h2>
        <p className="text-lg text-muted-foreground mb-6">
          Sem cartão. Ativação em minutos.
        </p>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8 text-sm">
          <div className="flex items-center justify-center gap-2 p-4 rounded-lg bg-card/50 border">
            <div className="w-2 h-2 rounded-full bg-primary"></div>
            <span>Receba agendamentos no mesmo dia</span>
          </div>
          <div className="flex items-center justify-center gap-2 p-4 rounded-lg bg-card/50 border">
            <div className="w-2 h-2 rounded-full bg-primary"></div>
            <span>Link público para WhatsApp e Instagram</span>
          </div>
          <div className="flex items-center justify-center gap-2 p-4 rounded-lg bg-card/50 border">
            <div className="w-2 h-2 rounded-full bg-primary"></div>
            <span>Painel simples para ajustar serviços e preços</span>
          </div>
        </div>

        <Button 
          variant="hero" 
          size="xl" 
          onClick={() => navigate('/cadastro')}
          className="text-lg px-12"
        >
          Criar meu app
        </Button>
      </div>
    </section>
  );
}