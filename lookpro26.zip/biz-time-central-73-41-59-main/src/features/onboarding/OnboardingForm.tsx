import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { X, Upload, Image as ImageIcon } from "lucide-react";
import { toast } from "@/hooks/use-toast";
import { resizeAndCompress, isValidImageType, isFileSizeValid, createImagePreview } from "@/utils/image/resizeAndCompress";
import { formatWhatsApp, validateWhatsApp, cleanWhatsApp } from "@/utils/whatsapp";
import { validatePhoneE164, normalizePhoneToE164, validatePhoneWithRegex } from "@/utils/phoneValidation";
import { submitLead, type OnboardingFormData } from "@/services/onboardingClient";
import { PhoneInput } from "@/components/PhoneInput";
import { FeatureFlags } from "@/lib/featureFlags";
import { reportSubmissionError, reportValidationError, getUserFriendlyMessage } from "@/lib/onboardingErrorReporter";

interface OnboardingFormProps {
  cities: { id: string; name: string }[];
  businessTypes: { id: string; name: string }[];
  onSuccess: (leadId: string) => void;
  onCancel: () => void;
}

const COMMON_SERVICES = [
  "Corte", "Barba", "Sobrancelha", "Manicure", "Pedicure", "Escova", 
  "Hidratação", "Coloração", "Luzes", "Massagem", "Limpeza de Pele",
  "Design de Sobrancelhas", "Penteado", "Maquiagem", "Depilação"
];

export function OnboardingForm({ cities, businessTypes, onSuccess, onCancel }: OnboardingFormProps) {
  const navigate = useNavigate();
  const [formData, setFormData] = useState<Partial<OnboardingFormData>>({
    servicos_principais: []
  });
  const [selectedServices, setSelectedServices] = useState<string[]>([]);
  const [customService, setCustomService] = useState("");
  const [photo, setPhoto] = useState<File | null>(null);
  const [photoPreview, setPhotoPreview] = useState<string | null>(null);
  const [termsAccepted, setTermsAccepted] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleWhatsAppChange = (value: string) => {
    if (FeatureFlags.ONBOARDING_SELF_SERVE) {
      // New flow: store E.164 format directly
      setFormData(prev => ({ ...prev, whatsapp: value }));
    } else {
      // Original flow: use existing formatting
      const formatted = formatWhatsApp(value);
      setFormData(prev => ({ ...prev, whatsapp: formatted }));
    }
  };

  const addService = (service: string) => {
    if (selectedServices.length < 3 && !selectedServices.includes(service)) {
      const updated = [...selectedServices, service];
      setSelectedServices(updated);
      setFormData(prev => ({ ...prev, servicos_principais: updated }));
    }
  };

  const removeService = (service: string) => {
    const updated = selectedServices.filter(s => s !== service);
    setSelectedServices(updated);
    setFormData(prev => ({ ...prev, servicos_principais: updated }));
  };

  const addCustomService = () => {
    if (customService.trim() && selectedServices.length < 3) {
      addService(customService.trim());
      setCustomService("");
    }
  };

  const handlePhotoChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      if (!isValidImageType(file)) {
        toast({
          title: "Formato não suportado",
          description: "Use apenas arquivos JPG ou PNG.",
          variant: "destructive"
        });
        return;
      }

      if (!isFileSizeValid(file)) {
        toast({
          title: "Arquivo muito grande",
          description: "O arquivo deve ter no máximo 5MB.",
          variant: "destructive"
        });
        return;
      }

      const preview = await createImagePreview(file);
      setPhotoPreview(preview);
      setPhoto(file);
      
      toast({
        title: "Foto adicionada",
        description: "Sua foto foi carregada com sucesso!"
      });
    } catch (error) {
      console.error('Error processing photo:', error);
      toast({
        title: "Erro ao carregar foto",
        description: "Tente novamente com outra imagem.",
        variant: "destructive"
      });
    }
  };

  const removePhoto = () => {
    setPhoto(null);
    setPhotoPreview(null);
  };

  const validateForm = (): boolean => {
    const required = ['estabelecimento', 'responsavel', 'whatsapp', 'cidade', 'tipo'];
    for (const field of required) {
      if (!formData[field as keyof OnboardingFormData]) {
        toast({
          title: "Campos obrigatórios",
          description: "Preencha todos os campos obrigatórios.",
          variant: "destructive"
        });
        return false;
      }
    }

    if (selectedServices.length === 0) {
      toast({
        title: "Serviços obrigatórios",
        description: "Adicione pelo menos 1 serviço principal.",
        variant: "destructive"
      });
      return false;
    }

    if (!termsAccepted) {
      toast({
        title: "Termos obrigatórios",
        description: "Aceite os termos para continuar.",
        variant: "destructive"
      });
      return false;
    }

    // Validate WhatsApp format with enhanced validation
    if (FeatureFlags.ONBOARDING_SELF_SERVE) {
      // New flow: validate E.164 format with normalization (relaxed)
      const normalizedPhone = normalizePhoneToE164(formData.whatsapp!);
      
      if (!validatePhoneE164(normalizedPhone) && !validatePhoneWithRegex(normalizedPhone)) {
        reportValidationError('Phone validation failed', {
          original: formData.whatsapp,
          normalized: normalizedPhone
        });
        
        toast({
          title: "WhatsApp inválido",
          description: "Informe DDD + telefone (apenas números). Ex.: DDD 11, Telefone 988888888.",
          variant: "destructive"
        });
        return false;
      }
    } else {
      // Original flow: use existing validation
      if (!formData.whatsapp || !validateWhatsApp(formData.whatsapp)) {
        toast({
          title: "WhatsApp inválido",
          description: "Digite um número de WhatsApp válido com DDD.",
          variant: "destructive"
        });
        return false;
      }
    }

    return true;
  };

  const handleSubmit = async () => {
    if (!validateForm()) {
      const correlationId = reportValidationError('Form validation failed', formData);
      return;
    }

    setIsSubmitting(true);
    let correlationId: string | undefined;
    
    try {
      let processedPhoto: string | undefined;
      
      if (photo) {
        const processed = await resizeAndCompress(photo);
        processedPhoto = processed.dataUrl;
      }

      // Create normalized payload for submission
      const submitData: OnboardingFormData = {
        estabelecimento: formData.estabelecimento!,
        responsavel: formData.responsavel!,
        whatsapp: FeatureFlags.ONBOARDING_SELF_SERVE 
          ? normalizePhoneToE164(formData.whatsapp!) // Ensure proper normalization
          : formData.whatsapp!,
        cidade: formData.cidade!,
        tipo: formData.tipo!,
        servicos_principais: selectedServices,
        foto_base64: processedPhoto,
        aceito_termos: termsAccepted
      };

      // Additional validation with backup regex
      if (FeatureFlags.ONBOARDING_SELF_SERVE) {
        const normalizedPhone = normalizePhoneToE164(formData.whatsapp!);
        
        if (!validatePhoneE164(normalizedPhone) && !validatePhoneWithRegex(normalizedPhone)) {
          correlationId = reportValidationError('Phone validation failed with both validators', {
            original: formData.whatsapp,
            normalized: normalizedPhone
          });
          
          toast({
            title: "WhatsApp inválido",
            description: "Informe DDD + telefone (apenas números). Ex.: DDD 11, Telefone 988888888.",
            variant: "destructive"
          });
          return;
        }
      }

      // Use edge function flow (service role, avoids RLS)
      const result = await submitLead(submitData);
      
      if (result.success) {
        console.log('Cadastro realizado com sucesso:', result.lead_id);
        onSuccess(result.lead_id);
      } else {
        correlationId = reportSubmissionError(
          result.message || 'Submission failed',
          submitData,
          undefined,
          result.message
        );
        
        throw new Error(result.message || 'Erro ao processar solicitação');
      }
    } catch (error: any) {
      console.error('Error submitting form:', error);
      
      // Report error if not already reported
      if (!correlationId) {
        correlationId = reportSubmissionError(error, formData);
      }
      
      // Show user-friendly message
      const phase = correlationId?.includes('validation') ? 'validation' : 'submission';
      const userMessage = getUserFriendlyMessage(phase as any);
      
      toast({
        title: "Erro no envio",
        description: userMessage,
        variant: "destructive"
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="overflow-x-hidden">
      <div className="text-center mb-6 md:mb-8">
        <h1 className="text-2xl md:text-3xl font-bold tracking-tight mb-4">
          Criar meu app de agendamentos
        </h1>
        <p className="text-base md:text-lg text-muted-foreground">
          Preencha os dados abaixo para criarmos seu app personalizado
        </p>
      </div>

      <div className="space-y-4 md:space-y-6">
        {/* Basic Info */}
        <div className="grid grid-cols-1 gap-4">
          <div className="space-y-2">
            <Label htmlFor="estabelecimento">Nome do estabelecimento *</Label>
            <Input
              id="estabelecimento"
              placeholder="Ex: Barbearia do João"
              value={formData.estabelecimento || ""}
              onChange={(e) => setFormData(prev => ({ ...prev, estabelecimento: e.target.value }))}
              className="w-full"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="responsavel">Seu nome (responsável) *</Label>
            <Input
              id="responsavel"
              placeholder="Ex: João Silva"
              value={formData.responsavel || ""}
              onChange={(e) => setFormData(prev => ({ ...prev, responsavel: e.target.value }))}
              className="w-full"
            />
          </div>
        </div>

        <div className="grid grid-cols-1 gap-4">
          {FeatureFlags.ONBOARDING_SELF_SERVE ? (
            <PhoneInput
              value={formData.whatsapp || ""}
              onChange={handleWhatsAppChange}
              className="w-full"
            />
          ) : (
            <div className="space-y-2">
              <Label htmlFor="whatsapp">WhatsApp (com DDD) *</Label>
              <Input
                id="whatsapp"
                placeholder="+55 (11) 91234-5678"
                value={formData.whatsapp || ""}
                onChange={(e) => handleWhatsAppChange(e.target.value)}
                className="w-full"
              />
            </div>
          )}
          <div className="space-y-2">
            <Label htmlFor="cidade">Cidade *</Label>
            <Input
              id="cidade"
              placeholder="Digite sua cidade"
              value={formData.cidade || ""}
              onChange={(e) => setFormData(prev => ({ ...prev, cidade: e.target.value }))}
              className="w-full"
            />
          </div>
        </div>

        <div className="space-y-2">
          <Label htmlFor="tipo">Tipo de negócio *</Label>
          <Select value={formData.tipo || ""} onValueChange={(value) => setFormData(prev => ({ ...prev, tipo: value }))}>
            <SelectTrigger>
              <SelectValue placeholder="Selecione o tipo do seu negócio" />
            </SelectTrigger>
            <SelectContent side="bottom" align="start" className="max-h-60 overflow-y-auto z-50 select-content-positioned">
              {businessTypes.map((type) => (
                <SelectItem key={type.id} value={type.name}>{type.name}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {/* Services */}
        <div className="space-y-2">
          <Label>3 serviços principais * ({selectedServices.length}/3)</Label>
          <div className="flex flex-wrap gap-2 mb-3">
            {selectedServices.map((service) => (
              <Badge key={service} variant="default" className="flex items-center gap-1">
                {service}
                <button
                  type="button"
                  onClick={() => removeService(service)}
                  className="ml-1 hover:text-destructive"
                >
                  <X className="h-3 w-3" />
                </button>
              </Badge>
            ))}
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-2">
            {COMMON_SERVICES.filter(service => !selectedServices.includes(service)).map((service) => (
              <Button
                key={service}
                type="button"
                variant="outline"
                size="sm"
                onClick={() => addService(service)}
                disabled={selectedServices.length >= 3}
                className="text-xs"
              >
                {service}
              </Button>
            ))}
          </div>
          
          {selectedServices.length < 3 && (
            <div className="flex gap-2">
              <Input
                placeholder="Ou digite um serviço personalizado"
                value={customService}
                onChange={(e) => setCustomService(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && addCustomService()}
              />
              <Button type="button" onClick={addCustomService} disabled={!customService.trim()}>
                Adicionar
              </Button>
            </div>
          )}
        </div>

        {/* Photo Upload */}
        <div className="space-y-2">
          <Label>Foto do estabelecimento (opcional)</Label>
          <p className="text-xs text-muted-foreground">
            Frente da loja ou uma foto interna legal. JPG/PNG, até 5 MB. 
            Se não tiver agora, pode enviar depois pelo WhatsApp — ativamos mesmo assim.
          </p>
          
          {photoPreview ? (
            <div className="relative">
              <img 
                src={photoPreview} 
                alt="Preview" 
                className="w-full h-40 object-cover rounded-lg border"
              />
              <Button
                type="button"
                variant="destructive"
                size="sm"
                onClick={removePhoto}
                className="absolute top-2 right-2"
              >
                <X className="h-4 w-4" />
              </Button>
            </div>
          ) : (
            <label className="flex flex-col items-center justify-center w-full h-40 border-2 border-dashed border-border rounded-lg cursor-pointer hover:bg-muted/50 transition-colors">
              <div className="flex flex-col items-center justify-center pt-5 pb-6">
                <Upload className="w-8 h-8 mb-4 text-muted-foreground" />
                <p className="mb-2 text-sm text-muted-foreground">
                  <span className="font-semibold">Clique para enviar</span> ou arraste a foto
                </p>
                <p className="text-xs text-muted-foreground">JPG ou PNG (máx. 5MB)</p>
              </div>
              <input
                type="file"
                className="hidden"
                accept="image/jpeg,image/jpg,image/png"
                onChange={handlePhotoChange}
                capture="environment"
              />
            </label>
          )}
        </div>

        {/* Terms */}
        <div className="flex items-center space-x-2">
          <Checkbox 
            id="terms" 
            checked={termsAccepted}
            onCheckedChange={(checked) => setTermsAccepted(checked === true)}
          />
          <Label htmlFor="terms" className="text-sm">
            Aceito os termos de uso e política de privacidade *
          </Label>
        </div>

        {/* Actions */}
        <div className="flex flex-col sm:flex-row gap-3 pt-4">
          <Button type="button" variant="soft" onClick={onCancel} className="w-full sm:flex-1 order-2 sm:order-1">
            Cancelar
          </Button>
          <Button 
            type="button" 
            variant="hero" 
            onClick={handleSubmit}
            disabled={isSubmitting}
            className="w-full sm:flex-1 order-1 sm:order-2"
          >
            {isSubmitting ? "Criando..." : "Criar meu app grátis"}
          </Button>
        </div>
      </div>
    </div>
  );
}