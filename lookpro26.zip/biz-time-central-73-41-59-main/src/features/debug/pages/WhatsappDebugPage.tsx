import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { Loader2, Send, MessageCircle, Database } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { sendTestMessage, validateE164, formatE164 } from "@/services/whatsappTestClient";
import { useToast } from "@/hooks/use-toast";

interface MessageLog {
  id: string;
  body: any;
  created_at: string;
}

export default function WhatsappDebugPage() {
  const [phone, setPhone] = useState("");
  const [message, setMessage] = useState("Hello World from LookPro!");
  const [isLoading, setIsLoading] = useState(false);
  const [logs, setLogs] = useState<MessageLog[]>([]);
  const [loadingLogs, setLoadingLogs] = useState(true);
  const { toast } = useToast();

  const loadMessageLogs = async () => {
    try {
      setLoadingLogs(true);
      
      // Use the RPC function we created
      const { data, error } = await supabase.rpc('get_whatsapp_message_logs', {
        limit_count: 10
      });

      if (error) {
        console.error("Error loading message logs:", error);
        toast({
          title: "Erro ao carregar logs",
          description: "Não foi possível carregar os logs de mensagens",
          variant: "destructive",
        });
        return;
      }

      // Cast the data to our MessageLog type
      setLogs((data as MessageLog[]) || []);
    } catch (error) {
      console.error("Error loading message logs:", error);
    } finally {
      setLoadingLogs(false);
    }
  };

  useEffect(() => {
    loadMessageLogs();
  }, []);

  const handleSendMessage = async () => {
    if (!phone.trim()) {
      toast({
        title: "Número obrigatório",
        description: "Por favor, informe o número de destino",
        variant: "destructive",
      });
      return;
    }

    if (!validateE164(phone)) {
      toast({
        title: "Formato inválido",
        description: "Número deve ter entre 10-15 dígitos (ex: 5511999999999)",
        variant: "destructive",
      });
      return;
    }

    setIsLoading(true);
    try {
      const result = await sendTestMessage({
        to: formatE164(phone),
        text: message,
      });

      if (result.success) {
        toast({
          title: "Mensagem enviada!",
          description: `Message ID: ${result.messageId}`,
        });
        
        // Recarregar logs após envio
        setTimeout(() => {
          loadMessageLogs();
        }, 2000);
      } else {
        toast({
          title: "Erro ao enviar",
          description: result.error || "Erro desconhecido",
          variant: "destructive",
        });
      }
    } catch (error) {
      toast({
        title: "Erro interno",
        description: "Falha na comunicação com a API",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const extractMessageInfo = (body: any) => {
    try {
      if (body?.entry?.[0]?.changes?.[0]?.value?.messages?.[0]) {
        const msg = body.entry[0].changes[0].value.messages[0];
        return {
          from: msg.from || "N/A",
          to: body.entry[0].changes[0].value.metadata?.phone_number_id || "N/A",
          type: msg.type || "unknown",
          text: msg.text?.body || msg.image?.caption || msg.document?.filename || "N/A",
        };
      }
      return null;
    } catch {
      return null;
    }
  };

  return (
    <div className="container mx-auto py-8 space-y-6">
      <div className="flex items-center gap-3">
        <MessageCircle className="h-8 w-8 text-primary" />
        <div>
          <h1 className="text-3xl font-bold">WhatsApp Debug</h1>
          <p className="text-muted-foreground">
            Teste de envio e monitoramento de mensagens WhatsApp Cloud API
          </p>
        </div>
      </div>

      {/* Card de Envio de Teste */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Send className="h-5 w-5" />
            Enviar Mensagem de Teste
          </CardTitle>
          <CardDescription>
            Envie uma mensagem de teste via WhatsApp Cloud API
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="phone">Número de Destino (E.164)</Label>
            <Input
              id="phone"
              placeholder="Ex: 5511999999999"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
            />
            <p className="text-sm text-muted-foreground">
              Formato: código do país + DDD + número (sem espaços ou símbolos)
            </p>
          </div>

          <div className="space-y-2">
            <Label htmlFor="message">Mensagem</Label>
            <Textarea
              id="message"
              placeholder="Digite sua mensagem..."
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              rows={3}
            />
          </div>

          <Button 
            onClick={handleSendMessage} 
            disabled={isLoading}
            className="w-full"
          >
            {isLoading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Enviando...
              </>
            ) : (
              <>
                <Send className="mr-2 h-4 w-4" />
                Enviar Hello World
              </>
            )}
          </Button>
        </CardContent>
      </Card>

      {/* Card de Logs */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2">
              <Database className="h-5 w-5" />
              Últimas Mensagens Recebidas
            </CardTitle>
            <CardDescription>
              Últimos 10 registros da tabela onboarding.messages_log
            </CardDescription>
          </div>
          <Button variant="outline" onClick={loadMessageLogs} disabled={loadingLogs}>
            {loadingLogs ? (
              <Loader2 className="h-4 w-4 animate-spin" />
            ) : (
              "Atualizar"
            )}
          </Button>
        </CardHeader>
        <CardContent>
          {loadingLogs ? (
            <div className="flex items-center justify-center py-8">
              <Loader2 className="h-6 w-6 animate-spin" />
              <span className="ml-2">Carregando logs...</span>
            </div>
          ) : logs.length === 0 ? (
            <Alert>
              <AlertDescription>
                Nenhuma mensagem encontrada. Envie uma mensagem de teste ou aguarde webhooks do WhatsApp.
              </AlertDescription>
            </Alert>
          ) : (
            <div className="space-y-4">
              {logs.map((log) => {
                const msgInfo = extractMessageInfo(log.body);
                return (
                  <div key={log.id} className="border rounded-lg p-4 space-y-2">
                    <div className="flex items-center justify-between">
                      <Badge variant="secondary">
                        {new Date(log.created_at).toLocaleString("pt-BR")}
                      </Badge>
                      {msgInfo && (
                        <Badge variant="outline">{msgInfo.type}</Badge>
                      )}
                    </div>
                    
                    {msgInfo ? (
                      <div className="grid grid-cols-2 gap-4 text-sm">
                        <div>
                          <strong>De:</strong> {msgInfo.from}
                        </div>
                        <div>
                          <strong>Para:</strong> {msgInfo.to}
                        </div>
                        <div className="col-span-2">
                          <strong>Conteúdo:</strong> {msgInfo.text}
                        </div>
                      </div>
                    ) : (
                      <details className="text-sm">
                        <summary className="cursor-pointer text-muted-foreground">
                          Ver payload bruto
                        </summary>
                        <pre className="mt-2 bg-muted p-2 rounded text-xs overflow-x-auto">
                          {JSON.stringify(log.body, null, 2)}
                        </pre>
                      </details>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Instruções */}
      <Card>
        <CardHeader>
          <CardTitle>Instruções de Configuração</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <Alert>
            <AlertDescription>
              <strong>Secrets necessários no Supabase:</strong>
              <ul className="list-disc list-inside mt-2 space-y-1">
                <li>WHATS_CLOUD_VERIFY_TOKEN=lookpro_webhook_2025</li>
                <li>WHATS_CLOUD_WABA_ID=4948938748664002</li>
                <li>WHATS_CLOUD_PHONE_NUMBER_ID=746528548550644</li>
                <li>WHATS_CLOUD_ACCESS_TOKEN={"<SEU_TOKEN_DA_META>"}</li>
              </ul>
            </AlertDescription>
          </Alert>
          
          <Alert>
            <AlertDescription>
              <strong>Webhook URL (já configurado):</strong><br />
              https://fdxmegjbmglkbpylfeso.supabase.co/functions/v1/whats-webhook
            </AlertDescription>
          </Alert>
        </CardContent>
      </Card>
    </div>
  );
}