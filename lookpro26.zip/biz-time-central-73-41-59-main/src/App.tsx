
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route, useLocation } from "react-router-dom";
import Index from "./pages/Index";
import NotFound from "./pages/NotFound";
import AdminDashboard from "./pages/dashboard/AdminDashboard";
import ProDashboard from "./pages/dashboard/ProDashboard";
import SuperDashboard from "./pages/dashboard/SuperDashboard";
import Establishment from "./pages/Establishment";
import Professional from "./pages/Professional";
import Vitrine from "./pages/Vitrine";
import ComoFunciona from "./pages/ComoFunciona";
import Planos from "./pages/Planos";
import Privacidade from "./pages/Privacidade";
import SuperLogin from "./pages/super/Login";
import SuperEstablishments from "./pages/super/Establishments";
import SuperUsers from "./pages/super/Users";
import SuperCategories from "./pages/super/Categories";
import SuperCities from "./pages/super/Cities";
import SuperPlans from "./pages/super/Plans";
import SuperReviews from "./pages/super/Reviews";
import SuperReports from "./pages/super/Reports";
import SuperTools from "./pages/super/Tools";
import SuperCMS from "./pages/super/CMS";
import SuperCMSEditor from "./pages/super/CMSEditor";
import { GlobalSettings as SuperGlobalSettings } from "./pages/super";
import AdminLayout from "./components/admin/AdminLayout";
import WhatsappDebugPage from "./features/debug/pages/WhatsappDebugPage";
const queryClient = new QueryClient();
import AdminAppointments from "./pages/dashboard/admin/Appointments";
import AdminServices from "./pages/dashboard/admin/Services";
import AdminServiceForm from "./pages/dashboard/admin/ServiceForm";
import AdminProfessionals from "./pages/dashboard/admin/Professionals";
import AdminProfessionalForm from "./pages/dashboard/admin/ProfessionalForm";
import AdminClients from "./pages/dashboard/admin/Clients";
import AdminReviews from "./pages/dashboard/admin/Reviews";
import AdminReports from "./pages/dashboard/admin/Reports";
import AdminNotifications from "./pages/dashboard/admin/Notifications";
import AdminSchedule from "./pages/dashboard/admin/Schedule";
import AdminSettings from "./pages/dashboard/admin/Settings";
import { AdminInbox } from "./features/onboarding/pages/AdminInbox";
import { FeatureFlags } from "./lib/featureFlags";
import ProLayout from "./components/pro/ProLayout";
import ProAgenda from "./pages/dashboard/pro/Agenda";
import ProServices from "./pages/dashboard/pro/Services";
import ProReviews from "./pages/dashboard/pro/Reviews";
import ProNotifications from "./pages/dashboard/pro/Notifications";
import ProProfile from "./pages/dashboard/pro/Profile";
import ProBloqueios from "./pages/dashboard/pro/Bloqueios";
import NovoAgendamento from "./pages/dashboard/pro/NovoAgendamento";
import MyAppointments from "./pages/client/MyAppointments";
import EditAppointment from "./pages/client/EditAppointment";
import AdminLogin from "./pages/auth/AdminLogin";
import ProLogin from "./pages/auth/ProLogin";
import Login from "./pages/auth/Login";
import CadastroSucesso from "./pages/CadastroSucesso";
import Cadastro from "./pages/Cadastro";

import Logo from "@/components/Logo";
import { TenantProvider } from "@/context/TenantContext";
import { useEffect } from "react";
import { applyPWAFromCMS } from "@/services/cms";
import { PWAInstallPrompt } from "@/components/PWAInstallPrompt";

const GlobalHeader = () => {
  const { pathname } = useLocation();
  const hide = pathname === "/" || pathname.startsWith("/vitrine") || pathname.startsWith("/e/") || pathname.startsWith("/dashboard") || pathname === "/super/login" || pathname === "/login" || pathname.startsWith("/login") || pathname === "/cadastro";
  if (hide) return null;
  return (
    <header className="border-b bg-background">
      <div className="container py-3">
        <Logo />
      </div>
    </header>
  );
};

const App = () => {
  useEffect(() => {
    // Apply PWA manifest/theme from CMS config
    applyPWAFromCMS();
  }, []);

  return (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <BrowserRouter>
        <TenantProvider>
        <PWAInstallPrompt />
        <Toaster />
        <Sonner />
        <GlobalHeader />
        <Routes>
          <Route path="/" element={<Index />} />
          <Route path="/vitrine" element={<Vitrine />} />
          <Route path="/como-funciona" element={<ComoFunciona />} />
          <Route path="/planos" element={<Planos />} />
          <Route path="/privacidade" element={<Privacidade />} />
        <Route path="/cadastro/sucesso" element={<CadastroSucesso />} />
        <Route path="/cadastro" element={<Cadastro />} />
           <Route path="/cliente/estabelecimento/:id" element={<Establishment />} />
           <Route path="/profissional/:idOrSlug" element={<Professional />} />
           <Route path="/e/:id" element={<Establishment />} />
          <Route path="/cliente/agendamentos" element={<MyAppointments />} />
          <Route path="/cliente/agendamentos/:id/editar" element={<EditAppointment />} />
          <Route path="/dashboard/admin" element={<AdminLayout><AdminDashboard /></AdminLayout>} />
          <Route path="/dashboard/admin/agendamentos" element={<AdminLayout><AdminAppointments /></AdminLayout>} />
          <Route path="/dashboard/admin/servicos" element={<AdminLayout><AdminServices /></AdminLayout>} />
          <Route path="/dashboard/admin/servicos/novo" element={<AdminLayout><AdminServiceForm /></AdminLayout>} />
          <Route path="/dashboard/admin/servicos/:id/editar" element={<AdminLayout><AdminServiceForm /></AdminLayout>} />
          <Route path="/dashboard/admin/profissionais" element={<AdminLayout><AdminProfessionals /></AdminLayout>} />
          <Route path="/dashboard/admin/profissionais/novo" element={<AdminLayout><AdminProfessionalForm /></AdminLayout>} />
          <Route path="/dashboard/admin/profissionais/:id/editar" element={<AdminLayout><AdminProfessionalForm /></AdminLayout>} />
          <Route path="/dashboard/admin/clientes" element={<AdminLayout><AdminClients /></AdminLayout>} />
          <Route path="/dashboard/admin/notificacoes" element={<AdminLayout><AdminNotifications /></AdminLayout>} />
          <Route path="/dashboard/admin/avaliacoes" element={<AdminLayout><AdminReviews /></AdminLayout>} />
          <Route path="/dashboard/admin/relatorios" element={<AdminLayout><AdminReports /></AdminLayout>} />
          <Route path="/dashboard/admin/horarios" element={<AdminLayout><AdminSchedule /></AdminLayout>} />
          <Route path="/dashboard/admin/configuracoes" element={<AdminLayout><AdminSettings /></AdminLayout>} />
          {/* Onboarding Inbox - Feature Flag Protected */}
          {FeatureFlags.ONBOARDING_SELF_SERVE && (
            <Route path="/dashboard/admin/onboarding/inbox" element={<AdminLayout><AdminInbox /></AdminLayout>} />
          )}
            <Route path="/dashboard/pro" element={<ProLayout><ProDashboard /></ProLayout>} />
            <Route path="/dashboard/pro/agenda" element={<ProLayout><ProAgenda /></ProLayout>} />
            <Route path="/dashboard/pro/novo-agendamento" element={<ProLayout><NovoAgendamento /></ProLayout>} />
            <Route path="/dashboard/pro/bloqueios" element={<ProLayout><ProBloqueios /></ProLayout>} />
            <Route path="/dashboard/pro/servicos" element={<ProLayout><ProServices /></ProLayout>} />
            <Route path="/dashboard/pro/avaliacoes" element={<ProLayout><ProReviews /></ProLayout>} />
            <Route path="/dashboard/pro/notificacoes" element={<ProLayout><ProNotifications /></ProLayout>} />
            <Route path="/dashboard/pro/perfil" element={<ProLayout><ProProfile /></ProLayout>} />
           <Route path="/login" element={<Login />} />
           <Route path="/login/admin" element={<AdminLogin />} />
           <Route path="/login/pro" element={<ProLogin />} />
           <Route path="/dashboard/super" element={<SuperDashboard />} />
           <Route path="/dashboard/super/cadastros" element={<AdminInbox />} />
           <Route path="/dashboard/super/estabelecimentos" element={<SuperEstablishments />} />
          <Route path="/dashboard/super/usuarios" element={<SuperUsers />} />
          <Route path="/dashboard/super/categorias" element={<SuperCategories />} />
          <Route path="/dashboard/super/cidades" element={<SuperCities />} />
          <Route path="/dashboard/super/planos" element={<SuperPlans />} />
          <Route path="/dashboard/super/avaliacoes" element={<SuperReviews />} />
           <Route path="/dashboard/super/relatorios" element={<SuperReports />} />
           <Route path="/dashboard/super/ferramentas" element={<SuperTools />} />
           <Route path="/dashboard/super/configuracoes" element={<SuperGlobalSettings />} />
           <Route path="/dashboard/super/conteudo-tema" element={<SuperCMS />} />
           <Route path="/dashboard/super/cms-editor" element={<SuperCMSEditor />} />
          <Route path="/super/login" element={<SuperLogin />} />
          {/* Debug routes with feature flag */}
          {import.meta.env.VITE_FEATURE_ONBOARDING_SELF_SERVE === 'true' && (
            <Route path="/debug/whatsapp" element={<WhatsappDebugPage />} />
          )}
          {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
          <Route path="*" element={<NotFound />} />
          </Routes>
        </TenantProvider>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
  );
};

export default App;
