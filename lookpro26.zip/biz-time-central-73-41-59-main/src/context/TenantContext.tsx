import React, { createContext, useContext, useMemo } from "react";
import { useLocation, useParams } from "react-router-dom";

export type TenantContextValue = {
  tenantId: string;
};

const TenantContext = createContext<TenantContextValue>({ tenantId: "default" });

export const TenantProvider: React.FC<React.PropsWithChildren> = ({ children }) => {
  const location = useLocation();
  // Try to infer tenant from common routes: /e/:id or /cliente/estabelecimento/:id
  const params = useParams();
  const tenantFromPath = useMemo(() => {
    // Match /e/:id
    const m1 = location.pathname.match(/^\/e\/([^/]+)/);
    if (m1?.[1]) return m1[1];
    // Match /cliente/estabelecimento/:id
    const m2 = location.pathname.match(/^\/cliente\/estabelecimento\/([^/]+)/);
    if (m2?.[1]) return m2[1];
    return "default"; // fallback to default
  }, [location.pathname]);

  const value = useMemo(() => ({ tenantId: tenantFromPath }), [tenantFromPath]);
  return <TenantContext.Provider value={value}>{children}</TenantContext.Provider>;
};

export const useTenantContext = () => useContext(TenantContext);
