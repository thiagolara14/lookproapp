import { createContext, useContext, ReactNode, useEffect, useState } from 'react';
import { supabase } from '@/integrations/supabase/client';

export type AuthUser = {
  id: string;
  uid: string;
  email: string;
  full_name: string;
  role?: 'super_admin' | 'admin' | 'professional' | 'client';
  establishmentId?: string;
};

type AuthContextType = {
  user: AuthUser | null;
  loading: boolean;
  signOut: () => Promise<void>;
};

const AuthContext = createContext<AuthContextType>({ 
  user: null, 
  loading: true, 
  signOut: async () => {} 
});

export const useAuth = () => useContext(AuthContext);
export const useAuthContext = () => useContext(AuthContext);

export const AuthProvider = ({ children }: { children: ReactNode }) => {
  const [user, setUser] = useState<AuthUser | null>(null);
  const [loading, setLoading] = useState(true);

  async function refresh() {
    try {
      const { data } = await supabase.auth.getUser();
      const u = data.user;
      
      if (!u) { 
        setUser(null); 
        setLoading(false); 
        return; 
      }

      // Get profile from profiles table with all needed data
      const { data: profile, error } = await supabase
        .from("profiles")
        .select("role, establishment_id, full_name, email")
        .eq("user_id", u.id)
        .maybeSingle();
      
      if (error) {
        console.error('Error fetching user profile:', error);
        setUser(null);
        setLoading(false);
        return;
      }

      if (!profile) {
        console.warn('No profile found for user:', u.id);
        setUser(null);
        setLoading(false);
        return;
      }

      console.log('User profile loaded:', profile);
      
      setUser({ 
        id: u.id, 
        uid: u.id, 
        email: profile.email || u.email || "", 
        full_name: profile.full_name || "Usuário",
        role: profile.role === 'pro' ? 'professional' : profile.role || undefined, 
        establishmentId: profile.establishment_id || undefined 
      });
    } catch (error) {
      console.error('Error refreshing auth:', error);
      setUser(null);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    refresh();
    const { data: { subscription } } = supabase.auth.onAuthStateChange((event, session) => {
      console.log('Auth state changed:', event, session?.user?.id);
      refresh();
    });
    return () => subscription.unsubscribe();
  }, []);

  const signOut = async () => {
    await supabase.auth.signOut();
    setUser(null);
  };

  return (
    <AuthContext.Provider value={{ user, loading, signOut }}>
      {children}
    </AuthContext.Provider>
  );
};