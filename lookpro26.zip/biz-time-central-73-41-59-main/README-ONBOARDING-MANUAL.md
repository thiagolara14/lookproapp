# Manual WhatsApp Onboarding Flow

Esta documentação descreve o novo fluxo de onboarding manual implementado atrás da feature flag `VITE_FEATURE_ONBOARDING_SELF_SERVE`.

## 🚩 Feature Flag

Para ativar o fluxo manual, defina a variável de ambiente:

```bash
VITE_FEATURE_ONBOARDING_SELF_SERVE=true
```

**Importante**: Sem essa flag, o sistema mantém o comportamento original com WhatsApp API automático.

## 🎯 Funcionalidades Implementadas

### ✅ Formulário "Criar App" Aprimorado

- **Telefone E.164**: Campo dividido em DDD + Número com validação brasileira
- **Cidade Livre**: Input de texto livre (não vincula automaticamente)
- **Sem WhatsApp API**: Não envia mensagens automaticamente
- **Compatibilidade**: Mantém fluxo original quando flag está desabilitada

### ✅ Admin Inbox (`/dashboard/admin/onboarding/inbox`)

- **Lista de Cadastros**: Últimos 30 dias com status e detalhes
- **Copy WhatsApp**: Botão para copiar mensagem padronizada
- **Edição**: Drawer para vincular cidade oficial
- **Status Visual**: Badges indicando cidade vinculada ou pendente

### ✅ Banco de Dados Seguro

- **Schema `onboarding`**: Tabelas isoladas com RLS
- **Metadata**: Rastreamento de cidade original e telefone E.164
- **Log de Mensagens**: Histórico de mensagens copiadas
- **Não invasivo**: Zero alteração em tabelas existentes

## 🏗️ Arquitetura

### Componentes Criados

```
src/
├── components/
│   └── PhoneInput.tsx              # Campo telefone DDD + número
├── features/onboarding/
│   ├── components/
│   │   └── CopyToClipboard.tsx     # Botão copiar para clipboard
│   └── pages/
│       └── AdminInbox.tsx          # Painel admin de cadastros
├── services/
│   └── onboardingManual.ts         # Service do fluxo manual
└── utils/
    └── phoneValidation.ts          # Validação E.164 brasileira
```

### Banco de Dados

```sql
-- Schema isolado para onboarding
CREATE SCHEMA onboarding;

-- Metadados de cadastro para processamento admin
CREATE TABLE onboarding.intake_meta (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  lead_id UUID,                    -- Referência para public.leads.id
  raw_city TEXT,                   -- Cidade digitada pelo cliente
  phone_e164 TEXT,                 -- Telefone normalizado (+55DDNUMBER)
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Log de mensagens WhatsApp copiadas
CREATE TABLE onboarding.messages_log (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  lead_id UUID NOT NULL,
  message_text TEXT NOT NULL,
  copied_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  sent_manually BOOLEAN DEFAULT FALSE,
  body JSONB DEFAULT '{}',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
```

## 📱 Fluxo do Usuário

### Cliente (Formulário)

1. **Telefone**: Preenche DDD (2 dígitos) + Número (8-9 dígitos)
2. **Cidade**: Digita nome da cidade livremente
3. **Outros Campos**: Mantém comportamento original
4. **Submit**: Salva no banco sem enviar WhatsApp
5. **Sucesso**: Redirecionamento normal para página de sucesso

### Admin (Inbox)

1. **Acessa**: `/dashboard/admin/onboarding/inbox`
2. **Visualiza**: Lista com novos cadastros dos últimos 30 dias
3. **Copia Mensagem**: Clica em "Copiar WhatsApp" → cola no app
4. **Vincula Cidade**: Clica em "Editar" → seleciona cidade oficial
5. **Envia Manual**: Cola mensagem no WhatsApp e envia

## 📋 Template de Mensagem

```
✅ Olá, {RESPONSAVEL}!

Seu app de agendamento LookPro está pronto 🚀

🔗 Link para clientes: [URL_PUBLICA]
🛠️ Painel Admin: [URL_ADMIN]
👤 Login: [LOGIN]
🔒 Senha temporária: [SENHA]

Dica: no celular, abra o link dos clientes e adicione à tela inicial para virar um "app".

Qualquer dúvida, me chama aqui 👍
```

## 🔧 Configuração de Desenvolvimento

### Ativar Feature Flag

```bash
# .env.local
VITE_FEATURE_ONBOARDING_SELF_SERVE=true
```

### Acessar Admin Inbox

1. Fazer login como admin
2. Navegar para `/dashboard/admin/onboarding/inbox`
3. Visualizar cadastros e testar funcionalidades

### Testar Fluxo Completo

1. **Cadastro**: Preencher formulário "Criar App"
2. **Verificar**: E.164 salvo corretamente no banco
3. **Admin**: Visualizar no inbox
4. **Copiar**: Testar botão de copiar mensagem
5. **Cidade**: Testar vinculação de cidade

## 🛡️ Segurança

- **RLS Habilitado**: Todas as tabelas novas com Row Level Security
- **Service Role Only**: Acesso apenas via backend com service role
- **Sem Exposição**: Dados sensíveis não expostos no frontend
- **Validação**: Telefone E.164 validado antes de salvar
- **Isolamento**: Schema `onboarding` isolado do core

## 🔍 Troubleshooting

### Feature Flag Não Funciona

```bash
# Verificar se variável está definida
echo $VITE_FEATURE_ONBOARDING_SELF_SERVE

# Reiniciar servidor de desenvolvimento
npm run dev
```

### Telefone Não Salva Corretamente

- Verificar se formato E.164 está sendo gerado (+55DDNUMBER)
- Checar validação no `phoneValidation.ts`
- Confirmar que DDD está entre 11-99

### Admin Inbox Não Carrega

- Verificar se usuário tem role `admin` ou `super_admin`
- Confirmar que tabelas `onboarding.*` existem no banco
- Checar logs do console para erros de RLS

### Mensagem Não Copia

- Verificar se navegador suporta `navigator.clipboard`
- Confirmar que site está rodando em HTTPS (produção)
- Testar em navegador diferente

## 🚀 Próximos Passos

1. **Integração Cidades**: Carregar cidades reais no select de vinculação
2. **Templates Dinâmicos**: Buscar dados reais de tenant para URLs/login
3. **Notificações**: Sistema de notificação para novos cadastros
4. **Relatórios**: Dashboard com métricas de conversão manual
5. **Automação**: Opção de reativar WhatsApp API por cadastro

## 📞 Suporte

Para dúvidas sobre implementação ou problemas técnicos:
- Verificar logs do console do navegador
- Checar logs do Supabase (Functions e Database)
- Validar configuração da feature flag